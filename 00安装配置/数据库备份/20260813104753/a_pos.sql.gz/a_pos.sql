-- MySQL dump 10.13  Distrib 8.4.7, for Linux (x86_64)
--
-- Host: localhost    Database: a_pos
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `a_pos`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `a_pos` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `a_pos`;

--
-- Table structure for table `biz_gift_dish_range`
--

DROP TABLE IF EXISTS `biz_gift_dish_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biz_gift_dish_range` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户ID',
  `sid` bigint NOT NULL COMMENT '门店ID',
  `lid` bigint NOT NULL COMMENT '逻辑编号(雪花算法)',
  `subject_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '[enum:SubjectType] 主体类型：ROLE-角色，USER-员工',
  `subject_id` bigint NOT NULL COMMENT '主体lid（关联角色lid或员工lid）',
  `range_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'ALL' COMMENT '[enum:RangeType] 范围类型：ALL-全部可赠，PART-指定范围',
  `dish_codes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '可赠菜品code列表（JSON数组），range_type=ALL时为NULL',
  `created_by` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-否，1-是',
  `revision` int NOT NULL DEFAULT '0' COMMENT '乐观锁版本号',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  UNIQUE KEY `uk_subject` (`mid`,`sid`,`subject_type`,`subject_id`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='可赠菜品范围配置（支持角色级别和员工个人级别覆盖，员工配置优先于角色配置）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biz_gift_dish_range`
--

LOCK TABLES `biz_gift_dish_range` WRITE;
/*!40000 ALTER TABLE `biz_gift_dish_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `biz_gift_dish_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biz_ops_limit`
--

DROP TABLE IF EXISTS `biz_ops_limit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biz_ops_limit` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户ID',
  `sid` bigint NOT NULL COMMENT '门店ID',
  `lid` bigint NOT NULL COMMENT '逻辑编号(雪花算法)',
  `subject_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '[enum:SubjectType] 主体类型：ROLE-角色，USER-员工',
  `subject_id` bigint NOT NULL COMMENT '主体lid（关联角色lid或员工lid）',
  `ops_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '[enum:OpsType] 操作类型：GIFT-赠送，REFUND-退菜',
  `limit_order` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '单额度上限，单位元（0-不限制）',
  `limit_day` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '日额度上限，单位元（0-不限制）',
  `limit_week` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '周额度上限，单位元（0-不限制）',
  `limit_month` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '月额度上限，单位元（0-不限制）',
  `created_by` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-否，1-是',
  `revision` int NOT NULL DEFAULT '0' COMMENT '乐观锁版本号',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  UNIQUE KEY `uk_subject_ops` (`mid`,`sid`,`subject_type`,`subject_id`,`ops_type`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='操作额度限制配置（赠送/退菜的金额限制，支持角色级别和员工个人级别覆盖）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biz_ops_limit`
--

LOCK TABLES `biz_ops_limit` WRITE;
/*!40000 ALTER TABLE `biz_ops_limit` DISABLE KEYS */;
/*!40000 ALTER TABLE `biz_ops_limit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biz_ops_limit_stat`
--

DROP TABLE IF EXISTS `biz_ops_limit_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biz_ops_limit_stat` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户ID',
  `sid` bigint NOT NULL COMMENT '门店ID',
  `lid` bigint NOT NULL COMMENT '逻辑编号(雪花算法)',
  `user_lid` bigint NOT NULL COMMENT '员工lid（关联sys_user.lid）',
  `ops_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '[enum:OpsType] 操作类型：GIFT-赠送，REFUND-退菜',
  `stat_day` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '当前日期key，格式yyyyMMdd，如20260327',
  `day_amount` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '今日已消耗金额，单位元',
  `stat_week` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '当前周key，格式yyyyww，如202613',
  `week_amount` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本周已消耗金额，单位元',
  `stat_month` varchar(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '当前月key，格式yyyyMM，如202603',
  `month_amount` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '本月已消耗金额，单位元',
  `created_by` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_by` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-否，1-是',
  `revision` int NOT NULL DEFAULT '0' COMMENT '乐观锁版本号（用于并发控制）',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  UNIQUE KEY `uk_user_ops` (`mid`,`sid`,`user_lid`,`ops_type`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='操作额度消耗统计（每员工每操作类型一行，周期key变更时懒重置金额）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biz_ops_limit_stat`
--

LOCK TABLES `biz_ops_limit_stat` WRITE;
/*!40000 ALTER TABLE `biz_ops_limit_stat` DISABLE KEYS */;
/*!40000 ALTER TABLE `biz_ops_limit_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dwd_bill`
--

DROP TABLE IF EXISTS `dwd_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dwd_bill` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户编号',
  `sid` bigint NOT NULL COMMENT '门店编号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `shop_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '门店名称',
  `report_date` datetime DEFAULT NULL COMMENT '日期',
  `saas_order_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '账单号',
  `saas_order_no` bigint NOT NULL COMMENT '账单流水号',
  `year_` int DEFAULT NULL COMMENT '年',
  `month_` bigint DEFAULT NULL COMMENT '月',
  `day_` bigint DEFAULT NULL COMMENT '日',
  `hour_` bigint DEFAULT NULL COMMENT '时',
  `season` bigint DEFAULT NULL COMMENT '季度',
  `person_num` int DEFAULT NULL COMMENT '客流',
  `amount_per_person` decimal(10,0) DEFAULT NULL COMMENT '客单价',
  `food_amount` decimal(10,0) DEFAULT NULL COMMENT '流水金额',
  `discount_amount` decimal(10,0) DEFAULT NULL COMMENT '折扣额',
  `service_charge_amount` decimal(10,0) DEFAULT NULL COMMENT '服务费',
  `fraction` decimal(10,0) DEFAULT NULL COMMENT '零头',
  `mantissa` decimal(10,0) DEFAULT NULL COMMENT '尾数',
  `timing_amount` decimal(10,0) DEFAULT NULL COMMENT '计时金额',
  `timing_discount_amount` decimal(10,0) DEFAULT NULL COMMENT '计时折扣额',
  `timing_service_charge_amount` decimal(10,0) DEFAULT NULL COMMENT '计时服务费',
  `overcharge_amount` decimal(10,0) DEFAULT NULL COMMENT '多收金额',
  `less_amount` decimal(10,0) DEFAULT NULL COMMENT '少收金额',
  `promotion_amount` decimal(10,0) DEFAULT NULL COMMENT '优惠金额',
  `paid_amount` decimal(10,0) DEFAULT NULL COMMENT '实收金额',
  `cancel_amount` decimal(10,0) DEFAULT NULL COMMENT '退菜金额',
  `send_amount` decimal(10,0) DEFAULT NULL COMMENT '赠送金额',
  `start_time` datetime DEFAULT NULL COMMENT '开台时间',
  `checkout_time` datetime DEFAULT NULL COMMENT '结账时间',
  `checkout_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收银员',
  `checkout_time_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '餐段',
  `duration` bigint DEFAULT NULL COMMENT '消费时长(毫秒)',
  `shift_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '班次',
  `order_sub_type` int DEFAULT NULL COMMENT '账单类型;堂食、外卖、自提',
  `channel_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '渠道',
  `area_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区域名称',
  `table_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '桌台名称',
  `create_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '开台人员',
  `table_leader` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '桌台负责人',
  `waiter_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务员',
  `channel_order_key_t_p` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '三方单号',
  `device_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备编号',
  `device_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备名称',
  `discount_range` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '折扣方式',
  `discount_rate` decimal(10,0) DEFAULT NULL COMMENT '折扣率',
  `discount_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '打折人',
  `service_charge_rate` decimal(10,0) DEFAULT NULL COMMENT '服务率',
  `fraction_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '零头调整人',
  `fjz_count` int DEFAULT NULL COMMENT '反结账次数',
  `invoice_amount` decimal(10,0) DEFAULT NULL COMMENT '发票金额',
  `invoice_title` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '发票抬头',
  `is_vip_price` tinyint(1) DEFAULT NULL COMMENT '使用了会员价',
  `card_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '会员类型',
  `card_level` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '会员等级',
  `card_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '会员卡号',
  `saas_order_remark` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `order_type` int DEFAULT NULL COMMENT '账单类型;快餐、酒楼、酒吧',
  `order_status` int DEFAULT NULL COMMENT '状态',
  `num_of_jiu_xi` decimal(10,0) DEFAULT NULL COMMENT '席数',
  `single_jiu_xi_amount` decimal(10,0) DEFAULT NULL COMMENT '单席金额',
  `jiu_xi_amount` decimal(10,0) DEFAULT NULL COMMENT '酒席金额',
  `is_jiu_xi` tinyint(1) DEFAULT NULL COMMENT '酒席单',
  `remark` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标记',
  `jiu_xi_order_amount` decimal(10,0) DEFAULT NULL COMMENT '酒席订金',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `card_number` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '食品卡号',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='账单明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dwd_bill`
--

LOCK TABLES `dwd_bill` WRITE;
/*!40000 ALTER TABLE `dwd_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `dwd_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dwd_food`
--

DROP TABLE IF EXISTS `dwd_food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dwd_food` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '集团编号',
  `sid` bigint NOT NULL COMMENT '门店编号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `shop_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '门店名称',
  `report_date` datetime DEFAULT NULL COMMENT '营业日期',
  `food_no` bigint DEFAULT NULL COMMENT '菜品流水号',
  `food_code` bigint DEFAULT NULL COMMENT '菜品编码',
  `food_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品名称',
  `food_unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '规格',
  `food_super_category_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品大类',
  `food_category_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品小类',
  `start_time` datetime DEFAULT NULL COMMENT '开台时间',
  `checkout_time` datetime DEFAULT NULL COMMENT '结账时间',
  `ordering_time` datetime DEFAULT NULL COMMENT '点菜时间',
  `ordered_time` datetime DEFAULT NULL COMMENT '上菜时间',
  `cook_duration` bigint DEFAULT NULL COMMENT '制作时长（毫秒）',
  `cook` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '厨师',
  `food_pro_price` decimal(10,0) DEFAULT NULL COMMENT '售价',
  `food_org_price` decimal(10,0) DEFAULT NULL COMMENT '原价',
  `food_number` decimal(10,0) DEFAULT NULL COMMENT '流水数量',
  `send_number` decimal(10,0) DEFAULT NULL COMMENT '赠送数量',
  `unit_adjutant_number` decimal(10,0) DEFAULT NULL COMMENT '辅助数量',
  `food_amount` decimal(10,0) DEFAULT NULL COMMENT '流水金额',
  `service_charge_amount` decimal(10,0) DEFAULT NULL COMMENT '服务费',
  `discount_amount` decimal(10,0) DEFAULT NULL COMMENT '折扣额',
  `discount_range` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '打折方式',
  `processing_fee` decimal(10,0) DEFAULT NULL COMMENT '加工费',
  `processing_fee_discount` decimal(10,0) DEFAULT NULL COMMENT '加工费折扣额',
  `processing_fee_service` decimal(10,0) DEFAULT NULL COMMENT '加工费服务费',
  `promotion_amount` decimal(10,0) DEFAULT NULL COMMENT '优惠金额',
  `paid_amount` decimal(10,0) DEFAULT NULL COMMENT '实收金额',
  `food_discount_rate` decimal(10,0) DEFAULT NULL COMMENT '折扣率',
  `department_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '出品部门',
  `food_subject_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品收入科目',
  `order_sub_type` int DEFAULT NULL COMMENT '账单类型',
  `channel_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '渠道',
  `food_taste` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '口味',
  `food_practice` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '做法',
  `shift_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '班次',
  `area_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区域名称',
  `table_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '桌台名称',
  `order_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '点菜人',
  `checkout_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收银员',
  `remark` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `saas_order_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '账单号',
  `saas_order_no` bigint NOT NULL COMMENT '账单流水号',
  `food_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `checkout_time_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '餐段',
  `send_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '赠送人',
  `send_for` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '赠送原因',
  `send_time` datetime DEFAULT NULL COMMENT '赠送时间',
  `cancel_number` decimal(10,0) DEFAULT NULL COMMENT '退菜数量',
  `cancel_for` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '退菜原因',
  `cancel_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '退菜人',
  `cancel_time` datetime DEFAULT NULL COMMENT '退菜时间',
  `is_rename` tinyint(1) DEFAULT NULL COMMENT '修改过菜名',
  `rename_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜名修改人',
  `is_mod_price` tinyint(1) DEFAULT NULL COMMENT '修改过价格',
  `mod_price_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '价格修改人',
  `mode_price_time` datetime DEFAULT NULL COMMENT '改价时间',
  `discount_rate` decimal(10,0) DEFAULT NULL COMMENT '折扣率',
  `discount_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '打折人',
  `year_` int DEFAULT NULL COMMENT '年',
  `month_` bigint DEFAULT NULL COMMENT '月',
  `day_` bigint DEFAULT NULL COMMENT '日',
  `season` bigint DEFAULT NULL COMMENT '季度',
  `is_jiu_xi` tinyint(1) DEFAULT NULL COMMENT '酒席菜',
  `card_number` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '食品卡号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='菜品销售明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dwd_food`
--

LOCK TABLES `dwd_food` WRITE;
/*!40000 ALTER TABLE `dwd_food` DISABLE KEYS */;
/*!40000 ALTER TABLE `dwd_food` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dwd_pay`
--

DROP TABLE IF EXISTS `dwd_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dwd_pay` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '集团编号',
  `sid` bigint NOT NULL COMMENT '门店编号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `shop_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '门店名称',
  `report_date` datetime DEFAULT NULL COMMENT '营业日期',
  `saas_order_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '账单号',
  `saas_order_no` bigint NOT NULL COMMENT '账单流水号',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付方式编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付方式名称',
  `type_` int DEFAULT NULL COMMENT '支付类型',
  `pay_amount` decimal(10,0) DEFAULT NULL COMMENT '支付金额',
  `exchange_amount` decimal(10,0) DEFAULT NULL COMMENT '找回金额',
  `amount` decimal(10,0) DEFAULT NULL COMMENT '实收金额',
  `is_real_income` tinyint(1) DEFAULT NULL COMMENT '真实收入',
  `shift_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '班次',
  `checkout_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收银员',
  `checkout_time_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '餐段',
  `year_` int DEFAULT NULL COMMENT '年',
  `month_` bigint DEFAULT NULL COMMENT '月',
  `day_` bigint DEFAULT NULL COMMENT '日',
  `season` bigint DEFAULT NULL COMMENT '季度',
  `card_number` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '食品卡号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='支付明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dwd_pay`
--

LOCK TABLES `dwd_pay` WRITE;
/*!40000 ALTER TABLE `dwd_pay` DISABLE KEYS */;
/*!40000 ALTER TABLE `dwd_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dwd_taste`
--

DROP TABLE IF EXISTS `dwd_taste`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dwd_taste` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '集团编号',
  `sid` bigint NOT NULL COMMENT '门店编号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `shop_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '门店名称',
  `report_date` datetime DEFAULT NULL COMMENT '营业日期',
  `saas_order_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '订单编号',
  `saas_order_no` bigint NOT NULL COMMENT '订单流水号',
  `food_super_category_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品大类',
  `food_category_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品小类',
  `food_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品',
  `food_no` bigint DEFAULT NULL COMMENT '菜品流水号',
  `unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '规格',
  `adjutant_unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '辅助规格',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `number` decimal(10,0) DEFAULT NULL COMMENT '数量',
  `price` decimal(10,0) DEFAULT NULL COMMENT '价格',
  `taste_amount` decimal(10,0) DEFAULT NULL COMMENT '费用',
  `discount_amount` decimal(10,0) DEFAULT NULL COMMENT '折扣额',
  `service_charge_amount` decimal(10,0) DEFAULT NULL COMMENT '服务费',
  `amount` decimal(10,0) DEFAULT NULL COMMENT '实际收费',
  `department_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '出品部门',
  `department` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '利润部门',
  `send_number` decimal(10,0) DEFAULT NULL COMMENT '赠送数量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `card_number` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '食品卡号',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='口味做法明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dwd_taste`
--

LOCK TABLES `dwd_taste` WRITE;
/*!40000 ALTER TABLE `dwd_taste` DISABLE KEYS */;
/*!40000 ALTER TABLE `dwd_taste` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_module`
--

DROP TABLE IF EXISTS `permission_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_module` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `view_lid` bigint DEFAULT NULL COMMENT '视角编号',
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标识符',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `sort_index` int DEFAULT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `package_lid` bigint DEFAULT NULL COMMENT '权限包编号',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='权限模块';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_module`
--

LOCK TABLES `permission_module` WRITE;
/*!40000 ALTER TABLE `permission_module` DISABLE KEYS */;
INSERT INTO `permission_module` VALUES (2,1,1,8405358097782205589,9,NULL,'基础资料',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,9),(3,1,1,-1926768086296430768,9,NULL,'会员营销',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,9),(4,1,1,-9018404071270729715,9,NULL,'微餐厅',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,9),(5,1,1,-1085489625362457348,9,NULL,'微商城',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,9),(6,1,1,-3442204558732739663,9,NULL,'供应链管理',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,9),(7,1,1,-4297295847238327216,9,NULL,'预订中心',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,9),(8,1,1,5864363836845476175,9,NULL,'报表中心',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,9),(9,1,1,-7742542543467360439,9,NULL,'运营分析',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,9),(10,1,1,4636338737535968509,9,NULL,'运营监控',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,9),(11,1,1,6026111568410028420,9,NULL,'下载中心',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,9),(12,1,1,6403919243177928205,12,NULL,'POS',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,10),(13,1,1,3525335625736998814,12,NULL,'KDS',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,10),(14,1,1,-2373347878464742961,12,NULL,'预定',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,10),(19,1,1,-3442204558732739663,10,NULL,'供应链管理',NULL,NULL,NULL,'2025-10-22 15:47:33',NULL,'2025-10-22 15:47:10',0,9),(24,1,1,6026111568410028420,10,NULL,'下载中心',NULL,NULL,NULL,'2025-10-22 15:47:33',NULL,'2025-10-22 15:47:10',0,9),(25,1,1,8405358097782205589,11,NULL,'基础资料',NULL,NULL,NULL,'2025-10-22 15:48:15',NULL,'2025-10-22 15:47:10',0,9),(29,1,1,-3442204558732739663,11,NULL,'供应链管理',NULL,NULL,NULL,'2025-10-22 15:48:15',NULL,'2025-10-22 15:47:10',0,9),(30,1,1,-4297295847238327216,11,NULL,'预订中心',NULL,NULL,NULL,'2025-10-22 15:48:15',NULL,'2025-10-22 15:47:10',0,9),(31,1,1,5864363836845476175,11,NULL,'报表中心',NULL,NULL,NULL,'2025-10-22 15:48:15',NULL,'2025-10-22 15:47:10',0,9),(34,1,1,6026111568410028420,11,NULL,'下载中心',NULL,NULL,NULL,'2025-10-22 15:48:15',NULL,'2025-10-22 15:47:10',0,9),(35,1,1,1983066908960686080,9,NULL,'门店宝',NULL,NULL,NULL,'2025-10-28 15:02:49',NULL,NULL,0,9),(37,1,1,1985289977214091264,9,NULL,'订货通',NULL,NULL,NULL,'2025-11-03 18:16:30',NULL,NULL,0,9),(38,1,1,1999387804631158784,12,NULL,'门店宝',NULL,NULL,NULL,'2025-12-12 15:56:14',NULL,NULL,0,10),(39,1,1,2034939318534750208,9,NULL,'集团视角权限',-1,NULL,NULL,'2026-03-20 18:25:15',NULL,NULL,0,9);
/*!40000 ALTER TABLE `permission_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_package`
--

DROP TABLE IF EXISTS `permission_package`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_package` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标识符',
  `sort_index` int DEFAULT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='权限包';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_package`
--

LOCK TABLES `permission_package` WRITE;
/*!40000 ALTER TABLE `permission_package` DISABLE KEYS */;
INSERT INTO `permission_package` VALUES (9,1,1,5633323527498500565,'商户中心',NULL,NULL,NULL,NULL,NULL,NULL,'2025-10-22 16:38:29',0),(10,1,1,-1488014729836024053,'POS收银',NULL,NULL,NULL,NULL,NULL,NULL,'2025-11-01 15:39:58',0);
/*!40000 ALTER TABLE `permission_package` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_page`
--

DROP TABLE IF EXISTS `permission_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_page` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint DEFAULT NULL COMMENT '逻辑编号',
  `module_lid` bigint DEFAULT NULL COMMENT '视角编号',
  `code` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '标识符',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `sort_index` int DEFAULT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `view_lid` bigint DEFAULT NULL COMMENT '视角编号',
  `package_lid` bigint DEFAULT NULL COMMENT '权限包编号',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1861 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='权限页面';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_page`
--

LOCK TABLES `permission_page` WRITE;
/*!40000 ALTER TABLE `permission_page` DISABLE KEYS */;
INSERT INTO `permission_page` VALUES (520,1,1,5944346530624170637,12,'/pos/zc_p_dl','登录',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,12,10),(521,1,1,2920410178605611717,12,'/pos/zc_p_zt','桌台',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,12,10),(522,1,1,5745505059716697549,12,'/pos/zc_p_dc','点餐',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,12,10),(523,1,1,-4357981368983419694,12,'/pos/zc_p_jz','结账',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,12,10),(524,1,1,9114401938074138759,12,'/pos/zc_p_dw','店务',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,12,10),(525,1,1,2745681665328977575,12,'/pos/zc_p_hy','会员',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,12,10),(526,1,1,-2963380276881739241,12,'/pos/zc_p_bb','报表',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,12,10),(527,1,1,3611320077956815892,12,'/pos/zc_p_zd','账单',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,12,10),(528,1,1,1436125902857263156,13,'/kds/zc_k_dl','登录',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,12,10),(529,1,1,-532746305543850831,14,'/book/zc_y_dl','登录',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0,12,10),(1298,1,1,-4819309935432126976,10,'/syslog/log/sysoplog','日志管理-操作日志',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1299,1,1,8221416378986230604,10,'/syslog/log/sysloginlog','日志管理-登录日志',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,1,9,9),(1300,1,1,2299797477459612429,9,'/operationanalysis/businesstrend','经营趋势看板',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1301,1,1,-7201476022377571540,9,'/operationanalysis/turnover','营业额分析看板',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1302,1,1,-2163123280622722562,9,'/operationanalysis/department','部门绩效看板',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1303,1,1,7058309112840239763,9,'/operationanalysis/finishrate','完成率统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1304,1,1,5677047817602380811,9,'/operationanalysis/performancetargets','业绩目标设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1305,1,1,-7622834852879124708,9,'/operationanalysis/operatingcosts','经营成本设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1306,1,1,1497123596418434217,5,'/minutemall/minutemallmrg/mallcategory','微商城-类别',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1307,1,1,-3660177406225432963,5,'/minutemall/minutemallmrg/mallspu','微商城-商品',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1308,1,1,-234688300174791957,5,'/minutemall/minutemallmrg/mallevaluation','微商城-评价',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1309,1,1,-5678366226772266172,5,'/minutemall/orderform','订单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1310,1,1,7812956636622379395,5,'/minutemall/aftersale','售后申请',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1311,1,1,1877047941477847002,5,'/minutemall/feedback','意见反馈',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1312,1,1,-7460323314052395265,8,'/reportformscenter/cashierquery/billsummary','收银查询-收银明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1313,1,1,-7460323314052395265,31,'/reportformscenter/cashierquery/billsummary','收银查询-收银明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1314,1,1,2358520473235092928,8,'/reportformscenter/cashierquery/billAuditSummary','收银查询-账单稽核明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1315,1,1,2358520473235092928,31,'/reportformscenter/cashierquery/billAuditSummary','收银查询-账单稽核明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1316,1,1,6375895299235858859,8,'/reportformscenter/cashierquery/cashiersummary','收银查询-收银汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1317,1,1,6375895299235858859,31,'/reportformscenter/cashierquery/cashiersummary','收银查询-收银汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1318,1,1,-8239514093870952601,8,'/reportformscenter/cashierquery/revenuecomposition','收银查询-收入构成',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1319,1,1,-8239514093870952601,31,'/reportformscenter/cashierquery/revenuecomposition','收银查询-收入构成',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1320,1,1,-1545937034290874069,8,'/reportformscenter/cashierquery/businessdetailsnew','收银查询-营业明细_新.',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,'2026-02-09 15:01:05',0,9,9),(1321,1,1,-1545937034290874069,31,'/reportformscenter/cashierquery/businessdetailsnew','收银查询-营业明细_新',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1322,1,1,-3200276531271962534,8,'/reportformscenter/cashierquery/sumofdailybusinessdata','收银查询-日营业数据汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1323,1,1,-3200276531271962534,31,'/reportformscenter/cashierquery/sumofdailybusinessdata','收银查询-日营业数据汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1324,1,1,3469694142698791373,8,'/reportformscenter/cashierquery/reversecheckoutrecord','收银查询-反结账记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1325,1,1,3469694142698791373,31,'/reportformscenter/cashierquery/reversecheckoutrecord','收银查询-反结账记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1326,1,1,-1013820027522606183,8,'/reportformscenter/cashierquery/creditsummary','收银查询-挂账账目汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1327,1,1,-1013820027522606183,31,'/reportformscenter/cashierquery/creditsummary','收银查询-挂账账目汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1328,1,1,1604464844189035382,8,'/reportformscenter/jdy/query-bill','金蝶云报表-账单-账单查询',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1329,1,1,1604464844189035382,31,'/reportformscenter/jdy/query-bill','金蝶云报表-账单-账单查询',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1330,1,1,1381432579844964160,8,'/reportformscenter/jdy/query-bill-food','金蝶云报表-账单-账单食品查询',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1331,1,1,1381432579844964160,31,'/reportformscenter/jdy/query-bill-food','金蝶云报表-账单-账单食品查询',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1332,1,1,-5837059720497769762,8,'/reportformscenter/jdy/query-settle-detail','金蝶云报表-账单-结算明细表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1333,1,1,-5837059720497769762,31,'/reportformscenter/jdy/query-settle-detail','金蝶云报表-账单-结算明细表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1334,1,1,4342128893575049654,8,'/reportformscenter/jdy/cashier-detail','金蝶云报表-财务报表-收银明细表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1335,1,1,4342128893575049654,31,'/reportformscenter/jdy/cashier-detail','金蝶云报表-财务报表-收银明细表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1336,1,1,-1504966451522197679,8,'/reportformscenter/jdy/cashier-summary','金蝶云报表-财务报表-收银汇总表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1337,1,1,-1504966451522197679,31,'/reportformscenter/jdy/cashier-summary','金蝶云报表-财务报表-收银汇总表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1338,1,1,8243184766034826886,8,'/reportformscenter/jdy/business-summary','金蝶云报表-营业报表-营业汇总表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1339,1,1,8243184766034826886,31,'/reportformscenter/jdy/business-summary','金蝶云报表-营业报表-营业汇总表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1340,1,1,8174563242813435782,8,'/reportformscenter/jdy/business-overview','金蝶云报表-营业报表-营业概况一览',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1341,1,1,8174563242813435782,31,'/reportformscenter/jdy/business-overview','金蝶云报表-营业报表-营业概况一览',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1342,1,1,95114595209949960,8,'/reportformscenter/jdy/clear-machine-shift','金蝶云报表-营业报表-清机转更表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1343,1,1,95114595209949960,31,'/reportformscenter/jdy/clear-machine-shift','金蝶云报表-营业报表-清机转更表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1344,1,1,7130972959437187424,8,'/reportformscenter/jdy/food-sale-summary','金蝶云报表-营业报表-食品销售汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1345,1,1,7130972959437187424,31,'/reportformscenter/jdy/food-sale-summary','金蝶云报表-营业报表-食品销售汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1346,1,1,-2877664023802317459,8,'/reportformscenter/jdy/food-sale-detail','金蝶云报表-营业报表-食品销售明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1347,1,1,-2877664023802317459,31,'/reportformscenter/jdy/food-sale-detail','金蝶云报表-营业报表-食品销售明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1348,1,1,-203715342127458772,8,'/reportformscenter/jdy/food-sale-rank','金蝶云报表-营业报表-食品销售排行',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1349,1,1,-203715342127458772,31,'/reportformscenter/jdy/food-sale-rank','金蝶云报表-营业报表-食品销售排行',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1350,1,1,3688074741665945204,8,'/reportformscenter/jdy/food-cancel-and-send-summary','金蝶云报表-营业报表-食品取消/招待汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1351,1,1,3688074741665945204,31,'/reportformscenter/jdy/food-cancel-and-send-summary','金蝶云报表-营业报表-食品取消/招待汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1352,1,1,5624862991148592178,8,'/reportformscenter/jdy/food-cancel-and-send-detail','金蝶云报表-营业报表-食品取消/招待明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1353,1,1,5624862991148592178,31,'/reportformscenter/jdy/food-cancel-and-send-detail','金蝶云报表-营业报表-食品取消/招待明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1354,1,1,-941370612617695809,8,'/reportformscenter/jdy/food-category-sale-summary','金蝶云报表-食品报表-食品类别营业汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1355,1,1,-941370612617695809,31,'/reportformscenter/jdy/food-category-sale-summary','金蝶云报表-食品报表-食品类别营业汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1356,1,1,5241413893925790936,8,'/reportformscenter/jdy/food-category-sale-detail','金蝶云报表-食品报表-食品类别营业明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1357,1,1,5241413893925790936,31,'/reportformscenter/jdy/food-category-sale-detail','金蝶云报表-食品报表-食品类别营业明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1358,1,1,6273777087683019735,8,'/reportformscenter/periodmealsegment/cashierofshiftmealsection','时段餐段-班次餐段收银',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1359,1,1,6273777087683019735,31,'/reportformscenter/periodmealsegment/cashierofshiftmealsection','时段餐段-班次餐段收银',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1360,1,1,2757369890919495936,8,'/reportformscenter/periodmealsegment/analysisofperiodclosingconsumption','时段餐段-时段结账消费分析',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1361,1,1,2757369890919495936,31,'/reportformscenter/periodmealsegment/analysisofperiodclosingconsumption','时段餐段-时段结账消费分析',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1362,1,1,-2017605110782516178,8,'/reportformscenter/periodmealsegment/analysisofperiodopeningconsumption','时段餐段-时段开台消费分析',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1363,1,1,-2017605110782516178,31,'/reportformscenter/periodmealsegment/analysisofperiodopeningconsumption','时段餐段-时段开台消费分析',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1364,1,1,-4489725455579415061,8,'/reportformscenter/regionaltable/roomandplatformstatistics','区域桌台-区域桌台统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1365,1,1,-4489725455579415061,31,'/reportformscenter/regionaltable/roomandplatformstatistics','区域桌台-区域桌台统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1366,1,1,1718630546320342997,8,'/reportformscenter/regionaltable/regionalbusinessstatistics','区域桌台-区域营业统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1367,1,1,1718630546320342997,31,'/reportformscenter/regionaltable/regionalbusinessstatistics','区域桌台-区域营业统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1368,1,1,-4945276641022007984,8,'/reportformscenter/comprehensiveanalysis/dailybusinessreport','综合分析-营业情况日报',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1369,1,1,-4945276641022007984,31,'/reportformscenter/comprehensiveanalysis/dailybusinessreport','综合分析-营业情况日报',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1370,1,1,-8144349128250407088,8,'/reportformscenter/comprehensiveanalysis/monthlysummary','综合分析-月度汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1371,1,1,-8144349128250407088,31,'/reportformscenter/comprehensiveanalysis/monthlysummary','综合分析-月度汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1372,1,1,7588211644853909308,8,'/reportformscenter/comprehensiveanalysis/datesummary','综合分析-日期汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1373,1,1,7588211644853909308,31,'/reportformscenter/comprehensiveanalysis/datesummary','综合分析-日期汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1374,1,1,21773485541913287,8,'/reportformscenter/comprehensiveanalysis/refundreasonsummary','综合分析-退菜原因汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1375,1,1,21773485541913287,31,'/reportformscenter/comprehensiveanalysis/refundreasonsummary','综合分析-退菜原因汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1376,1,1,-3302225781894835958,8,'/reportformscenter/businessstatement/shifthandoversheetsummary','营业报表-交班单汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1377,1,1,-3302225781894835958,31,'/reportformscenter/businessstatement/shifthandoversheetsummary','营业报表-交班单汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1378,1,1,-6804805399109676179,8,'/reportformscenter/businessstatement/shifthandoversheetdetail','营业报表-交班明细列表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1379,1,1,-6804805399109676179,31,'/reportformscenter/businessstatement/shifthandoversheetdetail','营业报表-交班明细列表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1380,1,1,1807655813872410843,8,'/reportformscenter/businessstatement/invoicingdetails','营业报表-开票明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1381,1,1,1807655813872410843,31,'/reportformscenter/businessstatement/invoicingdetails','营业报表-开票明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1382,1,1,5036891944183201878,8,'/reportformscenter/businessstatement/paymentmethodsummary','营业报表-支付方式汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1383,1,1,5036891944183201878,31,'/reportformscenter/businessstatement/paymentmethodsummary','营业报表-支付方式汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1384,1,1,2696234647191316705,8,'/reportformscenter/shopmanagerinspection/summaryofcomplimentarydishes','店长稽查-赠送菜品汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1385,1,1,2696234647191316705,31,'/reportformscenter/shopmanagerinspection/summaryofcomplimentarydishes','店长稽查-赠送菜品汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1386,1,1,8862954050124331042,8,'/reportformscenter/shopmanagerinspection/wholeorderdiscount','店长稽查-整单打折',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1387,1,1,8862954050124331042,31,'/reportformscenter/shopmanagerinspection/wholeorderdiscount','店长稽查-整单打折',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1388,1,1,-2899353489096348214,8,'/reportformscenter/shopmanagerinspection/singleitemdiscount','店长稽查-单品打折',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1389,1,1,-2899353489096348214,31,'/reportformscenter/shopmanagerinspection/singleitemdiscount','店长稽查-单品打折',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1390,1,1,-7704842477117965385,8,'/reportformscenter/shopmanagerinspection/adjustzero','店长稽查-调整零头',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1391,1,1,-7704842477117965385,31,'/reportformscenter/shopmanagerinspection/adjustzero','店长稽查-调整零头',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1392,1,1,191563609711279634,8,'/reportformscenter/shopmanagerinspection/banquetdetails','店长稽查-酒席单明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1393,1,1,191563609711279634,31,'/reportformscenter/shopmanagerinspection/banquetdetails','店长稽查-酒席单明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1394,1,1,-2933649348431341021,8,'/reportformscenter/shopmanagerinspection/productevaluation','店长稽查-商品评价',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1395,1,1,-2933649348431341021,31,'/reportformscenter/shopmanagerinspection/productevaluation','店长稽查-商品评价',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1396,1,1,5631788549894412151,8,'/reportformscenter/shopmanagerinspection/onlinecardopeningcost','店长稽查-线上开卡工本费',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1397,1,1,5631788549894412151,31,'/reportformscenter/shopmanagerinspection/onlinecardopeningcost','店长稽查-线上开卡工本费',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1398,1,1,-8929857283436684139,8,'/reportformscenter/memberstatement/memberpointsdetails','会员报表-会员积分详情',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1399,1,1,-8929857283436684139,31,'/reportformscenter/memberstatement/memberpointsdetails','会员报表-会员积分详情',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1400,1,1,9219776686475892847,8,'/reportformscenter/memberstatement/memberrechargedetails','会员报表-会员充值详情',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1401,1,1,9219776686475892847,31,'/reportformscenter/memberstatement/memberrechargedetails','会员报表-会员充值详情',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1402,1,1,6866664990975755857,8,'/reportformscenter/memberstatement/couponpurchaseorupgradecost','会员报表-会员购券/升级工本费详情',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1403,1,1,6866664990975755857,31,'/reportformscenter/memberstatement/couponpurchaseorupgradecost','会员报表-会员购券/升级工本费详情',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1404,1,1,6289918183485625566,8,'/reportformscenter/memberstatement/memberconsumedetails','会员报表-会员消费详情',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1405,1,1,6289918183485625566,31,'/reportformscenter/memberstatement/memberconsumedetails','会员报表-会员消费详情',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1406,1,1,8102773241758637682,8,'/reportformscenter/memberstatement/memberaccountdetails','会员报表-会员账户详情',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1407,1,1,8102773241758637682,31,'/reportformscenter/memberstatement/memberaccountdetails','会员报表-会员账户详情',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1408,1,1,-2008166242206465336,8,'/reportformscenter/memberstatement/memberrechargesummary','会员报表-会员充值汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1409,1,1,-2008166242206465336,31,'/reportformscenter/memberstatement/memberrechargesummary','会员报表-会员充值汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1410,1,1,6483843977034430556,8,'/reportformscenter/memberstatement/memberconsumesummary','会员报表-会员消费汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1411,1,1,6483843977034430556,31,'/reportformscenter/memberstatement/memberconsumesummary','会员报表-会员消费汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1412,1,1,-7064134737679179424,8,'/reportformscenter/memberstatement/recordofmembersluckydrawtimes','会员报表-会员抽奖次数记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1413,1,1,-7064134737679179424,31,'/reportformscenter/memberstatement/recordofmembersluckydrawtimes','会员报表-会员抽奖次数记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1414,1,1,5770051596906866680,8,'/reportformscenter/memberstatement/numberofrafflesremainingformembers','会员报表-会员剩余抽奖次数',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1415,1,1,5770051596906866680,31,'/reportformscenter/memberstatement/numberofrafflesremainingformembers','会员报表-会员剩余抽奖次数',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1416,1,1,4370635421665875995,8,'/reportformscenter/memberstatement/receptionofgiftpackagefornewcomers','会员报表-会员领取新人礼包',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1417,1,1,4370635421665875995,31,'/reportformscenter/memberstatement/receptionofgiftpackagefornewcomers','会员报表-会员领取新人礼包',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1418,1,1,7284173623881112383,8,'/reportformscenter/memberstatement/redenvelopereceivingrecord','会员报表-会员红包领取记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1419,1,1,7284173623881112383,31,'/reportformscenter/memberstatement/redenvelopereceivingrecord','会员报表-会员红包领取记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1420,1,1,5299590958877257825,8,'/reportformscenter/memberstatement/transferrecord','会员报表-优惠券转赠记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1421,1,1,5299590958877257825,31,'/reportformscenter/memberstatement/transferrecord','会员报表-优惠券转赠记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1422,1,1,2073521589364977795,8,'/reportformscenter/memberstatement/cardsettlesummary','会员报表-会员卡金额结算',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1423,1,1,2073521589364977795,31,'/reportformscenter/memberstatement/cardsettlesummary','会员报表-会员卡金额结算',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1424,1,1,-7477823345509628606,8,'/reportformscenter/memberstatement/incomeandexpenditurestatement','会员报表-会员卡连锁门店收支报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1425,1,1,-7477823345509628606,31,'/reportformscenter/memberstatement/incomeandexpenditurestatement','会员报表-会员卡连锁门店收支报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1426,1,1,-3043518913919597494,8,'/reportformscenter/memberstatement/memberaccountsummary','会员报表-会员账户汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1427,1,1,-3043518913919597494,31,'/reportformscenter/memberstatement/memberaccountsummary','会员报表-会员账户汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1428,1,1,-2186420840512632252,8,'/reportformscenter/memberstatement/memberbalancesummary','会员报表-会员余额汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1429,1,1,-2186420840512632252,31,'/reportformscenter/memberstatement/memberbalancesummary','会员报表-会员余额汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1430,1,1,7288191940549867512,8,'/reportformscenter/memberstatement/store-member-balance-summary','会员报表-门店会员余额汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1431,1,1,7288191940549867512,31,'/reportformscenter/memberstatement/store-member-balance-summary','会员报表-门店会员余额汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1432,1,1,968413403593822317,8,'/reportformscenter/memberstatement/sharecommission','会员报表-会员分享提成报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1433,1,1,968413403593822317,31,'/reportformscenter/memberstatement/sharecommission','会员报表-会员分享提成报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1434,1,1,-4057707542708591959,8,'/reportformscenter/memberstatement/reward','会员报表-打赏报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1435,1,1,-4057707542708591959,31,'/reportformscenter/memberstatement/reward','会员报表-打赏报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1436,1,1,7863061373758775225,8,'/reportformscenter/couponreport/vouchercollectiondetails','优惠券-领券明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1437,1,1,7863061373758775225,31,'/reportformscenter/couponreport/vouchercollectiondetails','优惠券-领券明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1438,1,1,-6768836243645045290,8,'/reportformscenter/couponreport/couponbuylog','优惠券-购买券记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1439,1,1,-6768836243645045290,31,'/reportformscenter/couponreport/couponbuylog','优惠券-购买券记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1440,1,1,-1989761365107303915,8,'/reportformscenter/decisionanalysis/salesinvoice','决策分析-销售账单汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1441,1,1,-1989761365107303915,31,'/reportformscenter/decisionanalysis/salesinvoice','决策分析-销售账单汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1442,1,1,-2099984908920777075,8,'/reportformscenter/decisionanalysis/deptinvoice','决策分析-部门账单汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1443,1,1,-2099984908920777075,31,'/reportformscenter/decisionanalysis/deptinvoice','决策分析-部门账单汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1444,1,1,-4773446404136214153,8,'/reportformscenter/decisionanalysis/deptinvoicedetail','决策分析-部门账单明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1445,1,1,-4773446404136214153,31,'/reportformscenter/decisionanalysis/deptinvoicedetail','决策分析-部门账单明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1446,1,1,9200824939423881146,8,'/reportformscenter/decisionanalysis/quarterlysales','决策分析-季度销售',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1447,1,1,9200824939423881146,31,'/reportformscenter/decisionanalysis/quarterlysales','决策分析-季度销售',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1448,1,1,-6495687091827547475,8,'/reportformscenter/decisionanalysis/monthsales','决策分析-月销售',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1449,1,1,-6495687091827547475,31,'/reportformscenter/decisionanalysis/monthsales','决策分析-月销售',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1450,1,1,4435579269107810274,8,'/reportformscenter/decisionanalysis/daysales','决策分析-日销售',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1451,1,1,4435579269107810274,31,'/reportformscenter/decisionanalysis/daysales','决策分析-日销售',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1452,1,1,4260349240327341985,8,'/reportformscenter/salesquery/foodsalesdetails','销售查询-菜品销售明细报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1453,1,1,4260349240327341985,31,'/reportformscenter/salesquery/foodsalesdetails','销售查询-菜品销售明细报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1454,1,1,-6867750831145129023,8,'/reportformscenter/salesquery/foodsalesranking','销售查询-菜品销售排行报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1455,1,1,-6867750831145129023,31,'/reportformscenter/salesquery/foodsalesranking','销售查询-菜品销售排行报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1456,1,1,8964974598555646403,8,'/reportformscenter/salesquery/salesperiodanalysis','销售查询-销售时段分析',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1457,1,1,8964974598555646403,31,'/reportformscenter/salesquery/salesperiodanalysis','销售查询-销售时段分析',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1458,1,1,-587565212876932710,8,'/reportformscenter/salesquery/salessummary','销售查询-菜品销售汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1459,1,1,-587565212876932710,31,'/reportformscenter/salesquery/salessummary','销售查询-菜品销售汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1460,1,1,-7935734929190720450,8,'/reportformscenter/salesquery/commissionreport','销售查询-提成报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1461,1,1,-7935734929190720450,31,'/reportformscenter/salesquery/commissionreport','销售查询-提成报表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1462,1,1,4282857665578064190,8,'/reportformscenter/refundgivechange/detailsoffreedishes','退赠改-赠菜明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1463,1,1,4282857665578064190,31,'/reportformscenter/refundgivechange/detailsoffreedishes','退赠改-赠菜明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1464,1,1,2576245384787732623,8,'/reportformscenter/refundgivechange/returndetails','退赠改-退菜明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1465,1,1,2576245384787732623,31,'/reportformscenter/refundgivechange/returndetails','退赠改-退菜明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1466,1,1,-7630757697179178486,8,'/reportformscenter/refundgivechange/renamingdetails','退赠改-改名明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1467,1,1,-7630757697179178486,31,'/reportformscenter/refundgivechange/renamingdetails','退赠改-改名明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1468,1,1,-4448061533459001808,8,'/reportformscenter/refundgivechange/pricechangedetails','退赠改-改价明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1469,1,1,-4448061533459001808,31,'/reportformscenter/refundgivechange/pricechangedetails','退赠改-改价明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1470,1,1,79801215728941838,8,'/reportformscenter/queuereport/queuestatistics','排队叫号-排队统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1471,1,1,79801215728941838,31,'/reportformscenter/queuereport/queuestatistics','排队叫号-排队统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1472,1,1,6473511522175812905,8,'/reportformscenter/queuereport/queueoverstatistics','排队叫号-排队过号统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1473,1,1,6473511522175812905,31,'/reportformscenter/queuereport/queueoverstatistics','排队叫号-排队过号统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1474,1,1,1942007232156986913,8,'/reportformscenter/kdsreport/preparationperformance','KDS绩效报表-配菜绩效',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1475,1,1,1942007232156986913,31,'/reportformscenter/kdsreport/preparationperformance','KDS绩效报表-配菜绩效',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1476,1,1,-5614023026053864761,8,'/reportformscenter/kdsreport/cookperformance','KDS绩效报表-制作绩效',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1477,1,1,-5614023026053864761,31,'/reportformscenter/kdsreport/cookperformance','KDS绩效报表-制作绩效',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1478,1,1,4776891164706498973,8,'/reportformscenter/kdsreport/deliveryperformance','KDS绩效报表-传菜绩效',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1479,1,1,4776891164706498973,31,'/reportformscenter/kdsreport/deliveryperformance','KDS绩效报表-传菜绩效',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1480,1,1,-80539249692654068,8,'/reportformscenter/signandreport/salesdetails','签单报表-签单菜品销售明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1481,1,1,-80539249692654068,31,'/reportformscenter/signandreport/salesdetails','签单报表-签单菜品销售明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1482,1,1,2994787024474057844,8,'/reportformscenter/signandreport/salessummary','签单报表-签单菜品销售汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1483,1,1,2994787024474057844,31,'/reportformscenter/signandreport/salessummary','签单报表-签单菜品销售汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1484,1,1,-4165060414709487805,4,'/onlinerestaurant/wxmrg/wxmerchantconfig','基本设置-微信授权',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1485,1,1,8960653277547225208,4,'/onlinerestaurant/wxmrg/douyinconfig','基本设置-抖音授权',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1486,1,1,-2244730425624049757,4,'/onlinerestaurant/wxmrg/candaoconfig','基本设置-餐道授权',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1487,1,1,7648970814594599829,4,'/onlinerestaurant/wxmrg/wxmsgtmpl','基本设置-消息提醒',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1488,1,1,8985539753173392023,4,'/onlinerestaurant/wxmrg/wxprogramtemplate','基本设置-小程序模板',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1489,1,1,2423403203024970398,4,'/onlinerestaurant/wxmrg/wxcard','基本设置-会员卡券',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1490,1,1,5503757010434807060,4,'/onlinerestaurant/wxorderdeliverymrg/ordercenter','订单/外卖-订单中心',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1491,1,1,1619072779111378415,4,'/onlinerestaurant/wxwananchimrg/wxmenu','公众号-菜单栏设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1492,1,1,720445822944532407,4,'/onlinerestaurant/wxwananchimrg/automaticreply','公众号-自动回复',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1493,1,1,-6392426429593995205,4,'/onlinerestaurant/wxwananchimrg/receivesettings','公众号-接收设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1494,1,1,4695584344315762598,4,'/onlinerestaurant/wxorderfoodbyphonemrg/ptqrbind','二维码管理-桌台二维码',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1495,1,1,3776080570582901137,4,'/onlinerestaurant/wxcustomdecorationmrg','小程序装饰',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1496,1,1,-8400441310962377800,4,'/onlinerestaurant/wxcallingsettings','排队叫号',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1497,1,1,-2598316323624644693,4,'/onlinerestaurant/wxlargescreensettings','餐厅大屏设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1498,1,1,-5548988955298360746,2,'/admin/ptdishmrg/ptdishtype','门店菜品-菜品类别',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1499,1,1,-5548988955298360746,25,'/admin/ptdishmrg/ptdishtype','门店菜品-菜品类别',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1500,1,1,-6266013132072548654,2,'/admin/ptdishmrg/dish-manage','门店菜品-菜品管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1501,1,1,-6266013132072548654,25,'/admin/ptdishmrg/dish-manage','门店菜品-菜品管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1502,1,1,-3628085877919715458,2,'/admin/ptdishmrg/ptcoolwaymrg','门店菜品-菜品做法',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1503,1,1,-3628085877919715458,25,'/admin/ptdishmrg/ptcoolwaymrg','门店菜品-菜品做法',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1504,1,1,6604398774988992725,2,'/admin/ptdishmrg/ptdisharea','门店菜品-菜品部位',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1505,1,1,6604398774988992725,25,'/admin/ptdishmrg/ptdisharea','门店菜品-菜品部位',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1506,1,1,1196504267442027558,2,'/admin/ptdishmrg/ptdishflavor','门店菜品-菜品口味',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1507,1,1,1196504267442027558,25,'/admin/ptdishmrg/ptdishflavor','门店菜品-菜品口味',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1508,1,1,-4798247618396725724,2,'/admin/ptdishmrg/ptdatasyncrecord','门店菜品-菜品同步',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1509,1,1,-4798247618396725724,25,'/admin/ptdishmrg/ptdatasyncrecord','门店菜品-菜品同步',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1510,1,1,-5532286223790031133,2,'/admin/ptdishmrg/posdishhidepage','门店菜品-时段隐藏',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1511,1,1,-5532286223790031133,25,'/admin/ptdishmrg/posdishhidepage','门店菜品-时段隐藏',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1512,1,1,-713976393756488732,2,'/admin/ptdishmrg/ptfestival','门店菜品-特殊日期',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1513,1,1,-713976393756488732,25,'/admin/ptdishmrg/ptfestival','门店菜品-特殊日期',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1514,1,1,2160593308409991866,2,'/admin/ptdishmrg/ptdishpricespecialpage','门店菜品-特殊价格',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1515,1,1,2160593308409991866,25,'/admin/ptdishmrg/ptdishpricespecialpage','门店菜品-特殊价格',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1516,1,1,-9031981940587614356,2,'/admin/ptdishmrg/ordering-setting','门店菜品-点餐默认设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1517,1,1,-9031981940587614356,25,'/admin/ptdishmrg/ordering-setting','门店菜品-点餐默认设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1518,1,1,-1646137062540631276,2,'/admin/groupdish/branddishtype','品牌菜品-品牌类库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1519,1,1,-1646137062540631276,25,'/admin/groupdish/branddishtype','品牌菜品-品牌类库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1520,1,1,2327487900538086343,2,'/admin/groupdish/branddish','品牌菜品-品牌菜品',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1521,1,1,2327487900538086343,25,'/admin/groupdish/branddish','品牌菜品-品牌菜品',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1522,1,1,-3020092438973776808,2,'/admin/groupdish/brandcookway','品牌菜品-品牌做法',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1523,1,1,-3020092438973776808,25,'/admin/groupdish/brandcookway','品牌菜品-品牌做法',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1524,1,1,5766984640261737021,2,'/admin/groupdish/branddisharea','品牌菜品-品牌部位',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1525,1,1,5766984640261737021,25,'/admin/groupdish/branddisharea','品牌菜品-品牌部位',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1526,1,1,-2937763110314355132,2,'/admin/groupdish/branddishflavor','品牌菜品-品牌口味',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1527,1,1,-2937763110314355132,25,'/admin/groupdish/branddishflavor','品牌菜品-品牌口味',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1528,1,1,-6657129488983294517,2,'/admin/groupdish/groupdishbook','品牌菜品-菜谱方案',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1529,1,1,-6657129488983294517,25,'/admin/groupdish/groupdishbook','品牌菜品-菜谱方案',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1530,1,1,-8125104443585937061,2,'/admin/pttblmrg/pttblarea','桌台管理-桌台区域',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1531,1,1,-8125104443585937061,25,'/admin/pttblmrg/pttblarea','桌台管理-桌台区域',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1532,1,1,7439881048150015700,2,'/admin/pttblmrg/pttbltype','桌台管理-桌台类型',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1533,1,1,7439881048150015700,25,'/admin/pttblmrg/pttbltype','桌台管理-桌台类型',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1534,1,1,-5237404207884581224,2,'/admin/pttblmrg/pttbl','桌台管理-桌台',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1535,1,1,-5237404207884581224,25,'/admin/pttblmrg/pttbl','桌台管理-桌台',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1536,1,1,6439910010241128381,2,'/admin/prnmrg','打印设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1537,1,1,6439910010241128381,25,'/admin/prnmrg','打印设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1538,1,1,-5012057322215833794,2,'/admin/operationalinfomrg/bizbusinesshours','运营资料-营业市别（餐段）',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1539,1,1,-5012057322215833794,25,'/admin/operationalinfomrg/bizbusinesshours','运营资料-营业市别（餐段）',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1540,1,1,8863673107171450336,2,'/admin/operationalinfomrg/bizdiscount','运营资料-折扣类型',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1541,1,1,8863673107171450336,25,'/admin/operationalinfomrg/bizdiscount','运营资料-折扣类型',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1542,1,1,-5685017397241047613,2,'/admin/operationalinfomrg/sysdictdata','运营资料-系统参数',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1543,1,1,-5685017397241047613,25,'/admin/operationalinfomrg/sysdictdata','运营资料-系统参数',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1544,1,1,1806957844582360768,2,'/admin/operationalinfomrg/paychannel','运营资料-支付通道',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1545,1,1,1806957844582360768,25,'/admin/operationalinfomrg/paychannel','运营资料-支付通道',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1546,1,1,8616327257770008409,2,'/admin/operationalinfomrg/creditpurchaseaccount','运营资料-挂账账号',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1547,1,1,8616327257770008409,25,'/admin/operationalinfomrg/creditpurchaseaccount','运营资料-挂账账号',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1548,1,1,7273537080750997695,2,'/admin/operationalinfomrg/posdev','运营资料-设备管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1549,1,1,7273537080750997695,25,'/admin/operationalinfomrg/posdev','运营资料-设备管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1550,1,1,1206492995857597669,2,'/admin/sysstoremrg/sysbrand','公众资料-企业信息',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1551,1,1,1206492995857597669,25,'/admin/sysstoremrg/sysbrand','公众资料-企业信息',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1552,1,1,-7789393716132151153,2,'/admin/sysstoremrg/sysstore','公众资料-店铺管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1553,1,1,-7789393716132151153,25,'/admin/sysstoremrg/sysstore','公众资料-店铺管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1554,1,1,3175695535749194983,2,'/admin/sysstoremrg/bizpayway','公众资料-结账方式',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1555,1,1,3175695535749194983,25,'/admin/sysstoremrg/bizpayway','公众资料-结账方式',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1556,1,1,-8401758438946329917,2,'/admin/sysstoremrg/bizincometype','公众资料-科目分类',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1557,1,1,-8401758438946329917,25,'/admin/sysstoremrg/bizincometype','公众资料-科目分类',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1558,1,1,-8967711162216624422,2,'/admin/sysstoremrg/bizincome','公众资料-收入科目',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1559,1,1,-8967711162216624422,25,'/admin/sysstoremrg/bizincome','公众资料-收入科目',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1560,1,1,-3049212897267487929,2,'/admin/sysstoremrg/posreasontypepage','公众资料-退赠起菜',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1561,1,1,-3049212897267487929,25,'/admin/sysstoremrg/posreasontypepage','公众资料-退赠起菜',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1562,1,1,6448775902095875086,2,'/admin/sysstoremrg/takeoutaggregationplatformchannelpage','公众资料-外卖渠道',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1563,1,1,6448775902095875086,25,'/admin/sysstoremrg/takeoutaggregationplatformchannelpage','公众资料-外卖渠道',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1564,1,1,-6610876372816564665,2,'/admin/syspowermrg/sysuser','权限管理-用户管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1565,1,1,-6610876372816564665,25,'/admin/syspowermrg/sysuser','权限管理-用户管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1566,1,1,-1422603708756287124,2,'/admin/syspowermrg/sysrole','权限管理-角色管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1567,1,1,-1422603708756287124,25,'/admin/syspowermrg/sysrole','权限管理-角色管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1568,1,1,-6577745530564306555,2,'/admin/smssmrg/bizsmsconfig','短信管理-短信设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1569,1,1,-6577745530564306555,25,'/admin/smssmrg/bizsmsconfig','短信管理-短信设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1570,1,1,-8243113841238005467,2,'/admin/smssmrg/smstemplate','短信管理-短信模板',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1571,1,1,-8243113841238005467,25,'/admin/smssmrg/smstemplate','短信管理-短信模板',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1572,1,1,-4007776094611379052,2,'/admin/smssmrg/bizsmssendrecord','短信管理-短信发送记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1573,1,1,-4007776094611379052,25,'/admin/smssmrg/bizsmssendrecord','短信管理-短信发送记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1574,1,1,-710874573579151971,2,'/admin/electronicinvoicemrg/electronicinvoice','电子发票-发票设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1575,1,1,-710874573579151971,25,'/admin/electronicinvoicemrg/electronicinvoice','电子发票-发票设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1576,1,1,-5892662801427503723,2,'/admin/electronicinvoicemrg/dwdinvoicebill','电子发票-发票记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1577,1,1,-5892662801427503723,25,'/admin/electronicinvoicemrg/dwdinvoicebill','电子发票-发票记录',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1578,1,1,8299494024108982962,3,'/membermarketing/crmmembermrg','基本档案',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1579,1,1,-3904044514582190226,3,'/membermarketing/crmmembermrg/crmcardtype','基本档案-会员卡类型',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1580,1,1,2649015601191756235,3,'/membermarketing/crmmembermrg/crmmember','基本档案-会员档案',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1581,1,1,-6441022907705041722,3,'/membermarketing/crmmembermrg/cardoperation','基本档案-会员卡操作',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1582,1,1,-4307782189003918479,3,'/membermarketing/crmmemberportraitmrg','数据',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1583,1,1,2094666682482005702,3,'/membermarketing/crmmemberportraitmrg/memberportrait','数据-会员画像',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1584,1,1,-6001266533442834750,3,'/membermarketing/crmmemberportraitmrg/memberscreening','数据-会员筛选',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1585,1,1,-281382581989788815,3,'/membermarketing/crmcardmarketingmrg','卡券营销',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1586,1,1,9030237479026692436,3,'/membermarketing/crmcardmarketingmrg/crmnewgift','卡券营销-新人礼包',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1587,1,1,9204449268851933276,3,'/membermarketing/crmcardmarketingmrg/reward','卡券营销-打赏',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1588,1,1,4598375617556287788,3,'/membermarketing/crmcardmarketingmrg/crmredenvelope','卡券营销-红包活动',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1589,1,1,-2454265350691984506,3,'/membermarketing/crmcardmarketingmrg/crmjoinactivity','卡券营销-续费奖励',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1590,1,1,-1271522526931113828,3,'/membermarketing/crmcardmarketingmrg/crmcouponpackage','卡券营销-券包管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1591,1,1,6782734242663667745,3,'/membermarketing/crmcardmarketingmrg/crmcoupon','卡券营销-券/红包管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1592,1,1,-3212314384930544984,3,'/membermarketing/crmcardmarketingmrg/crminvitationreward','卡券营销-邀请有礼',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1593,1,1,-4206561738512630283,3,'/membermarketing/crmcardmarketingmrg/crmfestival','卡券营销-节假日自定义',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1594,1,1,914034526807016792,3,'/membermarketing/crmcardmarketingmrg/batchcoupons','卡券营销-批量赠券/充值',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1595,1,1,-8196311904113742985,3,'/membermarketing/crmcardmarketingmrg/share-member','卡券营销-共享会员',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1596,1,1,-5591892806315637845,3,'/membermarketing/crmintegralmarketingmrg','积分营销',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1597,1,1,-7952815719381573807,3,'/membermarketing/crmintegralmarketingmrg/crmpointexchange','积分营销-积分兑换',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1598,1,1,-4534521465836554082,3,'/membermarketing/crmmarketingmrg','充值、消费',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1599,1,1,4210661468112393591,3,'/membermarketing/crmmarketingmrg/crmsaverule','充值、消费-储值套餐',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1600,1,1,2525376840975075365,3,'/membermarketing/crmmarketingmrg/crmcashback','充值、消费-消费返现',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1601,1,1,4183315779609872287,3,'/membermarketing/crmmarketingmrg/crmcardlevelandmorerecharge','充值、消费-消费智能推荐',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1602,1,1,1927586372704652023,3,'/membermarketing/crmmarketingmrg/crmcardlevelandoverlordmeal','充值、消费-霸王餐',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1603,1,1,1283306675780585646,3,'/membermarketing/crmmarketingmrg/crmconsumptioncouponrule','充值、消费-消费赠券',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1604,1,1,5718455950503887105,3,'/membermarketing/crmmarketingmrg/crmlargeturntable','充值、消费-大转盘',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1605,1,1,500314124012094274,3,'/membermarketing/crmmarketingmrg/birthdayvoucher','充值、消费-生日赠券',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1606,1,1,-2546269899430674233,7,'/book/meal_period_setting','餐段管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1607,1,1,-2546269899430674233,30,'/book/meal_period_setting','餐段管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1608,1,1,3888929033155948145,7,'/book/festival_setting/festival_category_list','吉祥日设置-吉祥日类别',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1609,1,1,3888929033155948145,30,'/book/festival_setting/festival_category_list','吉祥日设置-吉祥日类别',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1610,1,1,7649159518868916221,7,'/book/festival_setting/festival_setting_list','吉祥日设置-吉祥日设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1611,1,1,7649159518868916221,30,'/book/festival_setting/festival_setting_list','吉祥日设置-吉祥日设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1612,1,1,-7625180896747281079,7,'/book/occupancy_table_setting','上座率桌数设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1613,1,1,-7625180896747281079,30,'/book/occupancy_table_setting','上座率桌数设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1614,1,1,-7882958279181034635,7,'/book/table_lock_setting','设置锁台',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1615,1,1,-7882958279181034635,30,'/book/table_lock_setting','设置锁台',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1616,1,1,2695117215732563833,7,'/book/message_setting','消息设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1617,1,1,2695117215732563833,30,'/book/message_setting','消息设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1618,1,1,8508616126381626210,7,'/book/applet_invitation','小程序邀请函设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1619,1,1,8508616126381626210,30,'/book/applet_invitation','小程序邀请函设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1620,1,1,-6451105950967479713,6,'/warehouse/mydesktop','我的桌面',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1621,1,1,-6451105950967479713,19,'/warehouse/mydesktop','我的桌面',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1622,1,1,-6451105950967479713,29,'/warehouse/mydesktop','我的桌面',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1623,1,1,-656393782503146128,6,'/warehouse/publicinfo/organizationstructure','公众资料-组织结构',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1624,1,1,-656393782503146128,19,'/warehouse/publicinfo/organizationstructure','公众资料-组织结构',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1625,1,1,-656393782503146128,29,'/warehouse/publicinfo/organizationstructure','公众资料-组织结构',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1626,1,1,-1056011856090517942,6,'/warehouse/publicinfo/storegroup','公众资料-门店分组',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1627,1,1,-1056011856090517942,19,'/warehouse/publicinfo/storegroup','公众资料-门店分组',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1628,1,1,-1056011856090517942,29,'/warehouse/publicinfo/storegroup','公众资料-门店分组',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1629,1,1,-2598363587692187719,6,'/warehouse/publicinfo/targetmrg','公众资料-目标管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1630,1,1,-2598363587692187719,19,'/warehouse/publicinfo/targetmrg','公众资料-目标管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1631,1,1,-2598363587692187719,29,'/warehouse/publicinfo/targetmrg','公众资料-目标管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1632,1,1,-5732353092896997349,6,'/warehouse/publicinfo/supplierparams','公众资料-供应链参数',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1633,1,1,-5732353092896997349,19,'/warehouse/publicinfo/supplierparams','公众资料-供应链参数',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1634,1,1,-5732353092896997349,29,'/warehouse/publicinfo/supplierparams','公众资料-供应链参数',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1635,1,1,6142742542615251952,6,'/warehouse/basicfile/suppliermgr','基本档案-供应商管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1636,1,1,6142742542615251952,19,'/warehouse/basicfile/suppliermgr','基本档案-供应商管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1637,1,1,6142742542615251952,29,'/warehouse/basicfile/suppliermgr','基本档案-供应商管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1638,1,1,5862203110637528683,6,'/warehouse/basicfile/unitlabel','基本档案-单位标签',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1639,1,1,5862203110637528683,19,'/warehouse/basicfile/unitlabel','基本档案-单位标签',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1640,1,1,5862203110637528683,29,'/warehouse/basicfile/unitlabel','基本档案-单位标签',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1641,1,1,-4651663248777615503,6,'/warehouse/basicfile/wmsitemtype','基本档案-物品类别',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1642,1,1,-4651663248777615503,19,'/warehouse/basicfile/wmsitemtype','基本档案-物品类别',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1643,1,1,-4651663248777615503,29,'/warehouse/basicfile/wmsitemtype','基本档案-物品类别',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1644,1,1,-2037363707239973389,6,'/warehouse/basicfile/scgoods','基本档案-物品管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1645,1,1,-2037363707239973389,19,'/warehouse/basicfile/scgoods','基本档案-物品管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1646,1,1,-2037363707239973389,29,'/warehouse/basicfile/scgoods','基本档案-物品管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1647,1,1,-1341345227263711544,6,'/warehouse/basicfile/warehousemrg','基本档案-仓库管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1648,1,1,-1341345227263711544,19,'/warehouse/basicfile/warehousemrg','基本档案-仓库管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1649,1,1,-1341345227263711544,29,'/warehouse/basicfile/warehousemrg','基本档案-仓库管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1650,1,1,-1283594804696244872,6,'/warehouse/basicfile/deliveryrules','基本档案-配送规则',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1651,1,1,-1283594804696244872,19,'/warehouse/basicfile/deliveryrules','基本档案-配送规则',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1652,1,1,-1283594804696244872,29,'/warehouse/basicfile/deliveryrules','基本档案-配送规则',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1653,1,1,-2974066912974367149,6,'/warehouse/basicfile/customer-manage','基本档案-客户管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1654,1,1,-2974066912974367149,19,'/warehouse/basicfile/customer-manage','基本档案-客户管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1655,1,1,-2974066912974367149,29,'/warehouse/basicfile/customer-manage','基本档案-客户管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1656,1,1,737370539115613391,6,'/warehouse/inventorymrg/scgoodsinwarehouse','库存管理-仓库期初',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1657,1,1,737370539115613391,19,'/warehouse/inventorymrg/scgoodsinwarehouse','库存管理-仓库期初',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1658,1,1,737370539115613391,29,'/warehouse/inventorymrg/scgoodsinwarehouse','库存管理-仓库期初',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1659,1,1,-9171374732625005441,6,'/warehouse/inventorymrg/warehouseinventory','库存管理-仓库盘点',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1660,1,1,-9171374732625005441,19,'/warehouse/inventorymrg/warehouseinventory','库存管理-仓库盘点',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1661,1,1,-9171374732625005441,29,'/warehouse/inventorymrg/warehouseinventory','库存管理-仓库盘点',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1662,1,1,8131391219109968892,6,'/warehouse/inventorymrg/inventorymrg','库存管理-盘点管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1663,1,1,8131391219109968892,19,'/warehouse/inventorymrg/inventorymrg','库存管理-盘点管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1664,1,1,8131391219109968892,29,'/warehouse/inventorymrg/inventorymrg','库存管理-盘点管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1665,1,1,4686543655174894128,6,'/warehouse/inventorymrg/inventorydocuments','库存管理-库存单据',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1666,1,1,4686543655174894128,19,'/warehouse/inventorymrg/inventorydocuments','库存管理-库存单据',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1667,1,1,4686543655174894128,29,'/warehouse/inventorymrg/inventorydocuments','库存管理-库存单据',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1668,1,1,-5414925245645409476,6,'/warehouse/inventorymrg/monthendclosing','库存管理-月末结账',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1669,1,1,-5414925245645409476,19,'/warehouse/inventorymrg/monthendclosing','库存管理-月末结账',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1670,1,1,-5414925245645409476,29,'/warehouse/inventorymrg/monthendclosing','库存管理-月末结账',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1671,1,1,-7539392184041029411,6,'/warehouse/inventorymrg/inventory-document-bmlyd','库存管理-档口领料',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1672,1,1,-7539392184041029411,19,'/warehouse/inventorymrg/inventory-document-bmlyd','库存管理-档口领料',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1673,1,1,-7539392184041029411,29,'/warehouse/inventorymrg/inventory-document-bmlyd','库存管理-档口领料',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1674,1,1,-2162689285125813137,6,'/warehouse/pricemrg/vendorquotation','价格管理-供应商报价单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1675,1,1,-2162689285125813137,19,'/warehouse/pricemrg/vendorquotation','价格管理-供应商报价单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1676,1,1,-2162689285125813137,29,'/warehouse/pricemrg/vendorquotation','价格管理-供应商报价单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1677,1,1,5282064406447818585,6,'/warehouse/pricemrg/vendorquotationmrg','价格管理-供应商报价单管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1678,1,1,5282064406447818585,19,'/warehouse/pricemrg/vendorquotationmrg','价格管理-供应商报价单管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1679,1,1,5282064406447818585,29,'/warehouse/pricemrg/vendorquotationmrg','价格管理-供应商报价单管理',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1680,1,1,-874938679766545136,6,'/warehouse/pricemrg/deliveryquotation','价格管理-配送报价单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1681,1,1,-874938679766545136,19,'/warehouse/pricemrg/deliveryquotation','价格管理-配送报价单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1682,1,1,-874938679766545136,29,'/warehouse/pricemrg/deliveryquotation','价格管理-配送报价单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1683,1,1,4808983781874135754,6,'/warehouse/pricemrg/deliveryagreementprice','价格管理-配送协议价',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1684,1,1,4808983781874135754,19,'/warehouse/pricemrg/deliveryagreementprice','价格管理-配送协议价',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1685,1,1,4808983781874135754,29,'/warehouse/pricemrg/deliveryagreementprice','价格管理-配送协议价',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1686,1,1,2277627800474261276,6,'/warehouse/orderinspectionmrg/stallsorder','订货验货-档口订货',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1687,1,1,2277627800474261276,19,'/warehouse/orderinspectionmrg/stallsorder','订货验货-档口订货',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1688,1,1,2277627800474261276,29,'/warehouse/orderinspectionmrg/stallsorder','订货验货-档口订货',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1689,1,1,-1705417650398306519,6,'/warehouse/orderinspectionmrg/storeorder','订货验货-门店订货',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1690,1,1,-1705417650398306519,19,'/warehouse/orderinspectionmrg/storeorder','订货验货-门店订货',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1691,1,1,-1705417650398306519,29,'/warehouse/orderinspectionmrg/storeorder','订货验货-门店订货',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1692,1,1,-3720949412297610641,6,'/warehouse/orderinspectionmrg/inspectionwarehousing-goods','订货验货-验货入库（物品）',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1693,1,1,-3720949412297610641,19,'/warehouse/orderinspectionmrg/inspectionwarehousing-goods','订货验货-验货入库（物品）',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1694,1,1,-3720949412297610641,29,'/warehouse/orderinspectionmrg/inspectionwarehousing-goods','订货验货-验货入库（物品）',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1695,1,1,6085767260351957013,6,'/warehouse/orderinspectionmrg/inspectionwarehousing-supplier','订货验货-验货入库（供应商）',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1696,1,1,6085767260351957013,19,'/warehouse/orderinspectionmrg/inspectionwarehousing-supplier','订货验货-验货入库（供应商）',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1697,1,1,6085767260351957013,29,'/warehouse/orderinspectionmrg/inspectionwarehousing-supplier','订货验货-验货入库（供应商）',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1698,1,1,-6689922212774182743,6,'/warehouse/orderinspectionmrg/inventory-document-yhrkd','订货验货-自采入库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1699,1,1,-6689922212774182743,19,'/warehouse/orderinspectionmrg/inventory-document-yhrkd','订货验货-自采入库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1700,1,1,-6689922212774182743,29,'/warehouse/orderinspectionmrg/inventory-document-yhrkd','订货验货-自采入库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1701,1,1,6190532257721471020,6,'/warehouse/distributionmrg/purchaseorder','配送管理-订货单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1702,1,1,6190532257721471020,19,'/warehouse/distributionmrg/purchaseorder','配送管理-订货单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1703,1,1,6190532257721471020,29,'/warehouse/distributionmrg/purchaseorder','配送管理-订货单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1704,1,1,6817835285353041796,6,'/warehouse/distributionmrg/deliveryout','配送管理-订货转总仓出库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1705,1,1,6817835285353041796,19,'/warehouse/distributionmrg/deliveryout','配送管理-订货转总仓出库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1706,1,1,6817835285353041796,29,'/warehouse/distributionmrg/deliveryout','配送管理-订货转总仓出库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1707,1,1,-69327992978897112,6,'/warehouse/ordersignboard','订货看板',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1708,1,1,-69327992978897112,19,'/warehouse/ordersignboard','订货看板',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1709,1,1,-69327992978897112,29,'/warehouse/ordersignboard','订货看板',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1710,1,1,1420982839852865822,6,'/warehouse/settlementmrg/paymentorder','结算管理-付款单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1711,1,1,1420982839852865822,19,'/warehouse/settlementmrg/paymentorder','结算管理-付款单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1712,1,1,1420982839852865822,29,'/warehouse/settlementmrg/paymentorder','结算管理-付款单',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1713,1,1,4116339996153262875,6,'/warehouse/settlementmrg/suppliersettlement','结算管理-供应商结算',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1714,1,1,4116339996153262875,19,'/warehouse/settlementmrg/suppliersettlement','结算管理-供应商结算',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1715,1,1,4116339996153262875,29,'/warehouse/settlementmrg/suppliersettlement','结算管理-供应商结算',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1716,1,1,4622284956887061586,6,'/warehouse/settlementmrg/suppliersettlementquery','结算管理-供应商结算查询',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1717,1,1,4622284956887061586,19,'/warehouse/settlementmrg/suppliersettlementquery','结算管理-供应商结算查询',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1718,1,1,4622284956887061586,29,'/warehouse/settlementmrg/suppliersettlementquery','结算管理-供应商结算查询',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1719,1,1,-1354577928614818823,6,'/warehouse/settlementmrg/organizationsettlement','结算管理-组织结算',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1720,1,1,-1354577928614818823,19,'/warehouse/settlementmrg/organizationsettlement','结算管理-组织结算',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1721,1,1,-1354577928614818823,29,'/warehouse/settlementmrg/organizationsettlement','结算管理-组织结算',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1722,1,1,8763149182089836202,6,'/warehouse/settlementmrg/organizationsettlementquery','结算管理-组织结算查询',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1723,1,1,8763149182089836202,19,'/warehouse/settlementmrg/organizationsettlementquery','结算管理-组织结算查询',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1724,1,1,8763149182089836202,29,'/warehouse/settlementmrg/organizationsettlementquery','结算管理-组织结算查询',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1725,1,1,3183793231884339409,6,'/warehouse/costcontrol/costcardsettings','成本管理-菜品成本卡设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1726,1,1,3183793231884339409,19,'/warehouse/costcontrol/costcardsettings','成本管理-菜品成本卡设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1727,1,1,3183793231884339409,29,'/warehouse/costcontrol/costcardsettings','成本管理-菜品成本卡设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1728,1,1,5827403803465709984,6,'/warehouse/costcontrol/auxiliarycostsetting','成本管理-辅助成本设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1729,1,1,5827403803465709984,19,'/warehouse/costcontrol/auxiliarycostsetting','成本管理-辅助成本设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1730,1,1,5827403803465709984,29,'/warehouse/costcontrol/auxiliarycostsetting','成本管理-辅助成本设置',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1731,1,1,-863283386665547494,6,'/warehouse/costcontrol/automaticdeduction','成本管理-自动扣减出库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1732,1,1,-863283386665547494,19,'/warehouse/costcontrol/automaticdeduction','成本管理-自动扣减出库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1733,1,1,-863283386665547494,29,'/warehouse/costcontrol/automaticdeduction','成本管理-自动扣减出库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1734,1,1,-384628277701771014,6,'/warehouse/costcontrol/manualdeduction','成本管理-手动扣减出库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1735,1,1,-384628277701771014,19,'/warehouse/costcontrol/manualdeduction','成本管理-手动扣减出库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1736,1,1,-384628277701771014,29,'/warehouse/costcontrol/manualdeduction','成本管理-手动扣减出库',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1737,1,1,-7644182112758490423,6,'/warehouse/inventoryreport/itembalance','库存报表-收发存汇总表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1738,1,1,-7644182112758490423,19,'/warehouse/inventoryreport/itembalance','库存报表-收发存汇总表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1739,1,1,-7644182112758490423,29,'/warehouse/inventoryreport/itembalance','库存报表-收发存汇总表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1740,1,1,6214029339241356035,6,'/warehouse/inventoryreport/itemdetail','库存报表-收发存明细表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1741,1,1,6214029339241356035,19,'/warehouse/inventoryreport/itemdetail','库存报表-收发存明细表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1742,1,1,6214029339241356035,29,'/warehouse/inventoryreport/itemdetail','库存报表-收发存明细表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1743,1,1,-6808855533801657113,6,'/warehouse/inventoryreport/departtakedetail','库存报表-仓库部门领料明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1744,1,1,-6808855533801657113,19,'/warehouse/inventoryreport/departtakedetail','库存报表-仓库部门领料明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1745,1,1,-6808855533801657113,29,'/warehouse/inventoryreport/departtakedetail','库存报表-仓库部门领料明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1746,1,1,8225565306830611264,6,'/warehouse/inventoryreport/departtakesummary','库存报表-仓库部门领料汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1747,1,1,8225565306830611264,19,'/warehouse/inventoryreport/departtakesummary','库存报表-仓库部门领料汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1748,1,1,8225565306830611264,29,'/warehouse/inventoryreport/departtakesummary','库存报表-仓库部门领料汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1749,1,1,-8056502406606744576,6,'/warehouse/inventoryreport/purchasesummary','库存报表-物品采购汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1750,1,1,-8056502406606744576,19,'/warehouse/inventoryreport/purchasesummary','库存报表-物品采购汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1751,1,1,-8056502406606744576,29,'/warehouse/inventoryreport/purchasesummary','库存报表-物品采购汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1752,1,1,-2858614760902568333,6,'/warehouse/inventoryreport/outboundsummary','库存报表-仓库采购出库汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1753,1,1,-2858614760902568333,19,'/warehouse/inventoryreport/outboundsummary','库存报表-仓库采购出库汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1754,1,1,-2858614760902568333,29,'/warehouse/inventoryreport/outboundsummary','库存报表-仓库采购出库汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1755,1,1,4678501333298696974,6,'/warehouse/inventoryreport/outinsummary','库存报表-仓库出入库汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1756,1,1,4678501333298696974,19,'/warehouse/inventoryreport/outinsummary','库存报表-仓库出入库汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1757,1,1,4678501333298696974,29,'/warehouse/inventoryreport/outinsummary','库存报表-仓库出入库汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1758,1,1,-2457353317679552673,6,'/warehouse/inventoryreport/warehouserealstock','库存报表-仓库实时库存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1759,1,1,-2457353317679552673,19,'/warehouse/inventoryreport/warehouserealstock','库存报表-仓库实时库存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1760,1,1,-2457353317679552673,29,'/warehouse/inventoryreport/warehouserealstock','库存报表-仓库实时库存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1761,1,1,-730208749396638253,6,'/warehouse/inventoryreport/goodsrealstock','库存报表-物品实时库存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1762,1,1,-730208749396638253,19,'/warehouse/inventoryreport/goodsrealstock','库存报表-物品实时库存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1763,1,1,-730208749396638253,29,'/warehouse/inventoryreport/goodsrealstock','库存报表-物品实时库存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1764,1,1,2627178172133122831,6,'/warehouse/inventoryreport/salesinventorysummary','库存报表-物品进销存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1765,1,1,2627178172133122831,19,'/warehouse/inventoryreport/salesinventorysummary','库存报表-物品进销存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1766,1,1,2627178172133122831,29,'/warehouse/inventoryreport/salesinventorysummary','库存报表-物品进销存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1767,1,1,-5461695044861563329,6,'/warehouse/inventoryreport/warehouseinventory','库存报表-仓库进销存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1768,1,1,-5461695044861563329,19,'/warehouse/inventoryreport/warehouseinventory','库存报表-仓库进销存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1769,1,1,-5461695044861563329,29,'/warehouse/inventoryreport/warehouseinventory','库存报表-仓库进销存汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1770,1,1,7893393740149211871,6,'/warehouse/inventoryreport/supplierordersettlementdetail','库存报表-供应商已结/未结明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1771,1,1,7893393740149211871,19,'/warehouse/inventoryreport/supplierordersettlementdetail','库存报表-供应商已结/未结明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1772,1,1,7893393740149211871,29,'/warehouse/inventoryreport/supplierordersettlementdetail','库存报表-供应商已结/未结明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1773,1,1,5407429590496070848,6,'/warehouse/inventoryreport/supplierordersettlementsummary','库存报表-供应商结算汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1774,1,1,5407429590496070848,19,'/warehouse/inventoryreport/supplierordersettlementsummary','库存报表-供应商结算汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1775,1,1,5407429590496070848,29,'/warehouse/inventoryreport/supplierordersettlementsummary','库存报表-供应商结算汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1776,1,1,-8919571034880877570,6,'/warehouse/inventoryreport/supplierorderdetails','库存报表-供应商订货明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1777,1,1,-8919571034880877570,19,'/warehouse/inventoryreport/supplierorderdetails','库存报表-供应商订货明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1778,1,1,-8919571034880877570,29,'/warehouse/inventoryreport/supplierorderdetails','库存报表-供应商订货明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1779,1,1,3948610568287074378,6,'/warehouse/inventoryreport/supplierorderamount','库存报表-供应商订货金额',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1780,1,1,3948610568287074378,19,'/warehouse/inventoryreport/supplierorderamount','库存报表-供应商订货金额',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1781,1,1,3948610568287074378,29,'/warehouse/inventoryreport/supplierorderamount','库存报表-供应商订货金额',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1782,1,1,3455830524591456989,6,'/warehouse/inventoryreport/supplierpricelog','库存报表-供应商价格日志',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1783,1,1,3455830524591456989,19,'/warehouse/inventoryreport/supplierpricelog','库存报表-供应商价格日志',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1784,1,1,3455830524591456989,29,'/warehouse/inventoryreport/supplierpricelog','库存报表-供应商价格日志',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1785,1,1,906285370121016424,6,'/warehouse/inventoryreport/supplier-check-amount','库存报表-供应商对账金额表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1786,1,1,906285370121016424,19,'/warehouse/inventoryreport/supplier-check-amount','库存报表-供应商对账金额表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1787,1,1,906285370121016424,29,'/warehouse/inventoryreport/supplier-check-amount','库存报表-供应商对账金额表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1788,1,1,8190989176117756695,6,'/warehouse/inventoryreport/departmentorderdetails','库存报表-档口订货明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1789,1,1,8190989176117756695,19,'/warehouse/inventoryreport/departmentorderdetails','库存报表-档口订货明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1790,1,1,8190989176117756695,29,'/warehouse/inventoryreport/departmentorderdetails','库存报表-档口订货明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1791,1,1,-7162552362191031161,6,'/warehouse/inventoryreport/deptinoutdetail','库存报表-部门出入库明细表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1792,1,1,-7162552362191031161,19,'/warehouse/inventoryreport/deptinoutdetail','库存报表-部门出入库明细表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1793,1,1,-7162552362191031161,29,'/warehouse/inventoryreport/deptinoutdetail','库存报表-部门出入库明细表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1794,1,1,-4743622061236116194,6,'/warehouse/inventoryreport/goodstypesummary','库存报表-物品类别部门入货统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1795,1,1,-4743622061236116194,19,'/warehouse/inventoryreport/goodstypesummary','库存报表-物品类别部门入货统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1796,1,1,-4743622061236116194,29,'/warehouse/inventoryreport/goodstypesummary','库存报表-物品类别部门入货统计',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1797,1,1,8014492959935471801,6,'/warehouse/inventoryreport/departmentreturndetails','库存报表-档口退货明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1798,1,1,8014492959935471801,19,'/warehouse/inventoryreport/departmentreturndetails','库存报表-档口退货明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1799,1,1,8014492959935471801,29,'/warehouse/inventoryreport/departmentreturndetails','库存报表-档口退货明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1800,1,1,-8861398830934990897,6,'/warehouse/inventoryreport/detailsofgrossprofitofdishes','库存报表-菜品毛利明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1801,1,1,-8861398830934990897,19,'/warehouse/inventoryreport/detailsofgrossprofitofdishes','库存报表-菜品毛利明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1802,1,1,-8861398830934990897,29,'/warehouse/inventoryreport/detailsofgrossprofitofdishes','库存报表-菜品毛利明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1803,1,1,-6833715702939570719,6,'/warehouse/inventoryreport/costbreakdownoifdishes','库存报表-菜品成本明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1804,1,1,-6833715702939570719,19,'/warehouse/inventoryreport/costbreakdownoifdishes','库存报表-菜品成本明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1805,1,1,-6833715702939570719,29,'/warehouse/inventoryreport/costbreakdownoifdishes','库存报表-菜品成本明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1806,1,1,-2969080384801628755,6,'/warehouse/inventoryreport/realtimeinventoryofitems','库存报表-物品实时库存量',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1807,1,1,-2969080384801628755,19,'/warehouse/inventoryreport/realtimeinventoryofitems','库存报表-物品实时库存量',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1808,1,1,-2969080384801628755,29,'/warehouse/inventoryreport/realtimeinventoryofitems','库存报表-物品实时库存量',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1809,1,1,-62481487803163688,6,'/warehouse/inventoryreport/itemdaybook','库存报表-物品流水账',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1810,1,1,-62481487803163688,19,'/warehouse/inventoryreport/itemdaybook','库存报表-物品流水账',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1811,1,1,-62481487803163688,29,'/warehouse/inventoryreport/itemdaybook','库存报表-物品流水账',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1812,1,1,-3998244019445847744,6,'/warehouse/inventoryreport/profitlosssummary','库存报表-盘盈盘亏汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1813,1,1,-3998244019445847744,19,'/warehouse/inventoryreport/profitlosssummary','库存报表-盘盈盘亏汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1814,1,1,-3998244019445847744,29,'/warehouse/inventoryreport/profitlosssummary','库存报表-盘盈盘亏汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1815,1,1,4970797471414406361,6,'/warehouse/inventoryreport/stockwarning','库存报表-库存/保质期预警提醒',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1816,1,1,4970797471414406361,19,'/warehouse/inventoryreport/stockwarning','库存报表-库存/保质期预警提醒',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1817,1,1,4970797471414406361,29,'/warehouse/inventoryreport/stockwarning','库存报表-库存/保质期预警提醒',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1818,1,1,5763798181086528779,6,'/warehouse/inventoryreport/departgrossprofit','库存报表-档口销售毛利汇总表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1819,1,1,5763798181086528779,19,'/warehouse/inventoryreport/departgrossprofit','库存报表-档口销售毛利汇总表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1820,1,1,5763798181086528779,29,'/warehouse/inventoryreport/departgrossprofit','库存报表-档口销售毛利汇总表',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1821,1,1,6194666571144575146,6,'/warehouse/inventoryreport/goodsgrossprofit','库存报表-物品耗用成本分析汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1822,1,1,6194666571144575146,19,'/warehouse/inventoryreport/goodsgrossprofit','库存报表-物品耗用成本分析汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1823,1,1,6194666571144575146,29,'/warehouse/inventoryreport/goodsgrossprofit','库存报表-物品耗用成本分析汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1824,1,1,-6739490352389982816,6,'/warehouse/inventoryreport/billdetail','库存报表-单据信息明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1825,1,1,-6739490352389982816,19,'/warehouse/inventoryreport/billdetail','库存报表-单据信息明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1826,1,1,-6739490352389982816,29,'/warehouse/inventoryreport/billdetail','库存报表-单据信息明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1827,1,1,-8276110567253936352,6,'/warehouse/inventoryreport/billitemdetail','库存报表-单据信息物品明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1828,1,1,-8276110567253936352,19,'/warehouse/inventoryreport/billitemdetail','库存报表-单据信息物品明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1829,1,1,-8276110567253936352,29,'/warehouse/inventoryreport/billitemdetail','库存报表-单据信息物品明细',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1830,1,1,-8972473461619238660,6,'/warehouse/inventoryreport/billitemsummary','库存报表-单据信息物品汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,9,9),(1831,1,1,-8972473461619238660,19,'/warehouse/inventoryreport/billitemsummary','库存报表-单据信息物品汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,10,9),(1832,1,1,-8972473461619238660,29,'/warehouse/inventoryreport/billitemsummary','库存报表-单据信息物品汇总',NULL,NULL,NULL,'2025-10-27 11:11:51',NULL,NULL,0,11,9),(1833,1,1,6869153670758044623,35,'/home','首页',NULL,NULL,NULL,'2025-10-30 15:37:41',NULL,'2025-11-04 12:31:05',0,9,9),(1835,1,1,-5748890659328249781,35,'management','管理',NULL,NULL,NULL,'2025-11-03 11:29:32',NULL,'2025-11-04 12:31:05',0,9,9),(1836,1,1,-4378429075430521834,35,'report','报表',NULL,NULL,NULL,'2025-11-03 12:56:54',NULL,'2025-11-04 12:31:05',0,9,9),(1837,1,1,2603139454418834912,35,'my','我的',NULL,NULL,NULL,'2025-11-03 13:36:58',NULL,'2025-11-04 12:31:05',0,9,9),(1838,1,1,-514872548855960945,37,'home page','首页',NULL,NULL,NULL,'2025-11-03 18:17:56',NULL,'2025-11-04 12:31:05',0,9,9),(1839,1,1,-1903827675580077431,37,'order','订单',NULL,NULL,NULL,'2025-11-03 18:18:17',NULL,'2025-11-04 12:31:05',0,9,9),(1840,1,1,8673702838079830982,37,'inspection','验货',NULL,NULL,NULL,'2025-11-03 18:18:36',NULL,'2025-11-04 12:31:05',0,9,9),(1841,1,1,2603139454418834912,37,'my','我的',NULL,NULL,NULL,'2025-11-03 18:18:46',NULL,'2025-11-04 12:31:05',0,9,9),(1845,1,1,1996050753848463360,6,'/warehouse/inventoryreport','库存报表',NULL,NULL,NULL,'2025-12-03 10:55:59',NULL,NULL,0,9,9),(1846,1,1,1999387705591185408,12,'/mp','门店宝',NULL,NULL,NULL,'2025-12-12 15:55:50',NULL,NULL,1,12,10),(1847,1,1,1999387888030699520,38,'/mp/report','报表',NULL,NULL,NULL,'2025-12-12 15:56:33',NULL,NULL,0,12,10),(1848,1,1,209888664006305406,6,'/warehouse/inventoryreport/pricecomparisontable','库存报表-价格对比表',NULL,NULL,NULL,'2025-12-24 17:53:04',NULL,'2025-12-24 17:53:15',0,9,9),(1849,1,1,2008094673723498496,6,'/warehouse/inventoryreport/orderdiscrepancysummary','库存报表-订货差异订货汇总',NULL,NULL,NULL,'2026-01-05 16:34:13',NULL,NULL,0,9,9),(1850,1,1,-598855477941375071,35,'report_home','报表首页',NULL,NULL,NULL,'2026-01-07 17:05:32',NULL,'2026-01-07 17:06:12',0,9,9),(1851,1,1,5724041942178057731,2,'/admin/approval-manage/approval-center','审批管理-审批中心',NULL,NULL,NULL,'2026-01-07 18:24:29',NULL,'2026-01-07 18:24:48',0,9,9),(1852,1,1,2008847369762828288,2,'/admin/approval-manage/approval-config','审批管理-审批配置',NULL,NULL,NULL,'2026-01-07 18:25:10',NULL,NULL,0,9,9),(1853,1,1,-3544187412379708196,6,'/warehouse/inventoryreport/warehouseprofitlossdetail','库存报表-仓库盘盈盘亏明细',NULL,NULL,NULL,'2026-01-08 14:02:30',NULL,'2026-01-08 14:03:07',0,9,9),(1854,1,1,2009143780765134848,6,'/warehouse/inventoryreport/supplierinoutdetail','库存报表-供应商出入库明细',NULL,NULL,NULL,'2026-01-08 14:03:00',NULL,NULL,0,9,9),(1855,1,1,2016038348336984064,37,'inventory','盘点',NULL,NULL,NULL,'2026-01-27 14:39:33',NULL,NULL,1,9,9),(1856,1,1,-1545937034290874069,8,'/reportformscenter/cashierquery/businessdetailsnew','收银查询-菜品营业明细',NULL,NULL,NULL,'2026-02-09 14:59:12',NULL,'2026-02-09 15:00:17',0,9,9),(1857,1,1,3400659667175220552,8,'/reportformscenter/salesquery/deptsalessummary','销售查询-部门菜品销售汇总',NULL,NULL,NULL,'2026-02-09 19:02:24',NULL,'2026-02-09 19:02:41',0,9,9),(1858,1,1,2027296107670618112,2,'/admin/salesplan','促销方案',NULL,NULL,NULL,'2026-02-27 16:13:52',NULL,NULL,0,9,9),(1859,1,1,2034940059592769536,39,'/group','集团视角权限',NULL,NULL,NULL,'2026-03-20 18:28:12',NULL,NULL,0,9,9),(1860,1,1,2043537829579235328,8,'/reportformscenter/businessstatement/payment-type-summary','营业报表-日收入统计报表',NULL,NULL,NULL,'2026-04-13 11:52:40',NULL,NULL,0,9,9);
/*!40000 ALTER TABLE `permission_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_right`
--

DROP TABLE IF EXISTS `permission_right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_right` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `page_lid` bigint DEFAULT NULL COMMENT '页面编号',
  `code` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '标识符',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `sort_index` int DEFAULT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `view_lid` bigint DEFAULT NULL COMMENT '视角编号',
  `package_lid` bigint DEFAULT NULL COMMENT '权限包编号',
  `module_lid` bigint DEFAULT NULL COMMENT '视角编号',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2500 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='权限资源';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_right`
--

LOCK TABLES `permission_right` WRITE;
/*!40000 ALTER TABLE `permission_right` DISABLE KEYS */;
INSERT INTO `permission_right` VALUES (898,1,1,-2224214089717536138,528,'zc_k_dl_denglu','KDS登录',NULL,NULL,NULL,NULL,NULL,'2025-11-04 12:39:15',0,12,10,13),(899,1,1,6993226415817296264,529,'zc_y_dl_denglu','预定登录',NULL,NULL,NULL,NULL,NULL,'2025-11-04 12:39:15',0,12,10,14),(1292,1,1,643684053535151842,1498,'pt:dish:type:add','新增【菜品类别】',NULL,NULL,NULL,'2025-10-27 16:20:00',NULL,'2025-12-19 13:53:44',0,9,9,2),(1293,1,1,-7300082881444300542,1498,'pt:dish:type:edit','修改【菜品类别】',NULL,NULL,NULL,'2025-10-27 16:20:00',NULL,'2025-12-19 13:53:50',0,9,9,2),(1294,1,1,-985084746710599028,1498,'pt:dish:type:list','查询【菜品类别】',NULL,NULL,NULL,'2025-10-27 16:20:00',NULL,'2025-12-19 13:53:56',0,9,9,2),(1295,1,1,-2043452145054120451,1498,'pt:dish:type:del','删除【菜品类别】',NULL,NULL,NULL,'2025-10-27 16:20:00',NULL,'2025-12-19 13:54:02',0,9,9,2),(1296,1,1,-9169646046558055460,1500,'pt:dish:mng:add','新增【菜品】',NULL,NULL,NULL,'2025-10-27 16:24:22',NULL,'2025-12-19 13:54:39',0,9,9,2),(1297,1,1,-6999955501230783133,1500,'pt:dish:mng:edit','修改【菜品】',NULL,NULL,NULL,'2025-10-27 16:24:22',NULL,'2025-12-19 13:54:59',0,9,9,2),(1298,1,1,2799185211213902673,1500,'pt:dish:mng:list','查询【菜品】',NULL,NULL,NULL,'2025-10-27 16:24:22',NULL,'2025-12-19 13:55:05',0,9,9,2),(1299,1,1,-3699987587631824497,1500,'pt:dish:mng:del','删除【菜品】',NULL,NULL,NULL,'2025-10-27 16:24:22',NULL,'2025-12-19 13:55:12',0,9,9,2),(1300,1,1,543640783701452779,1502,'pt:dish:way:add','新增【做法】',NULL,NULL,NULL,'2025-10-27 16:25:12',NULL,'2025-12-19 13:55:46',0,9,9,2),(1301,1,1,-8174509366144382692,1502,'pt:dish:way:edit','修改【做法】',NULL,NULL,NULL,'2025-10-27 16:25:12',NULL,'2025-12-19 13:55:53',0,9,9,2),(1302,1,1,6393475758304786489,1502,'pt:dish:way:list','查询【做法】',NULL,NULL,NULL,'2025-10-27 16:25:12',NULL,'2025-12-19 13:55:58',0,9,9,2),(1303,1,1,-3764263495237233559,1502,'pt:dish:way:del','删除【做法】',NULL,NULL,NULL,'2025-10-27 16:25:12',NULL,'2025-12-19 13:56:04',0,9,9,2),(1304,1,1,-7787802592752789511,1504,'pt:dish:part:add','新增【菜品部位】',NULL,NULL,NULL,'2025-10-27 16:25:45',NULL,'2025-12-19 13:56:33',0,9,9,2),(1305,1,1,-7599129843315607812,1504,'pt:dish:part:edit','修改【菜品部位】',NULL,NULL,NULL,'2025-10-27 16:25:45',NULL,'2025-12-19 13:56:39',0,9,9,2),(1306,1,1,-892330186596198102,1504,'pt:dish:part:list','查询【菜品部位】',NULL,NULL,NULL,'2025-10-27 16:25:45',NULL,'2025-12-19 13:56:45',0,9,9,2),(1307,1,1,-1291468962847819203,1504,'pt:dish:part:del','删除【菜品部位】',NULL,NULL,NULL,'2025-10-27 16:25:45',NULL,'2025-12-19 13:56:50',0,9,9,2),(1308,1,1,1993593079611888461,1506,'pt:dish:taste:add','新增【口味】',NULL,NULL,NULL,'2025-10-27 16:26:14',NULL,'2025-12-19 13:57:20',0,9,9,2),(1309,1,1,-1346677836250873445,1506,'pt:dish:taste:edit','修改【口味】',NULL,NULL,NULL,'2025-10-27 16:26:14',NULL,'2025-12-19 13:57:26',0,9,9,2),(1310,1,1,-5634549017699355538,1506,'pt:dish:taste:list','查询【口味】',NULL,NULL,NULL,'2025-10-27 16:26:14',NULL,'2025-12-19 13:57:32',0,9,9,2),(1311,1,1,8143222217466045290,1506,'pt:dish:taste:del','删除【口味】',NULL,NULL,NULL,'2025-10-27 16:26:14',NULL,'2025-12-19 13:57:38',0,9,9,2),(1316,1,1,180342994797183000,1508,'pt:data:sync:record:add','新增【菜品同步】',NULL,NULL,NULL,'2025-10-27 16:26:53',NULL,'2025-11-04 12:39:15',0,9,9,2),(1317,1,1,8698576509093420923,1508,'pt:data:sync:record:edit','修改【菜品同步】',NULL,NULL,NULL,'2025-10-27 16:26:53',NULL,'2025-11-04 12:39:15',0,9,9,2),(1318,1,1,2002575489419093974,1508,'pt:data:sync:record:list','查询【菜品同步】',NULL,NULL,NULL,'2025-10-27 16:26:53',NULL,'2025-11-04 12:39:15',0,9,9,2),(1319,1,1,734830445442420555,1508,'pt:data:sync:record:del','删除【菜品同步】',NULL,NULL,NULL,'2025-10-27 16:26:53',NULL,'2025-11-04 12:39:15',0,9,9,2),(1320,1,1,610610196622144850,1510,'pos:dish:hide:add','新增【时段隐藏】',NULL,NULL,NULL,'2025-10-27 16:27:15',NULL,'2025-11-04 12:39:15',0,9,9,2),(1321,1,1,2863992631538399114,1510,'pos:dish:hide:edit','修改【时段隐藏】',NULL,NULL,NULL,'2025-10-27 16:27:15',NULL,'2025-11-04 12:39:15',0,9,9,2),(1322,1,1,3840895171046174706,1510,'pos:dish:hide:list','查询【时段隐藏】',NULL,NULL,NULL,'2025-10-27 16:27:15',NULL,'2025-11-04 12:39:15',0,9,9,2),(1323,1,1,-3584478140062998844,1510,'pos:dish:hide:del','删除【时段隐藏】',NULL,NULL,NULL,'2025-10-27 16:27:15',NULL,'2025-11-04 12:39:15',0,9,9,2),(1324,1,1,2318970093077546237,1512,'pt:festival:add','新增【特殊日期】',NULL,NULL,NULL,'2025-10-27 16:27:37',NULL,'2025-11-04 12:39:15',0,9,9,2),(1325,1,1,-5839896172938998942,1512,'pt:festival:edit','修改【特殊日期】',NULL,NULL,NULL,'2025-10-27 16:27:37',NULL,'2025-11-04 12:39:15',0,9,9,2),(1326,1,1,1869328190592793562,1512,'pt:festival:list','查询【特殊日期】',NULL,NULL,NULL,'2025-10-27 16:27:37',NULL,'2025-11-04 12:39:15',0,9,9,2),(1327,1,1,-8325597191269923634,1512,'pt:festival:del','删除【特殊日期】',NULL,NULL,NULL,'2025-10-27 16:27:37',NULL,'2025-11-04 12:39:15',0,9,9,2),(1328,1,1,-5164131455778282221,1514,'pt:dish:price:special:add','新增【特殊价格】',NULL,NULL,NULL,'2025-10-27 16:34:32',NULL,'2025-11-04 12:39:15',0,9,9,2),(1329,1,1,-3177196149003613130,1514,'pt:dish:price:special:edit','修改【特殊价格】',NULL,NULL,NULL,'2025-10-27 16:34:32',NULL,'2025-11-04 12:39:15',0,9,9,2),(1330,1,1,1080954097826323497,1514,'pt:dish:price:special:list','查询【特殊价格】',NULL,NULL,NULL,'2025-10-27 16:34:32',NULL,'2025-11-04 12:39:15',0,9,9,2),(1331,1,1,-8330169121342267674,1514,'pt:dish:price:special:del','删除【特殊价格】',NULL,NULL,NULL,'2025-10-27 16:34:32',NULL,'2025-11-04 12:39:15',0,9,9,2),(1332,1,1,-5751963226780884314,1516,'pt:dish:order:edit','默认设置',NULL,NULL,NULL,'2025-10-27 16:35:16',NULL,'2025-12-19 13:58:54',0,9,9,2),(1333,1,1,2306530833990968702,1518,'pt:brand:type:add','新增【品牌类库】',NULL,NULL,NULL,'2025-10-27 16:35:51',NULL,'2025-12-19 13:59:36',0,9,9,2),(1334,1,1,792277033799789590,1518,'pt:brand:type:edit','修改【品牌类库】',NULL,NULL,NULL,'2025-10-27 16:35:51',NULL,'2025-12-19 13:59:44',0,9,9,2),(1335,1,1,-3325849483959750952,1518,'pt:brand:type:list','查询【品牌类库】',NULL,NULL,NULL,'2025-10-27 16:35:51',NULL,'2025-12-19 13:59:50',0,9,9,2),(1336,1,1,-6873905127166348175,1518,'pt:brand:type:del','删除【品牌类库】',NULL,NULL,NULL,'2025-10-27 16:35:51',NULL,'2025-12-19 13:59:58',0,9,9,2),(1337,1,1,6236387958016441181,1520,'pt:brand:dish:add','新增【品牌菜品】',NULL,NULL,NULL,'2025-10-27 16:36:05',NULL,'2025-12-19 14:00:25',0,9,9,2),(1338,1,1,-3294780919838503171,1520,'pt:brand:dish:edit','修改【品牌菜品】',NULL,NULL,NULL,'2025-10-27 16:36:05',NULL,'2025-12-19 14:00:31',0,9,9,2),(1339,1,1,-2194166986583179988,1520,'pt:brand:dish:list','查询【品牌菜品】',NULL,NULL,NULL,'2025-10-27 16:36:05',NULL,'2025-12-19 14:00:36',0,9,9,2),(1340,1,1,-4725068676375185292,1520,'pt:brand:dish:del','删除【品牌菜品】',NULL,NULL,NULL,'2025-10-27 16:36:05',NULL,'2025-12-19 14:00:42',0,9,9,2),(1341,1,1,-6720102095806543570,1522,'pt:brand:way:add','新增【品牌做法】',NULL,NULL,NULL,'2025-10-27 16:36:24',NULL,'2025-12-19 14:01:08',0,9,9,2),(1342,1,1,-1210103644553244107,1522,'pt:brand:way:edit','修改【品牌做法】',NULL,NULL,NULL,'2025-10-27 16:36:24',NULL,'2025-12-19 14:01:15',0,9,9,2),(1343,1,1,6256185372504089637,1522,'pt:brand:way:list','查询【品牌做法】',NULL,NULL,NULL,'2025-10-27 16:36:24',NULL,'2025-12-19 14:01:19',0,9,9,2),(1344,1,1,1220849441570494246,1522,'pt:brand:way:del','删除【品牌做法】',NULL,NULL,NULL,'2025-10-27 16:36:24',NULL,'2025-12-19 14:01:24',0,9,9,2),(1345,1,1,-44005494040555968,1524,'pt:brand:part:add','新增【品牌部位】',NULL,NULL,NULL,'2025-10-27 16:36:48',NULL,'2025-12-19 14:01:43',0,9,9,2),(1346,1,1,-9212074161908978805,1524,'pt:brand:part:edit','修改【品牌部位】',NULL,NULL,NULL,'2025-10-27 16:36:48',NULL,'2025-12-19 14:01:48',0,9,9,2),(1347,1,1,-6568774071103286752,1524,'pt:brand:part:list','查询【品牌部位】',NULL,NULL,NULL,'2025-10-27 16:36:48',NULL,'2025-12-19 14:01:53',0,9,9,2),(1348,1,1,1651924066667994861,1524,'pt:brand:part:del','删除【品牌部位】',NULL,NULL,NULL,'2025-10-27 16:36:48',NULL,'2025-12-19 14:01:58',0,9,9,2),(1349,1,1,-107597990861201767,1526,'pt:brand:taste:add','新增【品牌口味】',NULL,NULL,NULL,'2025-10-27 16:37:04',NULL,'2025-12-19 14:02:21',0,9,9,2),(1350,1,1,2968496829012851424,1526,'pt:brand:taste:edit','修改【品牌口味】',NULL,NULL,NULL,'2025-10-27 16:37:04',NULL,'2025-12-19 14:02:28',0,9,9,2),(1351,1,1,-1885913778484779693,1526,'pt:brand:taste:list','查询【品牌口味】',NULL,NULL,NULL,'2025-10-27 16:37:04',NULL,'2025-12-19 14:02:33',0,9,9,2),(1352,1,1,-7677260311033316354,1526,'pt:brand:taste:del','删除【品牌口味】',NULL,NULL,NULL,'2025-10-27 16:37:04',NULL,'2025-12-19 14:02:38',0,9,9,2),(1353,1,1,-926800874257233401,1528,'pos:group:dish:book:add','新增【菜谱方案】',NULL,NULL,NULL,'2025-10-27 16:37:24',NULL,'2025-11-04 12:39:15',0,9,9,2),(1354,1,1,5635105166295103987,1528,'pos:group:dish:book:edit','修改【菜谱方案】',NULL,NULL,NULL,'2025-10-27 16:37:24',NULL,'2025-11-04 12:39:15',0,9,9,2),(1355,1,1,-4291371362747118378,1528,'pos:group:dish:book:list','查询【菜谱方案】',NULL,NULL,NULL,'2025-10-27 16:37:24',NULL,'2025-11-04 12:39:15',0,9,9,2),(1356,1,1,2107260731244327279,1528,'pos:group:dish:book:del','删除【菜谱方案】',NULL,NULL,NULL,'2025-10-27 16:37:24',NULL,'2025-11-04 12:39:15',0,9,9,2),(1357,1,1,4800171016192510005,1530,'pt:tbl:area:add','新增【桌台区域】',NULL,NULL,NULL,'2025-10-27 16:37:40',NULL,'2025-12-19 14:03:44',0,9,9,2),(1358,1,1,-4342437588808232819,1530,'pt:tbl:area:edit','修改【桌台区域】',NULL,NULL,NULL,'2025-10-27 16:37:40',NULL,'2025-12-19 14:03:51',0,9,9,2),(1359,1,1,1966035077063559088,1530,'pt:tbl:area:list','查询【桌台区域】',NULL,NULL,NULL,'2025-10-27 16:37:40',NULL,'2025-12-19 14:03:56',0,9,9,2),(1360,1,1,-8841680687397913657,1530,'pt:tbl:area:del','删除【桌台区域】',NULL,NULL,NULL,'2025-10-27 16:37:40',NULL,'2025-12-19 14:04:02',0,9,9,2),(1361,1,1,4729022080418608108,1532,'pt:tbl:type:add','新增【桌台类型】',NULL,NULL,NULL,'2025-10-27 16:38:09',NULL,'2025-12-19 14:04:21',0,9,9,2),(1362,1,1,-6937130332951784365,1532,'pt:tbl:type:edit','修改【桌台类型】',NULL,NULL,NULL,'2025-10-27 16:38:09',NULL,'2025-12-19 14:04:27',0,9,9,2),(1363,1,1,6799621788864348865,1532,'pt:tbl:type:list','查询【桌台类型】',NULL,NULL,NULL,'2025-10-27 16:38:09',NULL,'2025-12-19 14:04:32',0,9,9,2),(1364,1,1,3325186951927132306,1532,'pt:tbl:type:del','删除【桌台类型】',NULL,NULL,NULL,'2025-10-27 16:38:09',NULL,'2025-12-19 14:04:38',0,9,9,2),(1365,1,1,2209651432178559978,1534,'pt:tbl:add','新增【桌台】',NULL,NULL,NULL,'2025-10-27 16:38:18',NULL,'2025-11-04 12:39:15',0,9,9,2),(1366,1,1,-8988844578990463695,1534,'pt:tbl:edit','修改【桌台】',NULL,NULL,NULL,'2025-10-27 16:38:18',NULL,'2025-11-04 12:39:15',0,9,9,2),(1367,1,1,-5668010514752909968,1534,'pt:tbl:list','查询【桌台】',NULL,NULL,NULL,'2025-10-27 16:38:18',NULL,'2025-11-04 12:39:15',0,9,9,2),(1368,1,1,5706677055870859798,1534,'pt:tbl:del','删除【桌台】',NULL,NULL,NULL,'2025-10-27 16:38:18',NULL,'2025-11-04 12:39:15',0,9,9,2),(1369,1,1,7155170598293319608,1536,'pos:dev:add','新增【计算机】',NULL,NULL,NULL,'2025-10-27 16:38:35',NULL,'2025-11-04 12:39:15',0,9,9,2),(1370,1,1,-6343810586656405937,1536,'pos:dev:edit','修改【计算机】',NULL,NULL,NULL,'2025-10-27 16:38:35',NULL,'2025-11-04 12:39:15',0,9,9,2),(1371,1,1,1370073651787858273,1536,'pos:dev:list','查询【计算机】',NULL,NULL,NULL,'2025-10-27 16:38:35',NULL,'2025-11-04 12:39:15',0,9,9,2),(1372,1,1,1263119543508383218,1536,'pos:dev:del','删除【计算机】',NULL,NULL,NULL,'2025-10-27 16:38:35',NULL,'2025-11-04 12:39:15',0,9,9,2),(1373,1,1,16499132387181050,1536,'pos:prn:printer:add','新增【打印机】',NULL,NULL,NULL,'2025-10-27 16:38:52',NULL,'2025-11-04 12:39:15',0,9,9,2),(1374,1,1,2654473650465843013,1536,'pos:prn:printer:edit','修改【打印机】',NULL,NULL,NULL,'2025-10-27 16:38:52',NULL,'2025-11-04 12:39:15',0,9,9,2),(1375,1,1,6362695987594277460,1536,'pos:prn:printer:list','查询【打印机】',NULL,NULL,NULL,'2025-10-27 16:38:52',NULL,'2025-11-04 12:39:15',0,9,9,2),(1376,1,1,-7905246610201498773,1536,'pos:prn:printer:del','删除【打印机】',NULL,NULL,NULL,'2025-10-27 16:38:52',NULL,'2025-11-04 12:39:15',0,9,9,2),(1377,1,1,-3635849411805320721,1536,'print:job:type:switch:add','新增【打印开关】',NULL,NULL,NULL,'2025-10-27 16:39:08',NULL,'2025-11-04 12:39:15',0,9,9,2),(1378,1,1,-6088999813496741588,1536,'print:job:type:switch:edit','修改【打印开关】',NULL,NULL,NULL,'2025-10-27 16:39:08',NULL,'2025-11-04 12:39:15',0,9,9,2),(1379,1,1,-2501594174028670060,1536,'print:job:type:switch:list','查询【打印开关】',NULL,NULL,NULL,'2025-10-27 16:39:08',NULL,'2025-11-04 12:39:15',0,9,9,2),(1380,1,1,502173229693898303,1536,'print:job:type:switch:del','删除【打印开关】',NULL,NULL,NULL,'2025-10-27 16:39:08',NULL,'2025-11-04 12:39:15',0,9,9,2),(1381,1,1,3600352935854662769,1536,'pos:prn:queue:add','新增【打印队列】',NULL,NULL,NULL,'2025-10-27 16:39:25',NULL,'2025-11-04 12:39:15',0,9,9,2),(1382,1,1,-5033488343353424038,1536,'pos:prn:queue:edit','修改【打印队列】',NULL,NULL,NULL,'2025-10-27 16:39:25',NULL,'2025-11-04 12:39:15',0,9,9,2),(1383,1,1,-4050579776553246902,1536,'pos:prn:queue:list','查询【打印队列】',NULL,NULL,NULL,'2025-10-27 16:39:25',NULL,'2025-11-04 12:39:15',0,9,9,2),(1384,1,1,-8263596553654322696,1536,'pos:prn:queue:del','删除【打印队列】',NULL,NULL,NULL,'2025-10-27 16:39:25',NULL,'2025-11-04 12:39:15',0,9,9,2),(1385,1,1,-4527697296125559727,1536,'pos:dept:add','新增【出品部门】',NULL,NULL,NULL,'2025-10-27 16:39:46',NULL,'2025-11-04 12:39:15',0,9,9,2),(1386,1,1,8071536010348608839,1536,'pos:dept:edit','修改【出品部门】',NULL,NULL,NULL,'2025-10-27 16:39:46',NULL,'2025-11-04 12:39:15',0,9,9,2),(1387,1,1,-4899620959241953250,1536,'pos:dept:list','查询【出品部门】',NULL,NULL,NULL,'2025-10-27 16:39:46',NULL,'2025-11-04 12:39:15',0,9,9,2),(1388,1,1,4410578543210030916,1536,'pos:dept:del','删除【出品部门】',NULL,NULL,NULL,'2025-10-27 16:39:46',NULL,'2025-11-04 12:39:15',0,9,9,2),(1389,1,1,514160008576148075,1536,'pos:waiter:bill:setting:add','新增【传菜间】',NULL,NULL,NULL,'2025-10-27 16:40:07',NULL,'2025-11-04 12:39:15',0,9,9,2),(1390,1,1,5949538916310964604,1536,'pos:waiter:bill:setting:edit','修改【传菜间】',NULL,NULL,NULL,'2025-10-27 16:40:07',NULL,'2025-11-04 12:39:15',0,9,9,2),(1391,1,1,-357384071251760804,1536,'pos:waiter:bill:setting:list','查询【传菜间】',NULL,NULL,NULL,'2025-10-27 16:40:07',NULL,'2025-11-04 12:39:15',0,9,9,2),(1392,1,1,5722639084176254104,1536,'pos:waiter:bill:setting:del','删除【传菜间】',NULL,NULL,NULL,'2025-10-27 16:40:07',NULL,'2025-11-04 12:39:15',0,9,9,2),(1393,1,1,3725834901712851080,1536,'pos:customer:bill:setting:add','新增【客单设置】',NULL,NULL,NULL,'2025-10-27 16:40:27',NULL,'2025-11-04 12:39:15',0,9,9,2),(1394,1,1,2504357122146399732,1536,'pos:customer:bill:setting:edit','修改【客单设置】',NULL,NULL,NULL,'2025-10-27 16:40:27',NULL,'2025-11-04 12:39:15',0,9,9,2),(1395,1,1,-5947690963603063888,1536,'pos:customer:bill:setting:list','查询【客单设置】',NULL,NULL,NULL,'2025-10-27 16:40:27',NULL,'2025-11-04 12:39:15',0,9,9,2),(1396,1,1,-1661811899709944087,1536,'pos:customer:bill:setting:del','删除【客单设置】',NULL,NULL,NULL,'2025-10-27 16:40:27',NULL,'2025-11-04 12:39:15',0,9,9,2),(1397,1,1,3833754812943610193,1536,'pos:prn:style:row:add','新增【打印样式】',NULL,NULL,NULL,'2025-10-27 16:41:03',NULL,'2025-11-04 12:39:15',0,9,9,2),(1398,1,1,-2734271544826210769,1536,'pos:prn:style:row:edit','修改【打印样式】',NULL,NULL,NULL,'2025-10-27 16:41:03',NULL,'2025-11-04 12:39:15',0,9,9,2),(1399,1,1,7726824171896426324,1536,'pos:prn:style:row:list','查询【打印样式】',NULL,NULL,NULL,'2025-10-27 16:41:03',NULL,'2025-11-04 12:39:15',0,9,9,2),(1400,1,1,4099434658298173924,1536,'pos:prn:style:row:del','删除【打印样式】',NULL,NULL,NULL,'2025-10-27 16:41:03',NULL,'2025-11-04 12:39:15',0,9,9,2),(1401,1,1,-5979326150259200685,1538,'biz:business:hours:add','新增【营业市别】',NULL,NULL,NULL,'2025-10-27 16:41:34',NULL,'2025-11-04 12:39:15',0,9,9,2),(1402,1,1,-7026114751027359786,1538,'biz:business:hours:edit','修改【营业市别】',NULL,NULL,NULL,'2025-10-27 16:41:34',NULL,'2025-11-04 12:39:15',0,9,9,2),(1403,1,1,7451464416264543099,1538,'biz:business:hours:list','查询【营业市别】',NULL,NULL,NULL,'2025-10-27 16:41:34',NULL,'2025-11-04 12:39:15',0,9,9,2),(1404,1,1,-3250113786608935640,1538,'biz:business:hours:del','删除【营业市别】',NULL,NULL,NULL,'2025-10-27 16:41:34',NULL,'2025-11-04 12:39:15',0,9,9,2),(1405,1,1,390686704739821540,1540,'biz:discount:add','新增【折扣类型】',NULL,NULL,NULL,'2025-10-27 16:41:50',NULL,'2025-11-04 12:39:15',0,9,9,2),(1406,1,1,-2006449038912359387,1540,'biz:discount:edit','修改【折扣类型】',NULL,NULL,NULL,'2025-10-27 16:41:50',NULL,'2025-11-04 12:39:15',0,9,9,2),(1407,1,1,-6827168379655383501,1540,'biz:discount:list','查询【折扣类型】',NULL,NULL,NULL,'2025-10-27 16:41:50',NULL,'2025-11-04 12:39:15',0,9,9,2),(1408,1,1,-8533760439722581351,1540,'biz:discount:del','删除【折扣类型】',NULL,NULL,NULL,'2025-10-27 16:41:50',NULL,'2025-11-04 12:39:15',0,9,9,2),(1409,1,1,2457822178932526559,1542,'sys:config:data:add','新增【系统参数】',NULL,NULL,NULL,'2025-10-27 16:42:09',NULL,'2025-11-04 12:39:15',0,9,9,2),(1410,1,1,-6552510102039909652,1542,'sys:config:data:edit','修改【系统参数】',NULL,NULL,NULL,'2025-10-27 16:42:09',NULL,'2025-11-04 12:39:15',0,9,9,2),(1411,1,1,8285911637568882979,1542,'sys:config:data:list','查询【系统参数】',NULL,NULL,NULL,'2025-10-27 16:42:09',NULL,'2025-11-04 12:39:15',0,9,9,2),(1412,1,1,-860439218592378083,1542,'sys:config:data:del','删除【系统参数】',NULL,NULL,NULL,'2025-10-27 16:42:09',NULL,'2025-11-04 12:39:15',0,9,9,2),(1413,1,1,-5424956158938909146,1544,'pay:channel:add','新增【支付通道】',NULL,NULL,NULL,'2025-10-27 16:42:31',NULL,'2025-11-04 12:39:15',0,9,9,2),(1414,1,1,-8075664071746085443,1544,'pay:channel:edit','修改【支付通道】',NULL,NULL,NULL,'2025-10-27 16:42:31',NULL,'2025-11-04 12:39:15',0,9,9,2),(1415,1,1,2307561392687821099,1544,'pay:channel:list','查询【支付通道】',NULL,NULL,NULL,'2025-10-27 16:42:31',NULL,'2025-11-04 12:39:15',0,9,9,2),(1416,1,1,1545513753794800054,1544,'pay:channel:del','删除【支付通道】',NULL,NULL,NULL,'2025-10-27 16:42:31',NULL,'2025-11-04 12:39:15',0,9,9,2),(1417,1,1,-1394596401679649698,1546,'credit:purchase:account:add','新增【挂账账号】',NULL,NULL,NULL,'2025-10-27 16:42:49',NULL,'2025-11-04 12:39:15',0,9,9,2),(1418,1,1,5566947405115912772,1546,'credit:purchase:account:edit','修改【挂账账号】',NULL,NULL,NULL,'2025-10-27 16:42:49',NULL,'2025-11-04 12:39:15',0,9,9,2),(1419,1,1,-7615126041798723440,1546,'credit:purchase:account:list','查询【挂账账号】',NULL,NULL,NULL,'2025-10-27 16:42:49',NULL,'2025-11-04 12:39:15',0,9,9,2),(1420,1,1,5827596583529340240,1546,'credit:purchase:account:del','删除【挂账账号】',NULL,NULL,NULL,'2025-10-27 16:42:49',NULL,'2025-11-04 12:39:15',0,9,9,2),(1421,1,1,7155170598293319608,1548,'pos:dev:add','新增【计算机】',NULL,NULL,NULL,'2025-10-27 16:43:12',NULL,'2025-11-04 12:39:15',0,9,9,2),(1422,1,1,-6343810586656405937,1548,'pos:dev:edit','修改【计算机】',NULL,NULL,NULL,'2025-10-27 16:43:12',NULL,'2025-11-04 12:39:15',0,9,9,2),(1423,1,1,1370073651787858273,1548,'pos:dev:list','查询【计算机】',NULL,NULL,NULL,'2025-10-27 16:43:12',NULL,'2025-11-04 12:39:15',0,9,9,2),(1424,1,1,1263119543508383218,1548,'pos:dev:del','删除【计算机】',NULL,NULL,NULL,'2025-10-27 16:43:12',NULL,'2025-11-04 12:39:15',0,9,9,2),(1425,1,1,-5230267777621926361,1550,'sys:brand:add','新增【品牌】',NULL,NULL,NULL,'2025-10-27 16:43:54',NULL,'2025-11-04 12:39:15',0,9,9,2),(1426,1,1,-7586298241126116914,1550,'sys:brand:edit','修改【品牌】',NULL,NULL,NULL,'2025-10-27 16:43:54',NULL,'2025-11-04 12:39:16',0,9,9,2),(1427,1,1,-1918751848111129377,1550,'sys:brand:list','查询【品牌】',NULL,NULL,NULL,'2025-10-27 16:43:54',NULL,'2025-11-04 12:39:16',0,9,9,2),(1428,1,1,4536602654630726784,1550,'sys:brand:del','删除【品牌】',NULL,NULL,NULL,'2025-10-27 16:43:54',NULL,'2025-11-04 12:39:16',0,9,9,2),(1429,1,1,6108983165729454043,1552,'sys:store:add','新增【店铺】',NULL,NULL,NULL,'2025-10-27 16:44:11',NULL,'2025-11-04 12:39:16',0,9,9,2),(1430,1,1,3070417459890473841,1552,'sys:store:edit','修改【店铺】',NULL,NULL,NULL,'2025-10-27 16:44:11',NULL,'2025-11-04 12:39:16',0,9,9,2),(1431,1,1,-3819967688128486785,1552,'sys:store:list','查询【店铺】',NULL,NULL,NULL,'2025-10-27 16:44:11',NULL,'2025-11-04 12:39:16',0,9,9,2),(1432,1,1,6405280811334691664,1552,'sys:store:del','删除【店铺】',NULL,NULL,NULL,'2025-10-27 16:44:11',NULL,'2025-11-04 12:39:16',0,9,9,2),(1433,1,1,-3572947979631387297,1554,'biz:pay:way:add','新增【结账方式】',NULL,NULL,NULL,'2025-10-27 16:44:28',NULL,'2025-11-04 12:39:16',0,9,9,2),(1434,1,1,9038644586898350364,1554,'biz:pay:way:edit','修改【结账方式】',NULL,NULL,NULL,'2025-10-27 16:44:28',NULL,'2025-11-04 12:39:16',0,9,9,2),(1435,1,1,5410167473020587713,1554,'biz:pay:way:list','查询【结账方式】',NULL,NULL,NULL,'2025-10-27 16:44:28',NULL,'2025-11-04 12:39:16',0,9,9,2),(1436,1,1,3274992648137058129,1554,'biz:pay:way:del','删除【结账方式】',NULL,NULL,NULL,'2025-10-27 16:44:28',NULL,'2025-11-04 12:39:16',0,9,9,2),(1437,1,1,-1901042621054222087,1558,'biz:income:type:add','新增【收入科目】',NULL,NULL,NULL,'2025-10-27 16:44:45',NULL,'2025-11-04 12:39:16',0,9,9,2),(1438,1,1,-1307811658342786408,1558,'biz:income:type:edit','修改【收入科目】',NULL,NULL,NULL,'2025-10-27 16:44:45',NULL,'2025-11-04 12:39:16',0,9,9,2),(1439,1,1,-3033337984839847723,1558,'biz:income:type:list','查询【收入科目】',NULL,NULL,NULL,'2025-10-27 16:44:45',NULL,'2025-11-04 12:39:16',0,9,9,2),(1440,1,1,1233612919199448815,1558,'biz:income:type:del','删除【收入科目】',NULL,NULL,NULL,'2025-10-27 16:44:45',NULL,'2025-11-04 12:39:16',0,9,9,2),(1441,1,1,5954956434602514226,1560,'pos:reason:type:add','新增【退增起菜】',NULL,NULL,NULL,'2025-10-27 16:45:12',NULL,'2025-11-04 12:39:16',0,9,9,2),(1442,1,1,-7396802856590781134,1560,'pos:reason:type:edit','修改【退增起菜】',NULL,NULL,NULL,'2025-10-27 16:45:12',NULL,'2025-11-04 12:39:16',0,9,9,2),(1443,1,1,1195324875252343981,1560,'pos:reason:type:list','查询【退增起菜】',NULL,NULL,NULL,'2025-10-27 16:45:12',NULL,'2025-11-04 12:39:16',0,9,9,2),(1444,1,1,7915096491371210916,1560,'pos:reason:type:del','删除【退增起菜】',NULL,NULL,NULL,'2025-10-27 16:45:12',NULL,'2025-11-04 12:39:16',0,9,9,2),(1445,1,1,6068884443763959400,1562,'takeout:aggregation:platform:channel:add','新增【外卖渠道】',NULL,NULL,NULL,'2025-10-27 16:45:33',NULL,'2025-11-04 12:39:16',0,9,9,2),(1446,1,1,145189570541561073,1562,'takeout:aggregation:platform:channel:edit','修改【外卖渠道】',NULL,NULL,NULL,'2025-10-27 16:45:33',NULL,'2025-11-04 12:39:16',0,9,9,2),(1447,1,1,8338240473827432230,1562,'takeout:aggregation:platform:channel:list','查询【外卖渠道】',NULL,NULL,NULL,'2025-10-27 16:45:33',NULL,'2025-11-04 12:39:16',0,9,9,2),(1448,1,1,673816833361951361,1562,'takeout:aggregation:platform:channel:del','删除【外卖渠道】',NULL,NULL,NULL,'2025-10-27 16:45:33',NULL,'2025-11-04 12:39:16',0,9,9,2),(1449,1,1,-4907060914246082327,1564,'biz:user:add','新增【用户】',NULL,NULL,NULL,'2025-10-27 16:45:54',NULL,'2025-11-04 12:39:16',0,9,9,2),(1450,1,1,-3565585818970469584,1564,'biz:user:edit','修改【用户】',NULL,NULL,NULL,'2025-10-27 16:45:54',NULL,'2025-11-04 12:39:16',0,9,9,2),(1451,1,1,4784737283849950370,1564,'biz:user:list','查询【用户】',NULL,NULL,NULL,'2025-10-27 16:45:54',NULL,'2025-11-04 12:39:16',0,9,9,2),(1452,1,1,4509186436194011872,1564,'biz:user:del','删除【用户】',NULL,NULL,NULL,'2025-10-27 16:45:54',NULL,'2025-11-04 12:39:16',0,9,9,2),(1453,1,1,5087718480867755245,1566,'sys:role:add','新增【角色】',NULL,NULL,NULL,'2025-10-27 16:46:08',NULL,'2025-11-04 12:39:16',0,9,9,2),(1454,1,1,1033211673166287132,1566,'sys:role:edit','修改【角色】',NULL,NULL,NULL,'2025-10-27 16:46:08',NULL,'2025-11-04 12:39:16',0,9,9,2),(1455,1,1,-5886635655898104906,1566,'sys:role:list','查询【角色】',NULL,NULL,NULL,'2025-10-27 16:46:08',NULL,'2025-11-04 12:39:16',0,9,9,2),(1456,1,1,-1865103567102364087,1566,'sys:role:del','删除【角色】',NULL,NULL,NULL,'2025-10-27 16:46:08',NULL,'2025-11-04 12:39:16',0,9,9,2),(1457,1,1,1712838954320252182,1568,'biz:sms:config:add','新增【短信设置】',NULL,NULL,NULL,'2025-10-27 16:46:24',NULL,'2025-11-04 12:39:16',0,9,9,2),(1458,1,1,-5532235153908586186,1568,'biz:sms:config:edit','修改【短信设置】',NULL,NULL,NULL,'2025-10-27 16:46:24',NULL,'2025-11-04 12:39:16',0,9,9,2),(1459,1,1,-9151538746946111898,1568,'biz:sms:config:list','查询【短信设置】',NULL,NULL,NULL,'2025-10-27 16:46:24',NULL,'2025-11-04 12:39:16',0,9,9,2),(1460,1,1,-1097244659465353448,1568,'biz:sms:config:del','删除【短信设置】',NULL,NULL,NULL,'2025-10-27 16:46:24',NULL,'2025-11-04 12:39:16',0,9,9,2),(1461,1,1,-4720148778913537242,1570,'biz:sms:msg:style:add','新增【短信模板】',NULL,NULL,NULL,'2025-10-27 16:46:42',NULL,'2025-11-04 12:39:16',0,9,9,2),(1462,1,1,-6339863089181636176,1570,'biz:sms:msg:style:edit','修改【短信模板】',NULL,NULL,NULL,'2025-10-27 16:46:42',NULL,'2025-11-04 12:39:16',0,9,9,2),(1463,1,1,2411946373023604525,1570,'biz:sms:msg:style:list','查询【短信模板】',NULL,NULL,NULL,'2025-10-27 16:46:42',NULL,'2025-11-04 12:39:16',0,9,9,2),(1464,1,1,-224340201813674354,1570,'biz:sms:msg:style:del','删除【短信模板】',NULL,NULL,NULL,'2025-10-27 16:46:42',NULL,'2025-11-04 12:39:16',0,9,9,2),(1465,1,1,7461385703329325938,1572,'sms:send:record:add','新增【短信发送记录】',NULL,NULL,NULL,'2025-10-27 16:46:57',NULL,'2025-11-04 12:39:16',0,9,9,2),(1466,1,1,-3162822440161163866,1572,'sms:send:record:edit','修改【短信发送记录】',NULL,NULL,NULL,'2025-10-27 16:46:57',NULL,'2025-11-04 12:39:16',0,9,9,2),(1467,1,1,-2006678387040876324,1572,'sms:send:record:list','查询【短信发送记录】',NULL,NULL,NULL,'2025-10-27 16:46:57',NULL,'2025-11-04 12:39:16',0,9,9,2),(1468,1,1,-4767049427402328181,1572,'sms:send:record:del','删除【短信发送记录】',NULL,NULL,NULL,'2025-10-27 16:46:57',NULL,'2025-11-04 12:39:16',0,9,9,2),(1469,1,1,8896237457566915407,1574,'invoice:info:store:add','新增【电子发票】',NULL,NULL,NULL,'2025-10-27 16:47:15',NULL,'2025-11-04 12:39:16',0,9,9,2),(1470,1,1,6134187224297060368,1574,'invoice:info:store:edit','修改【电子发票】',NULL,NULL,NULL,'2025-10-27 16:47:15',NULL,'2025-11-04 12:39:16',0,9,9,2),(1471,1,1,6313715054095215026,1574,'invoice:info:store:list','查询【电子发票】',NULL,NULL,NULL,'2025-10-27 16:47:15',NULL,'2025-11-04 12:39:16',0,9,9,2),(1472,1,1,4644211072288704403,1574,'invoice:info:store:del','删除【电子发票】',NULL,NULL,NULL,'2025-10-27 16:47:15',NULL,'2025-11-04 12:39:16',0,9,9,2),(1473,1,1,191628482630456717,1576,'invoice:add','新增【发票】',NULL,NULL,NULL,'2025-10-27 16:47:30',NULL,'2025-11-04 12:39:16',0,9,9,2),(1474,1,1,6701521850684204745,1576,'invoice:edit','修改【发票】',NULL,NULL,NULL,'2025-10-27 16:47:30',NULL,'2025-11-04 12:39:16',0,9,9,2),(1475,1,1,8393547511898301120,1576,'invoice:list','查询【发票】',NULL,NULL,NULL,'2025-10-27 16:47:30',NULL,'2025-11-04 12:39:16',0,9,9,2),(1476,1,1,-7748130091823135741,1576,'invoice:del','删除【发票】',NULL,NULL,NULL,'2025-10-27 16:47:30',NULL,'2025-11-04 12:39:16',0,9,9,2),(1481,1,1,4090135179775133400,1578,'crm:card:type:add','新增【会员卡类型】',NULL,NULL,NULL,'2025-10-27 16:49:06',NULL,'2025-11-04 12:39:16',0,9,9,3),(1482,1,1,6158108573934221771,1578,'crm:card:type:edit','修改【会员卡类型】',NULL,NULL,NULL,'2025-10-27 16:49:06',NULL,'2025-11-04 12:39:16',0,9,9,3),(1483,1,1,6573195615028437695,1578,'crm:card:type:list','查询【会员卡类型】',NULL,NULL,NULL,'2025-10-27 16:49:06',NULL,'2025-11-04 12:39:16',0,9,9,3),(1484,1,1,-5163195218044499068,1578,'crm:card:type:del','删除【会员卡类型】',NULL,NULL,NULL,'2025-10-27 16:49:06',NULL,'2025-11-04 12:39:16',0,9,9,3),(1485,1,1,-3405683294078281844,1578,'crm:member:add','新增【会员档案】',NULL,NULL,NULL,'2025-10-27 16:49:22',NULL,'2025-11-04 12:39:16',0,9,9,3),(1486,1,1,6643984923456993442,1578,'crm:member:edit','修改【会员档案】',NULL,NULL,NULL,'2025-10-27 16:49:22',NULL,'2025-11-04 12:39:16',0,9,9,3),(1487,1,1,2022114034410762429,1578,'crm:member:list','查询【会员档案】',NULL,NULL,NULL,'2025-10-27 16:49:22',NULL,'2025-11-04 12:39:16',0,9,9,3),(1488,1,1,4901700201790471112,1578,'crm:member:del','删除【会员档案】',NULL,NULL,NULL,'2025-10-27 16:49:22',NULL,'2025-11-04 12:39:16',0,9,9,3),(1489,1,1,1810828605532019177,1585,'crm:new:gift:add','新增【新人礼包】',NULL,NULL,NULL,'2025-10-27 16:50:18',NULL,'2025-11-04 12:39:16',0,9,9,3),(1490,1,1,-6086540387782493137,1585,'crm:new:gift:edit','修改【新人礼包】',NULL,NULL,NULL,'2025-10-27 16:50:18',NULL,'2025-11-04 12:39:16',0,9,9,3),(1491,1,1,-3249972357714105746,1585,'crm:new:gift:list','查询【新人礼包】',NULL,NULL,NULL,'2025-10-27 16:50:18',NULL,'2025-11-04 12:39:16',0,9,9,3),(1492,1,1,-1593288949174887013,1585,'crm:new:gift:del','删除【新人礼包】',NULL,NULL,NULL,'2025-10-27 16:50:18',NULL,'2025-11-04 12:39:16',0,9,9,3),(1493,1,1,-6695965383139091620,1585,'crm:red:envelope:add','新增【红包活动】',NULL,NULL,NULL,'2025-10-27 16:50:38',NULL,'2025-11-04 12:39:16',0,9,9,3),(1494,1,1,2272459239233173597,1585,'crm:red:envelope:edit','修改【红包活动】',NULL,NULL,NULL,'2025-10-27 16:50:38',NULL,'2025-11-04 12:39:16',0,9,9,3),(1495,1,1,5143183040983660540,1585,'crm:red:envelope:list','查询【红包活动】',NULL,NULL,NULL,'2025-10-27 16:50:38',NULL,'2025-11-04 12:39:16',0,9,9,3),(1496,1,1,2080749310481788459,1585,'crm:red:envelope:del','删除【红包活动】',NULL,NULL,NULL,'2025-10-27 16:50:38',NULL,'2025-11-04 12:39:16',0,9,9,3),(1497,1,1,1630374193365134959,1585,'crm:join:activity:add','新增【续费奖励】',NULL,NULL,NULL,'2025-10-27 16:51:04',NULL,'2025-11-04 12:39:16',0,9,9,3),(1498,1,1,747216715091984499,1585,'crm:join:activity:edit','修改【续费奖励】',NULL,NULL,NULL,'2025-10-27 16:51:04',NULL,'2025-11-04 12:39:16',0,9,9,3),(1499,1,1,7882848007264190317,1585,'crm:join:activity:list','查询【续费奖励】',NULL,NULL,NULL,'2025-10-27 16:51:04',NULL,'2025-11-04 12:39:16',0,9,9,3),(1500,1,1,2883009196330701793,1585,'crm:join:activity:del','删除【续费奖励】',NULL,NULL,NULL,'2025-10-27 16:51:04',NULL,'2025-11-04 12:39:16',0,9,9,3),(1501,1,1,1163458804569095133,1585,'crm:coupon:add','新增【券包管理】',NULL,NULL,NULL,'2025-10-27 16:51:25',NULL,'2025-11-04 12:39:16',0,9,9,3),(1502,1,1,-7822155652378268224,1585,'crm:coupon:edit','修改【券包管理】',NULL,NULL,NULL,'2025-10-27 16:51:25',NULL,'2025-11-04 12:39:16',0,9,9,3),(1503,1,1,-2901860853109867360,1585,'crm:coupon:list','查询【券包管理】',NULL,NULL,NULL,'2025-10-27 16:51:25',NULL,'2025-11-04 12:39:16',0,9,9,3),(1504,1,1,7395843329357128061,1585,'crm:coupon:del','删除【券包管理】',NULL,NULL,NULL,'2025-10-27 16:51:25',NULL,'2025-11-04 12:39:16',0,9,9,3),(1505,1,1,6993346398780083730,1585,'crm:invitation:reward:add','新增【邀请有礼】',NULL,NULL,NULL,'2025-10-27 16:51:41',NULL,'2025-11-04 12:39:16',0,9,9,3),(1506,1,1,2852818207497480401,1585,'crm:invitation:reward:edit','修改【邀请有礼】',NULL,NULL,NULL,'2025-10-27 16:51:41',NULL,'2025-11-04 12:39:16',0,9,9,3),(1507,1,1,-2608717375284976116,1585,'crm:invitation:reward:list','查询【邀请有礼】',NULL,NULL,NULL,'2025-10-27 16:51:41',NULL,'2025-11-04 12:39:16',0,9,9,3),(1508,1,1,-4451039539519778427,1585,'crm:invitation:reward:del','删除【邀请有礼】',NULL,NULL,NULL,'2025-10-27 16:51:41',NULL,'2025-11-04 12:39:16',0,9,9,3),(1509,1,1,5079761948952767086,1585,'crm:festival:add','新增【节假日】',NULL,NULL,NULL,'2025-10-27 16:52:02',NULL,'2025-11-04 12:39:16',0,9,9,3),(1510,1,1,-7079276232543866287,1585,'crm:festival:edit','修改【节假日】',NULL,NULL,NULL,'2025-10-27 16:52:02',NULL,'2025-11-04 12:39:16',0,9,9,3),(1511,1,1,9220237525363995741,1585,'crm:festival:list','查询【节假日】',NULL,NULL,NULL,'2025-10-27 16:52:02',NULL,'2025-11-04 12:39:16',0,9,9,3),(1512,1,1,-1919146300234233860,1585,'crm:festival:del','删除【节假日】',NULL,NULL,NULL,'2025-10-27 16:52:02',NULL,'2025-11-04 12:39:16',0,9,9,3),(1513,1,1,-6975910182837304781,1585,'crm:actuator:add','新增【批量充值】',NULL,NULL,NULL,'2025-10-27 16:52:26',NULL,'2025-11-04 12:39:16',0,9,9,3),(1514,1,1,1872900796593220665,1585,'crm:actuator:edit','修改【批量充值】',NULL,NULL,NULL,'2025-10-27 16:52:26',NULL,'2025-11-04 12:39:16',0,9,9,3),(1515,1,1,-7877752491021337774,1585,'crm:actuator:list','查询【批量充值】',NULL,NULL,NULL,'2025-10-27 16:52:26',NULL,'2025-11-04 12:39:16',0,9,9,3),(1516,1,1,-3983464251475469331,1585,'crm:actuator:del','删除【批量充值】',NULL,NULL,NULL,'2025-10-27 16:52:26',NULL,'2025-11-04 12:39:16',0,9,9,3),(1517,1,1,-1508023938513420051,1585,'crm:shareholder:add','新增【共享会员】',NULL,NULL,NULL,'2025-10-27 16:52:46',NULL,'2025-11-04 12:39:16',0,9,9,3),(1518,1,1,449546077480291766,1585,'crm:shareholder:edit','修改【共享会员】',NULL,NULL,NULL,'2025-10-27 16:52:46',NULL,'2025-11-04 12:39:16',0,9,9,3),(1519,1,1,-5242860080407107227,1585,'crm:shareholder:list','查询【共享会员】',NULL,NULL,NULL,'2025-10-27 16:52:46',NULL,'2025-11-04 12:39:16',0,9,9,3),(1520,1,1,1815406705126320796,1585,'crm:shareholder:del','删除【共享会员】',NULL,NULL,NULL,'2025-10-27 16:52:46',NULL,'2025-11-04 12:39:16',0,9,9,3),(1521,1,1,-3986947047189232719,1585,'crm:reward:rule:add','新增【打赏】',NULL,NULL,NULL,'2025-10-27 16:53:05',NULL,'2025-11-04 12:39:16',0,9,9,3),(1522,1,1,-5782532679628964968,1585,'crm:reward:rule:edit','修改【打赏】',NULL,NULL,NULL,'2025-10-27 16:53:05',NULL,'2025-11-04 12:39:16',0,9,9,3),(1523,1,1,3719893227184960763,1585,'crm:reward:rule:list','查询【打赏】',NULL,NULL,NULL,'2025-10-27 16:53:05',NULL,'2025-11-04 12:39:16',0,9,9,3),(1524,1,1,-3600895270788250381,1585,'crm:reward:rule:del','删除【打赏】',NULL,NULL,NULL,'2025-10-27 16:53:05',NULL,'2025-11-04 12:39:16',0,9,9,3),(1525,1,1,-3203739414637976934,1596,'crm:point:exchange:add','新增【积分兑换】',NULL,NULL,NULL,'2025-10-27 16:53:25',NULL,'2025-11-04 12:39:16',0,9,9,3),(1526,1,1,-2767557881630954745,1596,'crm:point:exchange:edit','修改【积分兑换】',NULL,NULL,NULL,'2025-10-27 16:53:25',NULL,'2025-11-04 12:39:16',0,9,9,3),(1527,1,1,1824275241810205529,1596,'crm:point:exchange:list','查询【积分兑换】',NULL,NULL,NULL,'2025-10-27 16:53:25',NULL,'2025-11-04 12:39:16',0,9,9,3),(1528,1,1,-4714947875780749489,1596,'crm:point:exchange:del','删除【积分兑换】',NULL,NULL,NULL,'2025-10-27 16:53:25',NULL,'2025-11-04 12:39:16',0,9,9,3),(1529,1,1,-4207227121936675574,1598,'crm:save:rule:add','新增【充值套餐】',NULL,NULL,NULL,'2025-10-27 16:53:47',NULL,'2025-11-04 12:39:16',0,9,9,3),(1530,1,1,6235421473000626022,1598,'crm:save:rule:edit','修改【充值套餐】',NULL,NULL,NULL,'2025-10-27 16:53:47',NULL,'2025-11-04 12:39:16',0,9,9,3),(1531,1,1,4093943486142898379,1598,'crm:save:rule:list','查询【充值套餐】',NULL,NULL,NULL,'2025-10-27 16:53:47',NULL,'2025-11-04 12:39:16',0,9,9,3),(1532,1,1,-589805086076080922,1598,'crm:save:rule:del','删除【充值套餐】',NULL,NULL,NULL,'2025-10-27 16:53:47',NULL,'2025-11-04 12:39:16',0,9,9,3),(1533,1,1,2540635119286455170,1598,'crm:cash:back:add','新增【消费返现】',NULL,NULL,NULL,'2025-10-27 16:54:09',NULL,'2025-11-04 12:39:16',0,9,9,3),(1534,1,1,-1344734344017758975,1598,'crm:cash:back:edit','修改【消费返现】',NULL,NULL,NULL,'2025-10-27 16:54:09',NULL,'2025-11-04 12:39:16',0,9,9,3),(1535,1,1,203582636167638248,1598,'crm:cash:back:list','查询【消费返现】',NULL,NULL,NULL,'2025-10-27 16:54:09',NULL,'2025-11-04 12:39:16',0,9,9,3),(1536,1,1,8813504359742223885,1598,'crm:cash:back:del','删除【消费返现】',NULL,NULL,NULL,'2025-10-27 16:54:09',NULL,'2025-11-04 12:39:16',0,9,9,3),(1537,1,1,-7402143321831140387,1598,'crm:card:level:and:more:recharge:add','新增【智能推荐】',NULL,NULL,NULL,'2025-10-27 16:54:30',NULL,'2025-11-04 12:39:16',0,9,9,3),(1538,1,1,-2938111971864348924,1598,'crm:card:level:and:more:recharge:edit','修改【智能推荐】',NULL,NULL,NULL,'2025-10-27 16:54:30',NULL,'2025-11-04 12:39:16',0,9,9,3),(1539,1,1,4789897527416533023,1598,'crm:card:level:and:more:recharge:list','查询【智能推荐】',NULL,NULL,NULL,'2025-10-27 16:54:30',NULL,'2025-11-04 12:39:16',0,9,9,3),(1540,1,1,1322401837295962646,1598,'crm:card:level:and:more:recharge:del','删除【智能推荐】',NULL,NULL,NULL,'2025-10-27 16:54:30',NULL,'2025-11-04 12:39:16',0,9,9,3),(1541,1,1,2674842784819682215,1598,'crm:card:level:and:overlord:meal:add','新增【霸王餐】',NULL,NULL,NULL,'2025-10-27 16:54:44',NULL,'2025-11-04 12:39:16',0,9,9,3),(1542,1,1,-2311396703846505452,1598,'crm:card:level:and:overlord:meal:edit','修改【霸王餐】',NULL,NULL,NULL,'2025-10-27 16:54:44',NULL,'2025-11-04 12:39:16',0,9,9,3),(1543,1,1,-3004856219631269010,1598,'crm:card:level:and:overlord:meal:list','查询【霸王餐】',NULL,NULL,NULL,'2025-10-27 16:54:44',NULL,'2025-11-04 12:39:16',0,9,9,3),(1544,1,1,7773849438327339849,1598,'crm:card:level:and:overlord:meal:del','删除【霸王餐】',NULL,NULL,NULL,'2025-10-27 16:54:44',NULL,'2025-11-04 12:39:16',0,9,9,3),(1545,1,1,-2856942574174400734,1598,'crm:consumption:coupon:rule:add','新增【消费赠券】',NULL,NULL,NULL,'2025-10-27 16:54:58',NULL,'2025-11-04 12:39:16',0,9,9,3),(1546,1,1,6728454817220151918,1598,'crm:consumption:coupon:rule:edit','修改【消费赠券】',NULL,NULL,NULL,'2025-10-27 16:54:58',NULL,'2025-11-04 12:39:16',0,9,9,3),(1547,1,1,8739460447238029175,1598,'crm:consumption:coupon:rule:list','查询【消费赠券】',NULL,NULL,NULL,'2025-10-27 16:54:58',NULL,'2025-11-04 12:39:16',0,9,9,3),(1548,1,1,-3706599081452625238,1598,'crm:consumption:coupon:rule:del','删除【消费赠券】',NULL,NULL,NULL,'2025-10-27 16:54:58',NULL,'2025-11-04 12:39:16',0,9,9,3),(1549,1,1,-2832165271240966338,1598,'crm:large:turntable:add','新增【大转盘】',NULL,NULL,NULL,'2025-10-27 16:55:12',NULL,'2025-11-04 12:39:16',0,9,9,3),(1550,1,1,-2760858497404184779,1598,'crm:large:turntable:edit','修改【大转盘】',NULL,NULL,NULL,'2025-10-27 16:55:12',NULL,'2025-11-04 12:39:16',0,9,9,3),(1551,1,1,-1862839350561367643,1598,'crm:large:turntable:list','查询【大转盘】',NULL,NULL,NULL,'2025-10-27 16:55:12',NULL,'2025-11-04 12:39:16',0,9,9,3),(1552,1,1,-2360024446149560294,1598,'crm:large:turntable:del','删除【大转盘】',NULL,NULL,NULL,'2025-10-27 16:55:12',NULL,'2025-11-04 12:39:16',0,9,9,3),(1553,1,1,5896657656172545778,1598,'crm:birthday:rule:add','新增【生日赠券】',NULL,NULL,NULL,'2025-10-27 16:55:29',NULL,'2025-11-04 12:39:16',0,9,9,3),(1554,1,1,-933891469121940601,1598,'crm:birthday:rule:edit','修改【生日赠券】',NULL,NULL,NULL,'2025-10-27 16:55:29',NULL,'2025-11-04 12:39:16',0,9,9,3),(1555,1,1,-6435378857525780920,1598,'crm:birthday:rule:list','查询【生日赠券】',NULL,NULL,NULL,'2025-10-27 16:55:29',NULL,'2025-11-04 12:39:16',0,9,9,3),(1556,1,1,3327814310456962043,1598,'crm:birthday:rule:del','删除【生日赠券】',NULL,NULL,NULL,'2025-10-27 16:55:29',NULL,'2025-11-04 12:39:16',0,9,9,3),(1557,1,1,6108983165729454043,1623,'sys:store:add','新增【门店/配送中心】',NULL,NULL,NULL,'2025-10-27 17:03:04',NULL,'2025-11-04 12:39:16',0,9,9,6),(1558,1,1,3070417459890473841,1623,'sys:store:edit','修改【门店/配送中心】',NULL,NULL,NULL,'2025-10-27 17:03:04',NULL,'2025-11-04 12:39:16',0,9,9,6),(1559,1,1,-3819967688128486785,1623,'sys:store:list','查询【门店/配送中心】',NULL,NULL,NULL,'2025-10-27 17:03:04',NULL,'2025-11-04 12:39:16',0,9,9,6),(1560,1,1,6405280811334691664,1623,'sys:store:del','删除【门店/配送中心】',NULL,NULL,NULL,'2025-10-27 17:03:04',NULL,'2025-11-04 12:39:16',0,9,9,6),(1561,1,1,-3423507329709100954,1623,'sc:warehouse:add','新增【仓库】',NULL,NULL,NULL,'2025-10-27 17:03:21',NULL,'2025-11-04 12:39:16',0,9,9,6),(1562,1,1,-4436507328422958673,1623,'sc:warehouse:edit','修改【仓库】',NULL,NULL,NULL,'2025-10-27 17:03:21',NULL,'2025-11-04 12:39:16',0,9,9,6),(1563,1,1,-7932403101716593625,1623,'sc:warehouse:list','查询【仓库】',NULL,NULL,NULL,'2025-10-27 17:03:21',NULL,'2025-11-04 12:39:16',0,9,9,6),(1564,1,1,-558926377244303395,1623,'sc:warehouse:del','删除【仓库】',NULL,NULL,NULL,'2025-10-27 17:03:21',NULL,'2025-11-04 12:39:16',0,9,9,6),(1565,1,1,-8254919346629517236,1635,'sc:supplier:add','新增【供应商】',NULL,NULL,NULL,'2025-10-27 17:03:50',NULL,'2025-11-04 12:39:16',0,9,9,6),(1566,1,1,3144747004858023810,1635,'sc:supplier:edit','修改【供应商】',NULL,NULL,NULL,'2025-10-27 17:03:50',NULL,'2025-11-04 12:39:16',0,9,9,6),(1567,1,1,4890851788694820321,1635,'sc:supplier:list','查询【供应商】',NULL,NULL,NULL,'2025-10-27 17:03:50',NULL,'2025-11-04 12:39:16',0,9,9,6),(1568,1,1,-39359378499798758,1635,'sc:supplier:del','删除【供应商】',NULL,NULL,NULL,'2025-10-27 17:03:50',NULL,'2025-11-04 12:39:16',0,9,9,6),(1569,1,1,9053495442316387441,1638,'wms:label:unit:add','新增【单位标签】',NULL,NULL,NULL,'2025-10-27 17:04:10',NULL,'2025-11-04 12:39:16',0,9,9,6),(1570,1,1,-7152825306888654853,1638,'wms:label:unit:edit','修改【单位标签】',NULL,NULL,NULL,'2025-10-27 17:04:10',NULL,'2025-11-04 12:39:16',0,9,9,6),(1571,1,1,3269939119282795115,1638,'wms:label:unit:list','查询【单位标签】',NULL,NULL,NULL,'2025-10-27 17:04:10',NULL,'2025-11-04 12:39:16',0,9,9,6),(1572,1,1,7970860176463847537,1638,'wms:label:unit:del','删除【单位标签】',NULL,NULL,NULL,'2025-10-27 17:04:10',NULL,'2025-11-04 12:39:16',0,9,9,6),(1573,1,1,-1745080206100126261,1641,'sc:goods:type:add','新增【物品类别】',NULL,NULL,NULL,'2025-10-27 17:04:24',NULL,'2025-11-04 12:39:16',0,9,9,6),(1574,1,1,-2560260987398903731,1641,'sc:goods:type:edit','修改【物品类别】',NULL,NULL,NULL,'2025-10-27 17:04:24',NULL,'2025-11-04 12:39:16',0,9,9,6),(1575,1,1,3114508781716499496,1641,'sc:goods:type:list','查询【物品类别】',NULL,NULL,NULL,'2025-10-27 17:04:24',NULL,'2025-11-04 12:39:16',0,9,9,6),(1576,1,1,-6902494635858196195,1641,'sc:goods:type:del','删除【物品类别】',NULL,NULL,NULL,'2025-10-27 17:04:24',NULL,'2025-11-04 12:39:16',0,9,9,6),(1577,1,1,1520063526988913378,1644,'sc:goods:add','新增【物品】',NULL,NULL,NULL,'2025-10-27 17:04:37',NULL,'2025-11-04 12:39:16',0,9,9,6),(1578,1,1,1265977891417915763,1644,'sc:goods:edit','修改【物品】',NULL,NULL,NULL,'2025-10-27 17:04:37',NULL,'2025-11-04 12:39:16',0,9,9,6),(1579,1,1,2298800027341347643,1644,'sc:goods:list','查询【物品】',NULL,NULL,NULL,'2025-10-27 17:04:37',NULL,'2025-11-04 12:39:16',0,9,9,6),(1580,1,1,-4244767785288820477,1644,'sc:goods:del','删除【物品】',NULL,NULL,NULL,'2025-10-27 17:04:37',NULL,'2025-11-04 12:39:16',0,9,9,6),(1581,1,1,-3423507329709100954,1647,'sc:warehouse:add','新增【仓库】',NULL,NULL,NULL,'2025-10-27 17:04:55',NULL,'2025-11-04 12:39:16',0,9,9,6),(1582,1,1,-4436507328422958673,1647,'sc:warehouse:edit','修改【仓库】',NULL,NULL,NULL,'2025-10-27 17:04:55',NULL,'2025-11-04 12:39:16',0,9,9,6),(1583,1,1,-7932403101716593625,1647,'sc:warehouse:list','查询【仓库】',NULL,NULL,NULL,'2025-10-27 17:04:55',NULL,'2025-11-04 12:39:16',0,9,9,6),(1584,1,1,-558926377244303395,1647,'sc:warehouse:del','删除【仓库】',NULL,NULL,NULL,'2025-10-27 17:04:55',NULL,'2025-11-04 12:39:16',0,9,9,6),(1585,1,1,-7736540504716829313,1650,'sc:delivery:rule:add','新增【配送规则】',NULL,NULL,NULL,'2025-10-27 17:05:11',NULL,'2025-11-04 12:39:16',0,9,9,6),(1586,1,1,8724756198067320696,1650,'sc:delivery:rule:edit','修改【配送规则】',NULL,NULL,NULL,'2025-10-27 17:05:11',NULL,'2025-11-04 12:39:16',0,9,9,6),(1587,1,1,3481056098232389267,1650,'sc:delivery:rule:list','查询【配送规则】',NULL,NULL,NULL,'2025-10-27 17:05:11',NULL,'2025-11-04 12:39:16',0,9,9,6),(1588,1,1,-623899824497308953,1650,'sc:delivery:rule:del','删除【配送规则】',NULL,NULL,NULL,'2025-10-27 17:05:11',NULL,'2025-11-04 12:39:16',0,9,9,6),(1601,1,1,-895457890776189859,1665,'sc:st:bill:add','新增【仓库单据】',NULL,NULL,NULL,'2025-10-27 17:09:09',NULL,'2025-11-04 12:39:16',0,9,9,6),(1602,1,1,-230881487372112948,1665,'sc:st:bill:edit','修改【仓库单据】',NULL,NULL,NULL,'2025-10-27 17:09:09',NULL,'2025-11-04 12:39:16',0,9,9,6),(1603,1,1,-3337023914157320697,1665,'sc:st:bill:list','查询【仓库单据】',NULL,NULL,NULL,'2025-10-27 17:09:09',NULL,'2025-11-04 12:39:16',0,9,9,6),(1604,1,1,6218996874994285628,1665,'sc:st:bill:del','删除【仓库单据】',NULL,NULL,NULL,'2025-10-27 17:09:09',NULL,'2025-11-04 12:39:16',0,9,9,6),(1605,1,1,6823924140003331468,1668,'sc:stock:snapshot:of:month:add','新增【月末结账】',NULL,NULL,NULL,'2025-10-27 17:09:27',NULL,'2025-11-04 12:39:17',0,9,9,6),(1606,1,1,-871484839640688339,1668,'sc:stock:snapshot:of:month:edit','修改【月末结账】',NULL,NULL,NULL,'2025-10-27 17:09:27',NULL,'2025-11-04 12:39:17',0,9,9,6),(1607,1,1,-3651746796565225641,1668,'sc:stock:snapshot:of:month:list','查询【月末结账】',NULL,NULL,NULL,'2025-10-27 17:09:27',NULL,'2025-11-04 12:39:17',0,9,9,6),(1608,1,1,-967558688245084309,1668,'sc:stock:snapshot:of:month:del','删除【月末结账】',NULL,NULL,NULL,'2025-10-27 17:09:27',NULL,'2025-11-04 12:39:17',0,9,9,6),(1609,1,1,8942411248386954410,1200,'cashierquery/billsummary','查看【收银查询-收银明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1610,1,1,-4468723939052602328,1201,'cashierquery/billAuditSummary','查看【收银查询-账单稽核明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1611,1,1,7421586041726971950,1202,'cashierquery/cashiersummary','查看【收银查询-收银汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1612,1,1,2097165956332311926,1203,'cashierquery/revenuecomposition','查看【收银查询-收入构成】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1613,1,1,-1151805199313577397,1204,'cashierquery/businessdetailsnew','查看【收银查询-营业明细_新】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1614,1,1,3227646357356378644,1205,'cashierquery/sumofdailybusinessdata','查看【收银查询-日营业数据汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1615,1,1,-3933731336001478651,1206,'cashierquery/reversecheckoutrecord','查看【收银查询-反结账记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1616,1,1,-2528981686406953771,1207,'cashierquery/creditsummary','查看【收银查询-挂账账目汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1617,1,1,3664669290596051717,1208,'jdy/query-bill','查看【金蝶云报表-账单-账单查询】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1618,1,1,3171876808052607324,1209,'jdy/query-bill-food','查看【金蝶云报表-账单-账单食品查询】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1619,1,1,-1689165440479153165,1210,'jdy/query-settle-detail','查看【金蝶云报表-账单-结算明细表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1620,1,1,-7372077367851006071,1211,'jdy/cashier-detail','查看【金蝶云报表-财务报表-收银明细表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1621,1,1,-1801007309401303134,1212,'jdy/cashier-summary','查看【金蝶云报表-财务报表-收银汇总表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1622,1,1,-8557935786444401229,1213,'jdy/business-summary','查看【金蝶云报表-营业报表-营业汇总表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1623,1,1,-2771580380012606404,1214,'jdy/business-overview','查看【金蝶云报表-营业报表-营业概况一览】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1624,1,1,-8474121004611176487,1215,'jdy/clear-machine-shift','查看【金蝶云报表-营业报表-清机转更表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1625,1,1,-2738852166440984422,1216,'jdy/food-sale-summary','查看【金蝶云报表-营业报表-食品销售汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1626,1,1,6386147398707499748,1217,'jdy/food-sale-detail','查看【金蝶云报表-营业报表-食品销售明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1627,1,1,-4614608852747262735,1218,'jdy/food-sale-rank','查看【金蝶云报表-营业报表-食品销售排行】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1628,1,1,-1274971679523153837,1219,'jdy/food-cancel-and-send-summary','查看【金蝶云报表-营业报表-食品取消/招待汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1629,1,1,3719324312409889518,1220,'jdy/food-cancel-and-send-detail','查看【金蝶云报表-营业报表-食品取消/招待明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1630,1,1,-2835463423163051150,1221,'jdy/food-category-sale-summary','查看【金蝶云报表-食品报表-食品类别营业汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1631,1,1,6947119410993793752,1222,'jdy/food-category-sale-detail','查看【金蝶云报表-食品报表-食品类别营业明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1632,1,1,6644372774750703346,1223,'periodmealsegment/cashierofshiftmealsection','查看【时段餐段-班次餐段收银】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1633,1,1,-3242026925718100620,1224,'periodmealsegment/analysisofperiodclosingconsumption','查看【时段餐段-时段结账消费分析】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1634,1,1,-5852910367203364237,1225,'periodmealsegment/analysisofperiodopeningconsumption','查看【时段餐段-时段开台消费分析】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1635,1,1,-220858591363508895,1226,'regionaltable/roomandplatformstatistics','查看【区域桌台-区域桌台统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1636,1,1,-7203099729893171809,1227,'regionaltable/regionalbusinessstatistics','查看【区域桌台-区域营业统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1637,1,1,1481176937640306757,1228,'comprehensiveanalysis/dailybusinessreport','查看【综合分析-营业情况日报】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1638,1,1,-723139399626634429,1229,'comprehensiveanalysis/monthlysummary','查看【综合分析-月度汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1639,1,1,4446129180561550975,1230,'comprehensiveanalysis/datesummary','查看【综合分析-日期汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1640,1,1,-3623751899957999397,1231,'comprehensiveanalysis/refundreasonsummary','查看【综合分析-退菜原因汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1641,1,1,-3710846440614732767,1232,'businessstatement/shifthandoversheetsummary','查看【营业报表-交班单汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1642,1,1,8729826267378989837,1233,'businessstatement/shifthandoversheetdetail','查看【营业报表-交班明细列表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1643,1,1,-6442913818588785285,1234,'businessstatement/invoicingdetails','查看【营业报表-开票明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1644,1,1,2803067192677852293,1235,'businessstatement/paymentmethodsummary','查看【营业报表-支付方式汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1645,1,1,4826027120004631183,1236,'shopmanagerinspection/summaryofcomplimentarydishes','查看【店长稽查-赠送菜品汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1646,1,1,448432878676467168,1237,'shopmanagerinspection/wholeorderdiscount','查看【店长稽查-整单打折】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1647,1,1,-3710552175344158716,1238,'shopmanagerinspection/singleitemdiscount','查看【店长稽查-单品打折】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1648,1,1,-4053157736339784237,1239,'shopmanagerinspection/adjustzero','查看【店长稽查-调整零头】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1649,1,1,-7247907275171513054,1240,'shopmanagerinspection/banquetdetails','查看【店长稽查-酒席单明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1650,1,1,-4445954966716306188,1241,'shopmanagerinspection/productevaluation','查看【店长稽查-商品评价】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1651,1,1,5782426943725347870,1242,'shopmanagerinspection/onlinecardopeningcost','查看【店长稽查-线上开卡工本费】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1652,1,1,945762092223306154,1243,'memberstatement/memberpointsdetails','查看【会员报表-会员积分详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1653,1,1,1178512101619753352,1244,'memberstatement/memberrechargedetails','查看【会员报表-会员充值详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1654,1,1,-2019349876932510006,1245,'memberstatement/couponpurchaseorupgradecost','查看【会员报表-会员购券/升级工本费详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1655,1,1,-3735278132703138517,1246,'memberstatement/memberconsumedetails','查看【会员报表-会员消费详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1656,1,1,-9093186108755117593,1247,'memberstatement/memberaccountdetails','查看【会员报表-会员账户详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1657,1,1,-4965360735791497334,1248,'memberstatement/memberrechargesummary','查看【会员报表-会员充值汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1658,1,1,8369695010852944991,1249,'memberstatement/memberconsumesummary','查看【会员报表-会员消费汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1659,1,1,-4511644847802661242,1250,'memberstatement/recordofmembersluckydrawtimes','查看【会员报表-会员抽奖次数记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1660,1,1,-5146784938266691116,1251,'memberstatement/numberofrafflesremainingformembers','查看【会员报表-会员剩余抽奖次数】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1661,1,1,6698663729617675529,1252,'memberstatement/receptionofgiftpackagefornewcomers','查看【会员报表-会员领取新人礼包】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1662,1,1,1506335460021395083,1253,'memberstatement/redenvelopereceivingrecord','查看【会员报表-会员红包领取记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1663,1,1,-5297542793774803027,1254,'memberstatement/transferrecord','查看【会员报表-优惠券转赠记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1664,1,1,-6771533030643949625,1255,'memberstatement/cardsettlesummary','查看【会员报表-会员卡金额结算】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1665,1,1,9207294135036708516,1256,'memberstatement/incomeandexpenditurestatement','查看【会员报表-会员卡连锁门店收支报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1666,1,1,-6292160986358520286,1257,'memberstatement/memberaccountsummary','查看【会员报表-会员账户汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1667,1,1,8822602806444772158,1258,'memberstatement/memberbalancesummary','查看【会员报表-会员余额汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1668,1,1,4494612402817342185,1259,'memberstatement/store-member-balance-summary','查看【会员报表-门店会员余额汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1669,1,1,8542994614379159943,1260,'memberstatement/sharecommission','查看【会员报表-会员分享提成报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1670,1,1,-2281233787190064766,1261,'memberstatement/reward','查看【会员报表-打赏报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1671,1,1,-554752789258797309,1262,'couponreport/vouchercollectiondetails','查看【优惠券-领券明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1672,1,1,-4661581539974782901,1263,'couponreport/couponbuylog','查看【优惠券-购买券记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1673,1,1,-1172336233451126770,1264,'decisionanalysis/salesinvoice','查看【决策分析-销售账单汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1674,1,1,5051135197018460246,1265,'decisionanalysis/deptinvoice','查看【决策分析-部门账单汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1675,1,1,5216341786467523861,1266,'decisionanalysis/deptinvoicedetail','查看【决策分析-部门账单明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1676,1,1,7281371314836747967,1267,'decisionanalysis/quarterlysales','查看【决策分析-季度销售】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1677,1,1,3203611518711732902,1268,'decisionanalysis/monthsales','查看【决策分析-月销售】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1678,1,1,-4483384295888250123,1269,'decisionanalysis/daysales','查看【决策分析-日销售】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1679,1,1,2576882333920434608,1270,'salesquery/foodsalesdetails','查看【销售查询-菜品销售明细报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1680,1,1,6504518351615497146,1271,'salesquery/foodsalesranking','查看【销售查询-菜品销售排行报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1681,1,1,5348864171027558179,1272,'salesquery/salesperiodanalysis','查看【销售查询-销售时段分析】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1682,1,1,-646396803001045094,1273,'salesquery/salessummary','查看【销售查询-菜品销售汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1683,1,1,-5501883129045870961,1274,'salesquery/commissionreport','查看【销售查询-提成报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1684,1,1,1825757775422173088,1275,'refundgivechange/detailsoffreedishes','查看【退赠改-赠菜明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1685,1,1,-4390045038799753051,1276,'refundgivechange/returndetails','查看【退赠改-退菜明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1686,1,1,4751371246108357257,1277,'refundgivechange/renamingdetails','查看【退赠改-改名明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1687,1,1,-910867366538584487,1278,'refundgivechange/pricechangedetails','查看【退赠改-改价明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1688,1,1,4954894253686606144,1279,'queuereport/queuestatistics','查看【排队叫号-排队统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1689,1,1,3227886392987156514,1280,'queuereport/queueoverstatistics','查看【排队叫号-排队过号统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1690,1,1,-512771912935413849,1281,'kdsreport/preparationperformance','查看【KDS绩效报表-配菜绩效】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1691,1,1,2922937959083620728,1282,'kdsreport/cookperformance','查看【KDS绩效报表-制作绩效】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1692,1,1,-8155304736557507270,1283,'kdsreport/deliveryperformance','查看【KDS绩效报表-传菜绩效】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1693,1,1,-4538695234493719350,1284,'signandreport/salesdetails','查看【签单报表-签单菜品销售明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1694,1,1,-646007145060779354,1285,'signandreport/salessummary','查看【签单报表-签单菜品销售汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,NULL,NULL,NULL),(1695,1,1,4806612820451868030,1312,'bi:report:cashier:biz','查看【收银查询-收银明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:15:41',0,9,9,8),(1696,1,1,-8440063043053888203,1313,'bi:report:biz','查看【收银查询-收银明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1697,1,1,-4565792040606585752,1314,'bi:report:cashier:bill:audit:biz','查看【收银查询-账单稽核明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:16:10',0,9,9,8),(1698,1,1,-8440063043053888203,1315,'bi:report:biz','查看【收银查询-账单稽核明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1699,1,1,7902248780373264130,1316,'bi:report:cashier:summary:biz','查看【收银查询-收银汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:14:15',0,9,9,8),(1700,1,1,-8440063043053888203,1317,'bi:report:biz','查看【收银查询-收银汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1701,1,1,5157452809125770733,1318,'bi:report:cashier:composition:biz','查看【收银查询-收入构成】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:16:29',0,9,9,8),(1702,1,1,-8440063043053888203,1319,'bi:report:biz','查看【收银查询-收入构成】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1703,1,1,8808697803391485939,1320,'bi:report:cashier:bisiness:biz','查看【收银查询-营业明细_新】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:17:07',0,9,9,8),(1704,1,1,-8440063043053888203,1321,'bi:report:biz','查看【收银查询-营业明细_新】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1705,1,1,-2836251484218330581,1322,'bi:report:cashier:daily:biz','查看【收银查询-日营业数据汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:17:39',0,9,9,8),(1706,1,1,-8440063043053888203,1323,'bi:report:biz','查看【收银查询-日营业数据汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1707,1,1,-189175638636434545,1324,'bi:report:cashier:reverse:biz','查看【收银查询-反结账记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:18:09',0,9,9,8),(1708,1,1,-8440063043053888203,1325,'bi:report:biz','查看【收银查询-反结账记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1709,1,1,1637019429597747484,1326,'bi:report:cashier:credit:biz','查看【收银查询-挂账账目汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:18:34',0,9,9,8),(1710,1,1,-8440063043053888203,1327,'bi:report:biz','查看【收银查询-挂账账目汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1711,1,1,-1817744569795241807,1328,'bi:report:jd:bill:biz','查看【金蝶云报表-账单-账单查询】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:19:23',0,9,9,8),(1712,1,1,-8440063043053888203,1329,'bi:report:biz','查看【金蝶云报表-账单-账单查询】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1713,1,1,7943800675228571537,1330,'bi:report:jd:bill:food:biz','查看【金蝶云报表-账单-账单食品查询】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:19:38',0,9,9,8),(1714,1,1,-8440063043053888203,1331,'bi:report:biz','查看【金蝶云报表-账单-账单食品查询】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1715,1,1,-7628106157650482503,1332,'bi:report:jd:js:biz','查看【金蝶云报表-账单-结算明细表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:20:35',0,9,9,8),(1716,1,1,-8440063043053888203,1333,'bi:report:biz','查看【金蝶云报表-账单-结算明细表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1717,1,1,-2550038173414967222,1334,'bi:report:jd:cw:cashier:biz','查看【金蝶云报表-财务报表-收银明细表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:21:06',0,9,9,8),(1718,1,1,-8440063043053888203,1335,'bi:report:biz','查看【金蝶云报表-财务报表-收银明细表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1719,1,1,-569884862678828016,1336,'bi:report:jd:cw:summary:biz','查看【金蝶云报表-财务报表-收银汇总表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:21:29',0,9,9,8),(1720,1,1,-8440063043053888203,1337,'bi:report:biz','查看【金蝶云报表-财务报表-收银汇总表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1721,1,1,-4595586234281369293,1338,'bi:report:jd:business:biz','查看【金蝶云报表-营业报表-营业汇总表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:22:01',0,9,9,8),(1722,1,1,-8440063043053888203,1339,'bi:report:biz','查看【金蝶云报表-营业报表-营业汇总表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1723,1,1,-1113074706170887773,1340,'bi:report:jd:one:biz','查看【金蝶云报表-营业报表-营业概况一览】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:22:28',0,9,9,8),(1724,1,1,-8440063043053888203,1341,'bi:report:biz','查看【金蝶云报表-营业报表-营业概况一览】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1725,1,1,-8095487333051036775,1342,'bi:report:jd:qjzg:biz','查看【金蝶云报表-营业报表-清机转更表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:22:52',0,9,9,8),(1726,1,1,-8440063043053888203,1343,'bi:report:biz','查看【金蝶云报表-营业报表-清机转更表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1727,1,1,-6019499738619408260,1344,'bi:report:jd:food:sales:biz','查看【金蝶云报表-营业报表-食品销售汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:23:13',0,9,9,8),(1728,1,1,-8440063043053888203,1345,'bi:report:biz','查看【金蝶云报表-营业报表-食品销售汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1729,1,1,-8955649940871565102,1346,'bi:report:jd:food:sales:summary:biz','查看【金蝶云报表-营业报表-食品销售明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:23:30',0,9,9,8),(1730,1,1,-8440063043053888203,1347,'bi:report:biz','查看【金蝶云报表-营业报表-食品销售明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1731,1,1,6938901784457413653,1348,'bi:report:jd:food:sales:level:biz','查看【金蝶云报表-营业报表-食品销售排行】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:23:56',0,9,9,8),(1732,1,1,-8440063043053888203,1349,'bi:report:biz','查看【金蝶云报表-营业报表-食品销售排行】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1733,1,1,8015900916180594313,1350,'bi:report:jd:food:cancel:biz','查看【金蝶云报表-营业报表-食品取消/招待汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:24:17',0,9,9,8),(1734,1,1,-8440063043053888203,1351,'bi:report:biz','查看【金蝶云报表-营业报表-食品取消/招待汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1735,1,1,-3099874815983695584,1352,'bi:report:jd:food:cancel:detail:biz','查看【金蝶云报表-营业报表-食品取消/招待明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:24:47',0,9,9,8),(1736,1,1,-8440063043053888203,1353,'bi:report:biz','查看【金蝶云报表-营业报表-食品取消/招待明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1737,1,1,-6502077818953981829,1354,'bi:report:jd:food:type:biz','查看【金蝶云报表-食品报表-食品类别营业汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:25:18',0,9,9,8),(1738,1,1,-8440063043053888203,1355,'bi:report:biz','查看【金蝶云报表-食品报表-食品类别营业汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1739,1,1,-5595575137370959554,1356,'bi:report:jd:food:type:detail:biz','查看【金蝶云报表-食品报表-食品类别营业明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:25:26',0,9,9,8),(1740,1,1,-8440063043053888203,1357,'bi:report:biz','查看【金蝶云报表-食品报表-食品类别营业明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1741,1,1,-6404413577054896680,1358,'bi:report:sd:meal:biz','查看【时段餐段-班次餐段收银】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:26:02',0,9,9,8),(1742,1,1,-8440063043053888203,1359,'bi:report:biz','查看【时段餐段-班次餐段收银】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1743,1,1,2832638290188835485,1360,'bi:report:sd:jzxf:biz','查看【时段餐段-时段结账消费分析】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:26:16',0,9,9,8),(1744,1,1,-8440063043053888203,1361,'bi:report:biz','查看【时段餐段-时段结账消费分析】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1745,1,1,-607708171402350686,1362,'bi:report:sd:ktxf:biz','查看【时段餐段-时段开台消费分析】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:26:28',0,9,9,8),(1746,1,1,-8440063043053888203,1363,'bi:report:biz','查看【时段餐段-时段开台消费分析】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1747,1,1,-2946691948240634419,1364,'bi:report:qy:table:biz','查看【区域桌台-区域桌台统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:26:43',0,9,9,8),(1748,1,1,-8440063043053888203,1365,'bi:report:biz','查看【区域桌台-区域桌台统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1749,1,1,3623095550703473077,1366,'bi:report:qy:business:biz','查看【区域桌台-区域营业统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:27:10',0,9,9,8),(1750,1,1,-8440063043053888203,1367,'bi:report:biz','查看【区域桌台-区域营业统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1751,1,1,-4251874792451574521,1368,'bi:report:zh:daliy:biz','查看【综合分析-营业情况日报】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:27:46',0,9,9,8),(1752,1,1,-8440063043053888203,1369,'bi:report:biz','查看【综合分析-营业情况日报】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1753,1,1,-7335147486767405294,1370,'bi:report:zh:month:biz','查看【综合分析-月度汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:27:58',0,9,9,8),(1754,1,1,-8440063043053888203,1371,'bi:report:biz','查看【综合分析-月度汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1755,1,1,-130154425973316862,1372,'bi:report:zh:date:biz','查看【综合分析-日期汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:28:14',0,9,9,8),(1756,1,1,-8440063043053888203,1373,'bi:report:biz','查看【综合分析-日期汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1757,1,1,5048873513126617083,1374,'bi:report:zh:return:biz','查看【综合分析-退菜原因汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:28:52',0,9,9,8),(1758,1,1,-8440063043053888203,1375,'bi:report:biz','查看【综合分析-退菜原因汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1759,1,1,-4250821984981477865,1376,'bi:report:yy:jbd:biz','查看【营业报表-交班单汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:29:43',0,9,9,8),(1760,1,1,-8440063043053888203,1377,'bi:report:biz','查看【营业报表-交班单汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1761,1,1,-5641265230547586805,1378,'bi:report:yy:jbmx:biz','查看【营业报表-交班明细列表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:29:35',0,9,9,8),(1762,1,1,-8440063043053888203,1379,'bi:report:biz','查看【营业报表-交班明细列表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1763,1,1,9035291723978698221,1380,'bi:report:yy:kp:biz','查看【营业报表-开票明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:30:02',0,9,9,8),(1764,1,1,-8440063043053888203,1381,'bi:report:biz','查看【营业报表-开票明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:17',0,11,9,31),(1765,1,1,-8489360859128540936,1382,'bi:report:yy:pay:way:biz','查看【营业报表-支付方式汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:30:27',0,9,9,8),(1766,1,1,-8440063043053888203,1383,'bi:report:biz','查看【营业报表-支付方式汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1767,1,1,3385373607290823258,1384,'bi:report:dz:send:biz','查看【店长稽查-赠送菜品汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:30:42',0,9,9,8),(1768,1,1,-8440063043053888203,1385,'bi:report:biz','查看【店长稽查-赠送菜品汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1769,1,1,-1534530107721509514,1386,'bi:report:dz:zddz:biz','查看【店长稽查-整单打折】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:31:04',0,9,9,8),(1770,1,1,-8440063043053888203,1387,'bi:report:biz','查看【店长稽查-整单打折】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1771,1,1,-3258560122767717613,1388,'bi:report:dz:dpdz:biz','查看【店长稽查-单品打折】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:31:17',0,9,9,8),(1772,1,1,-8440063043053888203,1389,'bi:report:biz','查看【店长稽查-单品打折】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1773,1,1,6057471736627861916,1390,'bi:report:dz:tzlt:biz','查看【店长稽查-调整零头】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:31:35',0,9,9,8),(1774,1,1,-8440063043053888203,1391,'bi:report:biz','查看【店长稽查-调整零头】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1775,1,1,-6849621527827037190,1392,'bi:report:dz:jxdmx:biz','查看【店长稽查-酒席单明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:40:31',0,9,9,8),(1776,1,1,-8440063043053888203,1393,'bi:report:biz','查看【店长稽查-酒席单明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1777,1,1,-6986763324015241049,1394,'bi:report:dz:product:biz','查看【店长稽查-商品评价】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:40:47',0,9,9,8),(1778,1,1,-8440063043053888203,1395,'bi:report:biz','查看【店长稽查-商品评价】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1779,1,1,3670766930751603325,1396,'bi:report:dz:online:biz','查看【店长稽查-线上开卡工本费】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:41:06',0,9,9,8),(1780,1,1,-8440063043053888203,1397,'bi:report:biz','查看【店长稽查-线上开卡工本费】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1781,1,1,-7749500310064602912,1398,'bi:report:member:points:biz','查看【会员报表-会员积分详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:41:39',0,9,9,8),(1782,1,1,-8440063043053888203,1399,'bi:report:biz','查看【会员报表-会员积分详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1783,1,1,-7510057090063118749,1400,'bi:report:member:recharge:biz','查看【会员报表-会员充值详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:42:02',0,9,9,8),(1784,1,1,-8440063043053888203,1401,'bi:report:biz','查看【会员报表-会员充值详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1785,1,1,2805742230643559616,1402,'bi:report:member:coupon:biz','查看【会员报表-会员购券/升级工本费详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:42:19',0,9,9,8),(1786,1,1,-8440063043053888203,1403,'bi:report:biz','查看【会员报表-会员购券/升级工本费详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1787,1,1,347033883909270288,1404,'bi:report:member:consum:biz','查看【会员报表-会员消费详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:42:44',0,9,9,8),(1788,1,1,-8440063043053888203,1405,'bi:report:biz','查看【会员报表-会员消费详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1789,1,1,7162399947485535399,1406,'bi:report:member:account:biz','查看【会员报表-会员账户详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:43:02',0,9,9,8),(1790,1,1,-8440063043053888203,1407,'bi:report:biz','查看【会员报表-会员账户详情】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1791,1,1,3930253294937958218,1408,'bi:report:member:recharge:sum:biz','查看【会员报表-会员充值汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:43:18',0,9,9,8),(1792,1,1,-8440063043053888203,1409,'bi:report:biz','查看【会员报表-会员充值汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1793,1,1,5541247528987689684,1410,'bi:report:member:consum:sum:biz','查看【会员报表-会员消费汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:44:11',0,9,9,8),(1794,1,1,-8440063043053888203,1411,'bi:report:biz','查看【会员报表-会员消费汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1795,1,1,-5757769718310171522,1412,'bi:report:member:record:biz','查看【会员报表-会员抽奖次数记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:45:12',0,9,9,8),(1796,1,1,-8440063043053888203,1413,'bi:report:biz','查看【会员报表-会员抽奖次数记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1797,1,1,-7332456709589630641,1414,'bi:report:member:number:biz','查看【会员报表-会员剩余抽奖次数】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:45:42',0,9,9,8),(1798,1,1,-8440063043053888203,1415,'bi:report:biz','查看【会员报表-会员剩余抽奖次数】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1799,1,1,-6907055581086696088,1416,'bi:report:member:gift:biz','查看【会员报表-会员领取新人礼包】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:46:05',0,9,9,8),(1800,1,1,-8440063043053888203,1417,'bi:report:biz','查看【会员报表-会员领取新人礼包】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1801,1,1,5247396881536846229,1418,'bi:report:member:redenve:biz','查看【会员报表-会员红包领取记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:46:41',0,9,9,8),(1802,1,1,-8440063043053888203,1419,'bi:report:biz','查看【会员报表-会员红包领取记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1803,1,1,7994825879865876875,1420,'bi:report:member:trandfer:biz','查看【会员报表-优惠券转赠记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:47:06',0,9,9,8),(1804,1,1,-8440063043053888203,1421,'bi:report:biz','查看【会员报表-优惠券转赠记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1805,1,1,1884542778158644961,1422,'bi:report:member:card:biz','查看【会员报表-会员卡金额结算】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:47:30',0,9,9,8),(1806,1,1,-8440063043053888203,1423,'bi:report:biz','查看【会员报表-会员卡金额结算】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1807,1,1,-917507313965777813,1424,'bi:report:member:income:biz','查看【会员报表-会员卡连锁门店收支报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:47:59',0,9,9,8),(1808,1,1,-8440063043053888203,1425,'bi:report:biz','查看【会员报表-会员卡连锁门店收支报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1809,1,1,-6477849886034490142,1426,'bi:report:member:account:sum:biz','查看【会员报表-会员账户汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:48:24',0,9,9,8),(1810,1,1,-8440063043053888203,1427,'bi:report:biz','查看【会员报表-会员账户汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1811,1,1,1624638773988811382,1428,'bi:report:member:balance:biz','查看【会员报表-会员余额汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:48:52',0,9,9,8),(1812,1,1,-8440063043053888203,1429,'bi:report:biz','查看【会员报表-会员余额汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1813,1,1,-2917034630313172863,1430,'bi:report:member:store:balance:biz','查看【会员报表-门店会员余额汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:49:22',0,9,9,8),(1814,1,1,-8440063043053888203,1431,'bi:report:biz','查看【会员报表-门店会员余额汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1815,1,1,-2675946749078096698,1432,'bi:report:member:share:biz','查看【会员报表-会员分享提成报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:49:45',0,9,9,8),(1816,1,1,-8440063043053888203,1433,'bi:report:biz','查看【会员报表-会员分享提成报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1817,1,1,3889909214388614099,1434,'bi:report:member:reward:biz','查看【会员报表-打赏报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:50:07',0,9,9,8),(1818,1,1,-8440063043053888203,1435,'bi:report:biz','查看【会员报表-打赏报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1819,1,1,3033517600275045794,1436,'bi:report:coupon:collect:biz','查看【优惠券-领券明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:50:34',0,9,9,8),(1820,1,1,-8440063043053888203,1437,'bi:report:biz','查看【优惠券-领券明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1821,1,1,4428850225870976359,1438,'bi:report:coupon:buy:biz','查看【优惠券-购买券记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:50:59',0,9,9,8),(1822,1,1,-8440063043053888203,1439,'bi:report:biz','查看【优惠券-购买券记录】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1823,1,1,1137465179077182571,1440,'bi:report:decision:saleinvoice:biz','查看【决策分析-销售账单汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:51:29',0,9,9,8),(1824,1,1,-8440063043053888203,1441,'bi:report:biz','查看【决策分析-销售账单汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1825,1,1,2832670500209447505,1442,'bi:report:decision:deptinvoice:biz','查看【决策分析-部门账单汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:51:49',0,9,9,8),(1826,1,1,-8440063043053888203,1443,'bi:report:biz','查看【决策分析-部门账单汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1827,1,1,-8035739878851682221,1444,'bi:report:decision:deptinvoicedetail:biz','查看【决策分析-部门账单明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:53:01',0,9,9,8),(1828,1,1,-8440063043053888203,1445,'bi:report:biz','查看【决策分析-部门账单明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1829,1,1,-5554494994969521867,1446,'bi:report:decision:quarterlysales:biz','查看【决策分析-季度销售】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:53:31',0,9,9,8),(1830,1,1,-8440063043053888203,1447,'bi:report:biz','查看【决策分析-季度销售】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1831,1,1,-8953747971252979210,1448,'bi:report:decision:monthsales:biz','查看【决策分析-月销售】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:53:52',0,9,9,8),(1832,1,1,-8440063043053888203,1449,'bi:report:biz','查看【决策分析-月销售】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1833,1,1,-5523544851551601235,1450,'bi:report:decision:daysales:biz','查看【决策分析-日销售】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:54:14',0,9,9,8),(1834,1,1,-8440063043053888203,1451,'bi:report:biz','查看【决策分析-日销售】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1835,1,1,-4948274282838832040,1452,'bi:report:sales:foodsalesdetail:biz','查看【销售查询-菜品销售明细报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:54:47',0,9,9,8),(1836,1,1,-8440063043053888203,1453,'bi:report:biz','查看【销售查询-菜品销售明细报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1837,1,1,2297797328340523606,1454,'bi:report:sales:foodsalesranking:biz','查看【销售查询-菜品销售排行报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:55:08',0,9,9,8),(1838,1,1,-8440063043053888203,1455,'bi:report:biz','查看【销售查询-菜品销售排行报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1839,1,1,-5004345006886446245,1456,'bi:report:sales:salesperiod:biz','查看【销售查询-销售时段分析】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:55:34',0,9,9,8),(1840,1,1,-8440063043053888203,1457,'bi:report:biz','查看【销售查询-销售时段分析】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1841,1,1,6536921491064293641,1458,'bi:report:sales:salessummary:biz','查看【销售查询-菜品销售汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:55:56',0,9,9,8),(1842,1,1,-8440063043053888203,1459,'bi:report:biz','查看【销售查询-菜品销售汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1843,1,1,3825206396583653652,1460,'bi:report:sales:commissionreport:biz','查看【销售查询-提成报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:56:24',0,9,9,8),(1844,1,1,-8440063043053888203,1461,'bi:report:biz','查看【销售查询-提成报表】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1845,1,1,-5209505548413798589,1462,'bi:report:rgc:givefood:biz','查看【退赠改-赠菜明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:57:10',0,9,9,8),(1846,1,1,-8440063043053888203,1463,'bi:report:biz','查看【退赠改-赠菜明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1847,1,1,-1946338378074087388,1464,'bi:report:rgc:returndishes:biz','查看【退赠改-退菜明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 10:57:34',0,9,9,8),(1848,1,1,-8440063043053888203,1465,'bi:report:biz','查看【退赠改-退菜明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1849,1,1,6943237996344586845,1466,'bi:report:rgc:renamedetail:biz','查看【退赠改-改名明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 11:00:19',0,9,9,8),(1850,1,1,-8440063043053888203,1467,'bi:report:biz','查看【退赠改-改名明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1851,1,1,-6535709455254091168,1468,'bi:report:rgc:repricedetail:biz','查看【退赠改-改价明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 11:00:35',0,9,9,8),(1852,1,1,-8440063043053888203,1469,'bi:report:biz','查看【退赠改-改价明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1853,1,1,6502097433984211346,1470,'bi:report:queue:static:biz','查看【排队叫号-排队统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 11:01:03',0,9,9,8),(1854,1,1,-8440063043053888203,1471,'bi:report:biz','查看【排队叫号-排队统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1855,1,1,8918911665155158175,1472,'bi:report:queue:overstatic:biz','查看【排队叫号-排队过号统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 11:01:30',0,9,9,8),(1856,1,1,-8440063043053888203,1473,'bi:report:biz','查看【排队叫号-排队过号统计】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1857,1,1,7660923134441533473,1474,'bi:report:kds:siding:biz','查看【KDS绩效报表-配菜绩效】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 11:01:54',0,9,9,8),(1858,1,1,-8440063043053888203,1475,'bi:report:biz','查看【KDS绩效报表-配菜绩效】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1859,1,1,-233811043625050362,1476,'bi:report:kds:cooking:biz','查看【KDS绩效报表-制作绩效】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 11:02:06',0,9,9,8),(1860,1,1,-8440063043053888203,1477,'bi:report:biz','查看【KDS绩效报表-制作绩效】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1861,1,1,78207332809433089,1478,'bi:report:kds:serving:biz','查看【KDS绩效报表-传菜绩效】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 11:02:20',0,9,9,8),(1862,1,1,-8440063043053888203,1479,'bi:report:biz','查看【KDS绩效报表-传菜绩效】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1863,1,1,-8945362491503428455,1480,'bi:report:sign:salesdetail:biz','查看【签单报表-签单菜品销售明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 11:02:48',0,9,9,8),(1864,1,1,-8440063043053888203,1481,'bi:report:biz','查看【签单报表-签单菜品销售明细】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1865,1,1,7603072003415486416,1482,'bi:report:sign:salessummary:biz','查看【签单报表-签单菜品销售汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-12-24 11:03:12',0,9,9,8),(1866,1,1,-8440063043053888203,1483,'bi:report:biz','查看【签单报表-签单菜品销售汇总】',NULL,NULL,NULL,'2025-10-27 17:33:04',NULL,'2025-11-04 12:39:18',0,11,9,31),(1867,1,1,-3777140417680582809,1484,'wx:merchant:config:add','新增【微信授权】',NULL,NULL,NULL,'2025-10-27 17:37:06',NULL,'2025-11-04 12:39:18',0,9,9,4),(1868,1,1,5904884872631426442,1484,'wx:merchant:config:edit','修改【微信授权】',NULL,NULL,NULL,'2025-10-27 17:37:06',NULL,'2025-11-04 12:39:18',0,9,9,4),(1869,1,1,-4073209417679188162,1484,'wx:merchant:config:list','查询【微信授权】',NULL,NULL,NULL,'2025-10-27 17:37:06',NULL,'2025-11-04 12:39:18',0,9,9,4),(1870,1,1,6827321973993569376,1484,'wx:merchant:config:del','删除【微信授权】',NULL,NULL,NULL,'2025-10-27 17:37:06',NULL,'2025-11-04 12:39:18',0,9,9,4),(1871,1,1,-6332374408082449691,1485,'dou:yin:config:add','新增【抖音授权】',NULL,NULL,NULL,'2025-10-27 17:37:27',NULL,'2025-11-04 12:39:18',0,9,9,4),(1872,1,1,6536676540725694683,1485,'dou:yin:config:edit','修改【抖音授权】',NULL,NULL,NULL,'2025-10-27 17:37:27',NULL,'2025-11-04 12:39:18',0,9,9,4),(1873,1,1,8683987213441845863,1485,'dou:yin:config:list','查询【抖音授权】',NULL,NULL,NULL,'2025-10-27 17:37:27',NULL,'2025-11-04 12:39:18',0,9,9,4),(1874,1,1,-2291845592749660094,1485,'dou:yin:config:del','删除【抖音授权】',NULL,NULL,NULL,'2025-10-27 17:37:27',NULL,'2025-11-04 12:39:18',0,9,9,4),(1875,1,1,-2252256734741479275,1487,'wx:msg:tmpl:add','新增【消息提醒】',NULL,NULL,NULL,'2025-10-27 17:38:03',NULL,'2025-11-04 12:39:18',0,9,9,4),(1876,1,1,-3609977266159557613,1487,'wx:msg:tmpl:edit','修改【消息提醒】',NULL,NULL,NULL,'2025-10-27 17:38:03',NULL,'2025-11-04 12:39:18',0,9,9,4),(1877,1,1,3800390414881762482,1487,'wx:msg:tmpl:list','查询【消息提醒】',NULL,NULL,NULL,'2025-10-27 17:38:03',NULL,'2025-11-04 12:39:18',0,9,9,4),(1878,1,1,5625778708655648010,1487,'wx:msg:tmpl:del','删除【消息提醒】',NULL,NULL,NULL,'2025-10-27 17:38:03',NULL,'2025-11-04 12:39:18',0,9,9,4),(1879,1,1,-3777140417680582809,1488,'wx:merchant:config:add','新增【小程序模板】',NULL,NULL,NULL,'2025-10-27 17:38:18',NULL,'2025-11-04 12:39:18',0,9,9,4),(1880,1,1,5904884872631426442,1488,'wx:merchant:config:edit','修改【小程序模板】',NULL,NULL,NULL,'2025-10-27 17:38:18',NULL,'2025-11-04 12:39:18',0,9,9,4),(1881,1,1,-4073209417679188162,1488,'wx:merchant:config:list','查询【小程序模板】',NULL,NULL,NULL,'2025-10-27 17:38:18',NULL,'2025-11-04 12:39:18',0,9,9,4),(1882,1,1,6827321973993569376,1488,'wx:merchant:config:del','删除【小程序模板】',NULL,NULL,NULL,'2025-10-27 17:38:18',NULL,'2025-11-04 12:39:18',0,9,9,4),(1883,1,1,5993714406199732844,1489,'wx:card:add','新增【会员卡券】',NULL,NULL,NULL,'2025-10-27 17:38:43',NULL,'2025-11-04 12:39:18',0,9,9,4),(1884,1,1,-4070022306348294931,1489,'wx:card:edit','修改【会员卡券】',NULL,NULL,NULL,'2025-10-27 17:38:43',NULL,'2025-11-04 12:39:18',0,9,9,4),(1885,1,1,8955384825828111315,1489,'wx:card:list','查询【会员卡券】',NULL,NULL,NULL,'2025-10-27 17:38:43',NULL,'2025-11-04 12:39:18',0,9,9,4),(1886,1,1,8742656937576966155,1489,'wx:card:del','删除【会员卡券】',NULL,NULL,NULL,'2025-10-27 17:38:43',NULL,'2025-11-04 12:39:18',0,9,9,4),(1887,1,1,2612917804693131903,1490,'order:bill:add','新增【订单中心】',NULL,NULL,NULL,'2025-10-27 17:39:02',NULL,'2025-11-04 12:39:18',0,9,9,4),(1888,1,1,-2443555744158187677,1490,'order:bill:edit','修改【订单中心】',NULL,NULL,NULL,'2025-10-27 17:39:02',NULL,'2025-11-04 12:39:18',0,9,9,4),(1889,1,1,301261070423228041,1490,'order:bill:list','查询【订单中心】',NULL,NULL,NULL,'2025-10-27 17:39:02',NULL,'2025-11-04 12:39:18',0,9,9,4),(1890,1,1,4549491719831896962,1490,'order:bill:del','删除【订单中心】',NULL,NULL,NULL,'2025-10-27 17:39:02',NULL,'2025-11-04 12:39:18',0,9,9,4),(1891,1,1,773013039220589142,1491,'wx:menu:add','新增【菜单栏】',NULL,NULL,NULL,'2025-10-27 17:44:29',NULL,'2025-11-04 12:39:18',0,9,9,4),(1892,1,1,3999990557455582294,1491,'wx:menu:edit','修改【菜单栏】',NULL,NULL,NULL,'2025-10-27 17:44:29',NULL,'2025-11-04 12:39:18',0,9,9,4),(1893,1,1,-1475314848673971730,1491,'wx:menu:list','查询【菜单栏】',NULL,NULL,NULL,'2025-10-27 17:44:29',NULL,'2025-11-04 12:39:18',0,9,9,4),(1894,1,1,-4146538067216804081,1491,'wx:menu:del','删除【菜单栏】',NULL,NULL,NULL,'2025-10-27 17:44:29',NULL,'2025-11-04 12:39:18',0,9,9,4),(1895,1,1,-8410301893742908288,1493,'biz:receipt:bind:add','新增【接收设置】',NULL,NULL,NULL,'2025-10-27 17:44:51',NULL,'2025-11-04 12:39:18',0,9,9,4),(1896,1,1,5393113956293562737,1493,'biz:receipt:bind:edit','修改【接收设置】',NULL,NULL,NULL,'2025-10-27 17:44:51',NULL,'2025-11-04 12:39:18',0,9,9,4),(1897,1,1,5479961100109682899,1493,'biz:receipt:bind:list','查询【接收设置】',NULL,NULL,NULL,'2025-10-27 17:44:51',NULL,'2025-11-04 12:39:18',0,9,9,4),(1898,1,1,-8368973164848285934,1493,'biz:receipt:bind:del','删除【接收设置】',NULL,NULL,NULL,'2025-10-27 17:44:51',NULL,'2025-11-04 12:39:18',0,9,9,4),(1899,1,1,-4589300873681274132,1494,'pt:qr:bind:add','新增【桌台二维码】',NULL,NULL,NULL,'2025-10-27 17:45:09',NULL,'2025-11-04 12:39:18',0,9,9,4),(1900,1,1,526964019926828982,1494,'pt:qr:bind:edit','修改【桌台二维码】',NULL,NULL,NULL,'2025-10-27 17:45:09',NULL,'2025-11-04 12:39:18',0,9,9,4),(1901,1,1,-7255173433146737893,1494,'pt:qr:bind:list','查询【桌台二维码】',NULL,NULL,NULL,'2025-10-27 17:45:09',NULL,'2025-11-04 12:39:18',0,9,9,4),(1902,1,1,3518917261401321683,1494,'pt:qr:bind:del','删除【桌台二维码】',NULL,NULL,NULL,'2025-10-27 17:45:09',NULL,'2025-11-04 12:39:18',0,9,9,4),(1903,1,1,-4566240480161182609,1495,'wx:page:add','新增【小程序页面】',NULL,NULL,NULL,'2025-10-27 17:45:37',NULL,'2025-11-04 12:39:18',0,9,9,4),(1904,1,1,4935984745345272518,1495,'wx:page:edit','修改【小程序页面】',NULL,NULL,NULL,'2025-10-27 17:45:37',NULL,'2025-11-04 12:39:18',0,9,9,4),(1905,1,1,-1394188243609195010,1495,'wx:page:list','查询【小程序页面】',NULL,NULL,NULL,'2025-10-27 17:45:37',NULL,'2025-11-04 12:39:18',0,9,9,4),(1906,1,1,-7431315366170404240,1495,'wx:page:del','删除【小程序页面】',NULL,NULL,NULL,'2025-10-27 17:45:37',NULL,'2025-11-04 12:39:18',0,9,9,4),(1907,1,1,-7451312527775233420,1496,'pt:queue:add','新增【排队叫号】',NULL,NULL,NULL,'2025-10-27 17:45:58',NULL,'2025-11-04 12:39:18',0,9,9,4),(1908,1,1,8904832346610383278,1496,'pt:queue:edit','修改【排队叫号】',NULL,NULL,NULL,'2025-10-27 17:45:58',NULL,'2025-11-04 12:39:18',0,9,9,4),(1909,1,1,3662561532889161263,1496,'pt:queue:list','查询【排队叫号】',NULL,NULL,NULL,'2025-10-27 17:45:58',NULL,'2025-11-04 12:39:18',0,9,9,4),(1910,1,1,-5146932187541259882,1496,'pt:queue:del','删除【排队叫号】',NULL,NULL,NULL,'2025-10-27 17:45:58',NULL,'2025-11-04 12:39:18',0,9,9,4),(1911,1,1,-4566240480161182609,1497,'wx:page:add','新增【餐厅大屏】',NULL,NULL,NULL,'2025-10-27 17:46:37',NULL,'2025-11-04 12:39:18',0,9,9,4),(1912,1,1,4935984745345272518,1497,'wx:page:edit','修改【餐厅大屏】',NULL,NULL,NULL,'2025-10-27 17:46:37',NULL,'2025-11-04 12:39:18',0,9,9,4),(1913,1,1,-1394188243609195010,1497,'wx:page:list','查询【餐厅大屏】',NULL,NULL,NULL,'2025-10-27 17:46:37',NULL,'2025-11-04 12:39:18',0,9,9,4),(1914,1,1,-7431315366170404240,1497,'wx:page:del','删除【餐厅大屏】',NULL,NULL,NULL,'2025-10-27 17:46:37',NULL,'2025-11-04 12:39:18',0,9,9,4),(1915,1,1,1198424458677125467,1626,'biz:shop:group:add','新增【门店分组】',NULL,NULL,NULL,'2025-10-27 18:09:46',NULL,'2025-11-04 12:39:18',0,9,9,6),(1916,1,1,7276726556098064542,1626,'biz:shop:group:edit','修改【门店分组】',NULL,NULL,NULL,'2025-10-27 18:09:46',NULL,'2025-11-04 12:39:18',0,9,9,6),(1917,1,1,8179580054505256214,1626,'biz:shop:group:list','查询【门店分组】',NULL,NULL,NULL,'2025-10-27 18:09:46',NULL,'2025-11-04 12:39:18',0,9,9,6),(1918,1,1,443733268821079981,1626,'biz:shop:group:del','删除【门店分组】',NULL,NULL,NULL,'2025-10-27 18:09:46',NULL,'2025-11-04 12:39:18',0,9,9,6),(1919,1,1,3922275386390068912,1656,'sc:warehouse:init:begin','开始期初',NULL,NULL,NULL,'2025-10-27 19:26:05',NULL,'2025-11-04 12:39:18',0,9,9,6),(1920,1,1,3177755026902404036,1656,'sc:warehouse:init:all','添加所有物品',NULL,NULL,NULL,'2025-10-27 19:26:51',NULL,'2025-11-04 12:39:18',0,9,9,6),(1921,1,1,-8879542587498071190,1656,'sc:warehouse:init:revoke','撤销期初盘点',NULL,NULL,NULL,'2025-10-27 19:27:04',NULL,'2025-11-04 12:39:18',0,9,9,6),(1922,1,1,-8528490517222673334,1656,'sc:warehouse:init:batch','添加期初盘点物品',NULL,NULL,NULL,'2025-10-27 19:27:15',NULL,'2025-11-04 12:39:18',0,9,9,6),(1923,1,1,-5437864110509778253,1656,'sc:warehouse:init:del','删除期初盘点物品',NULL,NULL,NULL,'2025-10-27 19:27:26',NULL,'2025-11-04 12:39:18',0,9,9,6),(1924,1,1,8067341007489783874,1656,'sc:warehouse:init:save','保存期初盘点单',NULL,NULL,NULL,'2025-10-27 19:27:36',NULL,'2025-11-04 12:39:18',0,9,9,6),(1925,1,1,-6750005386060913387,1656,'sc:warehouse:init:done','确认期初盘点',NULL,NULL,NULL,'2025-10-27 19:27:48',NULL,'2025-11-04 12:39:18',0,9,9,6),(1926,1,1,3739523156827484858,1656,'sc:warehouse:init:import','期初导入',NULL,NULL,NULL,'2025-10-27 19:27:58',NULL,'2025-11-04 12:39:18',0,9,9,6),(1927,1,1,-6624959234358085385,1656,'wms:begin:check:import','查询导入结果',NULL,NULL,NULL,'2025-10-27 19:28:14',NULL,'2025-11-04 12:39:18',0,9,9,6),(1928,1,1,-4448248009598974739,1659,'sc:warehouse:check:begin','开始盘点',NULL,NULL,NULL,'2025-10-27 19:33:44',NULL,'2025-11-04 12:39:18',0,9,9,6),(1929,1,1,-7062340732116201957,1659,'sc:warehouse:check:clear','一键清除',NULL,NULL,NULL,'2025-10-27 19:33:56',NULL,'2025-11-04 12:39:18',0,9,9,6),(1930,1,1,-6035936884550927070,1659,'sc:warehouse:check:add','添加盘点物品',NULL,NULL,NULL,'2025-10-27 19:34:21',NULL,'2025-11-04 12:39:18',0,9,9,6),(1931,1,1,-1415100093806968275,1659,'sc:warehouse:check:as','另存为模板',NULL,NULL,NULL,'2025-10-27 19:34:31',NULL,'2025-11-04 12:39:18',0,9,9,6),(1932,1,1,-3872514456016238771,1659,'sc:warehouse:check:del','删除盘点物品',NULL,NULL,NULL,'2025-10-27 19:34:42',NULL,'2025-11-04 12:39:19',0,9,9,6),(1933,1,1,92599405103307236,1659,'sc:warehouse:check:save','暂存',NULL,NULL,NULL,'2025-10-27 19:34:52',NULL,'2025-11-04 12:39:19',0,9,9,6),(1934,1,1,8968121406415470185,1659,'sc:warehouse:check:revoke','撤销盘点',NULL,NULL,NULL,'2025-10-27 19:35:17',NULL,'2025-11-04 12:39:19',0,9,9,6),(1935,1,1,-8498233847570062187,1659,'wms:check:checkDone','结束盘点',NULL,NULL,NULL,'2025-10-27 19:35:29',NULL,'2025-11-04 12:39:19',0,9,9,6),(1936,1,1,-4616413302675386506,1659,'wms:check:revertCheck','盘点反审核',NULL,NULL,NULL,'2025-10-27 19:35:42',NULL,'2025-11-04 12:39:19',0,9,9,6),(1937,1,1,1722311617262001473,1659,'sc:warehouse:check:import','盘点导入',NULL,NULL,NULL,'2025-10-27 19:35:55',NULL,'2025-11-04 12:39:19',0,9,9,6),(1938,1,1,5763660614897814555,1659,'wms:check:import','查询导入结果',NULL,NULL,NULL,'2025-10-27 19:36:09',NULL,'2025-11-04 12:39:19',0,9,9,6),(1939,1,1,2391051421147140935,1659,'sc:warehouse:check:export','盘点导出',NULL,NULL,NULL,'2025-10-27 19:36:20',NULL,'2025-11-04 12:39:19',0,9,9,6),(1940,1,1,-5177142992060843522,1623,'sys:merchant:add','新增【集团】',NULL,NULL,NULL,'2025-10-28 11:12:29',NULL,'2025-11-04 12:39:19',0,9,9,6),(1941,1,1,-2132850461551442473,1623,'sys:merchant:edit','修改【集团】',NULL,NULL,NULL,'2025-10-28 11:12:29',NULL,'2025-11-04 12:39:19',0,9,9,6),(1942,1,1,6167176253216854753,1623,'sys:merchant:list','查询【集团】',NULL,NULL,NULL,'2025-10-28 11:12:29',NULL,'2025-11-04 12:39:19',0,9,9,6),(1943,1,1,-1518822183227143975,1623,'sys:merchant:del','删除【集团】',NULL,NULL,NULL,'2025-10-28 11:12:29',NULL,'2025-11-04 12:39:19',0,9,9,6),(1944,1,1,-5230267777621926361,1623,'sys:brand:add','新增【品牌】',NULL,NULL,NULL,'2025-10-28 11:15:41',NULL,'2025-11-04 12:39:19',0,9,9,6),(1945,1,1,-7586298241126116914,1623,'sys:brand:edit','修改【品牌】',NULL,NULL,NULL,'2025-10-28 11:15:41',NULL,'2025-11-04 12:39:19',0,9,9,6),(1946,1,1,-1918751848111129377,1623,'sys:brand:list','查询【品牌】',NULL,NULL,NULL,'2025-10-28 11:15:41',NULL,'2025-11-04 12:39:19',0,9,9,6),(1947,1,1,4536602654630726784,1623,'sys:brand:del','删除【品牌】',NULL,NULL,NULL,'2025-10-28 11:15:41',NULL,'2025-11-04 12:39:19',0,9,9,6),(1948,1,1,2149559737009396908,1629,'sc:organ:target:add','新增【目标】',NULL,NULL,NULL,'2025-10-28 11:24:45',NULL,'2025-11-04 12:39:19',0,9,9,6),(1949,1,1,-1940527317138883712,1629,'sc:organ:target:edit','修改【目标】',NULL,NULL,NULL,'2025-10-28 11:24:45',NULL,'2025-11-04 12:39:19',0,9,9,6),(1950,1,1,-8495584601416405790,1629,'sc:organ:target:list','查询【目标】',NULL,NULL,NULL,'2025-10-28 11:24:45',NULL,'2025-11-04 12:39:19',0,9,9,6),(1951,1,1,4460122819890855381,1629,'sc:organ:target:del','删除【目标】',NULL,NULL,NULL,'2025-10-28 11:24:45',NULL,'2025-11-04 12:39:19',0,9,9,6),(1952,1,1,567428606162432318,1632,'sc:paras:add','新增【参数】',NULL,NULL,NULL,'2025-10-28 11:25:06',NULL,'2025-11-04 12:39:19',0,9,9,6),(1953,1,1,9196362504514185352,1632,'sc:paras:edit','修改【参数】',NULL,NULL,NULL,'2025-10-28 11:25:06',NULL,'2025-11-04 12:39:19',0,9,9,6),(1954,1,1,-6527660027108045119,1632,'sc:paras:list','查询【参数】',NULL,NULL,NULL,'2025-10-28 11:25:06',NULL,'2025-11-04 12:39:19',0,9,9,6),(1955,1,1,3682665732684674852,1632,'sc:paras:del','删除【参数】',NULL,NULL,NULL,'2025-10-28 11:25:06',NULL,'2025-11-04 12:39:19',0,9,9,6),(1956,1,1,2438246731045540938,1662,'sc:st:check:bill:list','查询盘点单据',NULL,NULL,NULL,'2025-10-28 11:26:27',NULL,'2025-11-04 12:39:19',0,9,9,6),(1957,1,1,2609451699286580602,1662,'sc:st:check:bill:update','修改盘点单据',NULL,NULL,NULL,'2025-10-28 11:35:01',NULL,'2025-11-04 12:39:19',0,9,9,6),(1958,1,1,-5392228353881530828,1662,'sc:st:check:bill:del','删除盘点单据',NULL,NULL,NULL,'2025-10-28 11:35:15',NULL,'2025-11-04 12:39:19',0,9,9,6),(1959,1,1,-9184712273444585556,1662,'sc:st:check:bill:exportDetail','导出盘点详情',NULL,NULL,NULL,'2025-10-28 11:35:28',NULL,'2025-11-04 12:39:19',0,9,9,6),(1960,1,1,2164269230687683105,1665,'sc:st:bill:updateItem','修改单据明细',NULL,NULL,NULL,'2025-10-28 11:39:37',NULL,'2025-11-04 12:39:19',0,9,9,6),(1961,1,1,615745918003164155,1665,'sc:st:bill:listSettle','查看供货商结算列表',NULL,NULL,NULL,'2025-10-28 11:39:56',NULL,'2025-11-04 12:39:19',0,9,9,6),(1962,1,1,2193051210291302170,1635,'sc:supplier:addSuitStore','适用门店设置',NULL,NULL,NULL,'2025-10-30 11:24:50',NULL,'2025-11-04 12:39:19',0,9,9,6),(1963,1,1,575471809630457639,1635,'sc:supplier:invite','邀请注册',NULL,NULL,NULL,'2025-10-30 11:24:57',NULL,'2025-11-04 12:39:19',0,9,9,6),(1964,1,1,219914388711339744,1635,'ssc:supplier:applyList','管理申请',NULL,NULL,NULL,'2025-10-30 11:25:06',NULL,'2025-11-04 12:39:19',0,9,9,6),(1965,1,1,-1723398538042838258,1635,'sc:supplier:audit','供应商申请审核/绑定',NULL,NULL,NULL,'2025-10-30 11:25:13',NULL,'2026-04-07 17:42:03',0,9,9,6),(1966,1,1,1954978167202097497,1635,'sc:supplier:refuse','供应商申请拒绝',NULL,NULL,NULL,'2025-10-30 11:25:20',NULL,'2026-04-07 17:42:16',0,9,9,6),(1967,1,1,-1444704755344836318,1635,'sc:supplier:unbind','供应商申请解绑',NULL,NULL,NULL,'2025-10-30 11:25:30',NULL,'2025-11-04 12:39:19',0,9,9,6),(1968,1,1,-7582638195363417284,1635,'sc:supplier:export','导出供应商',NULL,NULL,NULL,'2025-10-30 11:25:38',NULL,'2025-11-04 12:39:19',0,9,9,6),(1973,1,1,-7077619410796252692,1641,'sc:goods:type:import','导入【物品类别】',NULL,NULL,NULL,'2025-10-30 11:31:41',NULL,'2025-11-04 12:39:19',0,9,9,6),(1974,1,1,3297552907397842546,1644,'sc:goods:addSuit','加入门店设置',NULL,NULL,NULL,'2025-10-30 11:32:01',NULL,'2025-11-04 12:39:19',0,9,9,6),(1975,1,1,-435193994665499361,1644,'sc:goods:updateBatchState','批量修改状态',NULL,NULL,NULL,'2025-10-30 11:32:13',NULL,'2025-11-04 12:39:19',0,9,9,6),(1976,1,1,3772992544743481529,1644,'sc:goods:import','导入物品',NULL,NULL,NULL,'2025-10-30 11:32:25',NULL,'2025-11-04 12:39:19',0,9,9,6),(1977,1,1,-8787882751330282504,1647,'sc:warehouse:init','仓库期初',NULL,NULL,NULL,'2025-10-30 11:32:51',NULL,'2025-11-04 12:39:19',0,9,9,6),(1978,1,1,7250604679426801750,1647,'sc:warehouse:paras','仓库参数设置',NULL,NULL,NULL,'2025-10-30 11:32:59',NULL,'2025-11-04 12:39:19',0,9,9,6),(1979,1,1,4090135179775133400,1579,'crm:card:type:add','新增【会员卡类型】',NULL,NULL,NULL,'2025-10-30 14:21:03',NULL,'2025-11-04 12:39:19',0,9,9,3),(1980,1,1,6158108573934221771,1579,'crm:card:type:edit','修改【会员卡类型】',NULL,NULL,NULL,'2025-10-30 14:21:03',NULL,'2025-11-04 12:39:19',0,9,9,3),(1981,1,1,6573195615028437695,1579,'crm:card:type:list','查询【会员卡类型】',NULL,NULL,NULL,'2025-10-30 14:21:03',NULL,'2025-11-04 12:39:19',0,9,9,3),(1982,1,1,-5163195218044499068,1579,'crm:card:type:del','删除【会员卡类型】',NULL,NULL,NULL,'2025-10-30 14:21:03',NULL,'2025-11-04 12:39:19',0,9,9,3),(1983,1,1,805345497893739070,NULL,'pos:waiter:wine:save','存酒',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1984,1,1,3533902384488170676,NULL,'pos:waiter:wine:take','取酒',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1985,1,1,3630656499014771110,NULL,'pos:waiter:wine:record','存取酒记录',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1986,1,1,2684902806795745018,NULL,'pos:waiter:wine:save:examine','存酒审核',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1987,1,1,-4704362933367868645,NULL,'pos:waiter:wine:take:examine','取酒审核',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1988,1,1,-5578293824001003838,525,'pos:func:member:charge','会员充值',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1989,1,1,1808857554184762320,525,'pos:func:member:create','会员登记',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1990,1,1,-890159481418749021,525,'member:ops:card:mod:type','修改会员卡类型',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1991,1,1,-6166298182404116024,525,'member:ops:card:replace','换卡',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1992,1,1,5191865616303963639,525,'member:ops:card:mod:name','修改会员名称',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1993,1,1,6151312127026837427,525,'member:ops:card:transfer','合并/转让',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1994,1,1,-5705039021480416919,525,'member:ops:card:adjust:balance','余额调整',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1995,1,1,-3747506537998657142,525,'member:ops:card:adjust:points','积分调整',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1996,1,1,5902636844655853150,525,'member:ops:card:bind','会员卡绑定',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1997,1,1,-5952327892935057795,525,'member:ops:card:mod:pwd','修改会员密码',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1998,1,1,1325814200198245995,525,'member:ops:card:refund','会员卡退卡',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(1999,1,1,-3906705618824510756,525,'member:ops:card:lock','会员卡挂失',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2000,1,1,-8664874683225363070,525,'member:ops:card:unlock','会员卡解挂',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2001,1,1,8628073190298518031,525,'member:ops:card:mod:phone','修改会员卡电话',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2002,1,1,-8300021308506809844,525,'member:ops:invoice:open','开发票',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2003,1,1,-338861577903754206,525,'member:ops:card:charge:reprint','充值记录重打印',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2004,1,1,-912142637232410059,525,'member:ops:card:charge:revoke','撤销会员充值',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2005,1,1,-8072822791146658771,525,'pos:func:member:invoice:cancel','充值发票撤销',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2006,1,1,-7653352346085182493,525,'pos:func:member:print','充值发票重打印',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2007,1,1,5385725010638234164,527,'dwd:bill:ops:refund:all','全单退菜',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2008,1,1,7862596156742195694,527,'dwd:bill:ops:urge:all','全单催菜',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2009,1,1,8899391336613870138,527,'dwd:bill:ops:wake:all','全单叫起',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2010,1,1,-5683214938469318717,527,'dwd:bill:ops:up:all','全单起菜',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2011,1,1,-1297829194534056501,527,'dwd:bill:ops:gift:all','全单赠送',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2012,1,1,-2156346139634976647,527,'dwd:bill:ops:gift:all:cancel','全单撤销赠送',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2013,1,1,2084459226951301703,527,'dwd:bill:ops:reprint:food','重打菜品',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2014,1,1,-2771653694224584856,527,'dwd:bill:ops:reprint:customer','重打楼面总单',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2015,1,1,-4788659027943200992,527,'dwd:bill:ops:reprint:waiter','重打厨房总单',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2016,1,1,-906511901121522580,527,'dwd:bill:ops:modify:service:rate','修改服务费率',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2017,1,1,9197568519491916121,527,'dwd:bill:ops:modify:people:num','修改人数',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2018,1,1,-98552324176966382,527,'dwd:bill:ops:change:marketer','修改营销人',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2019,1,1,6662714661049740499,527,'dwd:bill:ops:change:remark','修改订单备注',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2020,1,1,-4278925616194900141,527,'dwd:bill:ops:clock:up','上钟',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2021,1,1,-93709160234237998,527,'dwd:bill:ops:clock:down','落钟',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2022,1,1,-2237535320709031227,527,'dwd:bill:ops:settle','结算',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2023,1,1,-6662356601997410848,527,'dwd:bill:ops:discount:cancel','全单撤销打折',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2024,1,1,4309379638184282188,526,'pos:func:member:invoice','发票明细',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2025,1,1,-358732904415383653,526,'dwd:bill:ops:check:cancel','反结账',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2026,1,1,8159507971348635096,526,'dwd:bill:ops:change:pay','修改支付方式',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2027,1,1,5091673875936087885,526,'dwd:bill:ops:changed:remark','修改订单备注',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2028,1,1,6461594913906009959,526,'pos:func:bill:summary','账单汇总',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2029,1,1,-5330568411210960325,526,'pos:func:bill:day','日销售表',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2030,1,1,-8439202443673999212,526,'pos:func:bill:dept','部门报表',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2031,1,1,-6595705688583725536,526,'pos:func:bill:revoke','反结账记录',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2032,1,1,6841703637947448923,526,'pos:func:bill:refund:gift','退、赠记录',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2033,1,1,-6641319272523522264,526,'pos:func:bill:shift','查交班单',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2034,1,1,3909204740620426956,526,'pos:func:bill:refund:pay','支付退款',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2035,1,1,8018923414141736002,526,'pos:func:bill:credit','挂账回款',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2036,1,1,1596732901472237716,526,'member:ops:card:reverse','撤销回款',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2037,1,1,-4039427928409725074,526,'member:ops:card:reverse:reprint','挂账回款记录重打印',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2038,1,1,-486429512719477119,527,'pos:discount:order:all','可使用所有打折',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2039,1,1,-8471342292445905497,527,'pos:discount:order:part','只能使用指定范围的打折',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2043,1,1,7481161433282347742,522,'dwd:food:ops:scatter','散点转酒席',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2044,1,1,-7240699269947472447,522,'dwd:food:ops:refund','单个/批量退菜',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2045,1,1,-1647390140271317841,522,'dwd:food:ops:urge','单个/批量催菜',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2046,1,1,6100292709171715073,522,'dwd:food:ops:up','单个/批量起菜',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2047,1,1,477699714589485685,522,'dwd:food:ops:wake','单个/批量叫起',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2048,1,1,8747664693811785781,522,'dwd:food:ops:modify:price','修改价格',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2049,1,1,-4868604803283927074,522,'dwd:food:ops:modify:volume','修改数量',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2050,1,1,4332498711022756101,522,'dwd:food:ops:gift','单个/批量赠送',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2051,1,1,-7702993013271759998,522,'dwd:food:ops:gift:cancel','单个/批量撤销赠送',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2052,1,1,-2096118378922460734,522,'dwd:food:ops:modify:cook','修改做法',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2053,1,1,-7992182547231689700,522,'dwd:food:ops:modify:seat','修改菜品席数',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2054,1,1,-1371527287060342973,522,'dwd:food:ops:discount','单品打折',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2055,1,1,398876722462250784,522,'dwd:food:ops:discount:cancel','单品撤销打折',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2056,1,1,-4436331793279057291,522,'dwd:food:ops:transfer','单个/批量菜品转台',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2057,1,1,-3778896280738783959,522,'dwd:food:ops:replace','换品',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2058,1,1,7935117810478106328,522,'dwd:sold:out:add','沽清设置',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2059,1,1,3881257828534775785,522,'dwd:sold:out:delete','取消沽清',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2060,1,1,3126505279773353138,521,'dwd:bill:add','开台',NULL,NULL,NULL,NULL,NULL,'2026-03-26 15:46:57',0,12,10,12),(2061,1,1,7684875073453894645,521,'dwd:bill:ops:share:tbl','搭台',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2062,1,1,-6849401958599219012,521,'dwd:bill:ops:merge:tbl','并台',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2063,1,1,-7294406170990337913,521,'dwd:bill:ops:transfer:tbl','全单转台',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2064,1,1,-6566676204654189543,521,'dwd:bill:ops:revoke','撤台',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2065,1,1,-4622195182638309857,522,'dwd:bill:to:order','送单',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2066,1,1,-8661303522971049071,522,'pos:meal:order:all','可点所有菜品',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2067,1,1,5727920596153462643,522,'pos:meal:order:part','只能点指定范围的菜品',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2068,1,1,-6540795298570113461,522,'pos:meal:refund:all','可退所有菜品',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2069,1,1,-3883519385417029099,522,'pos:meal:refund:part','只能退指定范围的菜品',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2070,1,1,5038247604156350576,522,'pos:meal:refund:day','日退菜金额上限(为0时不限制)：',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',1,12,10,12),(2071,1,1,-6163543073015238822,522,'pos:meal:refund:week','周退菜金额上限(为0时不限制)：',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',1,12,10,12),(2072,1,1,4457372556433659296,522,'pos:meal:refund:month','月退菜金额上限(为0时不限制)：',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',1,12,10,12),(2073,1,1,-6003825301760257758,522,'pos:meal:gift:all','可赠送所有菜品',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2074,1,1,-7300230128800189140,522,'pos:meal:gift:part','只能赠指定范围的菜品',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2075,1,1,6158828958140034460,522,'pos:meal:gift:day','日赠菜金额上限(为0时不限制)：',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',1,12,10,12),(2076,1,1,938116257939287922,522,'pos:meal:gift:week','周赠菜金额上限(为0时不限制)：',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',1,12,10,12),(2077,1,1,-4208890685611335401,522,'pos:meal:gift:month','月赠菜金额上限(为0时不限制):',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',1,12,10,12),(2078,1,1,8377241058389532596,527,'pos:discount:food:all','可以对所有菜品进行单项打折',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2079,1,1,-2186711517714577741,527,'pos:discount:food:part','只能对指定范围的菜品进行单选打折',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2080,1,1,1806362860505251862,527,'pos:discount:food:rate','最低折扣率(设置为0时，不作限制):',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2081,1,1,1832036136945795769,523,'dwd:bill:ops:discount:all','全单打折',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2082,1,1,-6768556030784092899,523,'dwd:bill:ops:fraction:add','能调整零头（增加）',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2083,1,1,-8500808764002120837,523,'dwd:bill:ops:fraction:sub','能调整零头（减少）',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2084,1,1,3116216455867953776,523,'dwd:bill:ops:fraction:sub:order','每单减少金额限制为(设置为0时，不作限制):',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',1,12,10,12),(2085,1,1,2911078150578551619,523,'dwd:bill:ops:fraction:sub:day','每天减少金额限制为(设置为0时，不作限制):',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',1,12,10,12),(2086,1,1,-2170539759783688978,523,'dwd:bill:ops:fraction:sub:week','每周减少金额限制为(设置为0时，不作限制):',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',1,12,10,12),(2087,1,1,-5640128811556145478,523,'dwd:bill:ops:fraction:sub:month','每月减少金额限制为(设置为0时，不作限制):',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',1,12,10,12),(2088,1,1,-4651966797392029789,523,'dwd:bill:ops:enter:member','录入会员',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2089,1,1,2755893379679728280,523,'dwd:bill:ops:member:cancel','撤销会员',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2090,1,1,1556906073097554628,523,'dwd:bill:ops:check:revoke:settle','撤销结算/支付',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2091,1,1,-4674699524864694819,523,'dwd:bill:ops:check:out','结账',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2092,1,1,-4863658418395276066,523,'dwd:invoice:add','开发票',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2093,1,1,5026734063172450875,523,'pos:pay:way:check:all','可使用所有支付方式结账',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2094,1,1,2708137938420385241,523,'pos:pay:way:check:part','只能使用指定范围的支付方式结账',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2095,1,1,-610898261689920878,525,'pos:pay:way:charge:all','可使用所有支付方式充值',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2096,1,1,-1404217154650688480,525,'pos:pay:way:charge:part','只能使用指定范围的支付方式充值',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:12',0,12,10,12),(2098,1,1,-8076932044505200884,1833,'Actual Revenue (Including Service Fees)','首页-实收营业额（含服务费）',NULL,NULL,NULL,'2025-11-03 11:22:35',NULL,'2025-11-04 12:39:19',0,9,9,35),(2099,1,1,6330227101387049876,1833,'Actual Revenue (excluding service fees)','实收营业额（不含服务费）',NULL,NULL,NULL,'2025-11-03 11:22:51',NULL,'2025-11-04 12:39:19',0,9,9,35),(2100,1,1,7447505753411113609,1833,'gross profit margin','毛利率',NULL,NULL,NULL,'2025-11-03 11:23:39',NULL,'2025-11-04 12:39:19',0,9,9,35),(2101,1,1,1773179914422784394,1833,'Gross Profit','毛利额',NULL,NULL,NULL,'2025-11-03 11:25:05',NULL,'2025-11-04 12:39:19',0,9,9,35),(2102,1,1,1396415771244490401,1833,'Food cost','食材成本',NULL,NULL,NULL,'2025-11-03 11:25:34',NULL,'2025-11-04 12:39:19',0,9,9,35),(2103,1,1,-4708994879055905787,1833,'profit','利润',NULL,NULL,NULL,'2025-11-03 11:25:54',NULL,'2025-11-04 12:39:19',0,9,9,35),(2104,1,1,2861071598449220791,1833,'per capita output','人均产出',NULL,NULL,NULL,'2025-11-03 11:26:16',NULL,'2025-11-04 12:39:19',0,9,9,35),(2105,1,1,4536587858057013995,1833,'operating cost','经营成本',NULL,NULL,NULL,'2025-11-03 11:26:44',NULL,'2025-11-04 12:39:19',0,9,9,35),(2106,1,1,5320697418437060071,1833,'Operating cost breakdown','经营成本明细',NULL,NULL,NULL,'2025-11-03 11:27:14',NULL,'2025-11-04 12:39:19',0,9,9,35),(2107,1,1,4086792279733107492,1833,'Total discount amount','折扣总金额',NULL,NULL,NULL,'2025-11-03 11:27:44',NULL,'2025-11-04 12:39:19',0,9,9,35),(2108,1,1,-5011237637226439297,1833,'Total amount of returned dishes','退菜总金额',NULL,NULL,NULL,'2025-11-03 11:28:10',NULL,'2025-11-04 12:39:19',0,9,9,35),(2109,1,1,7994926230387035031,1833,'Total gift amount','赠送总金额',NULL,NULL,NULL,'2025-11-03 11:28:41',NULL,'2025-11-04 12:39:19',0,9,9,35),(2110,1,1,-1933428777225820821,1833,'Total recharge amount','充值总金额',NULL,NULL,NULL,'2025-11-03 11:29:04',NULL,'2025-11-04 12:39:19',0,9,9,35),(2111,1,1,4213177829328038332,1838,'order goods','订货',NULL,NULL,NULL,'2025-11-03 18:19:20',NULL,'2025-11-04 12:39:19',0,9,9,37),(2112,1,1,-4110472259802392299,1838,'document','库存单据',NULL,NULL,NULL,'2025-11-03 18:19:41',NULL,'2025-11-04 12:39:19',0,9,9,37),(2113,1,1,-772244712254005488,1838,'purchase order','订货单',NULL,NULL,NULL,'2025-11-03 18:20:11',NULL,'2025-11-04 12:39:19',0,9,9,37),(2114,1,1,4783881269467037572,1838,'Order Dashboard','订货看板',NULL,NULL,NULL,'2025-11-03 18:20:32',NULL,'2025-11-04 12:39:19',0,9,9,37),(2115,1,1,6824452273704589383,1838,'Supplier allocation','供应商分拨',NULL,NULL,NULL,'2025-11-03 18:21:02',NULL,'2025-11-04 12:39:19',0,9,9,37),(2116,1,1,-1199227302840976871,1838,'Supplier Management','供应商管理',NULL,NULL,NULL,'2025-11-03 18:22:03',NULL,'2025-11-04 12:39:19',0,9,9,37),(2117,1,1,7166013551277417050,1838,'Item Management','物品管理',NULL,NULL,NULL,'2025-11-03 18:22:20',NULL,'2025-11-04 12:39:19',0,9,9,37),(2118,1,1,-2082141621031237889,1838,'Delivery Rules','配送规则',NULL,NULL,NULL,'2025-11-03 18:23:05',NULL,'2025-11-04 12:39:19',0,9,9,37),(2119,1,1,5200161603413808584,1838,'Order Summary','订货汇总',NULL,NULL,NULL,'2025-11-03 18:23:32',NULL,'2025-11-04 12:39:19',0,9,9,37),(2120,1,1,499561311665621778,1838,'Order Details','订货明细',NULL,NULL,NULL,'2025-11-03 18:24:16',NULL,'2025-11-04 12:39:19',0,9,9,37),(2121,1,1,115691953041886864,1838,'Ordering Template','订货模版',NULL,NULL,NULL,'2025-11-03 18:24:35',NULL,'2025-11-04 12:39:19',0,9,9,37),(2122,1,1,5019539383812431185,1839,'Stall order','档口订单查看',NULL,NULL,NULL,'2025-11-03 18:25:00',NULL,'2025-11-04 12:39:19',0,9,9,37),(2123,1,1,2831838335751418420,1839,'File review','档口订单审核',NULL,NULL,NULL,'2025-11-03 18:25:21',NULL,'2025-11-04 12:39:19',0,9,9,37),(2124,1,1,4047669524701390984,1839,'File counter audit','档口订单反审核',NULL,NULL,NULL,'2025-11-03 18:26:27',NULL,'2025-11-04 12:39:19',0,9,9,37),(2125,1,1,3668682314569797042,1839,'File generation','档口生成门店订货单',NULL,NULL,NULL,'2025-11-03 18:27:05',NULL,'2025-11-04 12:39:19',0,9,9,37),(2126,1,1,4936948353724319321,1839,'View store orders','门店订单查看',NULL,NULL,NULL,'2025-11-03 18:27:57',NULL,'2025-11-04 12:39:19',0,9,9,37),(2127,1,1,2502835432280981306,1839,'Store order review','门店订单审核',NULL,NULL,NULL,'2025-11-03 18:28:23',NULL,'2025-11-04 12:39:19',0,9,9,37),(2128,1,1,1020080764878550492,1839,'Anti audit of store orders','门店订单反审核',NULL,NULL,NULL,'2025-11-03 18:28:47',NULL,'2025-11-04 12:39:19',0,9,9,37),(2129,1,1,3456713315492562689,1839,'Store submits order','门店提交订货单',NULL,NULL,NULL,'2025-11-03 18:29:30',NULL,'2025-11-04 12:39:19',0,9,9,37),(2130,1,1,-8493646791375417216,1840,'Confirm inspection','进入验货',NULL,NULL,NULL,'2025-11-03 18:29:52',NULL,'2025-11-04 12:39:19',0,9,9,37),(2131,1,1,2836059362608445063,1840,'Modify Quantity','修改验货数量',NULL,NULL,NULL,'2025-11-03 18:30:46',NULL,'2025-11-04 12:39:19',0,9,9,37),(2132,1,1,1643134291679929764,1839,'Stall order deletion','档口订单删除',4,NULL,NULL,'2025-11-04 10:49:50',NULL,'2025-11-04 12:39:19',0,9,9,37),(2133,1,1,8822567973509171176,1839,'Store order deletion','门店订单删除',NULL,NULL,NULL,'2025-11-04 10:53:30',NULL,'2025-11-04 12:39:19',0,9,9,37),(2134,1,1,-2714318697951958475,1840,'Modify the unit price','修改单价',NULL,NULL,NULL,'2025-11-04 10:56:04',NULL,'2025-11-04 12:39:19',0,9,9,37),(2135,1,1,-1633039866879843543,1840,'Confirm receipt','确认收货',NULL,NULL,NULL,'2025-11-04 10:56:46',NULL,'2025-11-05 11:29:38',0,9,9,37),(2136,1,1,-2123687707107077299,1840,'Cancel the order','取消订货',NULL,NULL,NULL,'2025-11-04 10:57:05',NULL,'2025-11-05 11:29:38',0,9,9,37),(2137,1,1,8731116402052086795,1840,'Reject','拒收',NULL,NULL,NULL,'2025-11-04 10:57:29',NULL,'2025-11-05 11:29:38',0,9,9,37),(2138,1,1,-5068030082848187740,1840,'Undo the rejection','撤销拒收',NULL,NULL,NULL,'2025-11-04 10:57:49',NULL,'2025-11-05 11:29:38',0,9,9,37),(2140,1,1,-6163854310414182551,1841,'Switch stores','切换门店',NULL,NULL,NULL,'2025-11-04 11:00:12',NULL,'2025-11-04 12:39:19',0,9,9,37),(2141,1,1,7874654120860164444,524,'daily_settlement:do','日结',NULL,NULL,NULL,'2025-12-02 17:07:07',NULL,'2025-12-18 10:58:20',0,12,10,12),(2142,1,1,-8915807870508581209,524,'daily_settlement:undo','反日结',NULL,NULL,NULL,'2025-12-02 17:07:29',NULL,'2025-12-18 10:58:20',0,12,10,12),(2143,1,1,-6951149859946110875,522,'dwd:bill:ops:reprint:checkout','重打结账单',NULL,NULL,NULL,'2025-12-06 09:15:37',NULL,'2025-12-18 10:58:20',0,12,10,12),(2144,1,1,7112602986240069620,522,'dwd:bill:ops:reprint:totalbilllocal','重打楼面总单',NULL,NULL,NULL,'2025-12-06 09:15:45',NULL,'2025-12-18 10:58:20',0,12,10,12),(2145,1,1,1816958170408058766,522,'dwd:bill:ops:reprint:totalbill','重打厨房总单',NULL,NULL,NULL,'2025-12-06 09:15:53',NULL,'2025-12-18 10:58:20',0,12,10,12),(2146,1,1,-992262482056179166,522,'dwd:bill:ops:reprint:oldordermenu','重打出品单',NULL,NULL,NULL,'2025-12-06 09:15:59',NULL,'2025-12-18 10:58:20',0,12,10,12),(2147,1,1,-8830463455771213117,1847,'/mp/report/yygk','营业概况',NULL,NULL,NULL,'2025-12-12 15:59:31',NULL,'2025-12-18 10:58:20',0,12,10,38),(2148,1,1,4343648290835412464,1847,'/mp/report/yyfx','运营分析',NULL,NULL,NULL,'2025-12-12 15:59:56',NULL,'2025-12-18 10:58:20',0,12,10,38),(2149,1,1,3963884319804954109,1847,'/mp/report/zyzt','自营外卖/自提订单明细',NULL,NULL,NULL,'2025-12-12 16:00:31',NULL,'2025-12-18 10:58:20',0,12,10,38),(2150,1,1,9018875894604134722,1847,'/mp/report/dndd','店内订单明细',NULL,NULL,NULL,'2025-12-12 16:00:51',NULL,'2025-12-18 10:58:20',0,12,10,38),(2151,1,1,-8437450997750735794,1847,'/mp/report/yyzb','营业指标同环比',NULL,NULL,NULL,'2025-12-12 16:01:27',NULL,'2025-12-18 10:58:20',0,12,10,38),(2152,1,1,-8991662782031746203,1847,'/mp/report/mgcztj','敏感操作统计',NULL,NULL,NULL,'2025-12-12 16:01:43',NULL,'2025-12-12 16:06:13',0,12,10,38),(2153,1,1,-780260323924984784,1847,'/mp/report/bmyy','部门营业统计',NULL,NULL,NULL,'2025-12-12 16:02:12',NULL,'2025-12-18 10:58:20',0,12,10,38),(2154,1,1,8755364260472346526,1847,'/mp/report/syysy','收银员收银统计',NULL,NULL,NULL,'2025-12-12 16:02:34',NULL,'2025-12-18 10:58:20',0,12,10,38),(2155,1,1,-5277338904394627703,1847,'/mp/report/mdyy','门店营业排行',NULL,NULL,NULL,'2025-12-12 16:02:54',NULL,'2025-12-18 10:58:20',0,12,10,38),(2156,1,1,-8262036715734525056,1847,'/mp/report/cqztyy','餐区桌台营业统计',NULL,NULL,NULL,'2025-12-12 16:03:17',NULL,'2025-12-18 10:58:20',0,12,10,38),(2157,1,1,5186886341145376362,1847,'/mp/report/csdyy','餐时段营业统计',NULL,NULL,NULL,'2025-12-12 16:03:36',NULL,'2025-12-18 10:58:20',0,12,10,38),(2158,1,1,-5528049635726713709,1847,'/mp/report/mgczxq','敏感操作详情',NULL,NULL,NULL,'2025-12-12 16:04:02',NULL,'2025-12-18 10:58:20',0,12,10,38),(2159,1,1,-8276424424091260966,1847,'/mp/report/zfjs','支付结算',NULL,NULL,NULL,'2025-12-12 16:04:25',NULL,'2025-12-18 10:58:20',0,12,10,38),(2160,1,1,6148114914026549725,1847,'/mp/report/zjmx','支付明细',NULL,NULL,NULL,'2025-12-12 16:04:41',NULL,'2025-12-18 10:58:20',0,12,10,38),(2161,1,1,3573684030601465831,1847,'/mp/report/cpxstj','菜品销售统计',NULL,NULL,NULL,'2025-12-12 16:05:06',NULL,'2025-12-18 10:58:20',0,12,10,38),(2162,1,1,-948719188634807972,1847,'/mp/report/cpxsmx','菜品销售明细',NULL,NULL,NULL,'2025-12-12 16:05:22',NULL,'2025-12-18 10:58:20',0,12,10,38),(2163,1,1,3825672682318257506,1847,'/mp/report/cpbs','菜品报损统计',NULL,NULL,NULL,'2025-12-12 16:05:39',NULL,'2025-12-18 10:58:20',0,12,10,38),(2164,1,1,3064290568355570784,1847,'/mp/report/jjbtj','交接班统计',NULL,NULL,NULL,'2025-12-12 16:06:00',NULL,'2025-12-18 10:58:20',0,12,10,38),(2165,1,1,6755245703588045715,1665,'sc:st:bill:finish','审核【仓库单据】',NULL,NULL,NULL,'2025-12-12 16:17:02',NULL,'2025-12-18 10:58:20',0,9,9,6),(2166,1,1,2911377555702607768,1836,'yygk','营业概况',NULL,NULL,NULL,'2025-12-12 17:27:44',NULL,'2025-12-18 10:58:20',0,9,9,35),(2167,1,1,5882929267821796100,1836,'yyfx','运营分析',NULL,NULL,NULL,'2025-12-12 17:28:00',NULL,'2025-12-18 10:58:20',0,9,9,35),(2168,1,1,-6281171081769616445,1836,'zyzt','自营外卖/自提订单明细',NULL,NULL,NULL,'2025-12-12 17:28:15',NULL,'2025-12-18 10:58:20',0,9,9,35),(2169,1,1,-4216578997674350308,1836,'dndd','店内订单明细',NULL,NULL,NULL,'2025-12-12 17:28:30',NULL,'2025-12-18 10:58:20',0,9,9,35),(2170,1,1,-8537546267624102736,1836,'yyzb','营业指标同环比',NULL,NULL,NULL,'2025-12-12 17:28:44',NULL,'2025-12-18 10:58:20',0,9,9,35),(2171,1,1,1226728220210394377,1836,'mgcztj','敏感操作统计',NULL,NULL,NULL,'2025-12-12 17:28:58',NULL,'2025-12-18 10:58:20',0,9,9,35),(2172,1,1,5051253441521013476,1836,'bmyy','部门营业统计',NULL,NULL,NULL,'2025-12-12 17:29:11',NULL,'2025-12-18 10:58:20',0,9,9,35),(2173,1,1,-3823061561686283173,1836,'syysy','收银员收银统计',NULL,NULL,NULL,'2025-12-12 17:29:25',NULL,'2025-12-18 10:58:20',0,9,9,35),(2174,1,1,831569258390453382,1836,'mdyy','门店营业排行',NULL,NULL,NULL,'2025-12-12 17:29:39',NULL,'2025-12-18 10:58:20',0,9,9,35),(2175,1,1,6800341980619819152,1836,'cqztyy','餐区桌台营业统计',NULL,NULL,NULL,'2025-12-12 17:29:52',NULL,'2025-12-18 10:58:20',0,9,9,35),(2176,1,1,3441928319579342981,1836,'csdyy','餐时段营业统计',NULL,NULL,NULL,'2025-12-12 17:30:07',NULL,'2025-12-18 10:58:20',0,9,9,35),(2177,1,1,7560386480648395303,1836,'mgczxq','敏感操作详情',NULL,NULL,NULL,'2025-12-12 17:30:20',NULL,'2025-12-18 10:58:20',0,9,9,35),(2178,1,1,2762341172367740604,1836,'zfjs','支付结算',NULL,NULL,NULL,'2025-12-12 17:30:33',NULL,'2025-12-18 10:58:20',0,9,9,35),(2179,1,1,3439704824718569859,1836,'zjmx','支付明细',NULL,NULL,NULL,'2025-12-12 17:30:49',NULL,'2025-12-18 10:58:20',0,9,9,35),(2180,1,1,4228282370555620216,1836,'cpxstj','菜品销售统计',NULL,NULL,NULL,'2025-12-12 17:31:07',NULL,'2025-12-18 10:58:20',0,9,9,35),(2181,1,1,5145450378722136799,1836,'cpxsmx','菜品销售明细',NULL,NULL,NULL,'2025-12-12 17:31:21',NULL,'2025-12-18 10:58:20',0,9,9,35),(2182,1,1,2339210114435889169,1836,'cpbs','菜品报损统计',NULL,NULL,NULL,'2025-12-12 17:31:34',NULL,'2025-12-18 10:58:20',0,9,9,35),(2183,1,1,-5072190001476573135,1836,'jjbtj','交接班统计',NULL,NULL,NULL,'2025-12-12 17:31:48',NULL,'2025-12-18 10:58:20',0,9,9,35),(2184,1,1,-2499849295272084,1665,'sc:st:bill:revert','反审核【仓库单据】',NULL,NULL,NULL,'2025-12-13 11:08:57',NULL,'2025-12-18 10:58:20',0,9,9,6),(2185,1,1,-8409948647343005566,523,'snack_ops:rmv','整单取消',NULL,NULL,NULL,'2025-12-14 11:44:44',NULL,'2025-12-18 10:58:20',0,12,10,12),(2186,1,1,6533322433533533931,523,'dwd:bill:ops:refund:foods','批量退款',NULL,NULL,NULL,'2025-12-14 12:43:29',NULL,'2025-12-18 10:58:20',0,12,10,12),(2187,1,1,-2380678328953234043,523,'dwd:bill:ops:refund:order','整单退款',NULL,NULL,NULL,'2025-12-14 12:43:37',NULL,'2025-12-18 10:58:20',0,12,10,12),(2188,1,1,-3739977952888839752,1725,'sc:product:setupUnit','菜品设置/编辑成本卡',2,NULL,NULL,'2025-12-15 11:39:48',NULL,'2025-12-19 11:29:19',0,9,9,6),(2189,1,1,8741672921573431799,1725,'sc:product:copy','复制成本卡',3,NULL,NULL,'2025-12-15 11:40:02',NULL,'2025-12-19 11:29:39',0,9,9,6),(2190,1,1,2731184284609511239,1725,'sc:product:replace','修改替换原材料',4,NULL,NULL,'2025-12-15 11:40:18',NULL,'2025-12-19 11:29:45',0,9,9,6),(2191,1,1,2910690492512881990,1725,'sc:product:batch_clean','批量删除成本卡',5,NULL,NULL,'2025-12-15 11:40:27',NULL,'2025-12-19 11:29:50',0,9,9,6),(2192,1,1,9178664621427052531,1725,'sc:product:import','导入成本卡',6,NULL,NULL,'2025-12-15 11:40:37',NULL,'2025-12-19 11:29:56',0,9,9,6),(2193,1,1,2942068985626254983,1725,'sc:product:/export','导出成本卡',7,NULL,NULL,'2025-12-15 11:40:46',NULL,'2025-12-19 11:30:00',0,9,9,6),(2194,1,1,-2565166951006227304,1725,'sc:product:query','查看成本卡列表',0,NULL,NULL,'2025-12-16 11:26:22',NULL,'2025-12-19 14:13:25',0,9,9,6),(2195,1,1,3438511420035353278,1725,'sc:product:query_detail','查看成本卡详情',1,NULL,NULL,'2025-12-19 11:28:19',NULL,'2025-12-20 17:33:34',0,9,9,6),(2196,1,1,-7286249711801024351,1665,'sc:st:bill:copy','复制单据',NULL,NULL,NULL,'2025-12-19 16:16:17',NULL,'2025-12-20 17:33:34',0,9,9,6),(2197,1,1,-7722392454359842708,1665,'sc:st:bill:red','冲红单据',NULL,NULL,NULL,'2025-12-19 16:16:27',NULL,'2025-12-20 17:33:34',0,9,9,6),(2198,1,1,-3735973803300774401,1665,'sc:st:bill:finish_batch','批量审核',NULL,NULL,NULL,'2025-12-19 16:16:36',NULL,'2025-12-20 17:33:34',0,9,9,6),(2199,1,1,3573365258794595164,1665,'sc:st:bill:print','打印单据',NULL,NULL,NULL,'2025-12-19 16:16:44',NULL,'2025-12-20 17:33:34',0,9,9,6),(2200,1,1,2896960631159902221,1665,'sc:st:bill:export','导出单据',NULL,NULL,NULL,'2025-12-19 16:16:54',NULL,'2025-12-20 17:33:34',0,9,9,6),(2201,1,1,-6566521981481858493,1620,'sc:my:desk:list','查看',NULL,NULL,NULL,'2025-12-24 11:26:44',NULL,'2025-12-24 11:36:37',0,9,9,6),(2202,1,1,8907667537708268207,1653,'sc:customer:list','查看客户列表',NULL,NULL,NULL,'2025-12-24 11:37:50',NULL,'2025-12-25 16:02:00',0,9,9,6),(2203,1,1,3413443055528853447,1653,'sc:customer:detail','查看客户详情',NULL,NULL,NULL,'2025-12-24 11:38:15',NULL,'2025-12-25 16:02:00',0,9,9,6),(2204,1,1,8077735319287534393,1653,'sc:customer:add','新增客户',NULL,NULL,NULL,'2025-12-24 11:38:36',NULL,'2025-12-25 16:02:00',0,9,9,6),(2205,1,1,-3169993899677600554,1653,'sc:customer:edit','编辑客户信息',NULL,NULL,NULL,'2025-12-24 11:39:00',NULL,'2025-12-25 16:02:00',0,9,9,6),(2206,1,1,5084003059270043130,1653,'sc:customer:del','删除客户',NULL,NULL,NULL,'2025-12-24 11:39:27',NULL,'2025-12-25 16:02:00',0,9,9,6),(2207,1,1,161211671538236581,1674,'sc:quote:order:list','查看报价单列表',NULL,NULL,NULL,'2025-12-24 11:54:00',NULL,'2025-12-24 11:54:34',0,9,9,6),(2208,1,1,-4947225393879231170,1674,'sc:quote:order:detail','查看报价单详情',NULL,NULL,NULL,'2025-12-24 11:55:47',NULL,'2025-12-25 16:02:00',0,9,9,6),(2209,1,1,-7837473721221211450,1674,'sc:quote:order:add','新增报价单',NULL,NULL,NULL,'2025-12-24 11:56:02',NULL,'2025-12-25 16:02:00',0,9,9,6),(2210,1,1,7870063156365145968,1674,'sc:quote:order:update','编辑报价单',NULL,NULL,NULL,'2025-12-24 11:56:16',NULL,'2025-12-25 16:02:00',0,9,9,6),(2211,1,1,-4062422469868137353,1674,'sc:quote:order:state','审核报价单',NULL,NULL,NULL,'2025-12-24 11:57:06',NULL,'2025-12-25 16:02:00',0,9,9,6),(2212,1,1,2003676343750426624,1674,'sc:quote:order:batch_state','批量审核报价单',NULL,NULL,NULL,'2025-12-24 11:57:21',NULL,NULL,1,9,9,6),(2213,1,1,6807153118879968375,1674,'sc:quote:order:del','删除报价单',NULL,NULL,NULL,'2025-12-24 11:57:38',NULL,'2025-12-25 16:02:00',0,9,9,6),(2214,1,1,7012654277336044253,1674,'quote:order:import','导入报价单',NULL,NULL,NULL,'2025-12-24 11:57:52',NULL,'2025-12-25 16:02:00',0,9,9,6),(2215,1,1,-3190800311563206126,1677,'sc:supplier:quote:list','查看列表',NULL,NULL,NULL,'2025-12-24 13:36:05',NULL,'2025-12-25 16:02:00',0,9,9,6),(2216,1,1,-2770863007467846393,1677,'sc:supplier:quote:add','新增报价单',NULL,NULL,NULL,'2025-12-24 13:36:32',NULL,'2025-12-25 16:02:00',0,9,9,6),(2217,1,1,-4833506045791766224,1677,'sc:supplier:quote:update','编辑报价单',NULL,NULL,NULL,'2025-12-24 13:36:46',NULL,'2025-12-25 16:02:00',0,9,9,6),(2218,1,1,879661841983926817,1677,'sc:supplier:quote:import','导入报价单',NULL,NULL,NULL,'2025-12-24 13:36:57',NULL,'2025-12-25 16:02:00',0,9,9,6),(2219,1,1,-1834855814376468028,1677,'sc:supplier:quote:export','导出报价单',NULL,NULL,NULL,'2025-12-24 13:37:10',NULL,'2025-12-25 16:02:00',0,9,9,6),(2220,1,1,-9221780803362028977,1680,'sc:delivery:order:list','查看列表',NULL,NULL,NULL,'2025-12-24 13:45:59',NULL,'2025-12-25 16:02:00',0,9,9,6),(2221,1,1,-4927023625122436910,1680,'sc:delivery:order:detail','查看详情',NULL,NULL,NULL,'2025-12-24 13:46:12',NULL,'2025-12-25 16:02:00',0,9,9,6),(2222,1,1,3523982975576732508,1680,'sc:delivery:order:add','新增报价单',NULL,NULL,NULL,'2025-12-24 13:46:23',NULL,'2025-12-25 16:02:00',0,9,9,6),(2223,1,1,3008165096871851227,1680,'sc:delivery:order:state','审核报价单',NULL,NULL,NULL,'2025-12-24 13:46:39',NULL,'2025-12-25 16:02:00',0,9,9,6),(2224,1,1,6480103046028102059,1680,'sc:delivery:order:del','删除报价单',NULL,NULL,NULL,'2025-12-24 13:46:51',NULL,'2025-12-25 16:02:00',0,9,9,6),(2225,1,1,4545167445025436823,1683,'sc:delivery:order:listQuote','查看列表',NULL,NULL,NULL,'2025-12-24 13:54:47',NULL,'2025-12-25 16:02:00',0,9,9,6),(2226,1,1,-8361147712970870445,1683,'sc:delivery:order:getSuitShops','适用组织',NULL,NULL,NULL,'2025-12-24 13:55:11',NULL,'2025-12-25 16:02:00',0,9,9,6),(2227,1,1,2745640932568275201,1683,'sc:delivery:order:addOtherQuote','添加例外',NULL,NULL,NULL,'2025-12-24 13:55:25',NULL,'2025-12-25 16:02:00',0,9,9,6),(2228,1,1,6241498491811093175,1683,'sc:delivery:order:addQuote','新增协议价',NULL,NULL,NULL,'2025-12-24 13:55:41',NULL,'2025-12-25 16:02:00',0,9,9,6),(2229,1,1,-9187027686210312784,1683,'sc:delivery:order:updateQuote','编辑协议价',NULL,NULL,NULL,'2025-12-24 13:55:53',NULL,'2025-12-25 16:02:00',0,9,9,6),(2230,1,1,-7845532267390826970,1683,'sc:delivery:order:rmvQuote','删除协议价',NULL,NULL,NULL,'2025-12-24 13:56:10',NULL,'2025-12-25 16:02:00',0,9,9,6),(2231,1,1,6566485090500800940,1686,'sc:depart:order:list','查看列表',NULL,NULL,NULL,'2025-12-24 14:10:55',NULL,'2025-12-25 16:02:00',0,9,9,6),(2232,1,1,-4665156296242344672,1686,'sc:depart:order:add','新增',NULL,NULL,NULL,'2025-12-24 14:11:07',NULL,'2025-12-25 16:02:00',0,9,9,6),(2233,1,1,-3600760813817929167,1686,'sc:depart:order:update','编辑',NULL,NULL,NULL,'2025-12-24 14:11:18',NULL,'2025-12-25 16:02:00',0,9,9,6),(2234,1,1,-373472725319836672,1686,'sc:depart:order:del','删除',NULL,NULL,NULL,'2025-12-24 14:11:32',NULL,'2025-12-25 16:02:00',0,9,9,6),(2235,1,1,2103287663857231575,1686,'sc:depart:order:reject','驳回',NULL,NULL,NULL,'2025-12-24 14:11:43',NULL,'2025-12-25 16:02:00',0,9,9,6),(2236,1,1,-5531112008401302722,1686,'sc:depart:order:state','审核',NULL,NULL,NULL,'2025-12-24 14:11:54',NULL,'2025-12-25 16:02:00',0,9,9,6),(2237,1,1,6079074294403218846,1686,'sc:depart:order:revert','反审核',NULL,NULL,NULL,'2025-12-24 14:12:05',NULL,'2025-12-25 16:02:00',0,9,9,6),(2238,1,1,1903234712253590485,1686,'sc:depart:order:build','生成门店订货单',NULL,NULL,NULL,'2025-12-24 14:12:19',NULL,'2025-12-25 16:02:00',0,9,9,6),(2239,1,1,-4315300057574447435,1689,'sc:store:order:list','查看列表',NULL,NULL,NULL,'2025-12-24 14:26:10',NULL,'2025-12-25 16:02:00',0,9,9,6),(2240,1,1,2687661404613766004,1689,'sc:store:order:detail','查看详情',NULL,NULL,NULL,'2025-12-24 14:26:24',NULL,'2025-12-25 16:02:00',0,9,9,6),(2241,1,1,4110762673880968813,1689,'sc:store:order:add','新增',NULL,NULL,NULL,'2025-12-24 14:26:34',NULL,'2025-12-25 16:02:00',0,9,9,6),(2242,1,1,2284865273063336522,1689,'sc:store:order:update','编辑',NULL,NULL,NULL,'2025-12-24 14:26:45',NULL,'2025-12-25 16:02:00',0,9,9,6),(2243,1,1,9071233103788801631,1689,'sc:store:order:del','删除',NULL,NULL,NULL,'2025-12-24 14:26:59',NULL,'2025-12-25 16:02:00',0,9,9,6),(2244,1,1,-5290338929559734566,1689,'sc:store:order:state','审核',NULL,NULL,NULL,'2025-12-24 14:27:14',NULL,'2025-12-25 16:02:00',0,9,9,6),(2245,1,1,7882556228417653305,1689,'sc:store:order:revert','反审核',NULL,NULL,NULL,'2025-12-24 14:27:26',NULL,'2025-12-25 16:02:00',0,9,9,6),(2246,1,1,8045678738322154337,1689,'sc:store:order:reject','驳回·',NULL,NULL,NULL,'2025-12-24 14:27:37',NULL,'2025-12-25 16:02:00',0,9,9,6),(2247,1,1,491632498063903143,1689,'sc:store:order:submit','提交订货单',NULL,NULL,NULL,'2025-12-24 14:27:52',NULL,'2025-12-25 16:02:00',0,9,9,6),(2248,1,1,-1378615671058626385,1689,'sc:store:order:build','合并',NULL,NULL,NULL,'2025-12-24 14:28:04',NULL,'2025-12-25 16:02:00',0,9,9,6),(2249,1,1,2100449276445144800,1692,'sc:inspect:item:listItems','查看列表',NULL,NULL,NULL,'2025-12-24 14:36:14',NULL,'2025-12-25 16:02:00',0,9,9,6),(2250,1,1,3848673706984180298,1692,'sc:inspect:item:updateItems','编辑',NULL,NULL,NULL,'2025-12-24 14:36:25',NULL,'2025-12-25 16:02:00',0,9,9,6),(2251,1,1,7757786073110213893,1692,'sc:inspect:item:inspect','验货入库',NULL,NULL,NULL,'2025-12-24 14:36:36',NULL,'2025-12-25 16:02:00',0,9,9,6),(2252,1,1,1464031546355388068,1692,'sc:inspect:item:printInspectOrderTask','打印验货入库单',NULL,NULL,NULL,'2025-12-24 14:36:49',NULL,'2025-12-25 16:02:00',0,9,9,6),(2253,1,1,-7439357200517300861,1692,'sc:inspect:item:exportSupplierItemTask','导出供应商分拨单',NULL,NULL,NULL,'2025-12-24 14:37:03',NULL,'2025-12-25 16:02:00',0,9,9,6),(2254,1,1,-3713616629967361311,1692,'sc:inspect:item:printSupplierItemTask','打印供应商分拨单',NULL,NULL,NULL,'2025-12-24 14:37:18',NULL,'2025-12-25 16:02:00',0,9,9,6),(2255,1,1,-4736459919865213460,1695,'sc:inspect:supplier:list','查看列表',NULL,NULL,NULL,'2025-12-24 14:48:05',NULL,'2025-12-25 16:02:00',0,9,9,6),(2256,1,1,2527138726116195348,1695,'sc:inspect:supplier:audit','验货',NULL,NULL,NULL,'2025-12-24 14:48:17',NULL,'2025-12-25 16:02:00',0,9,9,6),(2257,1,1,2761836330284983060,1701,'sc:rdc:order:list','查看列表',NULL,NULL,NULL,'2025-12-24 14:50:58',NULL,'2025-12-25 16:02:00',0,9,9,6),(2258,1,1,194218279621899432,1701,'sc:rdc:order:detail','查看详情',NULL,NULL,NULL,'2025-12-24 14:51:11',NULL,'2025-12-25 16:02:00',0,9,9,6),(2259,1,1,568259655424563903,1701,'sc:rdc:order:add','新增',NULL,NULL,NULL,'2025-12-24 14:51:25',NULL,'2025-12-25 16:02:00',0,9,9,6),(2260,1,1,1894050149633679451,1701,'sc:rdc:order:update','编辑',NULL,NULL,NULL,'2025-12-24 14:51:37',NULL,'2025-12-25 16:02:00',0,9,9,6),(2261,1,1,-7685604780263847822,1701,'sc:rdc:order:state','审核',NULL,NULL,NULL,'2025-12-24 14:52:31',NULL,'2025-12-25 16:02:00',0,9,9,6),(2262,1,1,8885149491831697675,1701,'sc:rdc:order:revert','反审核',NULL,NULL,NULL,'2025-12-24 14:52:42',NULL,'2025-12-25 16:02:00',0,9,9,6),(2263,1,1,-1054445701183986250,1701,'sc:rdc:order:reject','驳回',NULL,NULL,NULL,'2025-12-24 14:52:53',NULL,'2025-12-25 16:02:00',0,9,9,6),(2264,1,1,3431757320716425242,1701,'sc:rdc:order:del','删除',NULL,NULL,NULL,'2025-12-24 14:53:05',NULL,'2025-12-25 16:02:00',0,9,9,6),(2265,1,1,5104080745899980016,1701,'sc:rdc:order:import','导入',NULL,NULL,NULL,'2025-12-24 14:53:21',NULL,'2025-12-25 16:02:00',0,9,9,6),(2266,1,1,-1666509101525951408,1701,'sc:rdc:order:export','导出',NULL,NULL,NULL,'2025-12-24 14:53:33',NULL,'2025-12-25 16:02:00',0,9,9,6),(2267,1,1,4157999574725825798,1704,'sc:delivery:out:list','查看列表',NULL,NULL,NULL,'2025-12-24 15:00:59',NULL,'2025-12-25 16:02:00',0,9,9,6),(2268,1,1,-6224433244952748119,1704,'sc:delivery:out:updateItems','编辑',NULL,NULL,NULL,'2025-12-24 15:01:10',NULL,'2025-12-25 16:02:00',0,9,9,6),(2269,1,1,-5289611393413603651,1704,'sc:delivery:out:deliveryOutbound','出库',NULL,NULL,NULL,'2025-12-24 15:01:21',NULL,'2025-12-25 11:33:01',0,9,9,6),(2270,1,1,1685450555283486528,1704,'sc:delivery:out:export','导出订货明细',NULL,NULL,NULL,'2025-12-24 15:01:37',NULL,'2025-12-25 16:02:00',0,9,9,6),(2271,1,1,6023658336461640918,1704,'sc:delivery:out:print','打印配送单',NULL,NULL,NULL,'2025-12-24 15:01:49',NULL,'2025-12-25 16:02:00',0,9,9,6),(2272,1,1,-1560981000335955357,1707,'sc:rdc:order:listItems','查看列表',NULL,NULL,NULL,'2025-12-24 15:06:22',NULL,'2025-12-25 16:02:00',0,9,9,6),(2273,1,1,-6589880397749425095,1707,'sc:rdc:order:updateItems','编辑',NULL,NULL,NULL,'2025-12-24 15:06:49',NULL,'2025-12-25 16:02:00',0,9,9,6),(2274,1,1,3297340565848263965,1707,'sc:rdc:order:submitted','审核并提交',NULL,NULL,NULL,'2025-12-24 15:07:03',NULL,'2025-12-25 16:02:00',0,9,9,6),(2275,1,1,4936128728942238206,1707,'sc:rdc:order:split','拆分记录',NULL,NULL,NULL,'2025-12-24 15:07:35',NULL,'2025-12-25 16:02:00',0,9,9,6),(2276,1,1,2308773366298162169,1707,'sc:rdc:order:modSupplier','修改供应商',NULL,NULL,NULL,'2025-12-24 15:07:49',NULL,'2025-12-25 16:02:00',0,9,9,6),(2277,1,1,470566036449498440,1707,'sc:rdc:order:modArrivalTime','修改到货日期',NULL,NULL,NULL,'2025-12-24 15:08:10',NULL,'2025-12-25 16:02:00',0,9,9,6),(2278,1,1,2459120226373336386,1707,'sc:rdc:order:exportRdcOrderListTask','导出订货清单',NULL,NULL,NULL,'2025-12-24 15:08:18',NULL,'2025-12-25 16:02:00',0,9,9,6),(2279,1,1,1023501144081306037,1707,'sc:rdc:order:exportRdcOrderItemTask','导出订货明细',NULL,NULL,NULL,'2025-12-24 15:08:31',NULL,'2025-12-25 16:02:00',0,9,9,6),(2280,1,1,-7812854747920780775,1707,'sc:inspect:item:exportAllotOrderTask','分拨单',NULL,NULL,NULL,'2025-12-24 15:08:44',NULL,'2025-12-25 16:02:00',0,9,9,6),(2281,1,1,7569815007189176738,1707,'sc:inspect:item:exportDeliveryOrderTask','配送单',NULL,NULL,NULL,'2025-12-24 15:08:57',NULL,'2025-12-25 16:02:00',0,9,9,6),(2282,1,1,-1067799555279444847,1707,'sc:inspect:item:exportDepartOrderTask','导出档口订货单',NULL,NULL,NULL,'2025-12-24 15:09:21',NULL,'2025-12-25 16:02:00',0,9,9,6),(2283,1,1,7810744383169415420,1707,'sc:inspect:item:printAllotOrderTask','打印供货商分拨单',NULL,NULL,NULL,'2025-12-24 15:09:38',NULL,'2025-12-25 16:02:00',0,9,9,6),(2284,1,1,7734706421064378453,1707,'sc:inspect:item:printDeliveryOrderTask','打印配送单',NULL,NULL,NULL,'2025-12-24 15:09:52',NULL,'2025-12-25 16:02:00',0,9,9,6),(2285,1,1,5432971124107377324,1710,'sc:prepay:order:list','查看列表',NULL,NULL,NULL,'2025-12-24 15:18:12',NULL,'2025-12-25 16:02:00',0,9,9,6),(2286,1,1,-5869302584534432009,1710,'sc:prepay:order:detail','查看详情',NULL,NULL,NULL,'2025-12-24 15:18:22',NULL,'2025-12-25 16:02:00',0,9,9,6),(2287,1,1,7582655929917095322,1710,'sc:prepay:order:add','新增预付款单',NULL,NULL,NULL,'2025-12-24 15:18:44',NULL,'2025-12-25 16:02:00',0,9,9,6),(2288,1,1,4578799247324271844,1710,'sc:prepay:order:update','编辑预付款单',NULL,NULL,NULL,'2025-12-24 15:18:53',NULL,'2025-12-25 16:02:00',0,9,9,6),(2289,1,1,-96274204369653483,1710,'sc:prepay:order:state','审核预付款单',NULL,NULL,NULL,'2025-12-24 15:19:08',NULL,'2025-12-25 16:02:00',0,9,9,6),(2290,1,1,-1213333115888286892,1710,'sc:prepay:order:del','删除预付款单',NULL,NULL,NULL,'2025-12-24 15:19:26',NULL,'2025-12-25 16:02:00',0,9,9,6),(2291,1,1,-6119317272165613014,1713,'sc:bill:list','单据结算列表查看',NULL,NULL,NULL,'2025-12-24 15:42:58',NULL,'2025-12-25 16:02:00',0,9,9,6),(2292,1,1,-1071304496961476437,1713,'sc:good:list','物品结算列表查看',NULL,NULL,NULL,'2025-12-24 15:43:10',NULL,'2025-12-25 16:02:00',0,9,9,6),(2293,1,1,8481446080477454443,1713,'sc:bill:pay:item:add','新增付款-单据结算',NULL,NULL,NULL,'2025-12-24 15:43:37',NULL,'2025-12-25 16:02:00',0,9,9,6),(2294,1,1,-7453164288233649591,1713,'sc:st:bill:checked','对账-单据结算',NULL,NULL,NULL,'2025-12-24 15:44:04',NULL,'2025-12-25 16:02:00',0,9,9,6),(2295,1,1,7206411548995203323,1713,'sc:bill:pay:item:checked','核销-单据结算',NULL,NULL,NULL,'2025-12-24 15:44:43',NULL,'2025-12-25 16:02:00',0,9,9,6),(2296,1,1,8337914737982557703,1713,'sc:st:bill:listSettleDetail','单据明细-单据结算',NULL,NULL,NULL,'2025-12-24 15:45:25',NULL,'2025-12-25 16:02:00',0,9,9,6),(2297,1,1,-6795173618146295709,1713,'sc:bill:pay:item:cancel','取消付款-单据结算',NULL,NULL,NULL,'2025-12-24 15:45:40',NULL,'2025-12-25 16:02:00',0,9,9,6),(2298,1,1,6742493166924747064,1713,'sc:bill:invoice:order:add','添加发票-单据结算',NULL,NULL,NULL,'2025-12-24 15:45:54',NULL,'2025-12-25 16:02:00',0,9,9,6),(2299,1,1,7049415475702141251,1713,'sc:bill:invoice:order:cancel','取消发票-单据结算',NULL,NULL,NULL,'2025-12-24 15:46:09',NULL,'2025-12-25 16:02:00',0,9,9,6),(2300,1,1,-3068089568437288441,1713,'sc:st:bill:cancelChecked','取消对账-单据结算',NULL,NULL,NULL,'2025-12-24 15:46:22',NULL,'2025-12-25 16:02:00',0,9,9,6),(2301,1,1,4535860311986930601,1713,'sc:bill:pay:item:allAdd','全部付款-单据结算',NULL,NULL,NULL,'2025-12-24 15:46:37',NULL,'2025-12-25 16:02:00',0,9,9,6),(2302,1,1,4284716936650104509,1713,'sc:st:bill:exportBillSettleTask','导出-单据结算',NULL,NULL,NULL,'2025-12-24 15:46:57',NULL,'2025-12-25 16:02:00',0,9,9,6),(2303,1,1,9121805811553752942,1713,'sc:st:good:exportBillSettleTask','导出-物品结算',NULL,NULL,NULL,'2025-12-24 15:47:11',NULL,'2025-12-25 16:02:00',0,9,9,6),(2304,1,1,6304234654533936061,1716,'sc:bill:pay:item:settleList','查看列表',NULL,NULL,NULL,'2025-12-24 15:55:16',NULL,'2025-12-25 16:02:00',0,9,9,6),(2305,1,1,-1325777922340148076,1716,'sc:bill:pay:item:settleExport','导出',NULL,NULL,NULL,'2025-12-24 15:56:01',NULL,'2025-12-25 16:02:00',0,9,9,6),(2306,1,1,-8688373730450822265,1722,'sc:warehouse:pay:item:settleList','查看列表',NULL,NULL,NULL,'2025-12-24 16:07:20',NULL,'2025-12-25 16:02:00',0,9,9,6),(2307,1,1,-5604103870699507834,1722,'sc:warehouse:pay:item:settleExport','导出',NULL,NULL,NULL,'2025-12-24 16:07:31',NULL,'2025-12-25 16:02:00',0,9,9,6),(2308,1,1,7736613591951921288,1719,'sc:organ:st:bill:list','查看列表',NULL,NULL,NULL,'2025-12-24 16:09:14',NULL,'2025-12-25 16:02:00',0,9,9,6),(2309,1,1,3267906118682776452,1719,'sc:organ:bill:pay:item:add','新增付款',NULL,NULL,NULL,'2025-12-24 16:09:27',NULL,'2025-12-25 16:02:00',0,9,9,6),(2310,1,1,-8011115791413426190,1719,'sc:organ:st:bill:checked','对账',NULL,NULL,NULL,'2025-12-24 16:09:37',NULL,'2025-12-25 16:02:00',0,9,9,6),(2311,1,1,325204822517994821,1719,'sc:organ:bill:pay:item:checked','核销',NULL,NULL,NULL,'2025-12-24 16:09:47',NULL,'2025-12-25 16:02:00',0,9,9,6),(2312,1,1,7815758073074725886,1719,'sc:organ:bill:pay:item:cancel','取消付款',NULL,NULL,NULL,'2025-12-24 16:09:57',NULL,'2025-12-25 16:02:00',0,9,9,6),(2313,1,1,-8239944586523220273,1719,'sc:organ:bill:invoice:order:add','添加发票',NULL,NULL,NULL,'2025-12-24 16:10:09',NULL,'2025-12-25 16:02:00',0,9,9,6),(2314,1,1,8917234644971202136,1719,'sc:organ:bill:invoice:order:cancel','取消发票',NULL,NULL,NULL,'2025-12-24 16:10:20',NULL,'2025-12-25 16:02:00',0,9,9,6),(2315,1,1,-8770994436898363715,1719,'sc:organ:st:bill:cancelChecked','取消对账',NULL,NULL,NULL,'2025-12-24 16:10:31',NULL,'2025-12-25 16:02:00',0,9,9,6),(2316,1,1,7065285738560747688,1719,'sc:organ:bill:pay:item:allAdd','全部付款',NULL,NULL,NULL,'2025-12-24 16:10:43',NULL,'2025-12-25 16:02:00',0,9,9,6),(2317,1,1,9193494395837898013,1719,'sc:organ:st:bill:exportBillSettleTask','导出列表',NULL,NULL,NULL,'2025-12-24 16:10:55',NULL,'2025-12-25 16:02:00',0,9,9,6),(2318,1,1,-2285119025506229887,1719,'sc:organ:bill:pay:item:list','结算付款记录显示',NULL,NULL,NULL,'2025-12-24 16:11:13',NULL,'2025-12-25 16:02:00',0,9,9,6),(2319,1,1,-736309959963648065,1719,'sc:organ:bill:invoice:order:list','发票记录显示',NULL,NULL,NULL,'2025-12-24 16:11:25',NULL,'2025-12-25 16:02:00',0,9,9,6),(2320,1,1,-9208441706096927116,1713,'sc:prepay:order:page','预付金记录显示',NULL,NULL,NULL,'2025-12-24 16:12:41',NULL,'2025-12-25 16:02:00',0,9,9,6),(2321,1,1,-4224627498452294535,1713,'sc:bill:pay:item:list','结算付款记录显示',NULL,NULL,NULL,'2025-12-24 16:13:01',NULL,'2025-12-25 16:02:00',0,9,9,6),(2322,1,1,69403635829788807,1713,'sc:bill:invoice:order:list','发票记录显示',NULL,NULL,NULL,'2025-12-24 16:13:13',NULL,'2025-12-25 16:02:00',0,9,9,6),(2323,1,1,-5278945768663879544,1728,'sc:assist:cost:list','查看列表',NULL,NULL,NULL,'2025-12-24 16:22:22',NULL,'2025-12-25 16:02:00',0,9,9,6),(2324,1,1,-4256040593357400918,1728,'sc:assist:cost:add','新增',NULL,NULL,NULL,'2025-12-24 16:22:31',NULL,'2025-12-25 16:02:00',0,9,9,6),(2325,1,1,1531021608427685859,1728,'sc:assist:cost:update','编辑',NULL,NULL,NULL,'2025-12-24 16:22:44',NULL,'2025-12-25 16:02:00',0,9,9,6),(2326,1,1,1439945017165838461,1728,'sc:assist:cost:del','删除',NULL,NULL,NULL,'2025-12-24 16:22:53',NULL,'2025-12-25 16:02:00',0,9,9,6),(2327,1,1,-2568111672404643270,1731,'sc:deduct:rule:list','查看列表',NULL,NULL,NULL,'2025-12-24 16:26:24',NULL,'2025-12-25 16:02:00',0,9,9,6),(2328,1,1,4989769211334390397,1731,'sc:deduct:rule:add','扣减仓库设置',NULL,NULL,NULL,'2025-12-24 16:33:06',NULL,'2025-12-25 16:02:00',0,9,9,6),(2329,1,1,1443933893125243777,1731,'sc:deduct:rule:export','导出仓库设置',NULL,NULL,NULL,'2025-12-24 16:33:18',NULL,'2025-12-25 16:02:00',0,9,9,6),(2330,1,1,-4837039720896413494,1734,'sc:deduct:day:list','查看待扣减列表',NULL,NULL,NULL,'2025-12-24 16:36:38',NULL,'2025-12-25 16:02:00',0,9,9,6),(2331,1,1,-4196653489363113483,1734,'sc:deduct:day:already:list','查看已扣减列表',NULL,NULL,NULL,'2025-12-24 16:36:52',NULL,'2025-12-25 16:02:00',0,9,9,6),(2332,1,1,620542703829269681,1734,'sc:deduct:day:subAll','全部手动扣减',NULL,NULL,NULL,'2025-12-24 16:37:04',NULL,'2025-12-25 16:02:00',0,9,9,6),(2333,1,1,8418890980491330403,1734,'sc:deduct:day:sub','部分手动扣减',NULL,NULL,NULL,'2025-12-24 16:37:17',NULL,'2025-12-25 16:02:00',0,9,9,6),(2334,1,1,-1953102660371302761,1734,'sc:deduct:rule:hand:export','导出仓库设置',NULL,NULL,NULL,'2025-12-24 16:38:03',NULL,'2025-12-25 16:02:00',0,9,9,6),(2335,1,1,-8864973317767303925,1737,'sc:goods:balance:list','查看',NULL,NULL,NULL,'2025-12-24 16:43:44',NULL,'2025-12-25 16:02:00',0,9,9,6),(2336,1,1,-8450381039868207422,1737,'sc:goods:balance:export','导出',NULL,NULL,NULL,'2025-12-24 16:43:54',NULL,'2025-12-25 16:02:00',0,9,9,6),(2337,1,1,3990493307042269748,1740,'sc:goods:detail:list','查看',NULL,NULL,NULL,'2025-12-24 16:44:42',NULL,'2025-12-25 16:02:00',0,9,9,6),(2338,1,1,1064950895714809230,1740,'sc:goods:detail:export','导出',NULL,NULL,NULL,'2025-12-24 16:44:54',NULL,'2025-12-25 16:02:00',0,9,9,6),(2339,1,1,-4695381301748599673,1764,'sc:goods:summary:list','查看',NULL,NULL,NULL,'2025-12-24 16:47:53',NULL,'2025-12-25 16:02:00',0,9,9,6),(2340,1,1,-3363922641418761230,1764,'sc:goods:summary:export','导出',NULL,NULL,NULL,'2025-12-24 16:48:03',NULL,'2025-12-25 16:02:00',0,9,9,6),(2341,1,1,9087477430573828905,1743,'sc:depart:take:detail:list','查看',NULL,NULL,NULL,'2025-12-24 16:50:27',NULL,'2025-12-25 16:02:00',0,9,9,6),(2342,1,1,16891025762051304,1743,'sc:depart:take:detail:export','导出',NULL,NULL,NULL,'2025-12-24 16:50:37',NULL,'2025-12-25 16:02:00',0,9,9,6),(2343,1,1,4850990246409408369,1746,'sc:depart:take:summary:list','查看',NULL,NULL,NULL,'2025-12-24 16:53:28',NULL,'2025-12-25 16:02:00',0,9,9,6),(2344,1,1,-564406046455863596,1746,'sc:depart:take:summary:export','导出',NULL,NULL,NULL,'2025-12-24 16:53:37',NULL,'2025-12-25 16:02:00',0,9,9,6),(2345,1,1,-6804690490976670641,1749,'sc:purchase:summary:list','查看',NULL,NULL,NULL,'2025-12-24 16:54:52',NULL,'2025-12-25 16:02:00',0,9,9,6),(2346,1,1,-1273190368641989870,1749,'sc:purchase:summary:export','导出',NULL,NULL,NULL,'2025-12-24 16:55:02',NULL,'2025-12-25 16:02:00',0,9,9,6),(2347,1,1,-6303235608676417136,1752,'sc:outbound:summary:list','查看',NULL,NULL,NULL,'2025-12-24 16:55:47',NULL,'2025-12-25 16:02:00',0,9,9,6),(2348,1,1,-5319528949183721150,1752,'sc:outbound:summary:export','导出',NULL,NULL,NULL,'2025-12-24 16:55:58',NULL,'2025-12-25 16:02:00',0,9,9,6),(2349,1,1,7985762785811031847,1755,'sc:outin:summary:list','查看',NULL,NULL,NULL,'2025-12-24 16:56:41',NULL,'2025-12-25 16:02:00',0,9,9,6),(2350,1,1,6755142008694734267,1755,'sc:outin:summary:export','导出',NULL,NULL,NULL,'2025-12-24 16:56:51',NULL,'2025-12-25 16:02:00',0,9,9,6),(2351,1,1,-6339640780232562569,1758,'sc:warehouse:realstock:list','查看',NULL,NULL,NULL,'2025-12-24 16:57:39',NULL,'2025-12-25 16:02:00',0,9,9,6),(2352,1,1,6268091036384887301,1758,'sc:warehouse:realstock:export','导出',NULL,NULL,NULL,'2025-12-24 16:57:52',NULL,'2025-12-25 16:02:00',0,9,9,6),(2353,1,1,4116396514133626771,1761,'sc:goods:realstock:list','查看',NULL,NULL,NULL,'2025-12-24 16:58:53',NULL,'2025-12-25 16:02:00',0,9,9,6),(2354,1,1,-7602001437318603851,1761,'sc:goods:realstock:export','导出',NULL,NULL,NULL,'2025-12-24 16:59:03',NULL,'2025-12-25 16:02:00',0,9,9,6),(2355,1,1,6851148690907287330,1767,'sc:warehouse:inventory:list','查看',NULL,NULL,NULL,'2025-12-24 16:59:46',NULL,'2025-12-25 16:02:00',0,9,9,6),(2356,1,1,-3284280243198936276,1767,'sc:warehouse:inventory:export','导出',NULL,NULL,NULL,'2025-12-24 16:59:56',NULL,'2025-12-25 16:02:00',0,9,9,6),(2357,1,1,6076522241006023747,1770,'sc:supplier:order:settlement:detail:list','查看',NULL,NULL,NULL,'2025-12-24 17:00:40',NULL,'2025-12-25 16:02:00',0,9,9,6),(2358,1,1,-2810014716880330480,1770,'sc:supplier:order:settlement:detail:export','导出',NULL,NULL,NULL,'2025-12-24 17:00:54',NULL,'2025-12-25 16:02:00',0,9,9,6),(2359,1,1,8784802906871622312,1773,'sc:supplier:order:settlement:summary:list','查看',NULL,NULL,NULL,'2025-12-24 17:05:23',NULL,'2025-12-25 16:02:00',0,9,9,6),(2360,1,1,-4488196119108823893,1773,'sc:supplier:order:settlement:summary:export','导出',NULL,NULL,NULL,'2025-12-24 17:05:33',NULL,'2025-12-25 16:02:00',0,9,9,6),(2361,1,1,-2219994312623275288,1776,'sc:supplier:order:details:list','查看',NULL,NULL,NULL,'2025-12-24 17:05:52',NULL,'2025-12-25 16:02:00',0,9,9,6),(2362,1,1,5163618375688718218,1776,'sc:supplier:order:details:export','导出',NULL,NULL,NULL,'2025-12-24 17:06:02',NULL,'2025-12-25 16:02:00',0,9,9,6),(2363,1,1,-1434836849010713269,1779,'sc:supplier:order:amount:list','查看',NULL,NULL,NULL,'2025-12-24 17:07:17',NULL,'2025-12-25 16:02:00',0,9,9,6),(2364,1,1,4017257165427747548,1779,'sc:supplier:order:amount:export','导出',NULL,NULL,NULL,'2025-12-24 17:07:26',NULL,'2025-12-25 16:02:00',0,9,9,6),(2365,1,1,-5760060287799227634,1782,'sc:supplier:price:log:list','查看',NULL,NULL,NULL,'2025-12-24 17:08:36',NULL,'2025-12-25 16:02:00',0,9,9,6),(2366,1,1,-2442626038000340688,1782,'sc:supplier:price:log:export','导出',NULL,NULL,NULL,'2025-12-24 17:08:45',NULL,'2025-12-25 16:02:00',0,9,9,6),(2367,1,1,5492610203417990429,1785,'sc:supplier:check:amount:list','查看',NULL,NULL,NULL,'2025-12-24 17:09:40',NULL,'2025-12-25 16:02:00',0,9,9,6),(2368,1,1,3385427132033063806,1785,'sc:supplier:check:amount:export','导出',NULL,NULL,NULL,'2025-12-24 17:09:52',NULL,'2025-12-25 16:02:00',0,9,9,6),(2369,1,1,1041642513457859397,1788,'sc:department:order:details:list','查看',NULL,NULL,NULL,'2025-12-24 17:10:40',NULL,'2025-12-25 16:02:00',0,9,9,6),(2370,1,1,8675379113478034147,1788,'sc:department:order:details:export','导出',NULL,NULL,NULL,'2025-12-24 17:10:50',NULL,'2025-12-25 16:02:00',0,9,9,6),(2371,1,1,-5943127862953976994,1791,'sc:dept:inout:detail:list','查看',NULL,NULL,NULL,'2025-12-24 17:11:51',NULL,'2025-12-25 16:02:00',0,9,9,6),(2372,1,1,-8333610968181933913,1791,'sc:dept:inout:detail:export','导出',NULL,NULL,NULL,'2025-12-24 17:12:01',NULL,'2025-12-25 16:02:00',0,9,9,6),(2373,1,1,-6643174328387918653,1797,'sc:dept:return:detail:list','查看',NULL,NULL,NULL,'2025-12-24 17:16:34',NULL,'2025-12-25 16:02:00',0,9,9,6),(2374,1,1,-6124437286250560684,1797,'sc:dept:return:detail:export','导出',NULL,NULL,NULL,'2025-12-24 17:16:44',NULL,'2025-12-25 16:02:00',0,9,9,6),(2375,1,1,3590919849656223811,1794,'sc:goods:type:summary:list','查看',NULL,NULL,NULL,'2025-12-24 17:17:02',NULL,'2025-12-25 16:02:00',0,9,9,6),(2376,1,1,5451074391706825568,1794,'sc:goods:type:summary:export','导出',NULL,NULL,NULL,'2025-12-24 17:17:13',NULL,'2025-12-25 16:02:00',0,9,9,6),(2377,1,1,7397957863775439506,1800,'sc:gross:profit:dish:list','查看',NULL,NULL,NULL,'2025-12-24 17:21:10',NULL,'2025-12-25 16:02:00',0,9,9,6),(2378,1,1,1205967083506202059,1800,'sc:gross:profit:dish:export','导出',NULL,NULL,NULL,'2025-12-24 17:21:21',NULL,'2025-12-25 16:02:00',0,9,9,6),(2379,1,1,-2240193761614647508,1803,'sc:cost:breakdown:of:dishes:list','查看',NULL,NULL,NULL,'2025-12-24 17:22:31',NULL,'2025-12-25 16:02:00',0,9,9,6),(2380,1,1,-4975297778356935786,1803,'sc:cost:breakdown:of:dishes:export','导出',NULL,NULL,NULL,'2025-12-24 17:22:41',NULL,'2025-12-25 16:02:00',0,9,9,6),(2381,1,1,8997751756280516653,1806,'sc:realtime:inventory:of:items:list','查看',NULL,NULL,NULL,'2025-12-24 17:23:54',NULL,'2025-12-25 16:02:00',0,9,9,6),(2382,1,1,7198741993994902817,1806,'sc:realtime:inventory:of:items:export','导出',NULL,NULL,NULL,'2025-12-24 17:24:07',NULL,'2025-12-25 16:02:00',0,9,9,6),(2383,1,1,6212570398564544151,1809,'sc:item:daybook:list','查看',NULL,NULL,NULL,'2025-12-24 17:25:15',NULL,'2025-12-25 16:02:00',0,9,9,6),(2384,1,1,5656688011751193687,1809,'sc:item:daybook:export','导出',NULL,NULL,NULL,'2025-12-24 17:25:28',NULL,'2025-12-25 16:02:00',0,9,9,6),(2385,1,1,824204655060236626,1812,'sc:profit:loss:summary:list','查看',NULL,NULL,NULL,'2025-12-24 17:25:58',NULL,'2025-12-25 16:02:00',0,9,9,6),(2386,1,1,1201535530576557900,1812,'sc:profit:loss:summary:export','导出',NULL,NULL,NULL,'2025-12-24 17:26:09',NULL,'2025-12-25 16:02:00',0,9,9,6),(2387,1,1,-6353054399476079067,1815,'sc:stock:warning:list','查看',NULL,NULL,NULL,'2025-12-24 17:27:15',NULL,'2025-12-25 16:02:00',0,9,9,6),(2388,1,1,5300722225430752463,1815,'sc:stock:warning:export','导出',NULL,NULL,NULL,'2025-12-24 17:27:27',NULL,'2025-12-25 16:02:00',0,9,9,6),(2389,1,1,-4132324318719326568,1818,'sc:depart:gross:profit:list','查看',NULL,NULL,NULL,'2025-12-24 17:28:39',NULL,'2025-12-25 16:02:00',0,9,9,6),(2390,1,1,-7160056791192375615,1818,'sc:depart:gross:profit:export','导出',NULL,NULL,NULL,'2025-12-24 17:28:51',NULL,'2025-12-25 16:02:00',0,9,9,6),(2391,1,1,-8759161421451060775,1821,'sc:goods:gross:profit:list','查看',NULL,NULL,NULL,'2025-12-24 17:30:16',NULL,'2025-12-25 16:02:00',0,9,9,6),(2392,1,1,-6029946714022185916,1821,'sc:goods:gross:profit:export','导出',NULL,NULL,NULL,'2025-12-24 17:30:27',NULL,'2025-12-25 16:02:00',0,9,9,6),(2393,1,1,540431411218611932,1824,'sc:bill:detail:list','查看',NULL,NULL,NULL,'2025-12-24 17:31:24',NULL,'2025-12-25 16:02:00',0,9,9,6),(2394,1,1,2223312192835632707,1824,'sc:bill:detail:export','导出',NULL,NULL,NULL,'2025-12-24 17:31:34',NULL,'2025-12-25 16:02:00',0,9,9,6),(2395,1,1,172738453523069470,1827,'sc:bill:item:detail:list','查看',NULL,NULL,NULL,'2025-12-24 17:32:39',NULL,'2025-12-25 16:02:00',0,9,9,6),(2396,1,1,-4146950875181473178,1827,'sc:bill:item:detail:export','导出',NULL,NULL,NULL,'2025-12-24 17:32:50',NULL,'2025-12-25 16:02:00',0,9,9,6),(2397,1,1,765128671345819699,1845,'sc:report:list','查看页面',NULL,NULL,NULL,'2025-12-24 17:37:16',NULL,'2025-12-25 16:02:00',0,9,9,6),(2398,1,1,8286445959606098994,1845,'sc:report:goodsbalance','收发存汇总表显示',NULL,NULL,NULL,'2025-12-24 17:37:39',NULL,'2025-12-25 16:02:00',0,9,9,6),(2399,1,1,-5767637046223355231,1845,'sc:report:goodsdetail','收发存明细表显示',NULL,NULL,NULL,'2025-12-24 17:38:05',NULL,'2025-12-25 16:02:00',0,9,9,6),(2400,1,1,-5396036582235212405,1845,'sc:report:goodsinout','物品进销存汇总显示',NULL,NULL,NULL,'2025-12-24 17:38:24',NULL,'2025-12-25 16:02:00',0,9,9,6),(2401,1,1,8589893925767384912,1845,'sc:report:warehouseinout','仓库进销存汇总显示',NULL,NULL,NULL,'2025-12-24 17:39:00',NULL,'2025-12-25 16:02:00',0,9,9,6),(2402,1,1,-2572277556006594821,1845,'sc:report:purchasesummary','仓库采购入库汇总显示',NULL,NULL,NULL,'2025-12-24 17:39:18',NULL,'2025-12-25 16:02:00',0,9,9,6),(2403,1,1,-4621691154006289026,1845,'sc:report:outboundsummary','仓库采购出库汇总显示',NULL,NULL,NULL,'2025-12-24 17:39:33',NULL,'2025-12-25 16:02:00',0,9,9,6),(2404,1,1,8543525904818524122,1845,'sc:report:outinsummary','仓库出入库汇总显示',NULL,NULL,NULL,'2025-12-24 17:39:50',NULL,'2025-12-25 16:02:00',0,9,9,6),(2405,1,1,7054899569684232637,1845,'sc:report:warehouserealstock','仓库实时库存汇总显示',NULL,NULL,NULL,'2025-12-24 17:40:10',NULL,'2025-12-25 16:02:00',0,9,9,6),(2406,1,1,-2693125393732947940,1845,'sc:report:departtakedetail','仓库领料明细显示',NULL,NULL,NULL,'2025-12-24 17:40:24',NULL,'2025-12-25 16:02:00',0,9,9,6),(2407,1,1,-4023781544104406354,1845,'sc:report:departtakesummary','仓库领料汇总',NULL,NULL,NULL,'2025-12-24 17:40:37',NULL,'2025-12-25 16:02:00',0,9,9,6),(2408,1,1,5404107540947722838,1845,'sc:report:goodsrealstockEx','物品实时库存汇总',NULL,NULL,NULL,'2025-12-24 17:40:51',NULL,'2025-12-25 16:02:00',0,9,9,6),(2409,1,1,7497350088180780402,1845,'sc:report:profitlosssummary','盘亏盘盈汇总显示',NULL,NULL,NULL,'2025-12-24 17:41:04',NULL,'2025-12-25 16:02:00',0,9,9,6),(2410,1,1,3419874555454618043,1845,'sc:report:stocktimewarning','库存/保质期预警提醒显示',NULL,NULL,NULL,'2025-12-24 17:42:21',NULL,'2025-12-25 16:02:00',0,9,9,6),(2411,1,1,-2039005556469704094,1845,'sc:report:suppliersettledetail','供应商结算明细显示',NULL,NULL,NULL,'2025-12-24 17:42:36',NULL,'2025-12-25 16:02:00',0,9,9,6),(2412,1,1,6550525572608552245,1845,'sc:report:suppliersettlesummary','供应商结算汇总显示',NULL,NULL,NULL,'2025-12-24 17:42:50',NULL,'2025-12-25 16:02:00',0,9,9,6),(2413,1,1,6486063403121031940,1845,'sc:report:supplierorderdetail','供应商订货明细显示',NULL,NULL,NULL,'2025-12-24 17:43:09',NULL,'2025-12-25 16:02:00',0,9,9,6),(2414,1,1,-2183085540728904393,1845,'sc:report:supplierorderamount','供应商订货金额显示',NULL,NULL,NULL,'2025-12-24 17:43:28',NULL,'2025-12-25 16:02:00',0,9,9,6),(2415,1,1,3841264630718448200,1845,'sc:report:supplierpriceLog','供应商价格日志显示',NULL,NULL,NULL,'2025-12-24 17:43:43',NULL,'2025-12-25 16:02:00',0,9,9,6),(2416,1,1,1949278221445628132,1845,'sc:report:suppliercheckamount','供应商对账金额显示',NULL,NULL,NULL,'2025-12-24 17:44:00',NULL,'2025-12-25 16:02:00',0,9,9,6),(2417,1,1,3513520494442987797,1845,'sc:report:departindentdetail','档口订货明细显示',NULL,NULL,NULL,'2025-12-24 17:44:14',NULL,'2025-12-25 16:02:00',0,9,9,6),(2418,1,1,3594798849912542753,1845,'sc:report:departrefunddetail','档口退货明细显示',NULL,NULL,NULL,'2025-12-24 17:44:29',NULL,'2025-12-25 16:02:00',0,9,9,6),(2419,1,1,5254051661432437987,1845,'sc:report:productgrossprofit','菜品毛利明细',NULL,NULL,NULL,'2025-12-24 17:44:58',NULL,'2025-12-25 16:02:00',0,9,9,6),(2420,1,1,-5660125561844360867,1845,'sc:report:productgrosscost','菜品成本明细显示',NULL,NULL,NULL,'2025-12-24 17:45:11',NULL,'2025-12-25 16:02:00',0,9,9,6),(2421,1,1,-8603378754884916274,1845,'sc:report:departgrossprofit','档口销售毛利汇总显示',NULL,NULL,NULL,'2025-12-24 17:45:30',NULL,'2025-12-25 16:02:00',0,9,9,6),(2422,1,1,6664822523123097234,1845,'sc:report:goodsgrossprofit','物品耗用成本分析汇总显示',NULL,NULL,NULL,'2025-12-24 17:45:51',NULL,'2025-12-25 16:02:00',0,9,9,6),(2423,1,1,5818467477290223347,1845,'sc:report:goodsrealstock','物品实时库存量',NULL,NULL,NULL,'2025-12-24 17:46:05',NULL,'2025-12-25 16:02:00',0,9,9,6),(2424,1,1,-8904001088776514813,1845,'sc:report:goodsitemdetail','物品流水账',NULL,NULL,NULL,'2025-12-24 17:46:20',NULL,'2025-12-25 16:02:00',0,9,9,6),(2425,1,1,-2589535307478401876,1845,'sc:report:billdetail','单据信息明细显示',NULL,NULL,NULL,'2025-12-24 17:46:38',NULL,'2025-12-25 16:02:00',0,9,9,6),(2426,1,1,2283239915738840566,1845,'sc:report:billitemDetail','单据信息物品明细显示',NULL,NULL,NULL,'2025-12-24 17:46:56',NULL,'2025-12-25 16:02:00',0,9,9,6),(2427,1,1,2717970213834545916,1845,'sc:report:billitemsummary','单据信息物品汇总显示',NULL,NULL,NULL,'2025-12-24 17:47:12',NULL,'2025-12-25 16:02:00',0,9,9,6),(2428,1,1,467377115457975561,1845,'sc:report:goods:type:summary','物品类别入货部门统计',NULL,NULL,NULL,'2025-12-24 17:47:35',NULL,'2025-12-25 16:02:00',0,9,9,6),(2429,1,1,-1969358464850983455,1845,'sc:report:dept:inout:detail','部门出入库明细表',NULL,NULL,NULL,'2025-12-24 17:47:52',NULL,'2025-12-25 16:02:00',0,9,9,6),(2430,1,1,-5239922100892300297,1845,'gyl:stock:rpt:wsmgr','仓库管理',NULL,NULL,NULL,'2025-12-24 17:48:07',NULL,'2025-12-25 16:02:00',0,9,9,6),(2431,1,1,3865479349501726923,1845,'gyl:stock:rpt:sp','供应商',NULL,NULL,NULL,'2025-12-24 17:48:20',NULL,'2025-12-25 16:02:00',0,9,9,6),(2432,1,1,8701812321930290827,1845,'gyl:stock:rpt:cost','成本',NULL,NULL,NULL,'2025-12-24 17:48:31',NULL,'2025-12-25 16:02:00',0,9,9,6),(2433,1,1,-6740513643163728761,1845,'gyl:stock:rpt:goods','物品',NULL,NULL,NULL,'2025-12-24 17:48:40',NULL,'2025-12-25 16:02:00',0,9,9,6),(2434,1,1,2643471940319917836,1845,'sc:report:price:comparison','价格对比表',NULL,NULL,NULL,'2025-12-24 17:52:38',NULL,'2025-12-25 16:02:00',0,9,9,6),(2435,1,1,9193019862905138835,1848,'sc:price:comparison:table:list','查看',NULL,NULL,NULL,'2025-12-24 17:56:57',NULL,'2025-12-25 16:02:00',0,9,9,6),(2436,1,1,-8648564602584421117,1848,'sc:price:comparison:table:export','导出',NULL,NULL,NULL,'2025-12-24 17:57:14',NULL,'2025-12-25 16:02:00',0,9,9,6),(2437,1,1,3901241281422899267,1701,'sc:rdc:order:modDeliveryFee','编辑配送费',NULL,NULL,NULL,'2025-12-25 11:18:43',NULL,'2025-12-25 16:02:00',0,9,9,6),(2438,1,1,-3526740035868455865,1704,'sc:delivery:out:exportOrder','导出配送单',NULL,NULL,NULL,'2025-12-25 11:25:04',NULL,'2025-12-25 16:02:00',0,9,9,6),(2439,1,1,-6416008754878686002,1680,'sc:delivery:order:update','编辑报价单',NULL,NULL,NULL,'2025-12-25 16:32:16',NULL,'2025-12-25 18:12:39',0,9,9,6),(2440,1,1,-8892629971318210605,1686,'sc:depart:order:detail','查看详情',NULL,NULL,NULL,'2025-12-25 16:55:35',NULL,'2025-12-25 18:12:39',0,9,9,6),(2441,1,1,1357133880480386087,1707,'sc:inspect:item:printGroupDeliveryOrderTask','打印集团配货单',NULL,NULL,NULL,'2025-12-25 17:18:48',NULL,'2025-12-25 18:12:39',0,9,9,6),(2442,1,1,7913658368533915901,1707,'sc:inspect:item:printOrderSummaryTask','打印订货汇总',NULL,NULL,NULL,'2025-12-31 10:07:52',NULL,'2026-01-07 18:58:48',0,9,9,6),(2443,1,1,-1205845281810014359,1686,'sc:depart:order:copy','复制',NULL,NULL,NULL,'2026-01-04 15:29:41',NULL,'2026-01-07 18:58:48',0,9,9,6),(2444,1,1,-602104726395235774,1689,'sc:store:order:copy','复制',NULL,NULL,NULL,'2026-01-04 15:43:59',NULL,'2026-01-07 18:58:48',0,9,9,6),(2445,1,1,3744359191443318393,1701,'sc:rdc:order:copy','复制',NULL,NULL,NULL,'2026-01-04 16:06:01',NULL,'2026-01-07 18:58:48',0,9,9,6),(2446,1,1,5058667126127144472,1845,'sc:report:order:difference','价格差异订货汇总',NULL,NULL,NULL,'2026-01-05 16:32:10',NULL,'2026-01-07 18:58:48',0,9,9,6),(2447,1,1,-8778790498513441264,1849,'sc:order:difference:details:list','查看',NULL,NULL,NULL,'2026-01-05 16:42:32',NULL,'2026-01-07 18:58:48',0,9,9,6),(2448,1,1,-8518563396039316341,1849,'sc:order:difference:details:export','导出',NULL,NULL,NULL,'2026-01-05 16:42:40',NULL,'2026-01-07 18:58:48',0,9,9,6),(2449,1,1,-6713620016075857688,1850,'mp:report:home','查看',NULL,NULL,NULL,'2026-01-07 17:06:38',NULL,'2026-01-07 18:58:48',0,9,9,35),(2450,1,1,6158202618938975073,1851,'approval:center:list','查看列表',NULL,NULL,NULL,'2026-01-07 18:26:50',NULL,'2026-01-07 18:58:48',0,9,9,2),(2451,1,1,829110761706732097,1851,'approval:center:detail','查看详情',NULL,NULL,NULL,'2026-01-07 18:27:01',NULL,'2026-01-07 18:58:48',0,9,9,2),(2452,1,1,-3728007872494840123,1851,'approval:center:audit','审批',NULL,NULL,NULL,'2026-01-07 18:27:15',NULL,'2026-01-07 18:58:48',0,9,9,2),(2453,1,1,4858515271973635029,1851,'approval:center:reset','驳回',NULL,NULL,NULL,'2026-01-07 18:27:25',NULL,'2026-01-07 18:58:48',0,9,9,2),(2454,1,1,1475325721209944979,1852,'approval:config:list','查看',NULL,NULL,NULL,'2026-01-07 18:28:47',NULL,'2026-01-07 18:58:48',0,9,9,2),(2455,1,1,1064299013938328079,1852,'approval:config:edit','编辑',NULL,NULL,NULL,'2026-01-07 18:29:08',NULL,'2026-01-07 18:58:48',0,9,9,2),(2456,1,1,7361898593125100548,1853,'sc:report:warehouseprofitlossdetail:list','查看',NULL,NULL,NULL,'2026-01-08 14:03:34',NULL,'2026-01-13 14:14:32',0,9,9,6),(2457,1,1,7891867359158720645,1853,'sc:report:warehouseprofitlossdetail:export','导出',NULL,NULL,NULL,'2026-01-08 14:03:48',NULL,'2026-01-13 14:14:32',0,9,9,6),(2458,1,1,7954849116060248001,1854,'sc:report:supplierinoutdetail:list','查看',NULL,NULL,NULL,'2026-01-08 14:04:06',NULL,'2026-01-13 14:14:32',0,9,9,6),(2459,1,1,2450702451591500717,1854,'sc:report:supplierinoutdetail:export','导出',NULL,NULL,NULL,'2026-01-08 14:04:17',NULL,'2026-01-13 14:14:32',0,9,9,6),(2460,1,1,-4717152624200743642,1845,'sc:report:warehouseprofitlossdetail','仓库盘盈盘亏明细',NULL,NULL,NULL,'2026-01-08 14:05:19',NULL,'2026-01-13 14:14:32',0,9,9,6),(2461,1,1,-8168501288042231940,1845,'sc:report:supplierinoutdetail','供应商出入库明细',NULL,NULL,NULL,'2026-01-08 14:05:33',NULL,'2026-01-13 14:14:32',0,9,9,6),(2462,1,1,-507692769492283446,1707,'sc:rdc:order:adjustNumber','批量调整发货数量',NULL,NULL,NULL,'2026-01-20 09:44:59',NULL,'2026-01-20 10:09:41',0,9,9,6),(2463,1,1,-4115690345472949749,1707,'sc:rdc:order:completeSort','完成分拣',NULL,NULL,NULL,'2026-01-20 09:45:12',NULL,'2026-01-20 10:09:41',0,9,9,6),(2464,1,1,1245518878417631721,1707,'sc:rdc:order:cancelSort','撤销分拣',NULL,NULL,NULL,'2026-01-20 09:45:25',NULL,'2026-01-20 10:09:41',0,9,9,6),(2465,1,1,-1406614343204167295,522,'snack_ops:save','挂单',NULL,NULL,NULL,'2026-01-24 15:07:55',NULL,'2026-01-24 15:13:19',0,12,10,12),(2466,1,1,-8914335802098662353,522,'snack_ops:take','取单',NULL,NULL,NULL,'2026-01-24 15:08:12',NULL,'2026-01-24 15:13:19',0,12,10,12),(2467,1,1,-6416257124531502595,1855,'search_inventory','查看',NULL,NULL,NULL,'2026-01-27 14:40:06',NULL,'2026-01-27 15:04:23',0,9,9,37),(2468,1,1,-782187944088080527,1855,'create_inventory','新增盘点',NULL,NULL,NULL,'2026-01-27 14:40:25',NULL,'2026-01-27 15:45:47',1,9,9,37),(2469,1,1,6666264050018978602,1855,'save_inventory','暂存盘点',NULL,NULL,NULL,'2026-01-27 14:40:38',NULL,'2026-01-27 15:45:47',1,9,9,37),(2470,1,1,5816968156965555438,1855,'cancel_inventory','取消盘点',NULL,NULL,NULL,'2026-01-27 14:40:50',NULL,'2026-01-27 15:45:47',1,9,9,37),(2471,1,1,7713748663659908636,1855,'over_inventory','结束盘点',NULL,NULL,NULL,'2026-01-27 14:41:09',NULL,'2026-01-27 15:45:47',1,9,9,37),(2472,1,1,8823060355965725580,1855,'reaudit_inventory','反审核盘点',NULL,NULL,NULL,'2026-01-27 14:41:27',NULL,'2026-01-27 15:07:00',1,9,9,37),(2473,1,1,-7793415814001028406,1838,'InventoryMrg','盘点管理',NULL,NULL,NULL,'2026-01-27 14:46:20',NULL,'2026-01-27 15:45:47',0,9,9,37),(2474,1,1,-782187944088080527,1838,'create_inventory','新增盘点',NULL,NULL,NULL,'2026-01-29 11:22:05',NULL,'2026-01-29 11:35:47',0,9,9,37),(2475,1,1,6666264050018978602,1838,'save_inventory','暂存盘点',NULL,NULL,NULL,'2026-01-29 11:22:22',NULL,'2026-01-29 11:35:47',0,9,9,37),(2476,1,1,5816968156965555438,1838,'cancel_inventory','取消盘点',NULL,NULL,NULL,'2026-01-29 11:22:40',NULL,'2026-01-29 11:35:47',0,9,9,37),(2477,1,1,7713748663659908636,1838,'over_inventory','结束盘点',NULL,NULL,NULL,'2026-01-29 11:22:58',NULL,'2026-01-29 11:35:47',0,9,9,37),(2478,1,1,8823060355965725580,1838,'reaudit_inventory','反审核盘点',NULL,NULL,NULL,'2026-01-29 11:23:42',NULL,'2026-01-29 11:35:47',0,9,9,37),(2479,1,1,2538909645180480818,1856,'report:ck:depart_daily_sale_detail','查看【收银查询-菜品营业明细】',NULL,NULL,NULL,'2026-02-09 15:02:23',NULL,'2026-02-09 15:05:21',0,9,9,8),(2480,1,1,-911672996165501374,1857,'report:ck:dept_food_sale_summary','查看-【销售查询-部门菜品销售汇总】',NULL,NULL,NULL,'2026-02-09 19:03:07',NULL,'2026-02-09 19:18:59',0,9,9,8),(2481,1,1,-5242905521598707442,1858,'pos:promote:list','查看列表【促销方案】',NULL,NULL,NULL,'2026-02-27 17:30:07',NULL,'2026-02-27 17:56:03',0,9,9,2),(2482,1,1,160618210202432514,1858,'pos:promote:view','查看详情【促销方案】',NULL,NULL,NULL,'2026-02-27 17:30:38',NULL,'2026-02-27 17:56:03',0,9,9,2),(2483,1,1,-7067445945788623556,1858,'pos:promote:add','新增【促销方案】',NULL,NULL,NULL,'2026-02-27 17:30:58',NULL,'2026-02-27 17:56:03',0,9,9,2),(2484,1,1,2544019218128824366,1858,'pos:promote:edit','编辑【促销方案】',NULL,NULL,NULL,'2026-02-27 17:31:16',NULL,'2026-02-27 17:56:03',0,9,9,2),(2485,1,1,8027647398013697698,1858,'pos:promote:del','删除【促销方案】',NULL,NULL,NULL,'2026-02-27 17:31:37',NULL,'2026-02-27 17:56:03',0,9,9,2),(2486,1,1,8905728230020065002,1858,'pos:promote:review','审核【促销方案】',NULL,NULL,NULL,'2026-02-27 17:31:55',NULL,'2026-02-27 17:56:03',0,9,9,2),(2487,1,1,4183793258509711694,1858,'pos:promote:copy','复制【促销方案】',NULL,NULL,NULL,'2026-02-27 17:32:11',NULL,'2026-02-27 17:56:03',0,9,9,2),(2488,1,1,-869681446985101764,1858,'pos:promote:enable','启用停用【促销方案】',NULL,NULL,NULL,'2026-02-27 17:32:28',NULL,'2026-02-27 17:56:03',0,9,9,2),(2489,1,1,-1130071125310230205,1858,'pos:promote:export','导出【促销方案】',NULL,NULL,NULL,'2026-02-27 17:32:48',NULL,'2026-02-27 17:56:03',0,9,9,2),(2490,1,1,1589072135384612139,1838,'StallPick','档口领料',NULL,NULL,NULL,'2026-03-09 15:48:28',NULL,'2026-03-09 16:32:31',0,9,9,37),(2491,1,1,-7996913601852551809,1838,'stall:pick:add','新增档口领料',NULL,NULL,NULL,'2026-03-09 15:50:25',NULL,'2026-03-09 16:32:31',0,9,9,37),(2492,1,1,6699902379491301620,1838,'stall:pick:update','编辑档口领料',NULL,NULL,NULL,'2026-03-09 15:50:53',NULL,'2026-03-09 16:32:31',0,9,9,37),(2493,1,1,3694846370162186996,1838,'stall:pick:finish','审核档口领料',NULL,NULL,NULL,'2026-03-09 15:51:07',NULL,'2026-03-09 16:32:31',0,9,9,37),(2494,1,1,-6688796131789520572,1838,'stall:pick:revert','反审核档口领料',NULL,NULL,NULL,'2026-03-09 15:51:59',NULL,'2026-03-09 16:32:31',0,9,9,37),(2495,1,1,-6198303160121593218,1838,'stall:pick:red','冲红档口领料',NULL,NULL,NULL,'2026-03-09 15:52:24',NULL,'2026-03-09 16:32:31',0,9,9,37),(2496,1,1,-1455007939582381579,1838,'stall:pick:del','删除档口领料',NULL,NULL,NULL,'2026-03-09 15:52:47',NULL,'2026-03-09 16:32:31',0,9,9,37),(2497,1,1,-5010882296249774147,1838,'stall:pick:copy','复制档口领料',NULL,NULL,NULL,'2026-03-09 15:58:48',NULL,'2026-03-09 16:32:31',0,9,9,37),(2498,1,1,2043538582507134976,1860,'bi:report:yy:day:static','查看【营业报表-日收入统计报表】',NULL,NULL,NULL,'2026-04-13 11:55:39',NULL,NULL,0,9,9,8),(2499,1,1,2043605968555020288,527,'dwd:bill:ops:open:cash','开钱箱',NULL,NULL,NULL,'2026-04-13 16:23:25',NULL,NULL,0,12,10,12);
/*!40000 ALTER TABLE `permission_right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_view`
--

DROP TABLE IF EXISTS `permission_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission_view` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `package_lid` bigint DEFAULT NULL COMMENT '权限包编号',
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标识符',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `sort_index` int DEFAULT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='权限视角';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_view`
--

LOCK TABLES `permission_view` WRITE;
/*!40000 ALTER TABLE `permission_view` DISABLE KEYS */;
INSERT INTO `permission_view` VALUES (9,1,1,-5327026198816254893,9,NULL,'集团视角',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0),(10,1,1,2965955012639221341,9,NULL,'配送中心视角',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0),(11,1,1,3521429139963149547,9,NULL,'门店视角',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0),(12,1,1,1885543383742989904,10,NULL,'门店视角',NULL,NULL,NULL,NULL,NULL,'2025-10-22 15:47:10',0);
/*!40000 ALTER TABLE `permission_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_app_ver`
--

DROP TABLE IF EXISTS `pos_app_ver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_app_ver` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `app` int DEFAULT NULL COMMENT '应用',
  `ver` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '版本号',
  `gradual` tinyint(1) DEFAULT NULL COMMENT '灰度升级',
  `dev_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '适用于灰度升级的设备',
  `installer_package` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '安装包路径',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `sids` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '门店列表',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '发布备注',
  `mids` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '集团列表',
  `force_install` tinyint(1) DEFAULT NULL COMMENT '是否强制安装升级包',
  `immediate_update` tinyint(1) DEFAULT NULL COMMENT '是否立即更新',
  `scheduled_update_time` datetime DEFAULT NULL COMMENT '计划安装时间',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_app` (`app`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='应用版本记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_app_ver`
--

LOCK TABLES `pos_app_ver` WRITE;
/*!40000 ALTER TABLE `pos_app_ver` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_app_ver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_approval_config`
--

DROP TABLE IF EXISTS `pos_approval_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_approval_config` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预留字段，编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '事件名称',
  `approval_type` int NOT NULL COMMENT '事件类型',
  `approval_conf` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '审批人配置',
  `approval_extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '预留字段，审批扩展',
  `enable` tinyint(1) NOT NULL COMMENT '审批开关',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='审批配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_approval_config`
--

LOCK TABLES `pos_approval_config` WRITE;
/*!40000 ALTER TABLE `pos_approval_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_approval_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_approval_order`
--

DROP TABLE IF EXISTS `pos_approval_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_approval_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '预留字段，审批单号',
  `report_date` datetime DEFAULT NULL COMMENT '单据日期',
  `title` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审批主题',
  `module` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审批模块',
  `urgency_level` int DEFAULT NULL COMMENT '紧急程度',
  `desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '变动说明/描述',
  `attachments` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '附件列表',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '审批内容',
  `approval_conf` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '审批配置',
  `approval_type` int NOT NULL COMMENT '事件类型',
  `initiator` bigint DEFAULT NULL COMMENT '审批人lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='审批单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_approval_order`
--

LOCK TABLES `pos_approval_order` WRITE;
/*!40000 ALTER TABLE `pos_approval_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_approval_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_auto_discount`
--

DROP TABLE IF EXISTS `pos_auto_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_auto_discount` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `discount_lid` bigint DEFAULT NULL COMMENT '折扣lid',
  `discount_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '折扣名称',
  `tbl_type_lid` bigint DEFAULT NULL COMMENT '桌台类型lid',
  `tbl_type_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '桌台类型名称',
  `period_lid` bigint DEFAULT NULL COMMENT '营业时段lid',
  `period_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '营业时段名称',
  `auto_discount_type` int DEFAULT NULL COMMENT '自动打折类型',
  `discount_time_type` int DEFAULT NULL COMMENT '打折时间类型',
  `start_at` datetime DEFAULT NULL COMMENT '开始时间',
  `end_at` datetime DEFAULT NULL COMMENT '结束时间',
  `monday` tinyint(1) DEFAULT NULL COMMENT '周一',
  `tuesday` tinyint(1) DEFAULT NULL COMMENT '周二',
  `wednesday` tinyint(1) DEFAULT NULL COMMENT '周三',
  `thursday` tinyint(1) DEFAULT NULL COMMENT '周四',
  `friday` tinyint(1) DEFAULT NULL COMMENT '周五',
  `saturday` tinyint(1) DEFAULT NULL COMMENT '周六',
  `sunday` tinyint(1) DEFAULT NULL COMMENT '周日',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `festival_lid` bigint DEFAULT NULL COMMENT '关联节假日 lid（仅 HD 类型使用）',
  `festival_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '节假日名称（冗余存储，仅 HD 类型使用）',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '规则名称',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='自动打折';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_auto_discount`
--

LOCK TABLES `pos_auto_discount` WRITE;
/*!40000 ALTER TABLE `pos_auto_discount` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_auto_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_book_group`
--

DROP TABLE IF EXISTS `pos_book_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_book_group` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `book_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '菜谱列表',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `brand_lid` bigint DEFAULT NULL COMMENT '品牌lid',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `idx_pos_book_group_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜谱分组';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_book_group`
--

LOCK TABLES `pos_book_group` WRITE;
/*!40000 ALTER TABLE `pos_book_group` DISABLE KEYS */;
INSERT INTO `pos_book_group` VALUES (23,1940284000182472704,NULL,2042543994733989890,'123','[]',NULL,NULL,'2026-04-10 10:03:31',NULL,NULL,0,2042543010529546242);
/*!40000 ALTER TABLE `pos_book_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_customer_bill_setting`
--

DROP TABLE IF EXISTS `pos_customer_bill_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_customer_bill_setting` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `prn_queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '打印队列',
  `by_mobile` tinyint(1) DEFAULT NULL COMMENT '移动设备发起的操作',
  `for_checkout` tinyint(1) DEFAULT NULL COMMENT '适用于结账单',
  `pc_lid` bigint DEFAULT NULL COMMENT '电脑编号',
  `tbl_area_lid` bigint DEFAULT NULL COMMENT '桌台区域编号',
  `tbl_type_lid` bigint DEFAULT NULL COMMENT '桌台类型编号',
  `tbl_lid` bigint DEFAULT NULL COMMENT '桌台编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1409 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='顾客联设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_customer_bill_setting`
--

LOCK TABLES `pos_customer_bill_setting` WRITE;
/*!40000 ALTER TABLE `pos_customer_bill_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_customer_bill_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_dept`
--

DROP TABLE IF EXISTS `pos_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_dept` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `type` int DEFAULT NULL COMMENT '类型',
  `profit_dept` bigint DEFAULT NULL COMMENT '利润部门',
  `prn_queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '打印队列',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `wms_dept_lids` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '供应链部门lids',
  `cashier_dept_names` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '收银部门lids',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1364 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='出品部门和出品部门管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_dept`
--

LOCK TABLES `pos_dept` WRITE;
/*!40000 ALTER TABLE `pos_dept` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_dev`
--

DROP TABLE IF EXISTS `pos_dev`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_dev` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备名称',
  `type_` int DEFAULT NULL,
  `model` int DEFAULT NULL COMMENT '设备型号',
  `extra_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '附加信息',
  `app_ver` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '软件版本',
  `online` tinyint(1) DEFAULT NULL COMMENT '在线',
  `last_active_time` datetime DEFAULT NULL COMMENT '上次激活时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `master_` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否主设备',
  `self_start` tinyint(1) NOT NULL DEFAULT '0' COMMENT '自启动',
  `app` int NOT NULL DEFAULT '1' COMMENT '软件类型',
  `app_pack_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '软件包名',
  `old_pack_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '软件旧包名',
  `pc_lid` bigint DEFAULT '0' COMMENT '服务器',
  `dev_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备UUID',
  `ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备IP',
  `hostname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主机名',
  `compile_time` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '编译时间',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=727 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='设备列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_dev`
--

LOCK TABLES `pos_dev` WRITE;
/*!40000 ALTER TABLE `pos_dev` DISABLE KEYS */;
INSERT INTO `pos_dev` VALUES (725,1940284000182472704,1940287289892687874,2039595652043378690,'001','计算机001',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-02 06:47:51',NULL,NULL,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL),(726,1940284000182472704,2042804773847437313,2042867702765588482,'123C001','123门店计算机001',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-04-11 07:29:49',NULL,NULL,0,0,0,1,NULL,NULL,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `pos_dev` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_dish_hide`
--

DROP TABLE IF EXISTS `pos_dish_hide`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_dish_hide` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `day_of_the_week` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '星期几',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `dish_type_lid_list` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '菜品类别编号',
  `dish_lid_list` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '菜品编号',
  `sellout_or_hide` tinyint(1) DEFAULT NULL COMMENT '用于隐藏或者估清的标志位',
  `state` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `pos_biz_type` int DEFAULT NULL COMMENT '业务类型',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=496 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='菜品隐藏设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_dish_hide`
--

LOCK TABLES `pos_dish_hide` WRITE;
/*!40000 ALTER TABLE `pos_dish_hide` DISABLE KEYS */;
INSERT INTO `pos_dish_hide` VALUES (495,1940284000182472704,1940287289892687874,2041353503449812993,'清蒸鲍鱼','[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\"]','2000-01-01 00:00:00','2000-01-01 23:59:59',NULL,NULL,1,1,NULL,NULL,'2026-04-07 03:12:56',NULL,NULL,1);
/*!40000 ALTER TABLE `pos_dish_hide` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_dish_to_prn_dept`
--

DROP TABLE IF EXISTS `pos_dish_to_prn_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_dish_to_prn_dept` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `prn_dept_lid` bigint DEFAULT NULL COMMENT '出品部门编号',
  `pc_lid` bigint DEFAULT NULL COMMENT '电脑编号',
  `tbl_area_lid` bigint DEFAULT NULL COMMENT '台区编号',
  `dish_type_lid` bigint DEFAULT NULL COMMENT '菜品类别编号',
  `dish_lid` bigint DEFAULT NULL COMMENT '菜品编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `type` int DEFAULT NULL COMMENT '类型',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=31395 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='菜品与出品部门的映射';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_dish_to_prn_dept`
--

LOCK TABLES `pos_dish_to_prn_dept` WRITE;
/*!40000 ALTER TABLE `pos_dish_to_prn_dept` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_dish_to_prn_dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_group_dish_book`
--

DROP TABLE IF EXISTS `pos_group_dish_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_group_dish_book` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `brand_lid` bigint DEFAULT NULL COMMENT '品牌编号',
  `published_time` datetime DEFAULT NULL COMMENT '上次发布时间',
  `published_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '发布人',
  `activation_time` datetime DEFAULT NULL COMMENT '生效时间',
  `status_` int DEFAULT NULL COMMENT '发布状态',
  `type_` int DEFAULT NULL COMMENT '类型',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `store_lids` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '默认门店',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `ldx_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='集团菜谱';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_group_dish_book`
--

LOCK TABLES `pos_group_dish_book` WRITE;
/*!40000 ALTER TABLE `pos_group_dish_book` DISABLE KEYS */;
INSERT INTO `pos_group_dish_book` VALUES (195,1978646278361620480,2038890075414728705,2038890075414728705,'测试门店',2038890034900373506,'2026-03-31 16:32:07','admin','2026-03-31 16:31:49',1,NULL,NULL,NULL,NULL,'2026-03-31 16:04:09',NULL,'2026-03-31 08:32:07',0,NULL),(196,1940284000182472704,2042544017689415682,2042544017689415682,'123',2042543010529546242,'2026-05-11 17:52:55','admin','2026-05-11 17:52:55',3,NULL,'发布失败:\n### Error querying database.  Cause: org.apache.ibatis.executor.ExecutorException: Error preparing statement.  Cause: org.apache.shardingsphere.sql.parser.exception.SQLParsingException\n### The error may exist in com/nms4cloud/pos2plugin/dal/mapper/PtDishMapper.java (best guess)\n### The error may involve com.nms4cloud.pos2plugin.dal.mapper.PtDishMapper.selectListByQuery\n### The error occurred while executing a query\n### SQL: SELECT `dish_type_code`, `online_type_code` FROM `pt_dish` WHERE `company_id` = ? AND `shop_id` = ? AND `lmnid` IN ()\n### Cause: org.apache.ibatis.executor.ExecutorException: Error preparing statement.  Cause: org.apache.shardingsphere.sql.parser.exception.SQLParsingException',NULL,NULL,'2026-04-10 18:03:37',NULL,'2026-05-11 09:52:55',0,NULL),(197,1940284000182472704,2053714018219331585,2053714018219331585,'巨焦',2042543010529546242,'2026-05-11 17:55:19','admin','2026-05-11 17:55:19',1,NULL,NULL,NULL,NULL,'2026-05-11 13:49:13',NULL,'2026-05-11 09:55:19',0,'1985885291726794753'),(198,1940284000182472704,2085617514230325250,2085617514230325250,'发布到东莞',2042543010529546242,'2026-08-07 15:01:50','admin','2026-08-07 15:01:49',1,NULL,'发布失败:\n### Error updating database.  Cause: org.apache.ibatis.executor.ExecutorException: Error preparing statement.  Cause: org.apache.shardingsphere.sql.parser.exception.SQLParsingException\n### The error may exist in com/nms4cloud/pos2plugin/dal/mapper/PtDishMapper.java (best guess)\n### The error may involve com.nms4cloud.pos2plugin.dal.mapper.PtDishMapper.deleteByQuery\n### The error occurred while executing an update\n### SQL: DELETE FROM `pt_dish` WHERE `company_id` = ? AND `shop_id` = ? AND `lmnid` IN ()\n### Cause: org.apache.ibatis.executor.ExecutorException: Error preparing statement.  Cause: org.apache.shardingsphere.sql.parser.exception.SQLParsingException',NULL,NULL,'2026-08-07 14:42:19',NULL,'2026-08-07 15:01:49',1,'1942885905090105345'),(199,1940284000182472704,2085635947890221057,2085635947890221057,'发布到东莞',2042543010529546242,'2026-08-07 15:56:26','admin','2026-08-07 15:56:26',3,NULL,'发布失败:\n### Error updating database.  Cause: org.apache.ibatis.executor.ExecutorException: Error preparing statement.  Cause: org.apache.shardingsphere.sql.parser.exception.SQLParsingException\n### The error may exist in com/nms4cloud/pos2plugin/dal/mapper/PtDishMapper.java (best guess)\n### The error may involve com.nms4cloud.pos2plugin.dal.mapper.PtDishMapper.deleteByQuery\n### The error occurred while executing an update\n### SQL: DELETE FROM `pt_dish` WHERE `company_id` = ? AND `shop_id` = ? AND `lmnid` IN ()\n### Cause: org.apache.ibatis.executor.ExecutorException: Error preparing statement.  Cause: org.apache.shardingsphere.sql.parser.exception.SQLParsingException',NULL,NULL,'2026-08-07 15:55:34',NULL,'2026-08-07 15:56:26',1,'1942885905090105345'),(200,1940284000182472704,2085636422874177537,2085636422874177537,'发布到东莞',2042543010529546242,'2026-08-11 17:55:50','admin','2026-08-11 17:55:50',1,NULL,'发布失败:Cannot invoke \"com.nms4cloud.pos4cloud.enums.GroupDishBookReleaseRuleEnum.ordinal()\" because the return value of \"com.nms4cloud.pos4cloud.dal.entity.PosGroupDishBookRelease.getBookReleaseRule()\" is null',NULL,NULL,'2026-08-07 15:57:27',NULL,'2026-08-11 17:55:49',0,'1942885905090105345');
/*!40000 ALTER TABLE `pos_group_dish_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_group_dish_book_release`
--

DROP TABLE IF EXISTS `pos_group_dish_book_release`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_group_dish_book_release` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `book_lid` bigint DEFAULT NULL COMMENT '菜谱',
  `store_lids` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '发布门店',
  `book_release_rule` int DEFAULT NULL COMMENT '发布规则',
  `dish_release_rule` int DEFAULT NULL COMMENT '菜品信息发布规则',
  `release_time` datetime DEFAULT NULL COMMENT '发布时间',
  `release_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '发布人',
  `done` tinyint(1) DEFAULT NULL COMMENT '发布完成',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `done_time` datetime DEFAULT NULL COMMENT '发布完成时间',
  `brand_lid` bigint DEFAULT NULL COMMENT '品牌lid',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4555 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='菜谱发布记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_group_dish_book_release`
--

LOCK TABLES `pos_group_dish_book_release` WRITE;
/*!40000 ALTER TABLE `pos_group_dish_book_release` DISABLE KEYS */;
INSERT INTO `pos_group_dish_book_release` VALUES (4522,1978646278361620480,NULL,2038897036992192514,2038890075414728705,'2038896375379398658',1,1,'2026-03-31 16:31:49','admin',1,NULL,NULL,'2026-03-31 08:31:49',NULL,'2026-03-31 08:32:07',0,'2026-03-31 16:32:07',2038890034900373506),(4523,1940284000182472704,NULL,2053722831878098946,2053714018219331585,'1985885291726794753',1,2,'2026-05-11 14:24:14','admin',1,NULL,NULL,'2026-05-11 06:24:14',NULL,'2026-05-11 06:24:17',0,'2026-05-11 14:24:17',2042543010529546242),(4524,1940284000182472704,NULL,2053775348792037378,2042544017689415682,'1979737429467095041',1,2,'2026-05-11 17:52:55','admin',1,NULL,NULL,'2026-05-11 09:52:55','admin','2026-05-11 09:52:55',0,'2026-05-11 17:52:55',2042543010529546242),(4525,1940284000182472704,NULL,2053775953166077954,2053714018219331585,'1979737429467095041',1,2,'2026-05-11 17:55:19','admin',1,NULL,NULL,'2026-05-11 09:55:19','admin','2026-05-11 09:55:19',0,'2026-05-11 17:55:19',2042543010529546242),(4526,1940284000182472704,NULL,2085617633902206977,2085617514230325250,'1942885905090105345',1,2,'2026-08-07 14:42:47','admin',1,NULL,NULL,'2026-08-07 14:42:47','admin','2026-08-07 14:43:18',0,'2026-08-07 14:43:18',2042543010529546242),(4527,1940284000182472704,NULL,2085622423713488898,2085617514230325250,'1942885905090105345',3,NULL,'2026-08-07 15:01:49','admin',1,NULL,NULL,'2026-08-07 15:01:49','admin','2026-08-07 15:01:49',0,'2026-08-07 15:01:50',2042543010529546242),(4528,1940284000182472704,NULL,2085636067218169857,2085635947890221057,'1942885905090105345',1,2,'2026-08-07 15:56:02','admin',1,NULL,NULL,'2026-08-07 15:56:02','admin','2026-08-07 15:56:02',0,'2026-08-07 15:56:02',2042543010529546242),(4529,1940284000182472704,NULL,2085636166941941761,2085635947890221057,'1942885905090105345',1,2,'2026-08-07 15:56:26','admin',1,NULL,NULL,'2026-08-07 15:56:26','admin','2026-08-07 15:56:26',0,'2026-08-07 15:56:26',2042543010529546242),(4530,1940284000182472704,NULL,2085636481799954434,2085636422874177537,'1942885905090105345',1,2,'2026-08-07 15:57:41','admin',1,NULL,NULL,'2026-08-07 15:57:41','admin','2026-08-07 15:57:41',0,'2026-08-07 15:57:41',2042543010529546242),(4531,1940284000182472704,NULL,2085654413401661442,2085636422874177537,'1942885905090105345',1,2,'2026-08-07 17:08:56','admin',1,NULL,NULL,'2026-08-07 17:08:56','admin','2026-08-07 17:08:56',0,'2026-08-07 17:08:56',2042543010529546242),(4532,1940284000182472704,NULL,2085654987396358145,2085636422874177537,'1942885905090105345',3,NULL,'2026-08-07 17:11:13','admin',1,NULL,NULL,'2026-08-07 17:11:13','admin','2026-08-07 17:11:13',0,'2026-08-07 17:11:13',2042543010529546242),(4533,1940284000182472704,NULL,2086657015989542914,2085636422874177537,'1942885905090105345',1,2,'2026-08-10 11:32:55','admin',1,NULL,NULL,'2026-08-10 11:32:55','admin','2026-08-10 11:33:13',0,'2026-08-10 11:33:14',2042543010529546242),(4534,1940284000182472704,NULL,2086657375349121025,2085636422874177537,'1942885905090105345',1,2,'2026-08-10 11:34:21','admin',1,NULL,NULL,'2026-08-10 11:34:21','admin','2026-08-10 11:34:21',0,'2026-08-10 11:34:21',2042543010529546242),(4535,1940284000182472704,NULL,2086657625786818561,2085636422874177537,'1942885905090105345',1,2,'2026-08-10 11:35:21','admin',1,NULL,NULL,'2026-08-10 11:35:20','admin','2026-08-10 11:35:20',0,'2026-08-10 11:35:21',2042543010529546242),(4536,1940284000182472704,NULL,2086657765515862017,2085636422874177537,'1942885905090105345',1,2,'2026-08-10 11:35:54','admin',1,NULL,NULL,'2026-08-10 11:35:54','admin','2026-08-10 11:35:54',0,'2026-08-10 11:35:54',2042543010529546242),(4537,1940284000182472704,NULL,2086692353932529666,2085636422874177537,'1942885905090105345',1,2,'2026-08-10 13:53:21','admin',1,NULL,NULL,'2026-08-10 13:53:20','admin','2026-08-10 13:53:55',0,'2026-08-10 13:53:56',2042543010529546242),(4538,1940284000182472704,NULL,2086692635697483778,2085636422874177537,'1942885905090105345',1,2,'2026-08-10 13:54:28','admin',1,NULL,NULL,'2026-08-10 13:54:27','admin','2026-08-10 13:54:27',0,'2026-08-10 13:54:28',2042543010529546242),(4539,1940284000182472704,NULL,2086693330613964802,2085636422874177537,'1942885905090105345',1,2,'2026-08-10 13:57:14','admin',1,NULL,NULL,'2026-08-10 13:57:13','admin','2026-08-10 13:57:13',0,'2026-08-10 13:57:14',2042543010529546242),(4540,1940284000182472704,NULL,2086694149774118913,2085636422874177537,'1942885905090105345',1,2,'2026-08-10 14:00:29','admin',1,NULL,NULL,'2026-08-10 14:00:28','admin','2026-08-10 14:00:28',0,'2026-08-10 14:00:29',2042543010529546242),(4541,1940284000182472704,NULL,2086694540381261825,2085636422874177537,'1942885905090105345',1,2,'2026-08-10 14:02:02','admin',1,NULL,NULL,'2026-08-10 14:02:01','admin','2026-08-10 14:02:02',0,'2026-08-10 14:02:02',2042543010529546242),(4542,1940284000182472704,NULL,2086703456389435393,2085636422874177537,'1942885905090105345',1,2,'2026-08-10 14:37:28','admin',1,NULL,NULL,'2026-08-10 14:37:27','admin','2026-08-10 14:37:27',0,'2026-08-10 14:37:28',2042543010529546242),(4543,1940284000182472704,NULL,2087082743757541378,2085636422874177537,'1942885905090105345',1,2,'2026-08-11 15:44:37','admin',1,NULL,NULL,'2026-08-11 15:44:36','admin','2026-08-11 15:44:52',0,'2026-08-11 15:44:52',2042543010529546242),(4544,1940284000182472704,NULL,2087083119835615233,2085636422874177537,'1942885905090105345',NULL,NULL,'2026-08-11 15:46:07','admin',1,NULL,NULL,'2026-08-11 15:46:06','admin','2026-08-11 15:46:06',0,'2026-08-11 15:46:07',2042543010529546242),(4545,1940284000182472704,NULL,2087083548501872641,2085636422874177537,'1942885905090105345',NULL,NULL,'2026-08-11 15:47:49','admin',1,NULL,NULL,'2026-08-11 15:47:48','admin','2026-08-11 15:47:48',0,'2026-08-11 15:47:49',2042543010529546242),(4546,1940284000182472704,NULL,2087083889305849858,2085636422874177537,'1942885905090105345',NULL,NULL,'2026-08-11 15:49:10','admin',1,NULL,NULL,'2026-08-11 15:49:10','admin','2026-08-11 15:49:10',0,'2026-08-11 15:49:10',2042543010529546242),(4547,1940284000182472704,NULL,2087084924260982785,2085636422874177537,'1942885905090105345',NULL,NULL,'2026-08-11 15:53:17','admin',1,NULL,NULL,'2026-08-11 15:53:16','admin','2026-08-11 15:53:16',0,'2026-08-11 15:53:17',2042543010529546242),(4548,1940284000182472704,NULL,2087085172433756161,2085636422874177537,'1942885905090105345',NULL,NULL,'2026-08-11 15:54:16','admin',1,NULL,NULL,'2026-08-11 15:54:15','admin','2026-08-11 15:54:15',0,'2026-08-11 15:54:16',2042543010529546242),(4549,1940284000182472704,NULL,2087114563262492674,2085636422874177537,'1942885905090105345',1,2,'2026-08-11 17:51:03','admin',1,NULL,NULL,'2026-08-11 17:51:03','admin','2026-08-11 17:51:03',0,'2026-08-11 17:51:03',2042543010529546242),(4550,1940284000182472704,NULL,2087114908374020098,2085636422874177537,'1942885905090105345',5,NULL,'2026-08-11 17:52:26','admin',1,NULL,NULL,'2026-08-11 17:52:25','admin','2026-08-11 17:52:25',0,'2026-08-11 17:52:26',2042543010529546242),(4551,1940284000182472704,NULL,2087115170631266305,2085636422874177537,'1942885905090105345',5,NULL,'2026-08-11 17:53:28','admin',1,NULL,NULL,'2026-08-11 17:53:28','admin','2026-08-11 17:53:28',0,'2026-08-11 17:53:28',2042543010529546242),(4552,1940284000182472704,NULL,2087115277032370177,2085636422874177537,'1942885905090105345',6,NULL,'2026-08-11 17:53:53','admin',1,NULL,NULL,'2026-08-11 17:53:53','admin','2026-08-11 17:53:53',0,'2026-08-11 17:53:53',2042543010529546242),(4553,1940284000182472704,NULL,2087115486806290434,2085636422874177537,'1942885905090105345',5,NULL,'2026-08-11 17:54:43','admin',1,NULL,NULL,'2026-08-11 17:54:43','admin','2026-08-11 17:54:43',0,'2026-08-11 17:54:43',2042543010529546242),(4554,1940284000182472704,NULL,2087115765433905153,2085636422874177537,'1942885905090105345',6,NULL,'2026-08-11 17:55:50','admin',1,NULL,NULL,'2026-08-11 17:55:49','admin','2026-08-11 17:55:49',0,'2026-08-11 17:55:50',2042543010529546242);
/*!40000 ALTER TABLE `pos_group_dish_book_release` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_operating_cost`
--

DROP TABLE IF EXISTS `pos_operating_cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_operating_cost` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `share` tinyint(1) DEFAULT NULL COMMENT '分摊到部门',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='经营成本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_operating_cost`
--

LOCK TABLES `pos_operating_cost` WRITE;
/*!40000 ALTER TABLE `pos_operating_cost` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_operating_cost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_operating_target`
--

DROP TABLE IF EXISTS `pos_operating_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_operating_target` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `cost_lid` bigint DEFAULT NULL COMMENT '成本lid',
  `cost_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '成本名称',
  `dept_lid` bigint DEFAULT NULL COMMENT '部门lid',
  `dept_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '部门名称',
  `year_` int DEFAULT NULL COMMENT '年',
  `month_` int DEFAULT NULL COMMENT '月',
  `day_` int DEFAULT NULL COMMENT '天',
  `value` decimal(19,10) DEFAULT NULL COMMENT '金额/百分比',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `report_date` datetime DEFAULT NULL COMMENT '日期',
  `organ_type` int NOT NULL DEFAULT '1' COMMENT '组织类型',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid` (`mid`,`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='经营成本目标';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_operating_target`
--

LOCK TABLES `pos_operating_target` WRITE;
/*!40000 ALTER TABLE `pos_operating_target` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_operating_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_perform_target`
--

DROP TABLE IF EXISTS `pos_perform_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_perform_target` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `dept_lid` bigint DEFAULT NULL COMMENT '部门lid',
  `dept_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '部门名称',
  `perform_type` int DEFAULT NULL COMMENT '业绩类型',
  `statistics_type` int DEFAULT NULL COMMENT '统计类型',
  `year_` int DEFAULT NULL COMMENT '年',
  `month_` int DEFAULT NULL COMMENT '月',
  `day_` int DEFAULT NULL COMMENT '天',
  `value` decimal(19,10) DEFAULT NULL COMMENT '金额/百分比',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `report_date` datetime DEFAULT NULL COMMENT '日期',
  `person` decimal(19,10) DEFAULT NULL COMMENT '人数',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid` (`mid`,`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='业绩目标';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_perform_target`
--

LOCK TABLES `pos_perform_target` WRITE;
/*!40000 ALTER TABLE `pos_perform_target` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_perform_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_pricing_by_time`
--

DROP TABLE IF EXISTS `pos_pricing_by_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_pricing_by_time` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `pricing_type` int DEFAULT NULL COMMENT '计价类型',
  `timeout_type` int DEFAULT NULL COMMENT '超时类型',
  `time_period_type` int DEFAULT NULL COMMENT '时段类型',
  `constant_time` int DEFAULT NULL COMMENT '固定时间',
  `constant_charge` decimal(10,0) DEFAULT NULL COMMENT '固定收费',
  `ceiling_charge` decimal(10,0) DEFAULT NULL COMMENT '封顶费',
  `timing_free_time` int DEFAULT NULL COMMENT '计时免费时间',
  `minimum_spending_duration` int DEFAULT NULL COMMENT '最低消费时长',
  `minimum_billing_duration` int DEFAULT NULL COMMENT '最小计费时长',
  `timing_participation_member_discount` tinyint(1) DEFAULT NULL COMMENT '计时参与会员折扣',
  `added_service_fee` tinyint(1) DEFAULT NULL COMMENT '加收服务费',
  `advance_session_charge` tinyint(1) DEFAULT NULL COMMENT '超前场收费',
  `advance_session_free_time` int DEFAULT NULL COMMENT '超前场免费时间',
  `advance_session_hourly_price` decimal(10,0) DEFAULT NULL COMMENT '超前场每小时价格',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='计时计价表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_pricing_by_time`
--

LOCK TABLES `pos_pricing_by_time` WRITE;
/*!40000 ALTER TABLE `pos_pricing_by_time` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_pricing_by_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_pricing_by_time_period`
--

DROP TABLE IF EXISTS `pos_pricing_by_time_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_pricing_by_time_period` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `time_period_type` int DEFAULT NULL COMMENT '时段类型',
  `start_time` datetime DEFAULT NULL COMMENT '起始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `single_price` int DEFAULT NULL COMMENT '时段金额',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='计时计价时段表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_pricing_by_time_period`
--

LOCK TABLES `pos_pricing_by_time_period` WRITE;
/*!40000 ALTER TABLE `pos_pricing_by_time_period` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_pricing_by_time_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_pricing_by_time_timeout`
--

DROP TABLE IF EXISTS `pos_pricing_by_time_timeout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_pricing_by_time_timeout` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `pricing_type` int DEFAULT NULL COMMENT '计价类型',
  `timeout_type` int DEFAULT NULL COMMENT '超时类型',
  `free_time_for_due_timeout` int DEFAULT NULL COMMENT '到点超时免收时间',
  `interval_free_time` int DEFAULT NULL COMMENT '区间免收时间',
  `interval_time_period` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '区间时间段',
  `interval_hourly_price` decimal(10,0) DEFAULT NULL COMMENT '区间每小时价格',
  `session_free_time` int DEFAULT NULL COMMENT '按场次免收时间',
  `hourly_free_time` int DEFAULT NULL COMMENT '按小时免收时间',
  `hourly_extra_charge_per_hour` decimal(10,0) DEFAULT NULL COMMENT '按小时每小时加收',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='计时计价超时表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_pricing_by_time_timeout`
--

LOCK TABLES `pos_pricing_by_time_timeout` WRITE;
/*!40000 ALTER TABLE `pos_pricing_by_time_timeout` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_pricing_by_time_timeout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_prn_job`
--

DROP TABLE IF EXISTS `pos_prn_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_prn_job` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `biz_bill_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务单号',
  `type_` int DEFAULT NULL COMMENT '类型',
  `purpose` int DEFAULT NULL COMMENT '用途',
  `prn_count` int DEFAULT NULL COMMENT '打印次数',
  `prn_queue_lid` bigint DEFAULT NULL COMMENT '打印队列编号',
  `prn_printer_lid` bigint DEFAULT NULL COMMENT '打印机编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='打印任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_prn_job`
--

LOCK TABLES `pos_prn_job` WRITE;
/*!40000 ALTER TABLE `pos_prn_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_prn_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_prn_printer`
--

DROP TABLE IF EXISTS `pos_prn_printer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_prn_printer` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `pc_lid` bigint DEFAULT NULL COMMENT '所属计算机',
  `type` int DEFAULT NULL COMMENT '类型',
  `model` int DEFAULT NULL COMMENT '型号',
  `extra_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '附加信息',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=680 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='打印机';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_prn_printer`
--

LOCK TABLES `pos_prn_printer` WRITE;
/*!40000 ALTER TABLE `pos_prn_printer` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_prn_printer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_prn_queue`
--

DROP TABLE IF EXISTS `pos_prn_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_prn_queue` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `pc_lid` bigint DEFAULT NULL COMMENT '所属计算机',
  `primary_printer` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '主打印机',
  `standby_printer` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备用打印机',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=683 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='打印队列';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_prn_queue`
--

LOCK TABLES `pos_prn_queue` WRITE;
/*!40000 ALTER TABLE `pos_prn_queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_prn_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_prn_style`
--

DROP TABLE IF EXISTS `pos_prn_style`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_prn_style` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `type_` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型',
  `extra_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '附加信息',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_type` (`mid`,`type_`) USING BTREE,
  KEY `idx_sid_type` (`sid`,`type_`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='打印单据样式';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_prn_style`
--

LOCK TABLES `pos_prn_style` WRITE;
/*!40000 ALTER TABLE `pos_prn_style` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_prn_style` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_prn_style_col`
--

DROP TABLE IF EXISTS `pos_prn_style_col`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_prn_style_col` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `style_type` int DEFAULT NULL COMMENT '单据类型',
  `row_lid` bigint DEFAULT NULL COMMENT '行编号',
  `type_` int DEFAULT NULL COMMENT '类型',
  `ds_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '数据源编号',
  `ds_field_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '数据源字段编号',
  `customized_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '自定义内容',
  `customized_content_suffix` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '自定义内容(后)',
  `width80` int DEFAULT NULL COMMENT '宽度(80毫米热敏纸)',
  `width76` int DEFAULT NULL COMMENT '宽度(76毫米针式打印机)',
  `width58` int DEFAULT NULL COMMENT '宽度(58毫米热敏纸)',
  `align` int DEFAULT NULL COMMENT '对齐方式',
  `font_size` int DEFAULT NULL COMMENT '字体',
  `bold` tinyint(1) DEFAULT NULL COMMENT '加粗',
  `show_index` int DEFAULT NULL COMMENT '显示顺序',
  `insert_separator_line` int DEFAULT NULL COMMENT '插入分割线数',
  `insert_blank_line` int DEFAULT NULL COMMENT '插入空行数',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `condition_ds_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '显示条件的数据源编号',
  `condition_operator` int DEFAULT NULL COMMENT '显示条件的操作符',
  `condition_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '显示条件的右值',
  `color` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '颜色',
  `bg` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '背景颜色',
  `summarize` tinyint(1) DEFAULT NULL COMMENT '需要打印汇总',
  `line_spacing` int DEFAULT NULL COMMENT '行间距',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=65262 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='打印样式列';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_prn_style_col`
--

LOCK TABLES `pos_prn_style_col` WRITE;
/*!40000 ALTER TABLE `pos_prn_style_col` DISABLE KEYS */;
INSERT INTO `pos_prn_style_col` VALUES (65153,1940284000182472704,1942885905090105345,2043610013815672834,32,2043610013765341186,3,NULL,NULL,'[{\"i\":1742723117791,\"v\":\"【每日销售报表】\",\"c\":true}]',NULL,NULL,NULL,NULL,NULL,4,NULL,0,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65154,1940284000182472704,1942885905090105345,2043610013815672835,32,2043610013765341187,3,NULL,NULL,'[{\"i\":1742723136855,\"v\":\"date_sale_info,beginDate\",\"c\":false},{\"i\":1742897257466,\"v\":\"-\",\"c\":true},{\"i\":1742897421336,\"v\":\"date_sale_info,endDate\",\"c\":false}]',NULL,100,100,100,1,2,NULL,1,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65155,1940284000182472704,1942885905090105345,2043610013815672836,32,2043610013765341188,3,NULL,NULL,'[{\"i\":1742886858160,\"v\":\"部门汇总\",\"c\":true}]',NULL,NULL,NULL,NULL,1,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65156,1940284000182472704,1942885905090105345,2043610013819867138,32,2043610013765341189,3,NULL,NULL,'[{\"i\":1742882506059,\"v\":\"部门\",\"c\":true}]',NULL,40,40,40,3,NULL,NULL,3,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65157,1940284000182472704,1942885905090105345,2043610013819867139,32,2043610013765341189,3,NULL,NULL,'[{\"i\":1742882513905,\"v\":\"金额\",\"c\":true}]',NULL,60,60,60,2,NULL,NULL,4,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65158,1940284000182472704,1942885905090105345,2043610013819867140,32,2043610013765341190,3,NULL,NULL,'[{\"i\":1742886582464,\"v\":\"dept_sum_info,name\",\"c\":false}]',NULL,40,40,40,3,NULL,NULL,5,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65159,1940284000182472704,1942885905090105345,2043610013819867141,32,2043610013765341190,3,NULL,NULL,'[{\"i\":1742886594028,\"v\":\"dept_sum_info,paidAmount\",\"c\":false}]',NULL,60,60,60,2,NULL,NULL,6,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65160,1940284000182472704,1942885905090105345,2043610013819867142,32,2043610013765341191,3,NULL,NULL,'[{\"i\":1742886949888,\"v\":\"收款汇总\",\"c\":true}]',NULL,NULL,NULL,NULL,1,NULL,NULL,7,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65161,1940284000182472704,1942885905090105345,2043610013819867143,32,2043610013765341192,3,NULL,NULL,'[{\"i\":1742886980669,\"v\":\"科目\",\"c\":true}]',NULL,55,55,55,3,NULL,NULL,8,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65162,1940284000182472704,1942885905090105345,2043610013819867144,32,2043610013765341192,3,NULL,NULL,'[{\"i\":1742887002530,\"v\":\"笔数\",\"c\":true}]',NULL,20,20,20,2,NULL,NULL,9,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65163,1940284000182472704,1942885905090105345,2043610013819867145,32,2043610013765341192,3,NULL,NULL,'[{\"i\":1742887033166,\"v\":\"金额\",\"c\":true}]',NULL,25,25,25,2,NULL,NULL,10,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65164,1940284000182472704,1942885905090105345,2043610013819867146,32,2043610013765341193,3,NULL,NULL,'[{\"i\":1742887183934,\"v\":\"paid_sum_info,name\",\"c\":false}]',NULL,55,55,55,3,NULL,NULL,11,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65165,1940284000182472704,1942885905090105345,2043610013819867147,32,2043610013765341193,3,NULL,NULL,'[{\"i\":1742887190074,\"v\":\"paid_sum_info,count\",\"c\":false}]',NULL,20,20,20,2,NULL,NULL,12,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65166,1940284000182472704,1942885905090105345,2043610013819867148,32,2043610013765341193,3,NULL,NULL,'[{\"i\":1742887198352,\"v\":\"paid_sum_info,amount\",\"c\":false}]',NULL,25,25,25,2,NULL,NULL,13,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65167,1940284000182472704,1942885905090105345,2043610013819867149,32,2043610013765341194,3,NULL,NULL,'[{\"i\":1742887296456,\"v\":\"充值汇总\",\"c\":true}]',NULL,NULL,NULL,NULL,1,NULL,NULL,14,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65168,1940284000182472704,1942885905090105345,2043610013819867150,32,2043610013765341195,3,NULL,NULL,'[{\"i\":1742887356478,\"v\":\"科目\",\"c\":true}]',NULL,55,55,55,3,NULL,NULL,15,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65169,1940284000182472704,1942885905090105345,2043610013819867151,32,2043610013765341195,3,NULL,NULL,'[{\"i\":1742887368994,\"v\":\"笔数\",\"c\":true}]',NULL,20,20,20,2,NULL,NULL,16,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65170,1940284000182472704,1942885905090105345,2043610013819867152,32,2043610013765341195,3,NULL,NULL,'[{\"i\":1742887374586,\"v\":\"金额\",\"c\":true}]',NULL,25,25,25,2,NULL,NULL,17,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65171,1940284000182472704,1942885905090105345,2043610013819867153,32,2043610013765341196,3,NULL,NULL,'[{\"i\":1742887437920,\"v\":\"charge_sum_info,name\",\"c\":false}]',NULL,55,55,55,3,NULL,NULL,18,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65172,1940284000182472704,1942885905090105345,2043610013819867154,32,2043610013765341196,3,NULL,NULL,'[{\"i\":1742887442570,\"v\":\"charge_sum_info,count\",\"c\":false}]',NULL,20,20,20,2,NULL,NULL,19,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65173,1940284000182472704,1942885905090105345,2043610013819867155,32,2043610013765341196,3,NULL,NULL,'[{\"i\":1742887447858,\"v\":\"charge_sum_info,amount\",\"c\":false}]',NULL,25,25,25,2,NULL,NULL,20,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65174,1940284000182472704,1942885905090105345,2043610013819867156,32,2043610013765341197,3,NULL,NULL,'[{\"i\":1742887556050,\"v\":\"回款汇总\",\"c\":true}]',NULL,NULL,NULL,NULL,1,NULL,NULL,21,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65175,1940284000182472704,1942885905090105345,2043610013819867157,32,2043610013765341198,3,NULL,NULL,'[{\"i\":1742887585948,\"v\":\"科目\",\"c\":true}]',NULL,55,55,55,3,NULL,NULL,22,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65176,1940284000182472704,1942885905090105345,2043610013819867158,32,2043610013765341198,3,NULL,NULL,'[{\"i\":1742887598938,\"v\":\"笔数\",\"c\":true}]',NULL,20,20,20,2,NULL,NULL,23,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65177,1940284000182472704,1942885905090105345,2043610013819867159,32,2043610013765341198,3,NULL,NULL,'[{\"i\":1742887582446,\"v\":\"金额\",\"c\":true}]',NULL,25,25,25,2,NULL,NULL,24,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65178,1940284000182472704,1942885905090105345,2043610013819867160,32,2043610013765341199,3,NULL,NULL,'[{\"i\":1742887639124,\"v\":\"credit_sum_info,name\",\"c\":false}]',NULL,55,55,55,3,NULL,NULL,25,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65179,1940284000182472704,1942885905090105345,2043610013819867161,32,2043610013765341199,3,NULL,NULL,'[{\"i\":1742887636256,\"v\":\"credit_sum_info,count\",\"c\":false}]',NULL,20,20,20,2,NULL,NULL,26,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65180,1940284000182472704,1942885905090105345,2043610013819867162,32,2043610013765341199,3,NULL,NULL,'[{\"i\":1742887631058,\"v\":\"credit_sum_info,amount\",\"c\":false}]',NULL,25,25,25,2,NULL,NULL,27,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65181,1940284000182472704,1942885905090105345,2043610013819867163,32,2043610013765341200,3,NULL,NULL,'[{\"i\":1749886671004,\"v\":\"优惠券汇总\",\"c\":true}]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,28,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65182,1940284000182472704,1942885905090105345,2043610013819867164,32,2043610013765341201,3,NULL,NULL,'[{\"i\":1749886755410,\"v\":\"名称\",\"c\":true}]',NULL,55,55,55,3,NULL,NULL,29,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65183,1940284000182472704,1942885905090105345,2043610013819867165,32,2043610013765341201,3,NULL,NULL,'[{\"i\":1749886773443,\"v\":\"张数\",\"c\":true}]',NULL,20,20,20,2,NULL,NULL,30,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65184,1940284000182472704,1942885905090105345,2043610013819867166,32,2043610013765341201,3,NULL,NULL,'[{\"i\":1749886781797,\"v\":\"金额\",\"c\":true}]',NULL,25,25,25,2,NULL,NULL,31,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65185,1940284000182472704,1942885905090105345,2043610013819867167,32,2043610013765341202,3,NULL,NULL,'[{\"i\":1749886809335,\"v\":\"coupon_sum_info,name\",\"c\":false}]',NULL,55,55,55,3,NULL,NULL,32,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65186,1940284000182472704,1942885905090105345,2043610013819867168,32,2043610013765341202,3,NULL,NULL,'[{\"i\":1749886818421,\"v\":\"coupon_sum_info,count\",\"c\":false}]',NULL,20,20,20,2,NULL,NULL,33,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65187,1940284000182472704,1942885905090105345,2043610013819867169,32,2043610013765341202,3,NULL,NULL,'[{\"i\":1749886824976,\"v\":\"coupon_sum_info,amount\",\"c\":false}]',NULL,25,25,25,2,NULL,NULL,34,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65188,1940284000182472704,1942885905090105345,2043610013819867170,32,2043610013765341203,3,NULL,NULL,'[{\"i\":9900170,\"v\":\"coupon_platform_detail_info,platformName\",\"c\":false}]',NULL,100,100,100,3,NULL,1,35,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),(65189,1940284000182472704,1942885905090105345,2043610013819867171,32,2043610013765341203,3,NULL,NULL,'[{\"i\":1749886809335,\"v\":\"coupon_platform_detail_info,name\",\"c\":false}]',NULL,55,55,55,3,NULL,NULL,36,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65190,1940284000182472704,1942885905090105345,2043610013819867172,32,2043610013765341203,3,NULL,NULL,'[{\"i\":1749886818421,\"v\":\"coupon_platform_detail_info,count\",\"c\":false}]',NULL,20,20,20,2,NULL,NULL,37,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65191,1940284000182472704,1942885905090105345,2043610013819867173,32,2043610013765341203,3,NULL,NULL,'[{\"i\":1749886824976,\"v\":\"coupon_platform_detail_info,amount\",\"c\":false}]',NULL,25,25,25,2,NULL,NULL,38,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65192,1940284000182472704,1942885905090105345,2043610013819867174,32,2043610013765341204,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,39,1,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65193,1940284000182472704,1942885905090105345,2043610013819867175,32,2043610013765341205,3,NULL,NULL,'[{\"i\":1742898148822,\"v\":\"赠、退菜监控\",\"c\":true}]',NULL,NULL,NULL,NULL,1,NULL,NULL,40,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65194,1940284000182472704,1942885905090105345,2043610013819867176,32,2043610013765341205,3,NULL,NULL,'[{\"i\":1742898192386,\"v\":\"赠送金额：\",\"c\":true}]',NULL,50,50,50,3,NULL,NULL,41,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65195,1940284000182472704,1942885905090105345,2043610013819867177,32,2043610013765341205,3,NULL,NULL,'[{\"i\":1742898206775,\"v\":\"date_sale_info,sendAmount\",\"c\":false}]',NULL,50,50,50,2,NULL,NULL,42,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65196,1940284000182472704,1942885905090105345,2043610013819867178,32,2043610013765341205,3,NULL,NULL,'[{\"i\":1742898221596,\"v\":\"退菜金额：\",\"c\":true}]',NULL,50,50,50,3,NULL,NULL,43,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65197,1940284000182472704,1942885905090105345,2043610013819867179,32,2043610013765341205,3,NULL,NULL,'[{\"i\":1742898227772,\"v\":\"date_sale_info,cancelAmount\",\"c\":false}]',NULL,50,50,50,2,NULL,NULL,44,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65198,1940284000182472704,1942885905090105345,2043610013819867180,32,2043610013765341205,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,45,1,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65199,1940284000182472704,1942885905090105345,2043610013819867181,32,2043610013765341206,3,NULL,NULL,'[{\"i\":1742887701484,\"v\":\"服务费合计：\",\"c\":true}]',NULL,40,40,40,3,NULL,NULL,46,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65200,1940284000182472704,1942885905090105345,2043610013819867182,32,2043610013765341206,3,NULL,NULL,'[{\"i\":1742887707871,\"v\":\"date_sale_info,serviceChargeAmount\",\"c\":false}]',NULL,60,60,60,2,NULL,NULL,47,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65201,1940284000182472704,1942885905090105345,2043610013819867183,32,2043610013765341207,3,NULL,NULL,'[{\"i\":1742887792096,\"v\":\"折扣额：\",\"c\":true}]',NULL,40,40,40,3,NULL,NULL,48,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65202,1940284000182472704,1942885905090105345,2043610013819867184,32,2043610013765341207,3,NULL,NULL,'[{\"i\":1742887804370,\"v\":\"date_sale_info,discountAmount\",\"c\":false}]',NULL,60,60,60,2,NULL,NULL,49,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65203,1940284000182472704,1942885905090105345,2043610013819867185,32,2043610013765341208,3,NULL,NULL,'[{\"i\":1742887834724,\"v\":\"零头：\",\"c\":true}]',NULL,40,40,40,3,NULL,NULL,50,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65204,1940284000182472704,1942885905090105345,2043610013819867186,32,2043610013765341208,3,NULL,NULL,'[{\"i\":1742887884620,\"v\":\"date_sale_info,fraction\",\"c\":false}]',NULL,60,60,60,2,NULL,NULL,51,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65205,1940284000182472704,1942885905090105345,2043610013819867187,32,2043610013765341209,3,NULL,NULL,'[{\"i\":1742887919026,\"v\":\"尾数：\",\"c\":true}]',NULL,50,50,50,3,NULL,NULL,52,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65206,1940284000182472704,1942885905090105345,2043610013819867188,32,2043610013765341209,3,NULL,NULL,'[{\"i\":1742887934454,\"v\":\"date_sale_info,mantissa\",\"c\":false}]',NULL,50,50,50,2,NULL,NULL,53,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65207,1940284000182472704,1942885905090105345,2043610013819867189,32,2043610013765341210,3,NULL,NULL,'[{\"i\":1742887979040,\"v\":\"收入合计：\",\"c\":true}]',NULL,40,40,40,3,NULL,NULL,54,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65208,1940284000182472704,1942885905090105345,2043610013819867190,32,2043610013765341210,3,NULL,NULL,'[{\"i\":1742887987074,\"v\":\"date_sale_info,totalIncome\",\"c\":false}]',NULL,60,60,60,2,NULL,NULL,55,NULL,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65209,1940284000182472704,1940287289892687874,2043897624480587778,32,2043897624044380162,3,NULL,NULL,'[{\"i\":1742723117791,\"v\":\"【每日销售报表】\",\"c\":true}]',NULL,NULL,NULL,NULL,NULL,4,NULL,0,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65210,1940284000182472704,1940287289892687874,2043897624480587779,32,2043897624044380163,3,NULL,NULL,'[{\"i\":1742723136855,\"v\":\"date_sale_info,beginDate\",\"c\":false},{\"i\":1742897257466,\"v\":\"-\",\"c\":true},{\"i\":1742897421336,\"v\":\"date_sale_info,endDate\",\"c\":false}]',NULL,100,100,100,1,2,NULL,1,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65211,1940284000182472704,1940287289892687874,2043897624480587780,32,2043897624044380164,3,NULL,NULL,'[{\"i\":1742886858160,\"v\":\"部门汇总\",\"c\":true}]',NULL,NULL,NULL,NULL,1,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65212,1940284000182472704,1940287289892687874,2043897624480587781,32,2043897624044380165,3,NULL,NULL,'[{\"i\":1742882506059,\"v\":\"部门\",\"c\":true}]',NULL,40,40,40,3,NULL,NULL,3,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65213,1940284000182472704,1940287289892687874,2043897624480587782,32,2043897624044380165,3,NULL,NULL,'[{\"i\":1742882513905,\"v\":\"金额\",\"c\":true}]',NULL,60,60,60,2,NULL,NULL,4,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65214,1940284000182472704,1940287289892687874,2043897624480587783,32,2043897624044380166,3,NULL,NULL,'[{\"i\":1742886582464,\"v\":\"dept_sum_info,name\",\"c\":false}]',NULL,40,40,40,3,NULL,NULL,5,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65215,1940284000182472704,1940287289892687874,2043897624480587784,32,2043897624044380166,3,NULL,NULL,'[{\"i\":1742886594028,\"v\":\"dept_sum_info,paidAmount\",\"c\":false}]',NULL,60,60,60,2,NULL,NULL,6,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65216,1940284000182472704,1940287289892687874,2043897624480587785,32,2043897624044380167,3,NULL,NULL,'[{\"i\":1742886949888,\"v\":\"收款汇总\",\"c\":true}]',NULL,NULL,NULL,NULL,1,NULL,NULL,7,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65217,1940284000182472704,1940287289892687874,2043897624480587786,32,2043897624044380168,3,NULL,NULL,'[{\"i\":1742886980669,\"v\":\"科目\",\"c\":true}]',NULL,55,55,55,3,NULL,NULL,8,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65218,1940284000182472704,1940287289892687874,2043897624480587787,32,2043897624044380168,3,NULL,NULL,'[{\"i\":1742887002530,\"v\":\"笔数\",\"c\":true}]',NULL,20,20,20,2,NULL,NULL,9,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65219,1940284000182472704,1940287289892687874,2043897624480587788,32,2043897624044380168,3,NULL,NULL,'[{\"i\":1742887033166,\"v\":\"金额\",\"c\":true}]',NULL,25,25,25,2,NULL,NULL,10,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65220,1940284000182472704,1940287289892687874,2043897624480587789,32,2043897624044380169,3,NULL,NULL,'[{\"i\":1742887183934,\"v\":\"paid_sum_info,name\",\"c\":false}]',NULL,55,55,55,3,NULL,NULL,11,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65221,1940284000182472704,1940287289892687874,2043897624480587790,32,2043897624044380169,3,NULL,NULL,'[{\"i\":1742887190074,\"v\":\"paid_sum_info,count\",\"c\":false}]',NULL,20,20,20,2,NULL,NULL,12,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65222,1940284000182472704,1940287289892687874,2043897624480587791,32,2043897624044380169,3,NULL,NULL,'[{\"i\":1742887198352,\"v\":\"paid_sum_info,amount\",\"c\":false}]',NULL,25,25,25,2,NULL,NULL,13,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65223,1940284000182472704,1940287289892687874,2043897624480587792,32,2043897624044380170,3,NULL,NULL,'[{\"i\":1742887296456,\"v\":\"充值汇总\",\"c\":true}]',NULL,NULL,NULL,NULL,1,NULL,NULL,14,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65224,1940284000182472704,1940287289892687874,2043897624480587793,32,2043897624044380171,3,NULL,NULL,'[{\"i\":1742887356478,\"v\":\"科目\",\"c\":true}]',NULL,55,55,55,3,NULL,NULL,15,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65225,1940284000182472704,1940287289892687874,2043897624480587794,32,2043897624044380171,3,NULL,NULL,'[{\"i\":1742887368994,\"v\":\"笔数\",\"c\":true}]',NULL,20,20,20,2,NULL,NULL,16,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65226,1940284000182472704,1940287289892687874,2043897624480587795,32,2043897624044380171,3,NULL,NULL,'[{\"i\":1742887374586,\"v\":\"金额\",\"c\":true}]',NULL,25,25,25,2,NULL,NULL,17,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65227,1940284000182472704,1940287289892687874,2043897624480587796,32,2043897624044380172,3,NULL,NULL,'[{\"i\":1742887437920,\"v\":\"charge_sum_info,name\",\"c\":false}]',NULL,55,55,55,3,NULL,NULL,18,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65228,1940284000182472704,1940287289892687874,2043897624480587797,32,2043897624044380172,3,NULL,NULL,'[{\"i\":1742887442570,\"v\":\"charge_sum_info,count\",\"c\":false}]',NULL,20,20,20,2,NULL,NULL,19,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65229,1940284000182472704,1940287289892687874,2043897624480587798,32,2043897624044380172,3,NULL,NULL,'[{\"i\":1742887447858,\"v\":\"charge_sum_info,amount\",\"c\":false}]',NULL,25,25,25,2,NULL,NULL,20,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65230,1940284000182472704,1940287289892687874,2043897624480587799,32,2043897624044380173,3,NULL,NULL,'[{\"i\":1742887556050,\"v\":\"回款汇总\",\"c\":true}]',NULL,NULL,NULL,NULL,1,NULL,NULL,21,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65231,1940284000182472704,1940287289892687874,2043897624480587800,32,2043897624044380174,3,NULL,NULL,'[{\"i\":1742887585948,\"v\":\"科目\",\"c\":true}]',NULL,55,55,55,3,NULL,NULL,22,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65232,1940284000182472704,1940287289892687874,2043897624480587801,32,2043897624044380174,3,NULL,NULL,'[{\"i\":1742887598938,\"v\":\"笔数\",\"c\":true}]',NULL,20,20,20,2,NULL,NULL,23,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65233,1940284000182472704,1940287289892687874,2043897624480587802,32,2043897624044380174,3,NULL,NULL,'[{\"i\":1742887582446,\"v\":\"金额\",\"c\":true}]',NULL,25,25,25,2,NULL,NULL,24,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65234,1940284000182472704,1940287289892687874,2043897624480587803,32,2043897624044380175,3,NULL,NULL,'[{\"i\":1742887639124,\"v\":\"credit_sum_info,name\",\"c\":false}]',NULL,55,55,55,3,NULL,NULL,25,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65235,1940284000182472704,1940287289892687874,2043897624480587804,32,2043897624044380175,3,NULL,NULL,'[{\"i\":1742887636256,\"v\":\"credit_sum_info,count\",\"c\":false}]',NULL,20,20,20,2,NULL,NULL,26,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65236,1940284000182472704,1940287289892687874,2043897624480587805,32,2043897624044380175,3,NULL,NULL,'[{\"i\":1742887631058,\"v\":\"credit_sum_info,amount\",\"c\":false}]',NULL,25,25,25,2,NULL,NULL,27,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65237,1940284000182472704,1940287289892687874,2043897624480587806,32,2043897624044380176,3,NULL,NULL,'[{\"i\":1749886671004,\"v\":\"优惠券汇总\",\"c\":true}]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,28,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65238,1940284000182472704,1940287289892687874,2043897624480587807,32,2043897624044380177,3,NULL,NULL,'[{\"i\":1749886755410,\"v\":\"名称\",\"c\":true}]',NULL,55,55,55,3,NULL,NULL,29,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65239,1940284000182472704,1940287289892687874,2043897624480587808,32,2043897624044380177,3,NULL,NULL,'[{\"i\":1749886773443,\"v\":\"张数\",\"c\":true}]',NULL,20,20,20,2,NULL,NULL,30,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65240,1940284000182472704,1940287289892687874,2043897624480587809,32,2043897624044380177,3,NULL,NULL,'[{\"i\":1749886781797,\"v\":\"金额\",\"c\":true}]',NULL,25,25,25,2,NULL,NULL,31,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65241,1940284000182472704,1940287289892687874,2043897624480587810,32,2043897624044380178,3,NULL,NULL,'[{\"i\":9900170,\"v\":\"coupon_platform_detail_info,platformName\",\"c\":false}]',NULL,100,100,100,3,NULL,1,32,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),(65242,1940284000182472704,1940287289892687874,2043897624480587811,32,2043897624044380178,3,NULL,NULL,'[{\"i\":1749886809335,\"v\":\"coupon_platform_detail_info,name\",\"c\":false}]',NULL,55,55,55,3,NULL,NULL,33,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65243,1940284000182472704,1940287289892687874,2043897624480587812,32,2043897624044380178,3,NULL,NULL,'[{\"i\":1749886818421,\"v\":\"coupon_platform_detail_info,count\",\"c\":false}]',NULL,20,20,20,2,NULL,NULL,34,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65244,1940284000182472704,1940287289892687874,2043897624480587813,32,2043897624044380178,3,NULL,NULL,'[{\"i\":1749886824976,\"v\":\"coupon_platform_detail_info,amount\",\"c\":false}]',NULL,25,25,25,2,NULL,NULL,35,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65245,1940284000182472704,1940287289892687874,2043897624480587814,32,2043897624044380179,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,36,1,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65246,1940284000182472704,1940287289892687874,2043897624480587815,32,2043897624044380180,3,NULL,NULL,'[{\"i\":1742898148822,\"v\":\"赠、退菜监控\",\"c\":true}]',NULL,NULL,NULL,NULL,1,NULL,NULL,37,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65247,1940284000182472704,1940287289892687874,2043897624480587816,32,2043897624044380180,3,NULL,NULL,'[{\"i\":1742898192386,\"v\":\"赠送金额：\",\"c\":true}]',NULL,50,50,50,3,NULL,NULL,38,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65248,1940284000182472704,1940287289892687874,2043897624480587817,32,2043897624044380180,3,NULL,NULL,'[{\"i\":1742898206775,\"v\":\"date_sale_info,sendAmount\",\"c\":false}]',NULL,50,50,50,2,NULL,NULL,39,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65249,1940284000182472704,1940287289892687874,2043897624480587818,32,2043897624044380180,3,NULL,NULL,'[{\"i\":1742898221596,\"v\":\"退菜金额：\",\"c\":true}]',NULL,50,50,50,3,NULL,NULL,40,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65250,1940284000182472704,1940287289892687874,2043897624480587819,32,2043897624044380180,3,NULL,NULL,'[{\"i\":1742898227772,\"v\":\"date_sale_info,cancelAmount\",\"c\":false}]',NULL,50,50,50,2,NULL,NULL,41,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65251,1940284000182472704,1940287289892687874,2043897624480587820,32,2043897624044380180,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,42,1,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65252,1940284000182472704,1940287289892687874,2043897624480587821,32,2043897624044380181,3,NULL,NULL,'[{\"i\":1742887701484,\"v\":\"服务费合计：\",\"c\":true}]',NULL,40,40,40,3,NULL,NULL,43,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65253,1940284000182472704,1940287289892687874,2043897624480587822,32,2043897624044380181,3,NULL,NULL,'[{\"i\":1742887707871,\"v\":\"date_sale_info,serviceChargeAmount\",\"c\":false}]',NULL,60,60,60,2,NULL,NULL,44,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65254,1940284000182472704,1940287289892687874,2043897624480587823,32,2043897624044380182,3,NULL,NULL,'[{\"i\":1742887792096,\"v\":\"折扣额：\",\"c\":true}]',NULL,40,40,40,3,NULL,NULL,45,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65255,1940284000182472704,1940287289892687874,2043897624480587824,32,2043897624044380182,3,NULL,NULL,'[{\"i\":1742887804370,\"v\":\"date_sale_info,discountAmount\",\"c\":false}]',NULL,60,60,60,2,NULL,NULL,46,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65256,1940284000182472704,1940287289892687874,2043897624480587825,32,2043897624044380183,3,NULL,NULL,'[{\"i\":1742887834724,\"v\":\"零头：\",\"c\":true}]',NULL,40,40,40,3,NULL,NULL,47,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65257,1940284000182472704,1940287289892687874,2043897624480587826,32,2043897624044380183,3,NULL,NULL,'[{\"i\":1742887884620,\"v\":\"date_sale_info,fraction\",\"c\":false}]',NULL,60,60,60,2,NULL,NULL,48,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65258,1940284000182472704,1940287289892687874,2043897624480587827,32,2043897624044380184,3,NULL,NULL,'[{\"i\":1742887919026,\"v\":\"尾数：\",\"c\":true}]',NULL,50,50,50,3,NULL,NULL,49,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65259,1940284000182472704,1940287289892687874,2043897624480587828,32,2043897624044380184,3,NULL,NULL,'[{\"i\":1742887934454,\"v\":\"date_sale_info,mantissa\",\"c\":false}]',NULL,50,50,50,2,NULL,NULL,50,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65260,1940284000182472704,1940287289892687874,2043897624480587829,32,2043897624044380185,3,NULL,NULL,'[{\"i\":1742887979040,\"v\":\"收入合计：\",\"c\":true}]',NULL,40,40,40,3,NULL,NULL,51,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65261,1940284000182472704,1940287289892687874,2043897624480587830,32,2043897624044380185,3,NULL,NULL,'[{\"i\":1742887987074,\"v\":\"date_sale_info,totalIncome\",\"c\":false}]',NULL,60,60,60,2,NULL,NULL,52,NULL,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `pos_prn_style_col` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_prn_style_item`
--

DROP TABLE IF EXISTS `pos_prn_style_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_prn_style_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `style` bigint DEFAULT NULL COMMENT '样式',
  `idx` int DEFAULT NULL COMMENT '顺序',
  `type_` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型',
  `condition_` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '打印条件',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '打印内容',
  `align` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '对齐方式',
  `width` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '宽度设置',
  `bold` tinyint(1) DEFAULT NULL COMMENT '加粗',
  `w_size` int DEFAULT NULL COMMENT '字体宽度',
  `h_size` int DEFAULT NULL COMMENT '字体高度',
  `reverse` tinyint(1) DEFAULT NULL COMMENT '反显',
  `underline` tinyint(1) DEFAULT NULL COMMENT '下划线',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_style` (`style`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='打印单据样式内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_prn_style_item`
--

LOCK TABLES `pos_prn_style_item` WRITE;
/*!40000 ALTER TABLE `pos_prn_style_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_prn_style_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_prn_style_row`
--

DROP TABLE IF EXISTS `pos_prn_style_row`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_prn_style_row` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `ds_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '数据源编号',
  `style_type` int DEFAULT NULL COMMENT '单据类型',
  `show_index` int DEFAULT NULL COMMENT '显示顺序',
  `display_condition` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '显示条件',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `condition_ds_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '显示条件的数据源编号',
  `condition_operator` int DEFAULT NULL COMMENT '显示条件的操作符',
  `condition_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '显示条件的右值',
  `summarize` tinyint(1) DEFAULT NULL COMMENT '需要打印汇总',
  `summarize_col_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '汇总列的名字',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_sid` (`mid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33608 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='打印样式行';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_prn_style_row`
--

LOCK TABLES `pos_prn_style_row` WRITE;
/*!40000 ALTER TABLE `pos_prn_style_row` DISABLE KEYS */;
INSERT INTO `pos_prn_style_row` VALUES (33559,1940284000182472704,1942885905090105345,2043610013765341186,NULL,32,0,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33560,1940284000182472704,1942885905090105345,2043610013765341187,NULL,32,1,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33561,1940284000182472704,1942885905090105345,2043610013765341188,NULL,32,2,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,deptAmount',13,'0',NULL,NULL),(33562,1940284000182472704,1942885905090105345,2043610013765341189,NULL,32,3,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,deptAmount',13,'0',NULL,NULL),(33563,1940284000182472704,1942885905090105345,2043610013765341190,'dept_sum_info',32,4,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,deptAmount',13,'0',1,NULL),(33564,1940284000182472704,1942885905090105345,2043610013765341191,NULL,32,5,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,paidAmount',13,'0',NULL,NULL),(33565,1940284000182472704,1942885905090105345,2043610013765341192,NULL,32,6,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,paidAmount',13,'0',NULL,NULL),(33566,1940284000182472704,1942885905090105345,2043610013765341193,'paid_sum_info',32,7,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,paidAmount',13,'0',1,NULL),(33567,1940284000182472704,1942885905090105345,2043610013765341194,NULL,32,8,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,chargeAmount',13,'0',0,NULL),(33568,1940284000182472704,1942885905090105345,2043610013765341195,NULL,32,9,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,chargeAmount',13,'0',NULL,NULL),(33569,1940284000182472704,1942885905090105345,2043610013765341196,'charge_sum_info',32,10,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,chargeAmount',13,'0',1,NULL),(33570,1940284000182472704,1942885905090105345,2043610013765341197,NULL,32,11,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,creditAmount',13,'0',NULL,NULL),(33571,1940284000182472704,1942885905090105345,2043610013765341198,NULL,32,12,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,creditAmount',13,'0',NULL,NULL),(33572,1940284000182472704,1942885905090105345,2043610013765341199,'credit_sum_info',32,13,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,creditAmount',13,'0',1,NULL),(33573,1940284000182472704,1942885905090105345,2043610013765341200,NULL,32,14,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,couponAmount',13,'0',NULL,NULL),(33574,1940284000182472704,1942885905090105345,2043610013765341201,NULL,32,15,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,couponAmount',13,'0',NULL,NULL),(33575,1940284000182472704,1942885905090105345,2043610013765341202,'coupon_sum_info',32,16,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,couponAmount',13,'0',1,NULL),(33576,1940284000182472704,1942885905090105345,2043610013765341203,'coupon_platform_detail_info',32,17,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,couponAmount',13,'0',1,NULL),(33577,1940284000182472704,1942885905090105345,2043610013765341204,NULL,32,18,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,couponAmount',13,'0',NULL,NULL),(33578,1940284000182472704,1942885905090105345,2043610013765341205,NULL,32,19,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33579,1940284000182472704,1942885905090105345,2043610013765341206,NULL,32,20,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,serviceChargeAmount',16,'0',NULL,NULL),(33580,1940284000182472704,1942885905090105345,2043610013765341207,NULL,32,21,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,discountAmount',16,'0',NULL,NULL),(33581,1940284000182472704,1942885905090105345,2043610013765341208,NULL,32,22,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,fraction',16,'0',NULL,NULL),(33582,1940284000182472704,1942885905090105345,2043610013765341209,NULL,32,23,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,mantissa',16,'0',NULL,NULL),(33583,1940284000182472704,1942885905090105345,2043610013765341210,NULL,32,24,NULL,NULL,NULL,'2026-04-13 08:39:30',NULL,NULL,'date_sale_info,totalIncome',16,'0',NULL,NULL),(33584,1940284000182472704,1940287289892687874,2043897624044380162,NULL,32,0,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33585,1940284000182472704,1940287289892687874,2043897624044380163,NULL,32,1,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33586,1940284000182472704,1940287289892687874,2043897624044380164,NULL,32,2,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,deptAmount',13,'0',NULL,NULL),(33587,1940284000182472704,1940287289892687874,2043897624044380165,NULL,32,3,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,deptAmount',13,'0',NULL,NULL),(33588,1940284000182472704,1940287289892687874,2043897624044380166,'dept_sum_info',32,4,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,deptAmount',13,'0',1,NULL),(33589,1940284000182472704,1940287289892687874,2043897624044380167,NULL,32,5,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,paidAmount',13,'0',NULL,NULL),(33590,1940284000182472704,1940287289892687874,2043897624044380168,NULL,32,6,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,paidAmount',13,'0',NULL,NULL),(33591,1940284000182472704,1940287289892687874,2043897624044380169,'paid_sum_info',32,7,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,paidAmount',13,'0',1,NULL),(33592,1940284000182472704,1940287289892687874,2043897624044380170,NULL,32,8,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,chargeAmount',13,'0',0,NULL),(33593,1940284000182472704,1940287289892687874,2043897624044380171,NULL,32,9,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,chargeAmount',13,'0',NULL,NULL),(33594,1940284000182472704,1940287289892687874,2043897624044380172,'charge_sum_info',32,10,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,chargeAmount',13,'0',1,NULL),(33595,1940284000182472704,1940287289892687874,2043897624044380173,NULL,32,11,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,creditAmount',13,'0',NULL,NULL),(33596,1940284000182472704,1940287289892687874,2043897624044380174,NULL,32,12,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,creditAmount',13,'0',NULL,NULL),(33597,1940284000182472704,1940287289892687874,2043897624044380175,'credit_sum_info',32,13,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,creditAmount',13,'0',1,NULL),(33598,1940284000182472704,1940287289892687874,2043897624044380176,NULL,32,14,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,couponAmount',13,'0',NULL,NULL),(33599,1940284000182472704,1940287289892687874,2043897624044380177,NULL,32,15,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,couponAmount',13,'0',NULL,NULL),(33600,1940284000182472704,1940287289892687874,2043897624044380178,'coupon_platform_detail_info',32,16,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,couponAmount',13,'0',1,NULL),(33601,1940284000182472704,1940287289892687874,2043897624044380179,NULL,32,17,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,couponAmount',13,'0',NULL,NULL),(33602,1940284000182472704,1940287289892687874,2043897624044380180,NULL,32,18,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33603,1940284000182472704,1940287289892687874,2043897624044380181,NULL,32,19,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,serviceChargeAmount',16,'0',NULL,NULL),(33604,1940284000182472704,1940287289892687874,2043897624044380182,NULL,32,20,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,discountAmount',16,'0',NULL,NULL),(33605,1940284000182472704,1940287289892687874,2043897624044380183,NULL,32,21,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,fraction',16,'0',NULL,NULL),(33606,1940284000182472704,1940287289892687874,2043897624044380184,NULL,32,22,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,mantissa',16,'0',NULL,NULL),(33607,1940284000182472704,1940287289892687874,2043897624044380185,NULL,32,23,NULL,NULL,NULL,'2026-04-14 03:42:22',NULL,NULL,'date_sale_info,totalIncome',16,'0',NULL,NULL);
/*!40000 ALTER TABLE `pos_prn_style_row` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_promote_rule`
--

DROP TABLE IF EXISTS `pos_promote_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_promote_rule` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `sids` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '适用门店',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '促销名称',
  `enable` tinyint(1) DEFAULT NULL COMMENT '是否启用',
  `type_` int DEFAULT NULL COMMENT '折扣类型',
  `begin_date` datetime DEFAULT NULL COMMENT '开始日期',
  `end_date` datetime DEFAULT NULL COMMENT '结束日期',
  `monday` tinyint(1) DEFAULT NULL COMMENT '星期一',
  `tuesday` tinyint(1) DEFAULT NULL COMMENT '星期二',
  `wednesday` tinyint(1) DEFAULT NULL COMMENT '星期三',
  `thursday` tinyint(1) DEFAULT NULL COMMENT '星期四',
  `friday` tinyint(1) DEFAULT NULL COMMENT '星期五',
  `saturday` tinyint(1) DEFAULT NULL COMMENT '星期六',
  `sunday` tinyint(1) DEFAULT NULL COMMENT '星期日',
  `everyone` tinyint(1) DEFAULT NULL COMMENT '所有顾客可参与',
  `only_member` tinyint(1) DEFAULT NULL COMMENT '仅会员可参与',
  `only_part_type` tinyint(1) DEFAULT NULL COMMENT '指定会员可参与',
  `part_types` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '会员类型列表',
  `promote_foods` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '促销菜品',
  `same_day_limit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '当日限次',
  `rule_extend` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '规则扩展',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `review` tinyint(1) DEFAULT NULL COMMENT '审核',
  `review_at` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核时间',
  `review_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核人',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='促销方案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_promote_rule`
--

LOCK TABLES `pos_promote_rule` WRITE;
/*!40000 ALTER TABLE `pos_promote_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_promote_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_reason_type`
--

DROP TABLE IF EXISTS `pos_reason_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_reason_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `reason_type` int DEFAULT NULL COMMENT '原因类型',
  `reason_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '原因名称',
  `print_status` tinyint(1) DEFAULT NULL COMMENT '打印状态',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=531 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='退赠起菜原因';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_reason_type`
--

LOCK TABLES `pos_reason_type` WRITE;
/*!40000 ALTER TABLE `pos_reason_type` DISABLE KEYS */;
INSERT INTO `pos_reason_type` VALUES (527,1940284000182472704,1940287289892687874,2042805013583368194,2,'123',1,NULL,NULL,'2026-04-11 03:20:43',NULL,'2026-04-11 03:20:49',0),(528,1940284000182472704,1985597708115406849,2042805088552357889,2,'123',1,NULL,NULL,'2026-04-11 03:21:01',NULL,NULL,0),(529,1940284000182472704,1942885905090105345,2042808976101740546,2,'123',1,NULL,NULL,'2026-04-11 03:36:28',NULL,NULL,0),(530,1940284000182472704,1940287289892687874,2087838542882017282,1,'测试',NULL,NULL,NULL,'2026-08-13 17:47:53',NULL,NULL,0);
/*!40000 ALTER TABLE `pos_reason_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_tag_template`
--

DROP TABLE IF EXISTS `pos_tag_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_tag_template` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '模板名称',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '背景图片',
  `idx` int NOT NULL DEFAULT '0' COMMENT '模板顺序',
  `def` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否默认',
  `used` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否使用',
  `extra_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '附加信息',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='价签模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_tag_template`
--

LOCK TABLES `pos_tag_template` WRITE;
/*!40000 ALTER TABLE `pos_tag_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_tag_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_waiter_bill_setting`
--

DROP TABLE IF EXISTS `pos_waiter_bill_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pos_waiter_bill_setting` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `prn_dept` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '出品部门',
  `tbl_area` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '桌台区域',
  `prn_queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '打印队列',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='传菜联设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_waiter_bill_setting`
--

LOCK TABLES `pos_waiter_bill_setting` WRITE;
/*!40000 ALTER TABLE `pos_waiter_bill_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `pos_waiter_bill_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `print_job_type_switch`
--

DROP TABLE IF EXISTS `print_job_type_switch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `print_job_type_switch` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `type` int DEFAULT NULL COMMENT '打印任务类型',
  `disabled_kitchen` tinyint(1) DEFAULT NULL COMMENT '不打印档口联',
  `disabled_waiter` tinyint(1) DEFAULT NULL COMMENT '不打印传菜联',
  `disabled_customer` tinyint(1) DEFAULT NULL COMMENT '不打印顾客联',
  `num_of_kitchen` int DEFAULT NULL COMMENT '档口联打印份数',
  `num_of_waiter` int DEFAULT NULL COMMENT '传菜联打印份数',
  `num_of_customer` int DEFAULT NULL COMMENT '顾客联打印份数',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=420 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='打印任务开关';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `print_job_type_switch`
--

LOCK TABLES `print_job_type_switch` WRITE;
/*!40000 ALTER TABLE `print_job_type_switch` DISABLE KEYS */;
/*!40000 ALTER TABLE `print_job_type_switch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_dish_price_special`
--

DROP TABLE IF EXISTS `pt_dish_price_special`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_dish_price_special` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `type` int DEFAULT NULL COMMENT '价格类型',
  `dish_lid` bigint DEFAULT NULL COMMENT '菜品编号',
  `unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品单位',
  `price` decimal(24,6) DEFAULT NULL COMMENT '菜品价格',
  `out_type_no` bigint DEFAULT NULL COMMENT '关联编号',
  `festival` bigint DEFAULT NULL COMMENT '节日编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `ldx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='菜品特殊价格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_dish_price_special`
--

LOCK TABLES `pt_dish_price_special` WRITE;
/*!40000 ALTER TABLE `pt_dish_price_special` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_dish_price_special` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_festival`
--

DROP TABLE IF EXISTS `pt_festival`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_festival` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `state` bigint DEFAULT NULL COMMENT '启用状态',
  `day_of_the_week` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '星期几',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='节日';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_festival`
--

LOCK TABLES `pt_festival` WRITE;
/*!40000 ALTER TABLE `pt_festival` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_festival` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_check_template`
--

DROP TABLE IF EXISTS `sc_check_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_check_template` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '盘点模板名称',
  `rows_` int NOT NULL COMMENT '物品数量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='盘点模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_check_template`
--

LOCK TABLES `sc_check_template` WRITE;
/*!40000 ALTER TABLE `sc_check_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_check_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_check_template_item`
--

DROP TABLE IF EXISTS `sc_check_template_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_check_template_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `template_lid` bigint NOT NULL COMMENT '模板lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `goods_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '物品编号',
  `goods_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '物品名称',
  `volume` decimal(24,6) DEFAULT NULL COMMENT '标准数量',
  `counting_volume` decimal(24,6) DEFAULT NULL COMMENT '计量数量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_template_lid` (`mid`,`template_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='盘点模板物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_check_template_item`
--

LOCK TABLES `sc_check_template_item` WRITE;
/*!40000 ALTER TABLE `sc_check_template_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_check_template_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `takeout_aggregation_platform_channel`
--

DROP TABLE IF EXISTS `takeout_aggregation_platform_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `takeout_aggregation_platform_channel` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `channel_type` int DEFAULT NULL COMMENT '通道类型',
  `channel_merchant_no` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '在通道中的商户号',
  `channel_store_code` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '在通道中的门店号',
  `channel_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '通道信息',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `terminal_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '终端号',
  `terminal_token` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '终端密钥',
  `disable` tinyint(1) DEFAULT NULL COMMENT '禁用',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_channel_store_code` (`channel_store_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='外卖聚合平台通道';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `takeout_aggregation_platform_channel`
--

LOCK TABLES `takeout_aggregation_platform_channel` WRITE;
/*!40000 ALTER TABLE `takeout_aggregation_platform_channel` DISABLE KEYS */;
INSERT INTO `takeout_aggregation_platform_channel` VALUES (27,1940284000182472704,1940287289892687874,2041361095630786562,2,'222','222',NULL,NULL,NULL,'2026-04-07 03:43:06',NULL,NULL,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `takeout_aggregation_platform_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `takeout_food_map`
--

DROP TABLE IF EXISTS `takeout_food_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `takeout_food_map` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `channel_type` int DEFAULT NULL COMMENT '渠道类型',
  `food_id_in_channel` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '渠道菜品编号',
  `platform_spu_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '外卖平台SPU ID',
  `has_picture` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否有图片',
  `food_unit_in_channel` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '渠道菜品单位',
  `food_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜品名称',
  `food_id_in_nms` bigint DEFAULT NULL COMMENT '我们系统的菜品编号',
  `food_unit_in_nms` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '我们系统的菜品单位',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `food_code_in_nms` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '我们系统的菜品编号',
  `attr_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '属性名称',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `disable` tinyint(1) DEFAULT NULL COMMENT '禁用',
  `spu` tinyint(1) DEFAULT NULL COMMENT '是否SPU',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=43309 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='外卖菜品映射表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `takeout_food_map`
--

LOCK TABLES `takeout_food_map` WRITE;
/*!40000 ALTER TABLE `takeout_food_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `takeout_food_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'a_pos'
--

--
-- Dumping routines for database 'a_pos'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-13 10:48:02
