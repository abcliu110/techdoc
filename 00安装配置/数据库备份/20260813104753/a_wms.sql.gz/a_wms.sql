-- MySQL dump 10.13  Distrib 8.4.7, for Linux (x86_64)
--
-- Host: localhost    Database: a_wms
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `a_wms`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `a_wms` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `a_wms`;

--
-- Table structure for table `order_item_depart_relate`
--

DROP TABLE IF EXISTS `order_item_depart_relate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_item_depart_relate` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `type_` int NOT NULL DEFAULT '1' COMMENT '订货单类型',
  `volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '数量',
  `item_lid` bigint NOT NULL COMMENT '物品lid',
  `order_lid` bigint NOT NULL COMMENT '订单lid',
  `depart_lid` bigint NOT NULL COMMENT '部门lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `report_date` datetime DEFAULT NULL COMMENT '订货日期',
  `supplier_lid` bigint DEFAULT NULL COMMENT '供应商lid',
  `goods_lid` bigint DEFAULT NULL COMMENT '物品lid',
  `delivery_type` int DEFAULT NULL COMMENT '配送方式',
  `order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '订单id',
  `order_state` int DEFAULT NULL COMMENT '单据状态',
  `org_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '原订货数量（标准单位）',
  `inspect_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '验货数量',
  `amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '金额',
  `org_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '原金额',
  `inspect_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '验货金额',
  `inspect` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否验货',
  `counting_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '计量数量',
  `inbound_lid` bigint DEFAULT NULL COMMENT '入库单lid',
  `inbound_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '入库单id',
  `scarce` tinyint(1) DEFAULT '0' COMMENT '缺货',
  `reject` tinyint(1) DEFAULT '0' COMMENT '拒收',
  `reject_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '拒收人',
  `reject_at` datetime DEFAULT NULL COMMENT '拒收时间',
  `reject_for` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '拒收原因',
  `cancel` tinyint(1) DEFAULT '0' COMMENT '取消',
  `cancel_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '取消人',
  `cancel_at` datetime DEFAULT NULL COMMENT '取消时间',
  `cancel_for` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '取消原因',
  `refund_state` int DEFAULT '0' COMMENT '退货状态',
  `refund_volume` decimal(24,6) DEFAULT NULL COMMENT '退货数量',
  `refund_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退货人',
  `refund_at` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退货时间',
  `refund_for` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退货原因',
  `refund_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退货单号',
  `inspect_indent_volume` decimal(24,6) DEFAULT NULL COMMENT '订购验货数量',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_item_lid` (`mid`,`item_lid`) USING BTREE,
  KEY `idx_mid_order_lid` (`mid`,`order_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=116391 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='订货单物品与部门关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item_depart_relate`
--

LOCK TABLES `order_item_depart_relate` WRITE;
/*!40000 ALTER TABLE `order_item_depart_relate` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_item_depart_relate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_assist_cost`
--

DROP TABLE IF EXISTS `sc_assist_cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_assist_cost` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '名称',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='辅助成本定义';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_assist_cost`
--

LOCK TABLES `sc_assist_cost` WRITE;
/*!40000 ALTER TABLE `sc_assist_cost` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_assist_cost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_auto_deduct_task`
--

DROP TABLE IF EXISTS `sc_auto_deduct_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_auto_deduct_task` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `warehouse_lid` bigint NOT NULL COMMENT '扣减仓库lid',
  `st_bill_lid` bigint NOT NULL COMMENT '库存单据lid',
  `st_bill_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '库存单据id',
  `volume` decimal(24,6) DEFAULT NULL COMMENT '扣减数量',
  `amount` decimal(24,6) DEFAULT NULL COMMENT '扣减金额',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `source_type` int DEFAULT '0' COMMENT '来源类型',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid_report_date_bill_lid` (`mid`,`sid`,`report_date`,`st_bill_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=526 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='自动扣减记录（用于反扣减冲红）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_auto_deduct_task`
--

LOCK TABLES `sc_auto_deduct_task` WRITE;
/*!40000 ALTER TABLE `sc_auto_deduct_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_auto_deduct_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_bill_invoice_order`
--

DROP TABLE IF EXISTS `sc_bill_invoice_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_bill_invoice_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '记账日期',
  `amount` decimal(24,6) NOT NULL COMMENT '金额',
  `supplier_lid` bigint NOT NULL COMMENT '供应商lid',
  `organ_lid` bigint NOT NULL COMMENT '组织lid',
  `invoice_type` int NOT NULL COMMENT '发票类型',
  `invoice_no` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '发票号码',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发票备注',
  `cancel_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '取消人',
  `cancel_lid` bigint DEFAULT NULL COMMENT '取消人lid',
  `cancel_time` datetime DEFAULT NULL COMMENT '取消时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `settle_type` int NOT NULL DEFAULT '1' COMMENT '结算类型',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_supplier_lid` (`mid`,`supplier_lid`) USING BTREE,
  KEY `idx_mid_organ_lid` (`mid`,`organ_lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='单据发票记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_bill_invoice_order`
--

LOCK TABLES `sc_bill_invoice_order` WRITE;
/*!40000 ALTER TABLE `sc_bill_invoice_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_bill_invoice_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_bill_invoice_ref`
--

DROP TABLE IF EXISTS `sc_bill_invoice_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_bill_invoice_ref` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '记账日期',
  `invoice_order_lid` bigint NOT NULL COMMENT '发票记录lid',
  `st_bill_lid` bigint NOT NULL COMMENT '仓库单据lid',
  `st_bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '仓库单据id',
  `supplier_lid` bigint NOT NULL COMMENT '供应商lid',
  `organ_lid` bigint NOT NULL COMMENT '组织lid',
  `amount` decimal(24,6) NOT NULL COMMENT '发票金额',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_lid` (`mid`,`invoice_order_lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='发票记录与单据关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_bill_invoice_ref`
--

LOCK TABLES `sc_bill_invoice_ref` WRITE;
/*!40000 ALTER TABLE `sc_bill_invoice_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_bill_invoice_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_bill_pay_item`
--

DROP TABLE IF EXISTS `sc_bill_pay_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_bill_pay_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '付款日期',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '付款名称',
  `supplier_lid` bigint NOT NULL COMMENT '供应商lid',
  `organ_lid` bigint NOT NULL COMMENT '组织lid',
  `st_bill_lid` bigint NOT NULL COMMENT '仓库单据lid',
  `st_bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '仓库单据id',
  `type_` int NOT NULL COMMENT '付款类型',
  `amount` decimal(24,6) NOT NULL COMMENT '核销金额',
  `balance_before` decimal(24,6) NOT NULL COMMENT '核销前金额',
  `balance_after` decimal(24,6) NOT NULL COMMENT '核销后金额',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '付款备注',
  `cancel_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '取消人',
  `cancel_lid` bigint DEFAULT NULL COMMENT '取消人lid',
  `cancel_time` datetime DEFAULT NULL COMMENT '取消时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `bill_type` int NOT NULL DEFAULT '1' COMMENT '单据类型',
  `settle_type` int NOT NULL DEFAULT '1' COMMENT '结算类型',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_bill_lid` (`mid`,`st_bill_lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='单据付款记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_bill_pay_item`
--

LOCK TABLES `sc_bill_pay_item` WRITE;
/*!40000 ALTER TABLE `sc_bill_pay_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_bill_pay_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_bill_stock`
--

DROP TABLE IF EXISTS `sc_bill_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_bill_stock` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year_` int NOT NULL COMMENT '年',
  `month_` int NOT NULL COMMENT '月',
  `day_` int NOT NULL COMMENT '日',
  `bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '账单编号',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `volume` decimal(24,6) NOT NULL COMMENT '扣减数量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `volume_for_counter` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '扣减计数数量',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid_bill_id` (`mid`,`sid`,`bill_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=38894 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='账单库存预扣减';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_bill_stock`
--

LOCK TABLES `sc_bill_stock` WRITE;
/*!40000 ALTER TABLE `sc_bill_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_bill_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_check_prohibit`
--

DROP TABLE IF EXISTS `sc_check_prohibit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_check_prohibit` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_goods_lid` (`mid`,`goods_lid`) USING BTREE,
  KEY `idx_mid_warehouse_lid` (`mid`,`warehouse_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='盘点禁用物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_check_prohibit`
--

LOCK TABLES `sc_check_prohibit` WRITE;
/*!40000 ALTER TABLE `sc_check_prohibit` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_check_prohibit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_check_template`
--

DROP TABLE IF EXISTS `sc_check_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_check_template` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '盘点模板名称',
  `rows_` int NOT NULL COMMENT '物品数量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='盘点模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_check_template`
--

LOCK TABLES `sc_check_template` WRITE;
/*!40000 ALTER TABLE `sc_check_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_check_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_check_template_item`
--

DROP TABLE IF EXISTS `sc_check_template_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_check_template_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `template_lid` bigint NOT NULL COMMENT '模板lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `goods_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '物品编号',
  `goods_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '物品名称',
  `volume` decimal(24,6) DEFAULT NULL COMMENT '标准数量',
  `counting_volume` decimal(24,6) DEFAULT NULL COMMENT '计量数量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_template_lid` (`mid`,`template_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=708 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='盘点模板物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_check_template_item`
--

LOCK TABLES `sc_check_template_item` WRITE;
/*!40000 ALTER TABLE `sc_check_template_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_check_template_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_deduct_day`
--

DROP TABLE IF EXISTS `sc_deduct_day`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_deduct_day` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '日期',
  `deducted` tinyint(1) NOT NULL COMMENT '是否扣减',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid` (`mid`,`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=312 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='有未扣减记录天数';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_deduct_day`
--

LOCK TABLES `sc_deduct_day` WRITE;
/*!40000 ALTER TABLE `sc_deduct_day` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_deduct_day` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_deduct_goods`
--

DROP TABLE IF EXISTS `sc_deduct_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_deduct_goods` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `shop_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '门店名称',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year_` int NOT NULL COMMENT '年',
  `month_` int NOT NULL COMMENT '月',
  `day_` int NOT NULL COMMENT '日',
  `st_bill_lid` bigint NOT NULL COMMENT '库存单据lid',
  `st_bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '库存单据id',
  `bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '账单编号',
  `profit_lid` bigint NOT NULL COMMENT '毛利表lid,保留字段',
  `organ_lid` bigint DEFAULT NULL COMMENT '扣减组织',
  `organ_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '扣减组织名称',
  `tbl_area_lid` bigint DEFAULT NULL COMMENT '区域lid',
  `tbl_area_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区域编号',
  `tbl_area_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区域名称',
  `product_lid` bigint NOT NULL COMMENT '商品lid',
  `product_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '商品编号',
  `product_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品名称',
  `product_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '商品单位',
  `product_idx` int NOT NULL COMMENT '商品索引',
  `product_volume` decimal(24,6) NOT NULL DEFAULT '1.000000' COMMENT '商品数量',
  `product_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '商品金额',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `goods_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '物品名称',
  `goods_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '物品单位',
  `standard_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标准单位',
  `goods_unit_lid` bigint NOT NULL COMMENT '物品单位lid',
  `theory_volume` decimal(24,6) DEFAULT '0.000000' COMMENT '理论用量',
  `actual_volume` decimal(24,6) DEFAULT '0.000000' COMMENT '实际用量',
  `counting_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '计量数量',
  `diff_volume` decimal(24,6) DEFAULT '0.000000' COMMENT '用量差异',
  `theory_cost` decimal(24,6) DEFAULT '0.000000' COMMENT '理论成本',
  `actual_cost` decimal(24,6) DEFAULT '0.000000' COMMENT '实际成本',
  `wastage_cost` decimal(24,6) DEFAULT '0.000000' COMMENT '耗损成本',
  `diff_cost` decimal(24,6) DEFAULT '0.000000' COMMENT '成本差异',
  `net_rate` decimal(24,6) DEFAULT NULL COMMENT '出净率',
  `net_weight` decimal(24,6) DEFAULT NULL COMMENT '净料重量',
  `yield_rate` decimal(24,6) DEFAULT NULL COMMENT '出成率',
  `cooked_weight` decimal(24,6) DEFAULT NULL COMMENT '熟菜重量',
  `unit_type` int DEFAULT NULL COMMENT '扣库单位类型',
  `small_type_lid` bigint DEFAULT NULL COMMENT '商品小类lid',
  `small_type` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品小类名称',
  `super_type_lid` bigint DEFAULT NULL COMMENT '商品大类lid',
  `super_type` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品大类名称',
  `source_type` int DEFAULT NULL COMMENT '来源类型',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE,
  KEY `idx_mid_profit_lid` (`mid`,`profit_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='单据商品扣库详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_deduct_goods`
--

LOCK TABLES `sc_deduct_goods` WRITE;
/*!40000 ALTER TABLE `sc_deduct_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_deduct_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_deduct_product`
--

DROP TABLE IF EXISTS `sc_deduct_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_deduct_product` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year_` int NOT NULL COMMENT '年',
  `month_` int NOT NULL COMMENT '月',
  `day_` int NOT NULL COMMENT '日',
  `st_bill_lid` bigint NOT NULL COMMENT '库存单据lid',
  `st_bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '库存单据id',
  `bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '账单编号',
  `organ_lid` bigint DEFAULT NULL COMMENT '扣减组织',
  `organ_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '扣减组织名称',
  `tbl_area_lid` bigint DEFAULT NULL COMMENT '区域lid',
  `tbl_area_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '区域编号',
  `tbl_area_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '区域名称',
  `product_lid` bigint NOT NULL COMMENT '商品lid',
  `product_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品编号',
  `product_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '商品名称',
  `product_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品单位',
  `product_idx` int NOT NULL COMMENT '商品索引',
  `product_volume` decimal(24,6) NOT NULL DEFAULT '1.000000' COMMENT '商品数量',
  `product_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '商品金额',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `source_type` int DEFAULT '0' COMMENT '来源类型',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_st_bill_lid` (`st_bill_lid`) USING BTREE,
  KEY `idx_mid_sid_bill_id` (`mid`,`sid`,`bill_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7272 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='单据商品扣减记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_deduct_product`
--

LOCK TABLES `sc_deduct_product` WRITE;
/*!40000 ALTER TABLE `sc_deduct_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_deduct_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_deduct_rule`
--

DROP TABLE IF EXISTS `sc_deduct_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_deduct_rule` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `relate_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品/小类/大类的id',
  `relate_lid` bigint NOT NULL COMMENT '商品/小类/大类的lid',
  `tbl_area_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '台区id',
  `tbl_area_lid` bigint NOT NULL COMMENT '台区lid',
  `organ_lid` bigint NOT NULL COMMENT '要扣减的组织lid',
  `type` int NOT NULL DEFAULT '1' COMMENT '类型，1 商品 2小类 3 大类',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_relate_lid` (`mid`,`relate_lid`) USING BTREE,
  KEY `idx_mid_tbl_area_lid` (`mid`,`tbl_area_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=582 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品扣减规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_deduct_rule`
--

LOCK TABLES `sc_deduct_rule` WRITE;
/*!40000 ALTER TABLE `sc_deduct_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_deduct_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_delivery_order`
--

DROP TABLE IF EXISTS `sc_delivery_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_delivery_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单据编号',
  `report_date` datetime NOT NULL COMMENT '报价日期',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `is_suit_all` tinyint(1) NOT NULL DEFAULT '1' COMMENT '全统一/部分例外',
  `quote_state` int NOT NULL COMMENT '报价状态',
  `audit_lid` bigint DEFAULT NULL COMMENT '审核人lid',
  `audit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核人',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `release_lid` bigint DEFAULT NULL COMMENT '发布人lid',
  `release_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发布人',
  `release_time` datetime DEFAULT NULL COMMENT '发布时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='配送报价单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_delivery_order`
--

LOCK TABLES `sc_delivery_order` WRITE;
/*!40000 ALTER TABLE `sc_delivery_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_delivery_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_delivery_order_item`
--

DROP TABLE IF EXISTS `sc_delivery_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_delivery_order_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '报价日期',
  `quote_order_lid` bigint NOT NULL COMMENT '报价单lid',
  `goods_type_lid` bigint NOT NULL COMMENT '物品类别lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `price` decimal(24,6) NOT NULL COMMENT '报价',
  `added_tax_type` int NOT NULL COMMENT '采购税率',
  `last_price` decimal(24,6) DEFAULT NULL COMMENT '上期价格',
  `last_order_price` decimal(24,6) DEFAULT NULL COMMENT '最近一次进货价',
  `begin_date` datetime NOT NULL COMMENT '价格生效日期',
  `end_date` datetime NOT NULL COMMENT '价格失效日期',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_quote_lid` (`mid`,`quote_order_lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3715 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='配送报价物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_delivery_order_item`
--

LOCK TABLES `sc_delivery_order_item` WRITE;
/*!40000 ALTER TABLE `sc_delivery_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_delivery_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_delivery_order_store`
--

DROP TABLE IF EXISTS `sc_delivery_order_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_delivery_order_store` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '适用门店sid',
  `report_date` datetime NOT NULL COMMENT '报价日期',
  `quote_order_lid` bigint NOT NULL COMMENT '报价单lid',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_quote_lid` (`mid`,`quote_order_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='配送报价单适用组织';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_delivery_order_store`
--

LOCK TABLES `sc_delivery_order_store` WRITE;
/*!40000 ALTER TABLE `sc_delivery_order_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_delivery_order_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_delivery_quote`
--

DROP TABLE IF EXISTS `sc_delivery_quote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_delivery_quote` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `quote_order_lid` bigint NOT NULL COMMENT '报价单lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `goods_type_lid` bigint NOT NULL COMMENT '物品类别lid',
  `price` decimal(24,6) NOT NULL COMMENT '售价/加价/比例系数',
  `last_order_price` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '0' COMMENT '上次进货单价',
  `final_price` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '最终价格',
  `added_tax_type` int NOT NULL COMMENT '采购税率',
  `incr_type` int NOT NULL COMMENT '加价方式',
  `is_suit_all` tinyint(1) NOT NULL COMMENT '是否统一',
  `begin_date` datetime NOT NULL COMMENT '价格生效日期',
  `end_date` datetime NOT NULL COMMENT '价格失效日期',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_goods_lid_sid` (`mid`,`goods_lid`,`sid`) USING BTREE,
  KEY `idx_mid_created_time` (`mid`,`created_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27258 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='配送协议价';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_delivery_quote`
--

LOCK TABLES `sc_delivery_quote` WRITE;
/*!40000 ALTER TABLE `sc_delivery_quote` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_delivery_quote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_delivery_rule`
--

DROP TABLE IF EXISTS `sc_delivery_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_delivery_rule` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '适用门店lid',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `delivery_type` int NOT NULL COMMENT '配送方式',
  `supplier_lid` bigint NOT NULL COMMENT '供应商lid',
  `def_supplier_lid` bigint DEFAULT NULL COMMENT '默认供应商lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `price` decimal(24,6) NOT NULL COMMENT '采购价格',
  `added_tax_type` int NOT NULL COMMENT '采购税率',
  `begin_date` datetime NOT NULL COMMENT '价格生效日期',
  `end_date` datetime NOT NULL COMMENT '价格失效日期',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_goods_lid` (`mid`,`goods_lid`) USING BTREE,
  KEY `idx_mid_supplier_lid` (`mid`,`supplier_lid`) USING BTREE,
  KEY `idx_mid_sid` (`mid`,`sid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=346097 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='配送规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_delivery_rule`
--

LOCK TABLES `sc_delivery_rule` WRITE;
/*!40000 ALTER TABLE `sc_delivery_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_delivery_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_depart_order`
--

DROP TABLE IF EXISTS `sc_depart_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_depart_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '订单编号',
  `store_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '门店订货单编号',
  `store_order_lid` bigint DEFAULT NULL COMMENT '门店订货单lid',
  `report_date` datetime NOT NULL COMMENT '订货日期',
  `organ_lid` bigint NOT NULL COMMENT '机构lid',
  `order_type` int NOT NULL COMMENT '订货单类型',
  `order_state` int NOT NULL COMMENT '订单状态',
  `rows` int NOT NULL COMMENT '记录数',
  `volume` decimal(24,6) NOT NULL COMMENT '总数量',
  `tax_amount` decimal(24,6) NOT NULL COMMENT '含税金额',
  `amount` decimal(24,6) NOT NULL COMMENT '总金额',
  `indent_volume` decimal(24,6) NOT NULL COMMENT '订购数量',
  `audit_lid` bigint DEFAULT NULL COMMENT '审核人lid',
  `audit_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核人',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `reject_lid` bigint DEFAULT NULL COMMENT '驳回人lid',
  `reject_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '驳回人',
  `reject_time` datetime DEFAULT NULL COMMENT '驳回时间',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date_org_lid` (`mid`,`report_date`,`organ_lid`) USING BTREE,
  KEY `idx_mid_report_date_store_order_lid` (`mid`,`report_date`,`store_order_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1934 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='档口订货单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_depart_order`
--

LOCK TABLES `sc_depart_order` WRITE;
/*!40000 ALTER TABLE `sc_depart_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_depart_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_depart_order_item`
--

DROP TABLE IF EXISTS `sc_depart_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_depart_order_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '订货日期',
  `depart_order_lid` bigint NOT NULL COMMENT '档口订货单lid',
  `depart_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '档口订货单编号',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `supplier_lid` bigint NOT NULL COMMENT '供货商lid',
  `organ_lid` bigint NOT NULL COMMENT '机构lid',
  `volume` decimal(24,6) NOT NULL COMMENT '标准数量',
  `indent_volume` decimal(24,6) NOT NULL COMMENT '订购数量',
  `price` decimal(24,6) NOT NULL COMMENT '订购价格',
  `amount` decimal(24,6) NOT NULL COMMENT '订购总额',
  `tax_rate` decimal(24,6) NOT NULL COMMENT '税率',
  `arrival_time` datetime NOT NULL COMMENT '到货日期',
  `delivery_type` int NOT NULL COMMENT '配送方式',
  `order_type` int NOT NULL COMMENT '订货单类型',
  `order_state` int NOT NULL COMMENT '订单状态',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date_depart_order_lid` (`mid`,`report_date`,`depart_order_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=84178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='档口订货物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_depart_order_item`
--

LOCK TABLES `sc_depart_order_item` WRITE;
/*!40000 ALTER TABLE `sc_depart_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_depart_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_goods`
--

DROP TABLE IF EXISTS `sc_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_goods` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物品编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物品名称',
  `enable` tinyint(1) DEFAULT NULL COMMENT '启用/禁用',
  `goods_type_lid` bigint NOT NULL COMMENT '物品类型lid',
  `mnemonic_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '助记码',
  `standards` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '物品规格',
  `reference_price` decimal(24,6) DEFAULT NULL COMMENT '参考价',
  `subject_type` int DEFAULT NULL COMMENT '统计科目',
  `check_in_type` int DEFAULT NULL COMMENT '盘点频率',
  `indent` tinyint(1) DEFAULT NULL COMMENT '可订货',
  `min_indent` decimal(24,6) DEFAULT NULL COMMENT '最小订购量',
  `single_indent` decimal(24,6) DEFAULT NULL COMMENT '单次订购量',
  `refund` tinyint(1) DEFAULT NULL COMMENT '可退货',
  `inbound` tinyint(1) DEFAULT NULL COMMENT '可入库',
  `min_indent_multiple` decimal(24,6) DEFAULT NULL COMMENT '最小订货单位倍数',
  `check_in_order` tinyint(1) DEFAULT NULL COMMENT '订货校验库存',
  `safety_upper` decimal(24,6) DEFAULT NULL COMMENT '安全库存上限',
  `safety_lower` decimal(24,6) DEFAULT NULL COMMENT '安全库存下限',
  `mandatory` tinyint(1) DEFAULT NULL COMMENT '必订物品',
  `weight` tinyint(1) DEFAULT NULL COMMENT '称重物品',
  `loss_rate` decimal(24,6) DEFAULT NULL COMMENT '损耗率',
  `expiry` tinyint(1) DEFAULT NULL COMMENT '保质期',
  `expiry_day` int DEFAULT NULL COMMENT '保质期（天）',
  `reminder_day` int DEFAULT NULL COMMENT '提前提醒天数',
  `in_expiry_day` int DEFAULT NULL COMMENT '入库保质期临期天数',
  `out_expiry_day` int DEFAULT NULL COMMENT '出库保质期临期天数',
  `batch_manage` tinyint(1) DEFAULT NULL COMMENT '批次管理',
  `expend` tinyint(1) DEFAULT NULL COMMENT '入库即耗用',
  `sn_manage` tinyint(1) DEFAULT NULL COMMENT 'SN码管理',
  `inspect_type` int DEFAULT NULL COMMENT '验货比率',
  `tax_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '税收分类编码',
  `tax_type` int DEFAULT NULL COMMENT '税率',
  `label_lid` bigint DEFAULT NULL COMMENT '标签lid',
  `producer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产地',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `storage_factor` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '储存条件',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `is_suit_all` tinyint(1) NOT NULL COMMENT '适用所有店铺',
  `shelve` tinyint(1) NOT NULL DEFAULT '1' COMMENT '上/下架',
  `indent_decimal` tinyint(1) NOT NULL DEFAULT '1' COMMENT '订货允许小数',
  `last_order_price` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '最近订货价',
  `pinyin` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '拼音',
  `last_price_date` datetime DEFAULT NULL COMMENT '最后一次价格订单日期',
  `indent_by_counting` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_id` (`mid`,`id`) USING BTREE,
  KEY `idx_mid_name` (`mid`,`name`) USING BTREE,
  KEY `idx_mid_good_type_lid` (`mid`,`goods_type_lid`) USING BTREE,
  KEY `idx_mid_label_lid` (`mid`,`label_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=72073 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_goods`
--

LOCK TABLES `sc_goods` WRITE;
/*!40000 ALTER TABLE `sc_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_goods_img`
--

DROP TABLE IF EXISTS `sc_goods_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_goods_img` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `img_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物品图片地址',
  `goods_lid` bigint NOT NULL COMMENT '物品Lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_goods_lid` (`mid`,`goods_lid`) USING BTREE,
  KEY `idx_goods_lid` (`goods_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=776 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品与图片关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_goods_img`
--

LOCK TABLES `sc_goods_img` WRITE;
/*!40000 ALTER TABLE `sc_goods_img` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_goods_img` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_goods_in_warehouse`
--

DROP TABLE IF EXISTS `sc_goods_in_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_goods_in_warehouse` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库lid',
  `price` decimal(24,6) NOT NULL COMMENT '库存价格',
  `volume` decimal(24,6) NOT NULL COMMENT '当前数量',
  `amount` decimal(24,6) NOT NULL COMMENT '当前金额',
  `unit_lid` bigint NOT NULL COMMENT '单位lid',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '单位',
  `bill_lid` bigint NOT NULL COMMENT '单据lid',
  `item_lid` bigint NOT NULL COMMENT '物品的lid',
  `last_stock_time` datetime NOT NULL COMMENT '入库时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `volume_for_counting` decimal(24,6) DEFAULT NULL COMMENT '当前数量',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_goods_lid` (`mid`,`goods_lid`) USING BTREE,
  KEY `idx_mid_warehouse_lid` (`mid`,`warehouse_lid`) USING BTREE,
  KEY `idx_mid_item_lid` (`mid`,`item_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=405708 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品仓库库存';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_goods_in_warehouse`
--

LOCK TABLES `sc_goods_in_warehouse` WRITE;
/*!40000 ALTER TABLE `sc_goods_in_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_goods_in_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_goods_store`
--

DROP TABLE IF EXISTS `sc_goods_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_goods_store` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `store_lid` bigint NOT NULL COMMENT '门店sid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_store_lid` (`mid`,`store_lid`) USING BTREE,
  KEY `idx_mid_goods_lid` (`mid`,`goods_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=606 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品门店关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_goods_store`
--

LOCK TABLES `sc_goods_store` WRITE;
/*!40000 ALTER TABLE `sc_goods_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_goods_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_goods_type`
--

DROP TABLE IF EXISTS `sc_goods_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_goods_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '编码',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '名称',
  `parent_lid` bigint DEFAULT NULL COMMENT '上一级',
  `level` int NOT NULL COMMENT '层级',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE,
  KEY `idx_mid_id` (`mid`,`id`) USING BTREE,
  KEY `idx_mid_name` (`mid`,`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1702 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_goods_type`
--

LOCK TABLES `sc_goods_type` WRITE;
/*!40000 ALTER TABLE `sc_goods_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_goods_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_goods_unit`
--

DROP TABLE IF EXISTS `sc_goods_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_goods_unit` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单位名称',
  `goods_lid` bigint NOT NULL COMMENT '物品Lid',
  `unit_lid` bigint DEFAULT NULL COMMENT '单位lid(备用)',
  `type_` int NOT NULL COMMENT '单位类型',
  `bar_code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '条码',
  `org_ratio` decimal(24,6) NOT NULL COMMENT '标准单位数量',
  `ratio` decimal(24,6) NOT NULL COMMENT '当前单位数量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `for_counting` tinyint(1) DEFAULT NULL COMMENT '用于计数',
  `generate` tinyint(1) DEFAULT '0' COMMENT '已产生单据',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_name` (`mid`,`name`) USING BTREE,
  KEY `idx_mid_goods_lid` (`mid`,`goods_lid`) USING BTREE,
  KEY `idx_mid_unit_lid` (`mid`,`unit_lid`) USING BTREE,
  KEY `idx_mid_barcode` (`mid`,`bar_code`) USING BTREE,
  KEY `idx_goods_lid` (`goods_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=363557 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品单位';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_goods_unit`
--

LOCK TABLES `sc_goods_unit` WRITE;
/*!40000 ALTER TABLE `sc_goods_unit` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_goods_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_history_order`
--

DROP TABLE IF EXISTS `sc_history_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_history_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `uid` bigint NOT NULL COMMENT '用户编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '订单编号',
  `report_date` datetime NOT NULL COMMENT '订货日期',
  `organ_lid` bigint NOT NULL COMMENT '机构lid',
  `order_type` int NOT NULL COMMENT '订货单类型',
  `rows` int NOT NULL COMMENT '记录数',
  `volume` decimal(24,6) NOT NULL COMMENT '总数量',
  `amount` decimal(24,6) NOT NULL COMMENT '总金额',
  `tax_amount` decimal(24,6) NOT NULL COMMENT '含税金额',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_uid` (`mid`,`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4534 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='最后一次订单记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_history_order`
--

LOCK TABLES `sc_history_order` WRITE;
/*!40000 ALTER TABLE `sc_history_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_history_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_history_order_item`
--

DROP TABLE IF EXISTS `sc_history_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_history_order_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `uid` bigint NOT NULL COMMENT '用户编号',
  `report_date` datetime NOT NULL COMMENT '订货日期',
  `history_order_lid` bigint NOT NULL COMMENT '订单lid',
  `history_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '订单编号',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `supplier_lid` bigint NOT NULL COMMENT '供货商lid',
  `organ_lid` bigint NOT NULL COMMENT '机构lid',
  `volume` decimal(24,6) NOT NULL COMMENT '订购数量',
  `price` decimal(24,6) NOT NULL COMMENT '订购价格',
  `amount` decimal(24,6) NOT NULL COMMENT '订购总额',
  `tax_rate` decimal(24,6) NOT NULL COMMENT '税率',
  `arrival_time` datetime NOT NULL COMMENT '到货日期',
  `delivery_type` int NOT NULL COMMENT '配送方式',
  `order_type` int NOT NULL COMMENT '订货单类型',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_lid` (`mid`,`history_order_lid`) USING BTREE,
  KEY `idx_mid_uid` (`mid`,`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=95678 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='最后一次订单物品记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_history_order_item`
--

LOCK TABLES `sc_history_order_item` WRITE;
/*!40000 ALTER TABLE `sc_history_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_history_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_history_remark`
--

DROP TABLE IF EXISTS `sc_history_remark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_history_remark` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `uid` bigint NOT NULL COMMENT '用户lid',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_uid` (`mid`,`uid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='历史备注';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_history_remark`
--

LOCK TABLES `sc_history_remark` WRITE;
/*!40000 ALTER TABLE `sc_history_remark` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_history_remark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_invoice_attachment`
--

DROP TABLE IF EXISTS `sc_invoice_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_invoice_attachment` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '记账日期',
  `invoice_order_lid` bigint NOT NULL COMMENT '发票记录lid',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '附件地址',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_lid` (`mid`,`invoice_order_lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='发票附件列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_invoice_attachment`
--

LOCK TABLES `sc_invoice_attachment` WRITE;
/*!40000 ALTER TABLE `sc_invoice_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_invoice_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_item_attachment`
--

DROP TABLE IF EXISTS `sc_item_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_item_attachment` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '日期',
  `item_lid` bigint NOT NULL COMMENT '物品lid',
  `bill_lid` bigint NOT NULL COMMENT '单据lid',
  `type_` int NOT NULL COMMENT '类型',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '附件地址',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_item_lid` (`mid`,`item_lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品附件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_item_attachment`
--

LOCK TABLES `sc_item_attachment` WRITE;
/*!40000 ALTER TABLE `sc_item_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_item_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_order_template`
--

DROP TABLE IF EXISTS `sc_order_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_order_template` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '模板名称',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='订货模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_order_template`
--

LOCK TABLES `sc_order_template` WRITE;
/*!40000 ALTER TABLE `sc_order_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_order_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_order_template_item`
--

DROP TABLE IF EXISTS `sc_order_template_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_order_template_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `order_lid` bigint NOT NULL COMMENT '模板lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `volume` decimal(24,6) NOT NULL COMMENT '物品数量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid_order_lid` (`mid`,`sid`,`order_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=736 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='订货模板物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_order_template_item`
--

LOCK TABLES `sc_order_template_item` WRITE;
/*!40000 ALTER TABLE `sc_order_template_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_order_template_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_organ_target`
--

DROP TABLE IF EXISTS `sc_organ_target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_organ_target` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `year` int NOT NULL COMMENT '年份',
  `month` int NOT NULL COMMENT '月份',
  `organ_lid` bigint NOT NULL COMMENT '组织lid',
  `amount` decimal(24,6) NOT NULL COMMENT '目标金额',
  `min_rate` decimal(24,6) NOT NULL COMMENT '毛利润参考最小值',
  `max_rate` decimal(24,6) NOT NULL COMMENT '毛利润参考最大值',
  `type_` int NOT NULL COMMENT '类型',
  `revision` int NOT NULL DEFAULT '0' COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_year_lid` (`mid`,`year`,`lid`) USING BTREE,
  KEY `idx_mid_year_sid_organ_lid` (`mid`,`year`,`sid`,`organ_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='组织目标管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_organ_target`
--

LOCK TABLES `sc_organ_target` WRITE;
/*!40000 ALTER TABLE `sc_organ_target` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_organ_target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_pay_task`
--

DROP TABLE IF EXISTS `sc_pay_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_pay_task` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `amount` decimal(24,6) NOT NULL COMMENT '支付金额',
  `wms_type` int NOT NULL COMMENT '供应链业务类型',
  `state` int NOT NULL COMMENT '支付状态',
  `app_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'appId',
  `open_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户open_id',
  `pay_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '支付单号',
  `finished_at` datetime DEFAULT NULL COMMENT '支付完成时间',
  `order_lids` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '订单lid列表',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供应链支付申请记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_pay_task`
--

LOCK TABLES `sc_pay_task` WRITE;
/*!40000 ALTER TABLE `sc_pay_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_pay_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_prepay_checked_item`
--

DROP TABLE IF EXISTS `sc_prepay_checked_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_prepay_checked_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '付款日期',
  `prepay_order_lid` bigint NOT NULL COMMENT '预付款单lid',
  `prepay_order_item_lid` bigint NOT NULL COMMENT '预付款项lid',
  `bill_pay_item_lid` bigint NOT NULL COMMENT '单据某次的预付款lid',
  `st_bill_lid` bigint NOT NULL COMMENT '仓库单据lid',
  `supplier_lid` bigint NOT NULL COMMENT '供货商的lid',
  `organ_lid` bigint NOT NULL COMMENT '组织lid',
  `type_` int NOT NULL COMMENT '付款类型',
  `amount` decimal(24,6) NOT NULL COMMENT '核销金额',
  `balance_before` decimal(24,6) NOT NULL COMMENT '核销前金额',
  `balance_after` decimal(24,6) NOT NULL COMMENT '核销后金额',
  `cancel_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '取消人',
  `cancel_lid` bigint DEFAULT NULL COMMENT '取消人lid',
  `cancel_time` datetime DEFAULT NULL COMMENT '取消时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_pay_item_lid` (`mid`,`bill_pay_item_lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='预付款核销记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_prepay_checked_item`
--

LOCK TABLES `sc_prepay_checked_item` WRITE;
/*!40000 ALTER TABLE `sc_prepay_checked_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_prepay_checked_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_prepay_order`
--

DROP TABLE IF EXISTS `sc_prepay_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_prepay_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单据编号',
  `report_date` datetime NOT NULL COMMENT '单据日期',
  `supplier_lid` bigint NOT NULL COMMENT '供货商编号',
  `rows` int NOT NULL COMMENT '记录数',
  `total_amount` decimal(24,6) NOT NULL COMMENT '总金额',
  `surplus_amount` decimal(24,6) NOT NULL COMMENT '剩余金额',
  `checked_amount` decimal(24,6) NOT NULL COMMENT '已核销金额',
  `order_state` int NOT NULL COMMENT '订单状态',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `audit_lid` bigint DEFAULT NULL COMMENT '审核人lid',
  `audit_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核人',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_supplier_lid` (`mid`,`supplier_lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供货商预付款';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_prepay_order`
--

LOCK TABLES `sc_prepay_order` WRITE;
/*!40000 ALTER TABLE `sc_prepay_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_prepay_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_prepay_order_item`
--

DROP TABLE IF EXISTS `sc_prepay_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_prepay_order_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '单据日期',
  `supplier_lid` bigint NOT NULL COMMENT '供货商编号',
  `order_state` int NOT NULL COMMENT '订单状态',
  `prepay_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '预付款单据编号',
  `prepay_order_lid` bigint NOT NULL COMMENT '预付款单lid',
  `amount` decimal(24,6) NOT NULL COMMENT '预付金额',
  `surplus_amount` decimal(24,6) NOT NULL COMMENT '剩余金额',
  `checked_amount` decimal(24,6) NOT NULL COMMENT '已核销金额',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '预付款名称',
  `type_` int NOT NULL COMMENT '付款类型',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_lid` (`mid`,`prepay_order_lid`) USING BTREE,
  KEY `idx_mid_supplier_lid` (`mid`,`supplier_lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供货商预付款项';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_prepay_order_item`
--

LOCK TABLES `sc_prepay_order_item` WRITE;
/*!40000 ALTER TABLE `sc_prepay_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_prepay_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_product`
--

DROP TABLE IF EXISTS `sc_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_product` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `product_type_lid` bigint NOT NULL COMMENT '商品类别lid',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '菜品编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '菜品名称',
  `enable` tinyint(1) NOT NULL DEFAULT '1' COMMENT '启用/禁用',
  `idx` int NOT NULL COMMENT '菜品顺序',
  `setup` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否设置',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_sid_id` (`mid`,`sid`,`id`) USING BTREE,
  KEY `idx_mid_product_type_lid` (`mid`,`product_type_lid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3485483 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_product`
--

LOCK TABLES `sc_product` WRITE;
/*!40000 ALTER TABLE `sc_product` DISABLE KEYS */;
INSERT INTO `sc_product` VALUES (3484658,1978646278361620480,2038890034900373506,2038895404669739010,2038895317390467074,'0101001','开胃酸菜焖鹅血',1,1,0,NULL,NULL,'2026-03-31 08:25:20',NULL,NULL,0),(3484659,1978646278361620480,2038890034900373506,2038895489956716545,2038895317390467074,'0101002','墨鱼饼拼煎酿辣椒',1,2,0,NULL,NULL,'2026-03-31 08:25:40',NULL,NULL,0),(3484660,1978646278361620480,2038890034900373506,2038895585872060418,2038895317390467074,'0001014','开胃酸菜焖鹅血',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484661,1978646278361620480,2038890034900373506,2038895585876254722,2038895317390467074,'0001015','墨鱼饼拼煎酿辣椒',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484662,1978646278361620480,2038890034900373506,2038895585876254723,2038895317390467074,'0001017','18岁初恋',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484663,1978646278361620480,2038890034900373506,2038895585876254724,2038895317390467074,'0001018','椒盐鹅下巴',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484664,1978646278361620480,2038890034900373506,2038895585880449025,2038895585876254726,'0001028','酸汤春笋',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484665,1978646278361620480,2038890034900373506,2038895585880449026,2038895585876254726,'0001029','酥炸黄金条',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484666,1978646278361620480,2038890034900373506,2038895585880449027,2038895585876254726,'0001030','椒盐玉米',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484667,1978646278361620480,2038890034900373506,2038895585884643330,2038895585880449029,'0001054','团圆鸿运盆菜(可预定)',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484668,1978646278361620480,2038890034900373506,2038895585884643331,2038895585880449029,'0001055','刺参佛跳墙',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484669,1978646278361620480,2038890034900373506,2038895585884643332,2038895585880449029,'0001056','啫啫东山羊',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484670,1978646278361620480,2038890034900373506,2038895585888837634,2038895585880449029,'0001058','黑松露鸡枞菌炒牛肉',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484671,1978646278361620480,2038890034900373506,2038895585888837635,2038895585880449029,'0001060','黄椒蒸火箭鱿鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484672,1978646278361620480,2038890034900373506,2038895585888837636,2038895585880449029,'0001062','酸汤东海黄鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484673,1978646278361620480,2038890034900373506,2038895585888837637,2038895585880449029,'0001063','伊比利猪肋排',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484674,1978646278361620480,2038890034900373506,2038895585893031937,2038895585880449029,'0001064','秘制酱焗东海黄鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484675,1978646278361620480,2038890034900373506,2038895585893031938,2038895585880449029,'0001065','焦糖焗爽鳝',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484676,1978646278361620480,2038890034900373506,2038895585893031939,2038895585880449029,'0001068','黑松露捞猪肚',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484677,1978646278361620480,2038890034900373506,2038895585897226241,2038895585893031941,'0001069','黑松露捞猪肚（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484678,1978646278361620480,2038890034900373506,2038895585897226242,2038895585893031941,'0001070','清蒸桂花鱼(房)',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484679,1978646278361620480,2038890034900373506,2038895585897226243,2038895585893031941,'0001071','顺德功夫三色鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484680,1978646278361620480,2038890034900373506,2038895585901420546,2038895585897226245,'0001072','叉烧酸菜炒饭',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484681,1978646278361620480,2038890034900373506,2038895585901420547,2038895585897226245,'0001073','秘制烤全翅',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484682,1978646278361620480,2038890034900373506,2038895585901420548,2038895585897226245,'0001074','高山脆皮土豆',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484683,1978646278361620480,2038890034900373506,2038895585905614849,2038895585897226245,'0001075','“旺气”黄皮汁',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484684,1978646278361620480,2038890034900373506,2038895585905614850,2038895585897226245,'0001076','大良双皮奶',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484685,1978646278361620480,2038890034900373506,2038895585905614851,2038895585897226245,'0001077','姜蓉煲仔饭',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484686,1978646278361620480,2038890034900373506,2038895585905614854,2038895585905614853,'0001078','山胡椒干窑排骨',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484687,1978646278361620480,2038890034900373506,2038895585909809153,2038895585905614853,'0001079','金银蒜干窑娃娃菜',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484688,1978646278361620480,2038890034900373506,2038895585909809156,2038895585909809155,'0001080','啫啫雪花牛肉粒',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484689,1978646278361620480,2038890034900373506,2038895585909809157,2038895585909809155,'0001081','啫啫砂锅鱼头',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484690,1978646278361620480,2038890034900373506,2038895585909809158,2038895585909809155,'0001082','秘制酱焗东海大黄鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484691,1978646278361620480,2038890034900373506,2038895585914003457,2038895585909809155,'0001083','葱油酱糖心鲍焗鸡(四只鲍鱼)',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484692,1978646278361620480,2038890034900373506,2038895585914003458,2038895585909809155,'0001084','啫啫鹅肠杏鲍菇',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484693,1978646278361620480,2038890034900373506,2038895585914003459,2038895585909809155,'0001086','锅烧牛仔骨',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484694,1978646278361620480,2038890034900373506,2038895585918197762,2038895585909809155,'0001087','啫啫芥兰',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484695,1978646278361620480,2038890034900373506,2038895585918197763,2038895585909809155,'0001088','啫啫走地鸡',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484696,1978646278361620480,2038890034900373506,2038895585918197764,2038895585909809155,'0001089','沙姜煎焗鸡',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484697,1978646278361620480,2038890034900373506,2038895585918197765,2038895585909809155,'0001090','煎酿豆腐',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484698,1978646278361620480,2038890034900373506,2038895585922392065,2038895585909809155,'0001091','黑叉烧拼墨鱼饼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484699,1978646278361620480,2038890034900373506,2038895585922392066,2038895585909809155,'0001092','啫啫虾酱豆角',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484700,1978646278361620480,2038890034900373506,2038895585922392069,2038895585922392068,'0001096','沙姜猪手/半只',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484701,1978646278361620480,2038890034900373506,2038895585922392070,2038895585922392068,'0001097','姜油炒吊龙',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484702,1978646278361620480,2038890034900373506,2038895585926586370,2038895585922392068,'0001098','鲍汁黑蒜三头糖心鲍捞鱼面',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484703,1978646278361620480,2038890034900373506,2038895585926586371,2038895585922392068,'0001099','老甲鱼（2斤）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484704,1978646278361620480,2038890034900373506,2038895585926586372,2038895585922392068,'0001100','金牌腊味煲仔饭',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484705,1978646278361620480,2038890034900373506,2038895585930780673,2038895585922392068,'0001101','黄鳝煲仔饭',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484706,1978646278361620480,2038890034900373506,2038895585930780674,2038895585922392068,'0001102','均安煎鱼饼（4个）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484707,1978646278361620480,2038890034900373506,2038895585930780675,2038895585922392068,'0001103','均安煎鱼饼（6个）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484708,1978646278361620480,2038890034900373506,2038895585934974977,2038895585922392068,'0001104','沙姜猪手/只',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484709,1978646278361620480,2038890034900373506,2038895585934974978,2038895585922392068,'0001105','顺德腊味合蒸',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484710,1978646278361620480,2038890034900373506,2038895585934974979,2038895585922392068,'0001106','鱼羊一锅鲜',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484711,1978646278361620480,2038890034900373506,2038895585934974980,2038895585922392068,'0001108','清焖海南东山羊',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484712,1978646278361620480,2038890034900373506,2038895585939169281,2038895585922392068,'0001109','花菜焖烧鹅',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484713,1978646278361620480,2038890034900373506,2038895585939169282,2038895585922392068,'0001110','排骨煲仔饭',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484714,1978646278361620480,2038890034900373506,2038895585939169283,2038895585922392068,'0001111','时令水果咕噜肉',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484715,1978646278361620480,2038890034900373506,2038895585939169284,2038895585922392068,'0001112','咸蛋黄焗虾',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484716,1978646278361620480,2038890034900373506,2038895585943363586,2038895585922392068,'0001113','顺德公炒银芽',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484717,1978646278361620480,2038890034900373506,2038895585943363587,2038895585922392068,'0001114','桑拿鸡',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484718,1978646278361620480,2038890034900373506,2038895585943363588,2038895585922392068,'0001115','椒盐鸡翼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484719,1978646278361620480,2038890034900373506,2038895585947557889,2038895585922392068,'0001116','咸蛋黄板栗南瓜茄子',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484720,1978646278361620480,2038890034900373506,2038895585947557890,2038895585922392068,'0001117','黄椒酱蒸火箭鱿',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484721,1978646278361620480,2038890034900373506,2038895585947557891,2038895585922392068,'0001118','基围虾/大份',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484722,1978646278361620480,2038890034900373506,2038895585947557892,2038895585922392068,'0001119','基围虾',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484723,1978646278361620480,2038890034900373506,2038895585951752194,2038895585922392068,'0001120','酸甜酱冰川茄夹',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484724,1978646278361620480,2038890034900373506,2038895585951752195,2038895585922392068,'0001121','干蒸容边排骨',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484725,1978646278361620480,2038890034900373506,2038895585951752196,2038895585922392068,'0001122','干蒸猪杂',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484726,1978646278361620480,2038890034900373506,2038895585951752197,2038895585922392068,'0001124','五柳炸蛋',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484727,1978646278361620480,2038890034900373506,2038895585955946497,2038895585922392068,'0001125','顺德小炒皇',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484728,1978646278361620480,2038890034900373506,2038895585955946498,2038895585922392068,'0001126','紫金凤爪窝烧牛尾',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484729,1978646278361620480,2038890034900373506,2038895585955946499,2038895585893031941,'0001127','紫金凤爪窝烧牛尾（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484730,1978646278361620480,2038890034900373506,2038895585960140802,2038895585922392068,'0001128','笋壳鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484731,1978646278361620480,2038890034900373506,2038895585960140803,2038895585922392068,'0001129','葱油焗炒蚌片',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484732,1978646278361620480,2038890034900373506,2038895585960140804,2038895585922392068,'0001130','葱油酱炒猪颈肉',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484733,1978646278361620480,2038890034900373506,2038895585960140805,2038895585922392068,'0001131','五谷杂粮煲',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484734,1978646278361620480,2038890034900373506,2038895585964335105,2038895585922392068,'0001132','酸辣藕尖炒黄牛肉',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484735,1978646278361620480,2038890034900373506,2038895585964335106,2038895585922392068,'0001133','嫩韭黄炒土鸡蛋',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484736,1978646278361620480,2038890034900373506,2038895585964335107,2038895585922392068,'0001134','老坛酸菜爆炒牛肉',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484737,1978646278361620480,2038890034900373506,2038895585964335108,2038895585922392068,'0001135','白灼吊桶仔',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484738,1978646278361620480,2038890034900373506,2038895585964335109,2038895585922392068,'0001136','沙姜爆炒猪利',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484739,1978646278361620480,2038890034900373506,2038895585968529409,2038895585922392068,'0001137','杂菌浸双丸',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484740,1978646278361620480,2038890034900373506,2038895585968529410,2038895585922392068,'0001138','香葱捞猪肚',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484741,1978646278361620480,2038890034900373506,2038895585968529411,2038895585922392068,'0001139','琥珀腰果',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484742,1978646278361620480,2038890034900373506,2038895585968529412,2038895585922392068,'0001140','蜂巢椒盐无骨鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484743,1978646278361620480,2038890034900373506,2038895585972723714,2038895585922392068,'0001141','蜂窝椒盐无骨鱼腩',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484744,1978646278361620480,2038890034900373506,2038895585972723715,2038895585922392068,'0001142','鹅血焖酸菜',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484745,1978646278361620480,2038890034900373506,2038895585972723716,2038895585893031941,'0003455','鲜花椒蒸笋壳鱼(房)',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484746,1978646278361620480,2038890034900373506,2038895585972723717,2038895585893031941,'0003457','啫啫砂锅鱼头(房)',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484747,1978646278361620480,2038890034900373506,2038895585976918018,2038895585893031941,'0003726','头菜蒸肉饼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484748,1978646278361620480,2038890034900373506,2038895585976918019,2038895585893031941,'0003727','焦糖焗爽鳝（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484749,1978646278361620480,2038890034900373506,2038895585976918020,2038895585893031941,'0003728','女儿红熟醉三拼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484750,1978646278361620480,2038890034900373506,2038895585981112321,2038895585893031941,'0003729','伊比利猪肋排（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484751,1978646278361620480,2038890034900373506,2038895585981112322,2038895585893031941,'0003732','顺德小炒皇（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484752,1978646278361620480,2038890034900373506,2038895585981112323,2038895585893031941,'0003733','葱油酱炒猪颈肉（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484753,1978646278361620480,2038890034900373506,2038895585981112324,2038895585893031941,'0003734','金牌酸菜鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484754,1978646278361620480,2038890034900373506,2038895585981112325,2038895585893031941,'0003735','姜汁芥兰（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484755,1978646278361620480,2038890034900373506,2038895585985306626,2038895585893031941,'0003738','黑松露叉烧炒饭（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484756,1978646278361620480,2038890034900373506,2038895585985306627,2038895585893031941,'0003739','葱油酱焗蚌片（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484757,1978646278361620480,2038890034900373506,2038895585985306628,2038895585893031941,'0003740','金榜牛乳蒸吊水皖鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484758,1978646278361620480,2038890034900373506,2038895585985306629,2038895585893031941,'0003743','惹味酸菜大肠（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484759,1978646278361620480,2038890034900373506,2038895585985306630,2038895585893031941,'0003774','清蒸吊水皖鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484760,1978646278361620480,2038890034900373506,2038895585989500929,2038895585893031941,'0003775','油盐蒸吊水皖鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484761,1978646278361620480,2038890034900373506,2038895585989500930,2038895585893031941,'0003886','深海金雕刺身（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484762,1978646278361620480,2038890034900373506,2038895585989500931,2038895585893031941,'0003887','椒盐鱼骨腩（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484763,1978646278361620480,2038890034900373506,2038895585989500932,2038895585893031941,'0003888','红烧脆皮乳鸽（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484764,1978646278361620480,2038890034900373506,2038895585989500933,2038895585893031941,'0003889','秘制酱东海黄鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484765,1978646278361620480,2038890034900373506,2038895585993695233,2038895585893031941,'0003890','金榜罗氏虾（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484766,1978646278361620480,2038890034900373506,2038895585993695234,2038895585893031941,'0003891','白灼基围虾（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484767,1978646278361620480,2038890034900373506,2038895585993695235,2038895585893031941,'0003892','椒盐基围虾（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484768,1978646278361620480,2038890034900373506,2038895585993695236,2038895585893031941,'0003893','黄焖老甲鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484769,1978646278361620480,2038890034900373506,2038895585997889538,2038895585893031941,'0003894','葱油酱大连鲍焗清远鸡/4只鲍鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484770,1978646278361620480,2038890034900373506,2038895585997889539,2038895585893031941,'0003895','葱油酱大连鲍焗清远鸡/8只鲍鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484771,1978646278361620480,2038890034900373506,2038895585997889540,2038895585893031941,'0003896','砂锅牛腩煲（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484772,1978646278361620480,2038890034900373506,2038895585997889541,2038895585893031941,'0003898','啫啫雪花牛肉粒（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484773,1978646278361620480,2038890034900373506,2038895586127912962,2038895585893031941,'0003901','顺德功夫醉鹅/小份（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484774,1978646278361620480,2038890034900373506,2038895586148884481,2038895585893031941,'0003902','顺德功夫蒸三色鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484775,1978646278361620480,2038890034900373506,2038895586148884482,2038895585893031941,'0003903','清蒸吊水鲩鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484776,1978646278361620480,2038890034900373506,2038895586153078785,2038895585922392068,'0003904','油盐蒸吊水鲩鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484777,1978646278361620480,2038890034900373506,2038895586153078786,2038895585893031941,'0003905','金榜牛乳蒸吊水鲩鱼（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484778,1978646278361620480,2038890034900373506,2038895586153078787,2038895585893031941,'0003906','金牌黑叉烧（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484779,1978646278361620480,2038890034900373506,2038895586153078788,2038895585893031941,'0003907','凤厨拆鱼羹/位（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484780,1978646278361620480,2038890034900373506,2038895586199216129,2038895585893031941,'0003908','凤厨拆鱼羹/份（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484781,1978646278361620480,2038890034900373506,2038895586232770561,2038895585893031941,'0003909','均安煎鱼饼6个（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484782,1978646278361620480,2038890034900373506,2038895586274713602,2038895585893031941,'0003910','香煎墨鱼饼/6个（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484783,1978646278361620480,2038890034900373506,2038895586274713603,2038895585893031941,'0003911','金榜海皇顺德豆腐（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484784,1978646278361620480,2038890034900373506,2038895586278907905,2038895585893031941,'0003912','顺德捞起非遗陈村粉（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484785,1978646278361620480,2038890034900373506,2038895586278907906,2038895585893031941,'0003913','顺德捞起鱼皮（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484786,1978646278361620480,2038890034900373506,2038895586278907907,2038895585893031941,'0003914','酱萝卜（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484787,1978646278361620480,2038890034900373506,2038895586283102209,2038895585893031941,'0003915','香醋红皮花生（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484788,1978646278361620480,2038890034900373506,2038895586283102210,2038895585893031941,'0003916','护肝草老鸽炖杏仁雪梨（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484789,1978646278361620480,2038890034900373506,2038895586283102211,2038895585893031941,'0003917','均安头菜荷叶蒸牛腱子（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484790,1978646278361620480,2038890034900373506,2038895586283102212,2038895585893031941,'0003919','荷香榄角蒸双鲜（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484791,1978646278361620480,2038890034900373506,2038895586287296513,2038895585893031941,'0003921','葱油酱焗猪颈肉 （房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484792,1978646278361620480,2038890034900373506,2038895586287296514,2038895585893031941,'0003922','姜油炒牛肉（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484793,1978646278361620480,2038890034900373506,2038895586287296515,2038895585893031941,'0003924','顺德鸡煲（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484794,1978646278361620480,2038890034900373506,2038895586287296516,2038895585893031941,'0003925','椰菜海皇粉丝煲（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484795,1978646278361620480,2038890034900373506,2038895586291490817,2038895585893031941,'0003926','顺德功夫鱼腐（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484796,1978646278361620480,2038890034900373506,2038895586291490818,2038895585893031941,'0003927','飘香镇江骨（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484797,1978646278361620480,2038890034900373506,2038895586291490819,2038895585893031941,'0003928','珍珠蚝虾仁煎土鸡蛋（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484798,1978646278361620480,2038890034900373506,2038895586291490820,2038895585893031941,'0003929','琥珀腰果（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484799,1978646278361620480,2038890034900373506,2038895586295685121,2038895585893031941,'0003931','南昆山泉水腐竹（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484800,1978646278361620480,2038890034900373506,2038895586295685122,2038895585893031941,'0003932','酸甜酱冰川茄夹（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484801,1978646278361620480,2038890034900373506,2038895586295685123,2038895585893031941,'0003933','金牌酸菜鲈鱼/中份（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484802,1978646278361620480,2038890034900373506,2038895586295685124,2038895585893031941,'0003934','爆炒鲜椒腰花（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484803,1978646278361620480,2038890034900373506,2038895586299879426,2038895585893031941,'0003935','小炒黄牛肉（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484804,1978646278361620480,2038890034900373506,2038895586299879427,2038895585893031941,'0003936','农家小炒肉（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484805,1978646278361620480,2038890034900373506,2038895586299879428,2038895585893031941,'0003937','鸡汤浸迟菜心（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484806,1978646278361620480,2038890034900373506,2038895586299879429,2038895585893031941,'0003938','芥兰炒腊肠（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484807,1978646278361620480,2038890034900373506,2038895586304073729,2038895585893031941,'0003939','飞天酱炒通菜（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484808,1978646278361620480,2038890034900373506,2038895586304073730,2038895585893031941,'0003940','金牌腊味煲仔饭（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484809,1978646278361620480,2038890034900373506,2038895586304073731,2038895585893031941,'0003942','顺德双皮奶（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484810,1978646278361620480,2038890034900373506,2038895586304073732,2038895585893031941,'0003943','顺德伦教糕（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484811,1978646278361620480,2038890034900373506,2038895586308268033,2038895585893031941,'0003944','大良炸牛奶/4个（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484812,1978646278361620480,2038890034900373506,2038895586308268034,2038895585893031941,'0003945','云南野生红茶（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484813,1978646278361620480,2038890034900373506,2038895586308268035,2038895585893031941,'0003946','陈皮白茶（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484814,1978646278361620480,2038890034900373506,2038895586312462337,2038895586308268037,'0000001','顺德七彩捞鸡/半只',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484815,1978646278361620480,2038890034900373506,2038895586312462340,2038895586312462339,'0001019','蒜蓉炒通菜',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484816,1978646278361620480,2038890034900373506,2038895586312462341,2038895586308268037,'0000002','顺德功夫三色鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484817,1978646278361620480,2038890034900373506,2038895586312462342,2038895585922392068,'0000003','桑拿无骨鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484818,1978646278361620480,2038890034900373506,2038895586316656641,2038895586312462344,'0000004','养生鱼头煲',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484819,1978646278361620480,2038890034900373506,2038895586316656642,2038895586312462339,'0001022','通菜',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484820,1978646278361620480,2038890034900373506,2038895586316656645,2038895586316656644,'0001027','香椿煎蛋',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484821,1978646278361620480,2038890034900373506,2038895586316656646,2038895586312462344,'0000005','咸牛乳蒸吊水皖鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484822,1978646278361620480,2038890034900373506,2038895586320850945,2038895586312462339,'0001023','猪油渣炒菜心',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484823,1978646278361620480,2038890034900373506,2038895586320850946,2038895586312462344,'0000006','金榜牛乳吊水皖鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484824,1978646278361620480,2038890034900373506,2038895586320850947,2038895586312462339,'0001024','冰川茄子',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484825,1978646278361620480,2038890034900373506,2038895586320850948,2038895585922392068,'0000007','顺德捞起鱼皮',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484826,1978646278361620480,2038890034900373506,2038895586325045250,2038895586312462339,'0001025','冬菇扒生菜',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484827,1978646278361620480,2038890034900373506,2038895586325045251,2038895586308268037,'0000008','顺德功夫鱼腐',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484828,1978646278361620480,2038890034900373506,2038895586325045252,2038895586312462339,'0001026','芥兰炒腊肠',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484829,1978646278361620480,2038890034900373506,2038895586325045253,2038895585922392068,'0000009','顺德拆鱼羹',1,0,0,NULL,NULL,'2026-03-31 08:26:39',NULL,NULL,0),(3484830,1978646278361620480,2038890034900373506,2038895586329239553,2038895586312462339,'0002027','红葱头生菜',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484831,1978646278361620480,2038890034900373506,2038895586329239554,2038895585922392068,'0000010','凤厨拆鱼羹/份',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484832,1978646278361620480,2038890034900373506,2038895586329239555,2038895586312462339,'0000051','鸡汤浸菜心',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484833,1978646278361620480,2038890034900373506,2038895586392154113,2038895586312462339,'0000052','姜汁芥兰',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484834,1978646278361620480,2038890034900373506,2038895586396348417,2038895586312462339,'0000069','腊味炒菜心',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484835,1978646278361620480,2038890034900373506,2038895586396348418,2038895586308268037,'0000013','顺德捞起非遗陈村粉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484836,1978646278361620480,2038890034900373506,2038895586396348419,2038895586312462339,'0000070','飞天酱炒通菜',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484837,1978646278361620480,2038890034900373506,2038895586400542722,2038895585897226245,'0000014','爆珠双皮奶',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484838,1978646278361620480,2038890034900373506,2038895586400542723,2038895586312462339,'00000NQ','蒜蓉炒菜心',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484839,1978646278361620480,2038890034900373506,2038895586400542724,2038895585897226245,'0000015','顺德小吃拼盘',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484840,1978646278361620480,2038890034900373506,2038895586400542725,2038895586312462339,'00000NR','蒜蓉炒油麦菜',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484841,1978646278361620480,2038890034900373506,2038895586404737026,2038895585922392068,'0000016','姜油炒牛肉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484842,1978646278361620480,2038890034900373506,2038895586404737027,2038895585922392068,'0000017','花胶猪肚鸡',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484843,1978646278361620480,2038890034900373506,2038895586404737028,2038895585922392068,'0000018','顺德鸡煲',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484844,1978646278361620480,2038890034900373506,2038895586404737029,2038895586312462339,'0S01003','腊肠炒迟菜心',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484845,1978646278361620480,2038890034900373506,2038895586404737030,2038895585876254726,'0000019','煎酿凉瓜煲',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484846,1978646278361620480,2038890034900373506,2038895586408931330,2038895586312462339,'0S01004','腊肠炒迟菜心（房）',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484847,1978646278361620480,2038890034900373506,2038895586408931331,2038895585922392068,'0000020','南昆山泉水腐竹',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484848,1978646278361620480,2038890034900373506,2038895586408931332,2038895586312462339,'0S01005','香菇扒青菜',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484849,1978646278361620480,2038890034900373506,2038895586413125633,2038895585876254726,'0000021','野味酸菜大肠',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484850,1978646278361620480,2038890034900373506,2038895586413125636,2038895586413125635,'0001031','吊水无骨鱼肉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484851,1978646278361620480,2038890034900373506,2038895586413125637,2038895585897226245,'0000022','五谷粗粮煲',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484852,1978646278361620480,2038890034900373506,2038895586413125638,2038895586413125635,'0001032','生菜',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484853,1978646278361620480,2038890034900373506,2038895586417319938,2038895585922392068,'0000023','蒜蓉焗基围虾',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484854,1978646278361620480,2038890034900373506,2038895586417319939,2038895586413125635,'0001033','清远跑山无骨鸡肉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484855,1978646278361620480,2038890034900373506,2038895586417319940,2038895585922392068,'0000024','葱油淋鲈鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484856,1978646278361620480,2038890034900373506,2038895586417319941,2038895586413125635,'0001034','吊水白贝',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484857,1978646278361620480,2038890034900373506,2038895586417319942,2038895585922392068,'0000025','蒜香骨',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484858,1978646278361620480,2038890034900373506,2038895586421514242,2038895586413125635,'0001035','手打鲮鱼滑',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484859,1978646278361620480,2038890034900373506,2038895586421514243,2038895585922392068,'0000026','飘香镇江骨',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484860,1978646278361620480,2038890034900373506,2038895586421514244,2038895586413125635,'0001036','毋米粥水火锅',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484861,1978646278361620480,2038890034900373506,2038895586421514245,2038895585922392068,'0000027','咸鱼茄子煲',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484862,1978646278361620480,2038890034900373506,2038895586425708546,2038895586413125635,'0001037','鲜活基围虾',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484863,1978646278361620480,2038890034900373506,2038895586425708549,2038895586425708548,'0000028','泰汁茄子',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484864,1978646278361620480,2038890034900373506,2038895586425708550,2038895586413125635,'0001038','新鲜吊龙肉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484865,1978646278361620480,2038890034900373506,2038895586425708551,2038895585922392068,'0000029','海皇椰菜粉丝煲',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484866,1978646278361620480,2038890034900373506,2038895586429902850,2038895585880449029,'0001039','清汤羊肉煲',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484867,1978646278361620480,2038890034900373506,2038895586429902851,2038895585880449029,'0001040','清汤羊肉煲/小份',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484868,1978646278361620480,2038890034900373506,2038895586429902852,2038895585922392068,'0000031','盐焗鹅掌翼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484869,1978646278361620480,2038890034900373506,2038895586429902853,2038895585880449029,'0001043','腊味炒连州迟菜心',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484870,1978646278361620480,2038890034900373506,2038895586434097154,2038895585922392068,'0000032','黑椒牛仔骨',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484871,1978646278361620480,2038890034900373506,2038895586434097155,2038895585880449029,'0001044','酸汤开胃鱼头煲',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484872,1978646278361620480,2038890034900373506,2038895586434097156,2038895585922392068,'0000033','砂锅牛腩煲',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484873,1978646278361620480,2038890034900373506,2038895586434097157,2038895585880449029,'0001047','红焖羊肉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484874,1978646278361620480,2038890034900373506,2038895586438291457,2038895585880449029,'0001046','鸿运佛跳墙（小份）',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484875,1978646278361620480,2038890034900373506,2038895586438291458,2038895585905614853,'0000035','白贝蒸鸡',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484876,1978646278361620480,2038890034900373506,2038895586438291459,2038895585880449029,'0001048','苔兰炒腊味',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484877,1978646278361620480,2038890034900373506,2038895586438291460,2038895585905614853,'0000036','蒜蓉蒸胜瓜',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484878,1978646278361620480,2038890034900373506,2038895586442485761,2038895585880449029,'0001049','酸汤肥牛',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484879,1978646278361620480,2038890034900373506,2038895586442485762,2038895585905614853,'0000037','鲜虾仁蒸土鸡蛋',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484880,1978646278361620480,2038890034900373506,2038895586442485763,2038895585880449029,'0001050','酸汤海鲜锅',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484881,1978646278361620480,2038890034900373506,2038895586442485764,2038895585905614853,'0000038','头菜蒸肉饼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484882,1978646278361620480,2038890034900373506,2038895586446680065,2038895585880449029,'0001051','黑醋焦糖焗鳝鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484883,1978646278361620480,2038890034900373506,2038895586446680066,2038895585897226245,'0000039','大良炸牛奶/4个',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484884,1978646278361620480,2038890034900373506,2038895586446680067,2038895585880449029,'0001052','鸡枞菌荷兰豆炒黄牛肉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484885,1978646278361620480,2038890034900373506,2038895586446680068,2038895585897226245,'0000040','顺德伦教糕',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484886,1978646278361620480,2038890034900373506,2038895586450874369,2038895585880449029,'0001053','沙姜焗火箭鱿',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484887,1978646278361620480,2038890034900373506,2038895586450874370,2038895585897226245,'0000041','腊味酸菜炒饭',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484888,1978646278361620480,2038890034900373506,2038895586450874371,2038895585897226245,'0000042','南瓜粥',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484889,1978646278361620480,2038890034900373506,2038895586450874372,2038895586425708548,'0000043','农家小炒肉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484890,1978646278361620480,2038890034900373506,2038895586450874373,2038895586425708548,'0000044','小炒黄牛肉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484891,1978646278361620480,2038890034900373506,2038895586455068674,2038895586425708548,'0000048','茄子恋上豆角',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484892,1978646278361620480,2038890034900373506,2038895586455068675,2038895586425708548,'0000049','台山花菜炒肉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484893,1978646278361620480,2038890034900373506,2038895586455068676,2038895586425708548,'0000050','农家一碗香',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484894,1978646278361620480,2038890034900373506,2038895586459262978,2038895585905614853,'0000071','蒜蓉粉丝蒸元贝',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484895,1978646278361620480,2038890034900373506,2038895586459262979,2038895585897226245,'0000073','大良炸牛奶/6个',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484896,1978646278361620480,2038890034900373506,2038895586463457282,2038895585897226245,'0000074','香草双皮奶',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484897,1978646278361620480,2038890034900373506,2038895586463457283,2038895585897226245,'0000075','抹茶双皮奶',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484898,1978646278361620480,2038890034900373506,2038895586463457284,2038895585897226245,'0000076','儿童套餐',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484899,1978646278361620480,2038890034900373506,2038895586467651585,2038895586425708548,'0000077','金牌酸菜鲈鱼/大份',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484900,1978646278361620480,2038890034900373506,2038895586467651586,2038895586425708548,'0000078','热油激香麻婆豆腐',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484901,1978646278361620480,2038890034900373506,2038895586471845889,2038895586312462344,'0000079','西江吊水无骨鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484902,1978646278361620480,2038890034900373506,2038895586492817410,2038895586312462344,'0000080','油盐蒸吊水山坑鲩',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484903,1978646278361620480,2038890034900373506,2038895586497011713,2038895586312462344,'0000081','清蒸吊水山坑鲩',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484904,1978646278361620480,2038890034900373506,2038895586497011714,2038895585922392068,'0000082','香煎墨鱼饼/6个',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484905,1978646278361620480,2038890034900373506,2038895586497011715,2038895585922392068,'0000083','香煎风干白鲳鱼/半条',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484906,1978646278361620480,2038890034900373506,2038895586497011716,2038895585922392068,'0000084','香煎风干白鲳鱼/条',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484907,1978646278361620480,2038890034900373506,2038895586501206017,2038895585922392068,'0000085','沙姜猪手/份',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484908,1978646278361620480,2038890034900373506,2038895586513788929,2038895585922392068,'0000087','盐焗鹅三宝',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484909,1978646278361620480,2038890034900373506,2038895586513788930,2038895585922392068,'0000088','椒盐基围虾',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484910,1978646278361620480,2038890034900373506,2038895586517983234,2038895585922392068,'0000089','白灼基围虾',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484911,1978646278361620480,2038890034900373506,2038895586517983235,2038895585922392068,'000008A','顺德鲍汁豆腐',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484912,1978646278361620480,2038890034900373506,2038895586517983236,2038895585922392068,'000008B','盐焗鸡/半只',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484913,1978646278361620480,2038890034900373506,2038895586522177537,2038895585922392068,'000008E','鲮鱼肉酿本地辣椒',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484914,1978646278361620480,2038890034900373506,2038895586522177538,2038895585922392068,'000008F','椒盐鱼骨腩',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484915,1978646278361620480,2038890034900373506,2038895586526371841,2038895585922392068,'000008G','九层塔卜卜白贝',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484916,1978646278361620480,2038890034900373506,2038895586526371842,2038895585922392068,'000008K','麻辣牛展',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484917,1978646278361620480,2038890034900373506,2038895586526371843,2038895585922392068,'000008L','顺德清汤羊煲',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484918,1978646278361620480,2038890034900373506,2038895586526371844,2038895585876254726,'000008M','黑毛节瓜炖鸡脚汤',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484919,1978646278361620480,2038890034900373506,2038895586530566146,2038895585876254726,'000008N','黑毛节瓜煲咸骨',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484920,1978646278361620480,2038890034900373506,2038895586530566147,2038895585876254726,'000008O','黑毛节瓜煎土鸡蛋',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484921,1978646278361620480,2038890034900373506,2038895586530566148,2038895586308268037,'000008P','金牌黑叉烧',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484922,1978646278361620480,2038890034900373506,2038895586530566149,2038895586308268037,'000008Q','顺德功夫醉鹅',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484923,1978646278361620480,2038890034900373506,2038895586530566150,2038895586308268037,'000008R','金榜海皇手磨顺德豆腐',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484924,1978646278361620480,2038890034900373506,2038895586534760449,2038895586308268037,'000008S','风生水起捞鱼皮',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484925,1978646278361620480,2038890034900373506,2038895586534760450,2038895585880449029,'00000C1','深海金雕刺身',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484926,1978646278361620480,2038890034900373506,2038895586534760453,2038895586534760452,'00000C2','堂灼酸汤大黄鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484927,1978646278361620480,2038890034900373506,2038895586534760454,2038895586534760452,'00000C5','清焖东山羊',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484928,1978646278361620480,2038890034900373506,2038895586538954754,2038895585905614853,'00000C6','无骨吊水鲩鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484929,1978646278361620480,2038890034900373506,2038895586538954755,2038895585905614853,'00000C7','肉沫蒸土鸡蛋',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484930,1978646278361620480,2038890034900373506,2038895586538954756,2038895585905614853,'00000C8','板栗南瓜蒸排骨',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484931,1978646278361620480,2038890034900373506,2038895586538954757,2038895585905614853,'00000C9','均安头菜荷叶蒸牛腱子',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484932,1978646278361620480,2038890034900373506,2038895586538954758,2038895585905614853,'00000CA','腊鲮鱼干蒸手剁肉饼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484933,1978646278361620480,2038890034900373506,2038895586543149058,2038895585905614853,'00000CB','藤椒蒸笋壳鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484934,1978646278361620480,2038890034900373506,2038895586543149059,2038895585905614853,'00000CC','香芋蒸排骨',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484935,1978646278361620480,2038890034900373506,2038895586543149060,2038895585905614853,'00000CD','黄椒酱蒸鱼头',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484936,1978646278361620480,2038890034900373506,2038895586543149061,2038895585905614853,'00000CE','虫草花蒸鸡',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484937,1978646278361620480,2038890034900373506,2038895586547343361,2038895585905614853,'00000CF','豉汁蒸鱼头',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484938,1978646278361620480,2038890034900373506,2038895586547343362,2038895585905614853,'00000CG','肉沫鸡蛋',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484939,1978646278361620480,2038890034900373506,2038895586547343363,2038895585905614853,'00000CI','荷香榄角蒸双鲜',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484940,1978646278361620480,2038890034900373506,2038895586547343364,2038895585905614853,'00000CJ','啫啫花菜烧鹅',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484941,1978646278361620480,2038890034900373506,2038895586547343365,2038895586425708548,'00000CK','金牌脆皮猪手',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484942,1978646278361620480,2038890034900373506,2038895586551537666,2038895586425708548,'00000CL','金牌酸菜鲈鱼/中份',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484943,1978646278361620480,2038890034900373506,2038895586551537667,2038895586425708548,'00000CM','香辣猪三宝',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484944,1978646278361620480,2038890034900373506,2038895586551537668,2038895586425708548,'00000CN','爆炒鲜椒腰花',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484945,1978646278361620480,2038890034900373506,2038895586551537669,2038895586312462344,'00000CO','冲浪西江河鱼一锅鲜',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484946,1978646278361620480,2038890034900373506,2038895586555731969,2038895586312462344,'00000CP','吊水山坑鲩',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484947,1978646278361620480,2038890034900373506,2038895586555731970,2038895586312462344,'00000CR','清蒸吊水山坑鲩',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484948,1978646278361620480,2038890034900373506,2038895586555731971,2038895586312462344,'00000CS','蜂窝椒盐无骨鱼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484949,1978646278361620480,2038890034900373506,2038895586555731972,2038895586312462344,'00000CT','鲜花椒白灼鲜鱿',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484950,1978646278361620480,2038890034900373506,2038895586555731973,2038895585897226245,'00000CU','牛腩汁捞陈村粉',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484951,1978646278361620480,2038890034900373506,2038895586559926274,2038895585897226245,'00000CV','香煎葱油饼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484952,1978646278361620480,2038890034900373506,2038895586559926275,2038895585897226245,'00000CX','红豆双皮奶',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484953,1978646278361620480,2038890034900373506,2038895586559926276,2038895585897226245,'00000CY','咸煎饼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484954,1978646278361620480,2038890034900373506,2038895586559926277,2038895585897226245,'00000CZ','鲜虾韭菜饼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484955,1978646278361620480,2038890034900373506,2038895586564120577,2038895585897226245,'00000D0','脆皮黑金豆腐',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3484956,1978646278361620480,2038890034900373506,2038895586564120578,2038895585897226245,'00000D1','葱香黄金饼',1,0,0,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(3485277,1940284000182472704,1940287289892687874,2041352053147570178,2041349265130786818,'0101001','清蒸鲍鱼',1,1,0,NULL,NULL,'2026-04-07 03:07:10',NULL,NULL,0),(3485278,1940284000182472704,2042543010529546242,2042543630806814722,2042543525278126082,'0101001','123',1,1,0,NULL,NULL,'2026-04-10 10:02:05',NULL,NULL,1),(3485279,1940284000182472704,2042804773847437313,2042873704147718146,2042872793253941249,'0101001','衡东脆肚',1,1,0,NULL,NULL,'2026-04-11 07:53:40',NULL,NULL,0),(3485280,1940284000182472704,1940287289892687874,2049442688793972737,2041349265130786818,'0101002','1分钱',1,2,0,NULL,NULL,'2026-04-29 10:56:28',NULL,NULL,1),(3485281,1940284000182472704,1940287289892687874,2049449428696567810,2041349265130786818,'0101002','1分钱',1,2,0,NULL,NULL,'2026-04-29 11:23:15',NULL,NULL,0),(3485282,1940284000182472704,2042543010529546242,2053713298288021506,2053713149717385217,'0101001','小炒肉',1,1,0,NULL,NULL,'2026-05-11 05:46:21',NULL,NULL,0),(3485283,1940284000182472704,2042543010529546242,2053713338410733569,2053713149717385217,'0101002','一碗香',1,2,0,NULL,NULL,'2026-05-11 05:46:30',NULL,NULL,0),(3485284,1940284000182472704,2042543010529546242,2053713382140547073,2053713149717385217,'0101003','黄牛肉',1,3,0,NULL,NULL,'2026-05-11 05:46:41',NULL,NULL,0),(3485285,1940284000182472704,2042543010529546242,2053713444384018433,2053713167413153793,'0102001','白切鸡',1,4,0,NULL,NULL,'2026-05-11 05:46:55',NULL,NULL,0),(3485286,1940284000182472704,2042543010529546242,2053713543621251074,2053713167413153793,'0102002','顺德醉鹅',1,5,0,NULL,NULL,'2026-05-11 05:47:19',NULL,NULL,0),(3485287,1940284000182472704,2042543010529546242,2053713600915443713,2053713197993824257,'0201001','小笼包',1,6,0,NULL,NULL,'2026-05-11 05:47:33',NULL,NULL,0),(3485288,1940284000182472704,2042543010529546242,2053713660176764930,2053713197993824257,'0201002','芝麻包',1,7,0,NULL,NULL,'2026-05-11 05:47:47',NULL,NULL,0),(3485289,1940284000182472704,2042543010529546242,2053713712731394050,2053713197993824257,'0201003','菠萝包',1,8,0,NULL,NULL,'2026-05-11 05:47:59',NULL,NULL,0),(3485290,1940284000182472704,1979737429467095041,2053713298288021506,2053713149717385217,'0101001','小炒肉',1,1,0,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(3485291,1940284000182472704,1979737429467095041,2053713338410733569,2053713149717385217,'0101002','一碗香',1,2,0,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(3485292,1940284000182472704,1979737429467095041,2053713382140547073,2053713149717385217,'0101003','黄牛肉',1,3,0,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(3485293,1940284000182472704,1979737429467095041,2053713444384018433,2053713167413153793,'0102001','白切鸡',1,4,0,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(3485294,1940284000182472704,1979737429467095041,2053713543621251074,2053713167413153793,'0102002','顺德醉鹅',1,5,0,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(3485295,1940284000182472704,1979737429467095041,2053713600915443713,2053713197993824257,'0201001','小笼包',1,6,0,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(3485296,1940284000182472704,1979737429467095041,2053713660176764930,2053713197993824257,'0201002','芝麻包',1,7,0,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(3485297,1940284000182472704,1979737429467095041,2053713712731394050,2053713197993824257,'0201003','菠萝包',1,8,0,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(3485347,1940284000182472704,2042543010529546242,2086692066618511361,2053713167413153793,'0102003','0810c菜品',1,9,0,NULL,NULL,'2026-08-10 13:52:13',NULL,NULL,0),(3485383,1940284000182472704,2042543010529546242,2086702789432184834,2053713167413153793,'0102004','测试001',1,10,0,NULL,NULL,'2026-08-10 14:34:48',NULL,NULL,0),(3485394,1940284000182472704,2042543010529546242,2087073956195733505,2053713197993824257,'0201004','测试0811',1,11,0,NULL,NULL,'2026-08-11 15:09:42',NULL,NULL,0),(3485396,1940284000182472704,2042543010529546242,2087079389845262338,2053713149717385217,'0101004','宫保鸡丁',1,12,0,NULL,NULL,'2026-08-11 15:31:17',NULL,NULL,0),(3485397,1940284000182472704,2042543010529546242,2087082564052586497,2053713149717385217,'0101005','宫保鸡丁01',1,13,0,NULL,NULL,'2026-08-11 15:43:54',NULL,NULL,0),(3485398,1940284000182472704,2042543010529546242,2087114322471694338,2053713149717385217,'0101006','宫保鸡丁03',1,14,0,NULL,NULL,'2026-08-11 17:50:06',NULL,NULL,0),(3485469,1940284000182472704,1942885905090105345,2053713298288021506,2053713149717385217,'0101001','小炒肉',1,1,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485470,1940284000182472704,1942885905090105345,2053713338410733569,2053713149717385217,'0101002','一碗香',1,2,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485471,1940284000182472704,1942885905090105345,2053713382140547073,2053713149717385217,'0101003','黄牛肉',1,3,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485472,1940284000182472704,1942885905090105345,2053713444384018433,2053713167413153793,'0102001','白切鸡',1,4,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485473,1940284000182472704,1942885905090105345,2053713543621251074,2053713167413153793,'0102002','顺德醉鹅',1,5,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485474,1940284000182472704,1942885905090105345,2053713600915443713,2053713197993824257,'0201001','小笼包',1,6,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485475,1940284000182472704,1942885905090105345,2053713660176764930,2053713197993824257,'0201002','芝麻包',1,7,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485476,1940284000182472704,1942885905090105345,2053713712731394050,2053713197993824257,'0201003','菠萝包',1,8,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485477,1940284000182472704,1942885905090105345,2086692066618511361,2053713167413153793,'0102003','0810c菜品',1,9,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485478,1940284000182472704,1942885905090105345,2086702789432184834,2053713167413153793,'0102004','测试001',1,10,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485479,1940284000182472704,1942885905090105345,2087073956195733505,2053713197993824257,'0201004','测试0811',1,11,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485480,1940284000182472704,1942885905090105345,2087079068779679746,2053713149717385217,'0101004','宫保鸡丁',1,11,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485481,1940284000182472704,1942885905090105345,2087082564052586497,2053713149717385217,'0101005','宫保鸡丁01',1,13,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(3485482,1940284000182472704,1942885905090105345,2087114322471694338,2053713149717385217,'0101006','宫保鸡丁03',1,14,0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0);
/*!40000 ALTER TABLE `sc_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_product_cost`
--

DROP TABLE IF EXISTS `sc_product_cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_product_cost` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `product_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品id',
  `product_lid` bigint NOT NULL COMMENT '商品lid',
  `product_unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品单位',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '成本名称',
  `assist_lid` bigint NOT NULL COMMENT '辅助成本的lid',
  `rate` decimal(24,6) NOT NULL COMMENT '占比',
  `cost` decimal(24,6) NOT NULL COMMENT '成本',
  `idx` int NOT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_product_lid_unit` (`mid`,`product_lid`,`product_unit`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品其他成本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_product_cost`
--

LOCK TABLES `sc_product_cost` WRITE;
/*!40000 ALTER TABLE `sc_product_cost` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_product_cost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_product_raw`
--

DROP TABLE IF EXISTS `sc_product_raw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_product_raw` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `product_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品id',
  `product_lid` bigint NOT NULL COMMENT '商品lid',
  `product_unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品单位',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `goods_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物品单位',
  `unit_lid` bigint NOT NULL COMMENT '单位lid',
  `raw_weight` decimal(24,6) NOT NULL COMMENT '原料重量',
  `price` decimal(24,6) NOT NULL COMMENT '原料单价',
  `net_rate` decimal(24,6) NOT NULL COMMENT '出净率',
  `net_weight` decimal(24,6) NOT NULL COMMENT '净料重量',
  `yield_rate` decimal(24,6) NOT NULL COMMENT '出成率',
  `cooked_weight` decimal(24,6) NOT NULL COMMENT '熟菜重量',
  `amount` decimal(24,6) NOT NULL COMMENT '金额（元）',
  `idx` int NOT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `unit_type` int NOT NULL DEFAULT '1' COMMENT '物品单位类型',
  `last_order_price` decimal(24,6) DEFAULT NULL COMMENT '上次进货单价',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_product_lid_unit` (`mid`,`product_lid`,`product_unit`) USING BTREE,
  KEY `idx_mid_goods_lid` (`mid`,`goods_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=987 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品原料';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_product_raw`
--

LOCK TABLES `sc_product_raw` WRITE;
/*!40000 ALTER TABLE `sc_product_raw` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_product_raw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_product_resource`
--

DROP TABLE IF EXISTS `sc_product_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_product_resource` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `product_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品id',
  `product_lid` bigint NOT NULL COMMENT '商品lid',
  `unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品单位',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '资源地址',
  `type_` int NOT NULL COMMENT '资源类型',
  `idx` int NOT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_product_lid_type_` (`mid`,`product_lid`,`type_`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=591 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品视频/图片';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_product_resource`
--

LOCK TABLES `sc_product_resource` WRITE;
/*!40000 ALTER TABLE `sc_product_resource` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_product_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_product_sale_cost`
--

DROP TABLE IF EXISTS `sc_product_sale_cost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_product_sale_cost` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `profit_lid` bigint NOT NULL COMMENT '毛利表lid,保留字段',
  `organ_lid` bigint NOT NULL COMMENT '组织lid',
  `product_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品id',
  `product_lid` bigint NOT NULL COMMENT '商品lid',
  `product_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品单位',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `goods_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物品单位',
  `goods_unit_lid` bigint NOT NULL COMMENT '物品单位lid',
  `theory_volume` decimal(24,6) DEFAULT '0.000000' COMMENT '理论用量',
  `actual_volume` decimal(24,6) DEFAULT '0.000000' COMMENT '实际用量',
  `diff_volume` decimal(24,6) DEFAULT '0.000000' COMMENT '用量差异',
  `theory_cost` decimal(24,6) DEFAULT '0.000000' COMMENT '理论成本',
  `actual_cost` decimal(24,6) DEFAULT '0.000000' COMMENT '实际成本',
  `wastage_cost` decimal(24,6) DEFAULT '0.000000' COMMENT '耗损成本',
  `diff_cost` decimal(24,6) DEFAULT '0.000000' COMMENT '成本差异',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year` int NOT NULL COMMENT '年',
  `month` int NOT NULL COMMENT '月',
  `day` int NOT NULL COMMENT '日',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `organ_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '组织名称',
  `product_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '商品名称',
  `goods_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '商品名称',
  `shop_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '店铺名称',
  `counting_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '计量数量',
  `source_type` int DEFAULT '0' COMMENT '来源类型',
  `bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '账单编号',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date_organ_lid` (`mid`,`report_date`,`organ_lid`) USING BTREE,
  KEY `idx_mid_report_date_product_lid` (`mid`,`report_date`,`product_lid`) USING BTREE,
  KEY `idx_mid_profit_lid` (`mid`,`profit_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12615 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品销售成本分析';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_product_sale_cost`
--

LOCK TABLES `sc_product_sale_cost` WRITE;
/*!40000 ALTER TABLE `sc_product_sale_cost` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_product_sale_cost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_product_sale_profit`
--

DROP TABLE IF EXISTS `sc_product_sale_profit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_product_sale_profit` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `organ_lid` bigint NOT NULL COMMENT '组织lid',
  `product_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品id',
  `product_lid` bigint NOT NULL COMMENT '商品lid',
  `product_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品单位',
  `sale_volume` decimal(24,6) NOT NULL COMMENT '销售数量',
  `sale_price` decimal(24,6) NOT NULL COMMENT '平均售价',
  `sale_amount` decimal(24,6) NOT NULL COMMENT '销售金额',
  `theory_cost` decimal(24,6) NOT NULL COMMENT '理论成本',
  `actual_cost` decimal(24,6) NOT NULL COMMENT '实际成本',
  `other_cost` decimal(24,6) NOT NULL COMMENT '其他成本',
  `diff_cost` decimal(24,6) NOT NULL COMMENT '成本差异',
  `bill_type` int NOT NULL DEFAULT '1' COMMENT '账单类型',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year` int NOT NULL COMMENT '年',
  `month` int NOT NULL COMMENT '月',
  `day` int NOT NULL COMMENT '日',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `organ_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '组织名称',
  `product_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '商品名称',
  `shop_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '店铺名称',
  `source_type` int DEFAULT '0' COMMENT '来源类型',
  `bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '账单编号',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date_organ_lid` (`mid`,`report_date`,`organ_lid`) USING BTREE,
  KEY `idx_mid_report_date_product_lid` (`mid`,`report_date`,`product_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2824 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品销售毛利分析';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_product_sale_profit`
--

LOCK TABLES `sc_product_sale_profit` WRITE;
/*!40000 ALTER TABLE `sc_product_sale_profit` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_product_sale_profit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_product_type`
--

DROP TABLE IF EXISTS `sc_product_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_product_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '名称',
  `parent_lid` bigint DEFAULT NULL COMMENT '上级分类',
  `idx` int NOT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=159846 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品类别';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_product_type`
--

LOCK TABLES `sc_product_type` WRITE;
/*!40000 ALTER TABLE `sc_product_type` DISABLE KEYS */;
INSERT INTO `sc_product_type` VALUES (159704,1978646278361620480,2038890034900373506,2038895277896900609,'01','顺德经典菜',NULL,1,NULL,NULL,'2026-03-31 08:24:50',NULL,NULL,0),(159705,1978646278361620480,2038890034900373506,2038895317390467074,'0101','顺德经典菜',2038895277896900609,2,NULL,NULL,'2026-03-31 08:25:20',NULL,NULL,0),(159706,1940284000182472704,1940287289892687874,2041349063640616962,'01','海鲜',NULL,1,NULL,NULL,'2026-04-07 02:55:18',NULL,NULL,0),(159707,1940284000182472704,1940287289892687874,2041349265130786818,'0101','鲍鱼',2041349063640616962,1,NULL,NULL,'2026-04-07 03:07:10',NULL,NULL,0),(159708,1940284000182472704,2042543010529546242,2042543080333774850,'01','111567',NULL,1,NULL,NULL,'2026-04-10 09:59:54',NULL,NULL,1),(159709,1940284000182472704,2042543010529546242,2042543525278126082,'0101','123',2042543080333774850,2,NULL,NULL,'2026-04-10 10:02:04',NULL,NULL,1),(159710,1940284000182472704,2042804773847437313,2042872418702594050,'01','衡阳菜',NULL,1,NULL,NULL,'2026-04-11 07:48:34',NULL,NULL,0),(159711,1940284000182472704,2042804773847437313,2042872793253941249,'0101','衡东菜',2042872418702594050,1,NULL,NULL,'2026-04-11 07:53:40',NULL,NULL,0),(159712,1940284000182472704,2042543010529546242,2053712930682441729,'01','中厨',NULL,1,NULL,NULL,'2026-05-11 05:44:53',NULL,NULL,0),(159713,1940284000182472704,2042543010529546242,2053712946373332994,'02','点心',NULL,2,NULL,NULL,'2026-05-11 05:44:57',NULL,NULL,0),(159714,1940284000182472704,2042543010529546242,2053713149717385217,'0101','湘菜',2053712930682441729,3,NULL,NULL,'2026-05-11 05:46:21',NULL,NULL,0),(159715,1940284000182472704,2042543010529546242,2053713167413153793,'0102','粤菜',2053712930682441729,4,NULL,NULL,'2026-05-11 05:46:55',NULL,NULL,0),(159716,1940284000182472704,2042543010529546242,2053713197993824257,'0201','包罗万有',2053712946373332994,5,NULL,NULL,'2026-05-11 05:47:33',NULL,NULL,0),(159717,1940284000182472704,1979737429467095041,2053712930682441729,'01','中厨',NULL,1,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(159718,1940284000182472704,1979737429467095041,2053712946373332994,'02','点心',NULL,2,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(159719,1940284000182472704,1979737429467095041,2053713149717385217,'0101','湘菜',2053712930682441729,3,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(159720,1940284000182472704,1979737429467095041,2053713167413153793,'0102','粤菜',2053712930682441729,4,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(159721,1940284000182472704,1979737429467095041,2053713197993824257,'0201','包罗万有',2053712946373332994,5,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(159725,1940284000182472704,2069309378492370946,2069319780444803073,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:20:56',NULL,NULL,0),(159726,1940284000182472704,2069309380170092545,2069320145672212481,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:22:23',NULL,NULL,0),(159727,1940284000182472704,2069309381751345153,2069320764197834754,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:24:50',NULL,NULL,0),(159728,1940284000182472704,2069309383236128769,2069321576168951810,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:04',NULL,NULL,0),(159729,1940284000182472704,2069309384725106689,2069321592912613377,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:08',NULL,NULL,0),(159730,1940284000182472704,2069309386209890306,2069321606091116546,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:11',NULL,NULL,0),(159731,1940284000182472704,2069309387703062529,2069321619177345025,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:14',NULL,NULL,0),(159732,1940284000182472704,2069309389309480961,2069321635732262913,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:18',NULL,NULL,0),(159733,1940284000182472704,2069309390785875969,2069321650546544641,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:22',NULL,NULL,0),(159734,1940284000182472704,2069309392262270977,2069321676060495874,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:28',NULL,NULL,0),(159735,1940284000182472704,2069309393730277378,2069321690891554818,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:31',NULL,NULL,0),(159736,1940284000182472704,2069309395206672385,2069321707383558146,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:35',NULL,NULL,0),(159737,1940284000182472704,2069309400239837185,2069321722176868354,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:39',NULL,NULL,0),(159738,1940284000182472704,2069309408972378114,2069321736970178561,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:42',NULL,NULL,0),(159739,1940284000182472704,2069309410448773122,2069321750027046914,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:46',NULL,NULL,0),(159740,1940284000182472704,2069309414605328385,2069321779139710977,'01','E2E-AUTO-券包分类',NULL,1,NULL,NULL,'2026-06-23 15:28:52',NULL,NULL,0),(159741,1940284000182472704,2069309378492370946,2069330660825894913,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:10',NULL,NULL,0),(159742,1940284000182472704,2069309380170092545,2069330676265127938,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:14',NULL,NULL,0),(159743,1940284000182472704,2069309381751345153,2069330691524005890,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:17',NULL,NULL,0),(159744,1940284000182472704,2069309383236128769,2069330708020203522,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:21',NULL,NULL,0),(159745,1940284000182472704,2069309384725106689,2069330721110626306,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:24',NULL,NULL,0),(159746,1940284000182472704,2069309386209890306,2069330739334877186,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:29',NULL,NULL,0),(159747,1940284000182472704,2069309387703062529,2069330754123993090,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:32',NULL,NULL,0),(159748,1940284000182472704,2069309389309480961,2069330767239581698,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:35',NULL,NULL,0),(159749,1940284000182472704,2069309390785875969,2069330780317421569,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:39',NULL,NULL,0),(159750,1940284000182472704,2069309392262270977,2069330793307181057,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:42',NULL,NULL,0),(159751,1940284000182472704,2069309393730277378,2069330806393409537,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:45',NULL,NULL,0),(159752,1940284000182472704,2069309395206672385,2069330821140582401,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:48',NULL,NULL,0),(159753,1940284000182472704,2069309400239837185,2069330835866783746,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:52',NULL,NULL,0),(159754,1940284000182472704,2069309408972378114,2069330858620882945,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:04:57',NULL,NULL,0),(159755,1940284000182472704,2069309410448773122,2069330873393221634,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:05:01',NULL,NULL,0),(159756,1940284000182472704,2069309414605328385,2069330889872642049,'02','E2E-AUTO-新人礼包分类',NULL,3,NULL,NULL,'2026-06-23 16:05:05',NULL,NULL,0),(159760,1940284000182472704,2056296261098147841,2069352451048869890,'01','E2E-AUTO-消费赠券边界测试分类',NULL,1,NULL,NULL,'2026-06-23 17:30:45',NULL,NULL,0),(159763,1940284000182472704,2056296261098147841,2069362342484381698,'02','赠券类',NULL,3,NULL,NULL,'2026-06-23 18:10:04',NULL,NULL,0),(159841,1940284000182472704,1942885905090105345,2053712930682441729,'01','中厨',NULL,1,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(159842,1940284000182472704,1942885905090105345,2053712946373332994,'02','点心',NULL,2,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(159843,1940284000182472704,1942885905090105345,2053713149717385217,'0101','湘菜',2053712930682441729,3,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(159844,1940284000182472704,1942885905090105345,2053713167413153793,'0102','粤菜',2053712930682441729,4,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(159845,1940284000182472704,1942885905090105345,2053713197993824257,'0201','包罗万有',2053712946373332994,5,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0);
/*!40000 ALTER TABLE `sc_product_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_product_unit`
--

DROP TABLE IF EXISTS `sc_product_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_product_unit` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `product_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商品id',
  `product_lid` bigint NOT NULL COMMENT '商品lid',
  `type_` int NOT NULL COMMENT '单位类型',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单位名称',
  `price` decimal(24,6) NOT NULL COMMENT '单位价格',
  `make_duration` int DEFAULT NULL COMMENT '制作时长',
  `process_flow` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '工艺流程',
  `weight` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '重量',
  `raw_cost` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '原材料成本',
  `gross_rate` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '毛利率',
  `assist_cost` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '辅助成本',
  `total_cost` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '综合总成本',
  `profit` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '纯利润',
  `profit_rate` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '纯利率',
  `cost_rate` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '成本率',
  `raw_weight` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '原料重量',
  `net_weight` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '净料重量',
  `cooked_weight` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '熟菜重量',
  `amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '金额（元）',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_product_lid` (`mid`,`product_lid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2219645 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品单位';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_product_unit`
--

LOCK TABLES `sc_product_unit` WRITE;
/*!40000 ALTER TABLE `sc_product_unit` DISABLE KEYS */;
INSERT INTO `sc_product_unit` VALUES (2218844,1978646278361620480,2038890034900373506,2038895404669739010,'0101001',2038895404669739010,2,'份',26.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:25:20',NULL,NULL,0),(2218845,1978646278361620480,2038890034900373506,2038895489956716545,'0101002',2038895489956716545,2,'份',56.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:25:40',NULL,NULL,0),(2218846,1978646278361620480,2038890034900373506,2038895585872060418,'0001014',2038895585872060418,2,'26',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218847,1978646278361620480,2038890034900373506,2038895585876254722,'0001015',2038895585876254722,2,'56',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218848,1978646278361620480,2038890034900373506,2038895585876254723,'0001017',2038895585876254723,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218849,1978646278361620480,2038890034900373506,2038895585876254724,'0001018',2038895585876254724,2,'43',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218850,1978646278361620480,2038890034900373506,2038895585880449025,'0001028',2038895585880449025,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218851,1978646278361620480,2038890034900373506,2038895585880449026,'0001029',2038895585880449026,2,'19',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218852,1978646278361620480,2038890034900373506,2038895585880449027,'0001030',2038895585880449027,2,'19',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218853,1978646278361620480,2038890034900373506,2038895585884643330,'0001054',2038895585884643330,2,'488',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218854,1978646278361620480,2038890034900373506,2038895585884643331,'0001055',2038895585884643331,2,'488',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218855,1978646278361620480,2038890034900373506,2038895585884643332,'0001056',2038895585884643332,2,'108',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218856,1978646278361620480,2038890034900373506,2038895585888837634,'0001058',2038895585888837634,2,'62',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218857,1978646278361620480,2038890034900373506,2038895585888837635,'0001060',2038895585888837635,2,'69',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218858,1978646278361620480,2038890034900373506,2038895585888837636,'0001062',2038895585888837636,2,'218',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218859,1978646278361620480,2038890034900373506,2038895585888837637,'0001063',2038895585888837637,2,'198',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218860,1978646278361620480,2038890034900373506,2038895585893031937,'0001064',2038895585893031937,2,'188',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218861,1978646278361620480,2038890034900373506,2038895585893031938,'0001065',2038895585893031938,2,'148',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218862,1978646278361620480,2038890034900373506,2038895585893031939,'0001068',2038895585893031939,2,'62',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218863,1978646278361620480,2038890034900373506,2038895585897226241,'0001069',2038895585897226241,2,'72',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218864,1978646278361620480,2038890034900373506,2038895585897226242,'0001070',2038895585897226242,2,'198',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218865,1978646278361620480,2038890034900373506,2038895585897226243,'0001071',2038895585897226243,2,'188',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218866,1978646278361620480,2038890034900373506,2038895585901420546,'0001072',2038895585901420546,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218867,1978646278361620480,2038890034900373506,2038895585901420547,'0001073',2038895585901420547,2,'16',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218868,1978646278361620480,2038890034900373506,2038895585901420548,'0001074',2038895585901420548,2,'18',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218869,1978646278361620480,2038890034900373506,2038895585905614849,'0001075',2038895585905614849,2,'18',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218870,1978646278361620480,2038890034900373506,2038895585905614850,'0001076',2038895585905614850,2,'16',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218871,1978646278361620480,2038890034900373506,2038895585905614851,'0001077',2038895585905614851,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218872,1978646278361620480,2038890034900373506,2038895585905614854,'0001078',2038895585905614854,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218873,1978646278361620480,2038890034900373506,2038895585909809153,'0001079',2038895585909809153,2,'26',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218874,1978646278361620480,2038890034900373506,2038895585909809156,'0001080',2038895585909809156,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218875,1978646278361620480,2038890034900373506,2038895585909809157,'0001081',2038895585909809157,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218876,1978646278361620480,2038890034900373506,2038895585909809158,'0001082',2038895585909809158,2,'188',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218877,1978646278361620480,2038890034900373506,2038895585914003457,'0001083',2038895585914003457,2,'148',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218878,1978646278361620480,2038890034900373506,2038895585914003458,'0001084',2038895585914003458,2,'62',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218879,1978646278361620480,2038890034900373506,2038895585914003459,'0001086',2038895585914003459,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218880,1978646278361620480,2038890034900373506,2038895585918197762,'0001087',2038895585918197762,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218881,1978646278361620480,2038890034900373506,2038895585918197763,'0001088',2038895585918197763,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218882,1978646278361620480,2038890034900373506,2038895585918197764,'0001089',2038895585918197764,2,'59',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218883,1978646278361620480,2038890034900373506,2038895585918197765,'0001090',2038895585918197765,2,'35',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218884,1978646278361620480,2038890034900373506,2038895585922392065,'0001091',2038895585922392065,2,'55',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218885,1978646278361620480,2038890034900373506,2038895585922392066,'0001092',2038895585922392066,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218886,1978646278361620480,2038890034900373506,2038895585922392069,'0001096',2038895585922392069,2,'32',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218887,1978646278361620480,2038890034900373506,2038895585922392070,'0001097',2038895585922392070,2,'69',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218888,1978646278361620480,2038890034900373506,2038895585926586370,'0001098',2038895585926586370,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218889,1978646278361620480,2038890034900373506,2038895585926586371,'0001099',2038895585926586371,2,'178',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218890,1978646278361620480,2038890034900373506,2038895585926586372,'0001100',2038895585926586372,2,'43',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218891,1978646278361620480,2038890034900373506,2038895585930780673,'0001101',2038895585930780673,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218892,1978646278361620480,2038890034900373506,2038895585930780674,'0001102',2038895585930780674,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218893,1978646278361620480,2038890034900373506,2038895585930780675,'0001103',2038895585930780675,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218894,1978646278361620480,2038890034900373506,2038895585934974977,'0001104',2038895585934974977,2,'63',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218895,1978646278361620480,2038890034900373506,2038895585934974978,'0001105',2038895585934974978,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218896,1978646278361620480,2038890034900373506,2038895585934974979,'0001106',2038895585934974979,2,'168',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218897,1978646278361620480,2038890034900373506,2038895585934974980,'0001108',2038895585934974980,2,'158',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218898,1978646278361620480,2038890034900373506,2038895585939169281,'0001109',2038895585939169281,2,'48',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218899,1978646278361620480,2038890034900373506,2038895585939169282,'0001110',2038895585939169282,2,'45',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218900,1978646278361620480,2038890034900373506,2038895585939169283,'0001111',2038895585939169283,2,'58',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218901,1978646278361620480,2038890034900373506,2038895585939169284,'0001112',2038895585939169284,2,'62',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218902,1978646278361620480,2038890034900373506,2038895585943363586,'0001113',2038895585943363586,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218903,1978646278361620480,2038890034900373506,2038895585943363587,'0001114',2038895585943363587,2,'66',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218904,1978646278361620480,2038890034900373506,2038895585943363588,'0001115',2038895585943363588,2,'43',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218905,1978646278361620480,2038890034900373506,2038895585947557889,'0001116',2038895585947557889,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218906,1978646278361620480,2038890034900373506,2038895585947557890,'0001117',2038895585947557890,2,'79',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218907,1978646278361620480,2038890034900373506,2038895585947557891,'0001118',2038895585947557891,2,'148',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218908,1978646278361620480,2038890034900373506,2038895585947557892,'0001119',2038895585947557892,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218909,1978646278361620480,2038890034900373506,2038895585951752194,'0001120',2038895585951752194,2,'45',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218910,1978646278361620480,2038890034900373506,2038895585951752195,'0001121',2038895585951752195,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218911,1978646278361620480,2038890034900373506,2038895585951752196,'0001122',2038895585951752196,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218912,1978646278361620480,2038890034900373506,2038895585951752197,'0001124',2038895585951752197,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218913,1978646278361620480,2038890034900373506,2038895585955946497,'0001125',2038895585955946497,2,'48',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218914,1978646278361620480,2038890034900373506,2038895585955946498,'0001126',2038895585955946498,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218915,1978646278361620480,2038890034900373506,2038895585955946499,'0001127',2038895585955946499,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218916,1978646278361620480,2038890034900373506,2038895585960140802,'0001128',2038895585960140802,2,'168',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218917,1978646278361620480,2038890034900373506,2038895585960140803,'0001129',2038895585960140803,2,'58',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218918,1978646278361620480,2038890034900373506,2038895585960140804,'0001130',2038895585960140804,2,'58',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218919,1978646278361620480,2038890034900373506,2038895585960140805,'0001131',2038895585960140805,2,'32',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218920,1978646278361620480,2038890034900373506,2038895585964335105,'0001132',2038895585964335105,2,'32.8',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218921,1978646278361620480,2038890034900373506,2038895585964335106,'0001133',2038895585964335106,2,'23.8',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218922,1978646278361620480,2038890034900373506,2038895585964335107,'0001134',2038895585964335107,2,'32.8',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218923,1978646278361620480,2038890034900373506,2038895585964335108,'0001135',2038895585964335108,2,'48',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218924,1978646278361620480,2038890034900373506,2038895585964335109,'0001136',2038895585964335109,2,'45',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218925,1978646278361620480,2038890034900373506,2038895585968529409,'0001137',2038895585968529409,2,'43',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218926,1978646278361620480,2038890034900373506,2038895585968529410,'0001138',2038895585968529410,2,'43',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218927,1978646278361620480,2038890034900373506,2038895585968529411,'0001139',2038895585968529411,2,'25',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218928,1978646278361620480,2038890034900373506,2038895585968529412,'0001140',2038895585968529412,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218929,1978646278361620480,2038890034900373506,2038895585972723714,'0001141',2038895585972723714,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218930,1978646278361620480,2038890034900373506,2038895585972723715,'0001142',2038895585972723715,2,'23',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218931,1978646278361620480,2038890034900373506,2038895585972723716,'0003455',2038895585972723716,2,'178',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218932,1978646278361620480,2038890034900373506,2038895585972723717,'0003457',2038895585972723717,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218933,1978646278361620480,2038890034900373506,2038895585976918018,'0003726',2038895585976918018,2,'48',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218934,1978646278361620480,2038890034900373506,2038895585976918019,'0003727',2038895585976918019,2,'168',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218935,1978646278361620480,2038890034900373506,2038895585976918020,'0003728',2038895585976918020,2,'218',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218936,1978646278361620480,2038890034900373506,2038895585981112321,'0003729',2038895585981112321,2,'218',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218937,1978646278361620480,2038890034900373506,2038895585981112322,'0003732',2038895585981112322,2,'52',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218938,1978646278361620480,2038890034900373506,2038895585981112323,'0003733',2038895585981112323,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218939,1978646278361620480,2038890034900373506,2038895585981112324,'0003734',2038895585981112324,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218940,1978646278361620480,2038890034900373506,2038895585981112325,'0003735',2038895585981112325,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218941,1978646278361620480,2038890034900373506,2038895585985306626,'0003738',2038895585985306626,2,'56',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218942,1978646278361620480,2038890034900373506,2038895585985306627,'0003739',2038895585985306627,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218943,1978646278361620480,2038890034900373506,2038895585985306628,'0003740',2038895585985306628,2,'98',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218944,1978646278361620480,2038890034900373506,2038895585985306629,'0003743',2038895585985306629,2,'72',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218945,1978646278361620480,2038890034900373506,2038895585985306630,'0003774',2038895585985306630,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218946,1978646278361620480,2038890034900373506,2038895585989500929,'0003775',2038895585989500929,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218947,1978646278361620480,2038890034900373506,2038895585989500930,'0003886',2038895585989500930,2,'138',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218948,1978646278361620480,2038890034900373506,2038895585989500931,'0003887',2038895585989500931,2,'33',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218949,1978646278361620480,2038890034900373506,2038895585989500932,'0003888',2038895585989500932,2,'59',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218950,1978646278361620480,2038890034900373506,2038895585989500933,'0003889',2038895585989500933,2,'208',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218951,1978646278361620480,2038890034900373506,2038895585993695233,'0003890',2038895585993695233,2,'168',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218952,1978646278361620480,2038890034900373506,2038895585993695234,'0003891',2038895585993695234,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218953,1978646278361620480,2038890034900373506,2038895585993695235,'0003892',2038895585993695235,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218954,1978646278361620480,2038890034900373506,2038895585993695236,'0003893',2038895585993695236,2,'108',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218955,1978646278361620480,2038890034900373506,2038895585997889538,'0003894',2038895585997889538,2,'158',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218956,1978646278361620480,2038890034900373506,2038895585997889539,'0003895',2038895585997889539,2,'238',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218957,1978646278361620480,2038890034900373506,2038895585997889540,'0003896',2038895585997889540,2,'138',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218958,1978646278361620480,2038890034900373506,2038895585997889541,'0003898',2038895585997889541,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218959,1978646278361620480,2038890034900373506,2038895586127912962,'0003901',2038895586127912962,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218960,1978646278361620480,2038890034900373506,2038895586148884481,'0003902',2038895586148884481,2,'188',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218961,1978646278361620480,2038890034900373506,2038895586148884482,'0003903',2038895586148884482,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218962,1978646278361620480,2038890034900373506,2038895586153078785,'0003904',2038895586153078785,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218963,1978646278361620480,2038890034900373506,2038895586153078786,'0003905',2038895586153078786,2,'98',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218964,1978646278361620480,2038890034900373506,2038895586153078787,'0003906',2038895586153078787,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218965,1978646278361620480,2038890034900373506,2038895586153078788,'0003907',2038895586153078788,2,'23',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218966,1978646278361620480,2038890034900373506,2038895586199216129,'0003908',2038895586199216129,2,'75',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218967,1978646278361620480,2038890034900373506,2038895586232770561,'0003909',2038895586232770561,2,'52',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218968,1978646278361620480,2038890034900373506,2038895586274713602,'0003910',2038895586274713602,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218969,1978646278361620480,2038890034900373506,2038895586274713603,'0003911',2038895586274713603,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218970,1978646278361620480,2038890034900373506,2038895586278907905,'0003912',2038895586278907905,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218971,1978646278361620480,2038890034900373506,2038895586278907906,'0003913',2038895586278907906,2,'35',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218972,1978646278361620480,2038890034900373506,2038895586278907907,'0003914',2038895586278907907,2,'15',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218973,1978646278361620480,2038890034900373506,2038895586283102209,'0003915',2038895586283102209,2,'16',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218974,1978646278361620480,2038890034900373506,2038895586283102210,'0003916',2038895586283102210,2,'48',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218975,1978646278361620480,2038890034900373506,2038895586283102211,'0003917',2038895586283102211,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218976,1978646278361620480,2038890034900373506,2038895586283102212,'0003919',2038895586283102212,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218977,1978646278361620480,2038890034900373506,2038895586287296513,'0003921',2038895586287296513,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218978,1978646278361620480,2038890034900373506,2038895586287296514,'0003922',2038895586287296514,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218979,1978646278361620480,2038890034900373506,2038895586287296515,'0003924',2038895586287296515,2,'75',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218980,1978646278361620480,2038890034900373506,2038895586287296516,'0003925',2038895586287296516,2,'58',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218981,1978646278361620480,2038890034900373506,2038895586291490817,'0003926',2038895586291490817,2,'53',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218982,1978646278361620480,2038890034900373506,2038895586291490818,'0003927',2038895586291490818,2,'53',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218983,1978646278361620480,2038890034900373506,2038895586291490819,'0003928',2038895586291490819,2,'58',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218984,1978646278361620480,2038890034900373506,2038895586291490820,'0003929',2038895586291490820,2,'28',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218985,1978646278361620480,2038890034900373506,2038895586295685121,'0003931',2038895586295685121,2,'33',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218986,1978646278361620480,2038890034900373506,2038895586295685122,'0003932',2038895586295685122,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218987,1978646278361620480,2038890034900373506,2038895586295685123,'0003933',2038895586295685123,2,'53',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218988,1978646278361620480,2038890034900373506,2038895586295685124,'0003934',2038895586295685124,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218989,1978646278361620480,2038890034900373506,2038895586299879426,'0003935',2038895586299879426,2,'73',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218990,1978646278361620480,2038890034900373506,2038895586299879427,'0003936',2038895586299879427,2,'53',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218991,1978646278361620480,2038890034900373506,2038895586299879428,'0003937',2038895586299879428,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218992,1978646278361620480,2038890034900373506,2038895586299879429,'0003938',2038895586299879429,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218993,1978646278361620480,2038890034900373506,2038895586304073729,'0003939',2038895586304073729,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218994,1978646278361620480,2038890034900373506,2038895586304073730,'0003940',2038895586304073730,2,'56',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218995,1978646278361620480,2038890034900373506,2038895586304073731,'0003942',2038895586304073731,2,'18',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218996,1978646278361620480,2038890034900373506,2038895586304073732,'0003943',2038895586304073732,2,'32',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218997,1978646278361620480,2038890034900373506,2038895586308268033,'0003944',2038895586308268033,2,'20',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218998,1978646278361620480,2038890034900373506,2038895586308268034,'0003945',2038895586308268034,2,'12',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2218999,1978646278361620480,2038890034900373506,2038895586308268035,'0003946',2038895586308268035,2,'12',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219000,1978646278361620480,2038890034900373506,2038895586312462337,'0000001',2038895586312462337,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219001,1978646278361620480,2038890034900373506,2038895586312462340,'0001019',2038895586312462340,2,'36',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219002,1978646278361620480,2038890034900373506,2038895586312462341,'0000002',2038895586312462341,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219003,1978646278361620480,2038890034900373506,2038895586312462342,'0000003',2038895586312462342,2,'59',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219004,1978646278361620480,2038890034900373506,2038895586316656641,'0000004',2038895586316656641,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219005,1978646278361620480,2038890034900373506,2038895586316656642,'0001022',2038895586316656642,2,'36',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219006,1978646278361620480,2038890034900373506,2038895586316656645,'0001027',2038895586316656645,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219007,1978646278361620480,2038890034900373506,2038895586316656646,'0000005',2038895586316656646,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219008,1978646278361620480,2038890034900373506,2038895586320850945,'0001023',2038895586320850945,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219009,1978646278361620480,2038890034900373506,2038895586320850946,'0000006',2038895586320850946,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219010,1978646278361620480,2038890034900373506,2038895586320850947,'0001024',2038895586320850947,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219011,1978646278361620480,2038890034900373506,2038895586320850948,'0000007',2038895586320850948,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219012,1978646278361620480,2038890034900373506,2038895586325045250,'0001025',2038895586325045250,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219013,1978646278361620480,2038890034900373506,2038895586325045251,'0000008',2038895586325045251,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219014,1978646278361620480,2038890034900373506,2038895586325045252,'0001026',2038895586325045252,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219015,1978646278361620480,2038890034900373506,2038895586325045253,'0000009',2038895586325045253,2,'16',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219016,1978646278361620480,2038890034900373506,2038895586329239553,'0002027',2038895586329239553,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219017,1978646278361620480,2038890034900373506,2038895586329239554,'0000010',2038895586329239554,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219018,1978646278361620480,2038890034900373506,2038895586329239555,'0000051',2038895586329239555,2,'33',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219019,1978646278361620480,2038890034900373506,2038895586392154113,'0000052',2038895586392154113,2,'33',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219020,1978646278361620480,2038890034900373506,2038895586396348417,'0000069',2038895586396348417,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219021,1978646278361620480,2038890034900373506,2038895586396348418,'0000013',2038895586396348418,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219022,1978646278361620480,2038890034900373506,2038895586396348419,'0000070',2038895586396348419,2,'36',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219023,1978646278361620480,2038890034900373506,2038895586400542722,'0000014',2038895586400542722,2,'16',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219024,1978646278361620480,2038890034900373506,2038895586400542723,'00000NQ',2038895586400542723,2,'35',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219025,1978646278361620480,2038890034900373506,2038895586400542724,'0000015',2038895586400542724,2,'28',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219026,1978646278361620480,2038890034900373506,2038895586400542725,'00000NR',2038895586400542725,2,'35',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219027,1978646278361620480,2038890034900373506,2038895586404737026,'0000016',2038895586404737026,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219028,1978646278361620480,2038890034900373506,2038895586404737027,'0000017',2038895586404737027,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219029,1978646278361620480,2038890034900373506,2038895586404737028,'0000018',2038895586404737028,2,'69',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219030,1978646278361620480,2038890034900373506,2038895586404737029,'0S01003',2038895586404737029,2,'42',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219031,1978646278361620480,2038890034900373506,2038895586404737030,'0000019',2038895586404737030,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219032,1978646278361620480,2038890034900373506,2038895586408931330,'0S01004',2038895586408931330,2,'42',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219033,1978646278361620480,2038890034900373506,2038895586408931331,'0000020',2038895586408931331,2,'33',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219034,1978646278361620480,2038890034900373506,2038895586408931332,'0S01005',2038895586408931332,2,'48',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219035,1978646278361620480,2038890034900373506,2038895586413125633,'0000021',2038895586413125633,2,'58',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219036,1978646278361620480,2038890034900373506,2038895586413125636,'0001031',2038895586413125636,2,'36',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219037,1978646278361620480,2038890034900373506,2038895586413125637,'0000022',2038895586413125637,2,'32',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219038,1978646278361620480,2038890034900373506,2038895586413125638,'0001032',2038895586413125638,2,'15',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219039,1978646278361620480,2038890034900373506,2038895586417319938,'0000023',2038895586417319938,2,'59',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219040,1978646278361620480,2038890034900373506,2038895586417319939,'0001033',2038895586417319939,2,'38',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219041,1978646278361620480,2038890034900373506,2038895586417319940,'0000024',2038895586417319940,2,'79',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219042,1978646278361620480,2038890034900373506,2038895586417319941,'0001034',2038895586417319941,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219043,1978646278361620480,2038890034900373506,2038895586417319942,'0000025',2038895586417319942,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219044,1978646278361620480,2038890034900373506,2038895586421514242,'0001035',2038895586421514242,2,'36',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219045,1978646278361620480,2038890034900373506,2038895586421514243,'0000026',2038895586421514243,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219046,1978646278361620480,2038890034900373506,2038895586421514244,'0001036',2038895586421514244,2,'168',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219047,1978646278361620480,2038890034900373506,2038895586421514245,'0000027',2038895586421514245,2,'36',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219048,1978646278361620480,2038890034900373506,2038895586425708546,'0001037',2038895586425708546,2,'26',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219049,1978646278361620480,2038890034900373506,2038895586425708549,'0000028',2038895586425708549,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219050,1978646278361620480,2038890034900373506,2038895586425708550,'0001038',2038895586425708550,2,'38',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219051,1978646278361620480,2038890034900373506,2038895586425708551,'0000029',2038895586425708551,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219052,1978646278361620480,2038890034900373506,2038895586429902850,'0001039',2038895586429902850,2,'138',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219053,1978646278361620480,2038890034900373506,2038895586429902851,'0001040',2038895586429902851,2,'98',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219054,1978646278361620480,2038890034900373506,2038895586429902852,'0000031',2038895586429902852,2,'79',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219055,1978646278361620480,2038890034900373506,2038895586429902853,'0001043',2038895586429902853,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219056,1978646278361620480,2038890034900373506,2038895586434097154,'0000032',2038895586434097154,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219057,1978646278361620480,2038890034900373506,2038895586434097155,'0001044',2038895586434097155,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219058,1978646278361620480,2038890034900373506,2038895586434097156,'0000033',2038895586434097156,2,'79',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219059,1978646278361620480,2038890034900373506,2038895586434097157,'0001047',2038895586434097157,2,'98',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219060,1978646278361620480,2038890034900373506,2038895586438291457,'0001046',2038895586438291457,2,'138',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219061,1978646278361620480,2038890034900373506,2038895586438291458,'0000035',2038895586438291458,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219062,1978646278361620480,2038890034900373506,2038895586438291459,'0001048',2038895586438291459,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219063,1978646278361620480,2038890034900373506,2038895586438291460,'0000036',2038895586438291460,2,'33',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219064,1978646278361620480,2038890034900373506,2038895586442485761,'0001049',2038895586442485761,2,'98',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219065,1978646278361620480,2038890034900373506,2038895586442485762,'0000037',2038895586442485762,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219066,1978646278361620480,2038890034900373506,2038895586442485763,'0001050',2038895586442485763,2,'108',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219067,1978646278361620480,2038890034900373506,2038895586442485764,'0000038',2038895586442485764,2,'36',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219068,1978646278361620480,2038890034900373506,2038895586446680065,'0001051',2038895586446680065,2,'138',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219069,1978646278361620480,2038890034900373506,2038895586446680066,'0000039',2038895586446680066,2,'19',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219070,1978646278361620480,2038890034900373506,2038895586446680067,'0001052',2038895586446680067,2,'62',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219071,1978646278361620480,2038890034900373506,2038895586446680068,'0000040',2038895586446680068,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219072,1978646278361620480,2038890034900373506,2038895586450874369,'0001053',2038895586450874369,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219073,1978646278361620480,2038890034900373506,2038895586450874370,'0000041',2038895586450874370,2,'36',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219074,1978646278361620480,2038890034900373506,2038895586450874371,'0000042',2038895586450874371,2,'5',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219075,1978646278361620480,2038890034900373506,2038895586450874372,'0000043',2038895586450874372,2,'43',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219076,1978646278361620480,2038890034900373506,2038895586450874373,'0000044',2038895586450874373,2,'58',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219077,1978646278361620480,2038890034900373506,2038895586455068674,'0000048',2038895586455068674,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219078,1978646278361620480,2038890034900373506,2038895586455068675,'0000049',2038895586455068675,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219079,1978646278361620480,2038890034900373506,2038895586455068676,'0000050',2038895586455068676,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219080,1978646278361620480,2038890034900373506,2038895586459262978,'0000071',2038895586459262978,2,'23',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219081,1978646278361620480,2038890034900373506,2038895586459262979,'0000073',2038895586459262979,2,'28',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219082,1978646278361620480,2038890034900373506,2038895586463457282,'0000074',2038895586463457282,2,'16',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219083,1978646278361620480,2038890034900373506,2038895586463457283,'0000075',2038895586463457283,2,'16',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219084,1978646278361620480,2038890034900373506,2038895586463457284,'0000076',2038895586463457284,2,'18',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219085,1978646278361620480,2038890034900373506,2038895586467651585,'0000077',2038895586467651585,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219086,1978646278361620480,2038890034900373506,2038895586467651586,'0000078',2038895586467651586,2,'14',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219087,1978646278361620480,2038890034900373506,2038895586471845889,'0000079',2038895586471845889,2,'59',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219088,1978646278361620480,2038890034900373506,2038895586492817410,'0000080',2038895586492817410,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219089,1978646278361620480,2038890034900373506,2038895586497011713,'0000081',2038895586497011713,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219090,1978646278361620480,2038890034900373506,2038895586497011714,'0000082',2038895586497011714,2,'48',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219091,1978646278361620480,2038890034900373506,2038895586497011715,'0000083',2038895586497011715,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219092,1978646278361620480,2038890034900373506,2038895586497011716,'0000084',2038895586497011716,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219093,1978646278361620480,2038890034900373506,2038895586501206017,'0000085',2038895586501206017,2,'48',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219094,1978646278361620480,2038890034900373506,2038895586513788929,'0000087',2038895586513788929,2,'79',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219095,1978646278361620480,2038890034900373506,2038895586513788930,'0000088',2038895586513788930,2,'59',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219096,1978646278361620480,2038890034900373506,2038895586517983234,'0000089',2038895586517983234,2,'59',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219097,1978646278361620480,2038890034900373506,2038895586517983235,'000008A',2038895586517983235,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219098,1978646278361620480,2038890034900373506,2038895586517983236,'000008B',2038895586517983236,2,'69',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219099,1978646278361620480,2038890034900373506,2038895586522177537,'000008E',2038895586522177537,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219100,1978646278361620480,2038890034900373506,2038895586522177538,'000008F',2038895586522177538,2,'33',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219101,1978646278361620480,2038890034900373506,2038895586526371841,'000008G',2038895586526371841,2,'36',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219102,1978646278361620480,2038890034900373506,2038895586526371842,'000008K',2038895586526371842,2,'46',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219103,1978646278361620480,2038890034900373506,2038895586526371843,'000008L',2038895586526371843,2,'98',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219104,1978646278361620480,2038890034900373506,2038895586526371844,'000008M',2038895586526371844,2,'19',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219105,1978646278361620480,2038890034900373506,2038895586530566146,'000008N',2038895586530566146,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219106,1978646278361620480,2038890034900373506,2038895586530566147,'000008O',2038895586530566147,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219107,1978646278361620480,2038890034900373506,2038895586530566148,'000008P',2038895586530566148,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219108,1978646278361620480,2038890034900373506,2038895586530566149,'000008Q',2038895586530566149,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219109,1978646278361620480,2038890034900373506,2038895586530566150,'000008R',2038895586530566150,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219110,1978646278361620480,2038890034900373506,2038895586534760449,'000008S',2038895586534760449,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219111,1978646278361620480,2038890034900373506,2038895586534760450,'00000C1',2038895586534760450,2,'118',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219112,1978646278361620480,2038890034900373506,2038895586534760453,'00000C2',2038895586534760453,2,'218',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219113,1978646278361620480,2038890034900373506,2038895586534760454,'00000C5',2038895586534760454,2,'158',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219114,1978646278361620480,2038890034900373506,2038895586538954754,'00000C6',2038895586538954754,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219115,1978646278361620480,2038890034900373506,2038895586538954755,'00000C7',2038895586538954755,2,'33',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219116,1978646278361620480,2038890034900373506,2038895586538954756,'00000C8',2038895586538954756,2,'55',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219117,1978646278361620480,2038890034900373506,2038895586538954757,'00000C9',2038895586538954757,2,'62',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219118,1978646278361620480,2038890034900373506,2038895586538954758,'00000CA',2038895586538954758,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219119,1978646278361620480,2038890034900373506,2038895586543149058,'00000CB',2038895586543149058,2,'128',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219120,1978646278361620480,2038890034900373506,2038895586543149059,'00000CC',2038895586543149059,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219121,1978646278361620480,2038890034900373506,2038895586543149060,'00000CD',2038895586543149060,2,'88',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219122,1978646278361620480,2038890034900373506,2038895586543149061,'00000CE',2038895586543149061,2,'63',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219123,1978646278361620480,2038890034900373506,2038895586547343361,'00000CF',2038895586547343361,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219124,1978646278361620480,2038890034900373506,2038895586547343362,'00000CG',2038895586547343362,2,'5.99',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219125,1978646278361620480,2038890034900373506,2038895586547343363,'00000CI',2038895586547343363,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219126,1978646278361620480,2038890034900373506,2038895586547343364,'00000CJ',2038895586547343364,2,'58',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219127,1978646278361620480,2038890034900373506,2038895586547343365,'00000CK',2038895586547343365,2,'15',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219128,1978646278361620480,2038890034900373506,2038895586551537666,'00000CL',2038895586551537666,2,'49',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219129,1978646278361620480,2038890034900373506,2038895586551537667,'00000CM',2038895586551537667,2,'68',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219130,1978646278361620480,2038890034900373506,2038895586551537668,'00000CN',2038895586551537668,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219131,1978646278361620480,2038890034900373506,2038895586551537669,'00000CO',2038895586551537669,2,'98',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219132,1978646278361620480,2038890034900373506,2038895586555731969,'00000CP',2038895586555731969,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219133,1978646278361620480,2038890034900373506,2038895586555731970,'00000CR',2038895586555731970,2,'78',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219134,1978646278361620480,2038890034900373506,2038895586555731971,'00000CS',2038895586555731971,2,'53',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219135,1978646278361620480,2038890034900373506,2038895586555731972,'00000CT',2038895586555731972,2,'58',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219136,1978646278361620480,2038890034900373506,2038895586555731973,'00000CU',2038895586555731973,2,'39',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219137,1978646278361620480,2038890034900373506,2038895586559926274,'00000CV',2038895586559926274,2,'28',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219138,1978646278361620480,2038890034900373506,2038895586559926275,'00000CX',2038895586559926275,2,'16',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219139,1978646278361620480,2038890034900373506,2038895586559926276,'00000CY',2038895586559926276,2,'8',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219140,1978646278361620480,2038890034900373506,2038895586559926277,'00000CZ',2038895586559926277,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219141,1978646278361620480,2038890034900373506,2038895586564120577,'00000D0',2038895586564120577,2,'28',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219142,1978646278361620480,2038890034900373506,2038895586564120578,'00000D1',2038895586564120578,2,'29',0.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-03-31 08:26:40',NULL,NULL,0),(2219463,1940284000182472704,1940287289892687874,2041352053147570178,'0101001',2041352053147570178,2,'碗',188.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-04-07 03:07:10',NULL,NULL,0),(2219464,1940284000182472704,2042543010529546242,2042543630806814722,'0101001',2042543630806814722,2,'碗',123.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-04-10 10:02:05',NULL,NULL,1),(2219465,1940284000182472704,2042804773847437313,2042873704147718146,'0101001',2042873704147718146,2,'碗',88.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-04-11 07:53:40',NULL,NULL,0),(2219466,1940284000182472704,1940287289892687874,2049442688793972737,'0101002',2049442688793972737,2,'26',0.010000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-04-29 10:56:28',NULL,NULL,1),(2219467,1940284000182472704,1940287289892687874,2049449428696567810,'0101002',2049449428696567810,2,'26',0.010000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-04-29 11:23:15',NULL,NULL,0),(2219468,1940284000182472704,1979737429467095041,2053713298288021506,'0101001',2053713298288021506,2,'份',65.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(2219469,1940284000182472704,1979737429467095041,2053713338410733569,'0101002',2053713338410733569,2,'份',65.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(2219470,1940284000182472704,1979737429467095041,2053713382140547073,'0101003',2053713382140547073,2,'份',65.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(2219471,1940284000182472704,1979737429467095041,2053713444384018433,'0102001',2053713444384018433,2,'份',58.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(2219472,1940284000182472704,1979737429467095041,2053713543621251074,'0102002',2053713543621251074,2,'份',98.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(2219473,1940284000182472704,1979737429467095041,2053713600915443713,'0201001',2053713600915443713,2,'份',12.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(2219474,1940284000182472704,1979737429467095041,2053713660176764930,'0201002',2053713660176764930,2,'份',13.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(2219475,1940284000182472704,1979737429467095041,2053713712731394050,'0201003',2053713712731394050,2,'份',14.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(2219631,1940284000182472704,1942885905090105345,2053713298288021506,'0101001',2053713298288021506,2,'份',65.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(2219632,1940284000182472704,1942885905090105345,2053713338410733569,'0101002',2053713338410733569,2,'份',65.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(2219633,1940284000182472704,1942885905090105345,2053713382140547073,'0101003',2053713382140547073,2,'份',65.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(2219634,1940284000182472704,1942885905090105345,2053713444384018433,'0102001',2053713444384018433,2,'份',58.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(2219635,1940284000182472704,1942885905090105345,2053713543621251074,'0102002',2053713543621251074,2,'份',98.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(2219636,1940284000182472704,1942885905090105345,2053713600915443713,'0201001',2053713600915443713,2,'份',12.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(2219637,1940284000182472704,1942885905090105345,2053713660176764930,'0201002',2053713660176764930,2,'份',13.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(2219638,1940284000182472704,1942885905090105345,2053713712731394050,'0201003',2053713712731394050,2,'份',14.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0),(2219639,1940284000182472704,1942885905090105345,2086692066618511361,'0102003',2086692066618511361,2,'份',12.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:50',NULL,NULL,0),(2219640,1940284000182472704,1942885905090105345,2086702789432184834,'0102004',2086702789432184834,2,'份',20.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:50',NULL,NULL,0),(2219641,1940284000182472704,1942885905090105345,2087073956195733505,'0201004',2087073956195733505,2,'份',30.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:50',NULL,NULL,0),(2219642,1940284000182472704,1942885905090105345,2087079068779679746,'0101004',2087079068779679746,2,'份',30.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:50',NULL,NULL,0),(2219643,1940284000182472704,1942885905090105345,2087082564052586497,'0101005',2087082564052586497,2,'份',35.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:50',NULL,NULL,0),(2219644,1940284000182472704,1942885905090105345,2087114322471694338,'0101006',2087114322471694338,2,'份',100.000000,NULL,NULL,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,0.000000,NULL,NULL,NULL,'2026-08-11 17:55:50',NULL,NULL,0);
/*!40000 ALTER TABLE `sc_product_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_quote_order`
--

DROP TABLE IF EXISTS `sc_quote_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_quote_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单据编号',
  `report_date` datetime NOT NULL COMMENT '报价日期',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `quote_state` int NOT NULL COMMENT '报价状态',
  `audit_lid` bigint DEFAULT NULL COMMENT '审核人lid',
  `audit_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核人',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `release_lid` bigint DEFAULT NULL COMMENT '发布人lid',
  `release_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发布人',
  `release_time` datetime DEFAULT NULL COMMENT '发布时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_report_date_lid` (`mid`,`report_date`,`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供货商报价单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_quote_order`
--

LOCK TABLES `sc_quote_order` WRITE;
/*!40000 ALTER TABLE `sc_quote_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_quote_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_quote_order_item`
--

DROP TABLE IF EXISTS `sc_quote_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_quote_order_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '报价日期',
  `quote_order_lid` bigint NOT NULL COMMENT '报价单lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `price` decimal(24,6) NOT NULL COMMENT '报价',
  `added_tax_type` int NOT NULL COMMENT '采购税率',
  `last_price` decimal(24,6) DEFAULT NULL COMMENT '上期价格',
  `begin_date` datetime NOT NULL COMMENT '价格生效日期',
  `end_date` datetime NOT NULL COMMENT '价格失效日期',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_report_date_order_lid` (`mid`,`report_date`,`quote_order_lid`) USING BTREE,
  KEY `idx_mid_report_date_goods_lid` (`mid`,`report_date`,`goods_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5784 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供货商报价单物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_quote_order_item`
--

LOCK TABLES `sc_quote_order_item` WRITE;
/*!40000 ALTER TABLE `sc_quote_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_quote_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_quote_order_store`
--

DROP TABLE IF EXISTS `sc_quote_order_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_quote_order_store` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '适用门店sid',
  `report_date` datetime NOT NULL COMMENT '报价日期',
  `quote_order_lid` bigint NOT NULL COMMENT '报价单lid',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_report_date_order_lid` (`mid`,`report_date`,`quote_order_lid`) USING BTREE,
  KEY `idx_mid_report_date_sid` (`mid`,`report_date`,`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供货商报价单适用组织';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_quote_order_store`
--

LOCK TABLES `sc_quote_order_store` WRITE;
/*!40000 ALTER TABLE `sc_quote_order_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_quote_order_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_quote_order_supplier`
--

DROP TABLE IF EXISTS `sc_quote_order_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_quote_order_supplier` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '报价日期',
  `supplier_lid` bigint NOT NULL COMMENT '供货商lid',
  `quote_order_lid` bigint NOT NULL COMMENT '报价单lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_report_date_order_lid` (`mid`,`report_date`,`quote_order_lid`) USING BTREE,
  KEY `idx_mid_report_date_supplier_lid` (`mid`,`report_date`,`supplier_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=344 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供货商报价单适用供货商';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_quote_order_supplier`
--

LOCK TABLES `sc_quote_order_supplier` WRITE;
/*!40000 ALTER TABLE `sc_quote_order_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_quote_order_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_rdc_order`
--

DROP TABLE IF EXISTS `sc_rdc_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_rdc_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '订货单号',
  `store_order_lid` bigint DEFAULT NULL COMMENT '门店订货单lid',
  `store_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '门店订货单号',
  `purchase_order_lid` bigint DEFAULT NULL COMMENT '采购单lid',
  `purchase_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '采购单号',
  `report_date` datetime NOT NULL COMMENT '订货日期',
  `organ_lid` bigint NOT NULL COMMENT '机构lid',
  `order_type` int NOT NULL COMMENT '订货单类型',
  `order_state` int NOT NULL COMMENT '订单状态',
  `rows` int NOT NULL COMMENT '记录数',
  `volume` decimal(24,6) NOT NULL COMMENT '总数量',
  `amount` decimal(24,6) NOT NULL COMMENT '总金额',
  `tax_amount` decimal(24,6) NOT NULL COMMENT '含税金额',
  `indent_volume` decimal(24,6) NOT NULL COMMENT '标准数量',
  `audit_lid` bigint DEFAULT NULL COMMENT '审核人lid',
  `audit_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核人',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `reject_lid` bigint DEFAULT NULL COMMENT '驳回人lid',
  `reject_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '驳回人',
  `reject_time` datetime DEFAULT NULL COMMENT '驳回时间',
  `submit_lid` bigint DEFAULT NULL COMMENT '提交人lid',
  `submit_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '提交人',
  `submit_time` datetime DEFAULT NULL COMMENT '提交时间',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `inspect_rows` int NOT NULL DEFAULT '0' COMMENT '验货记录数',
  `payed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否付款',
  `delivery_fee` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '配送费',
  `paid_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '已付款金额',
  `checked_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '已核销金额',
  `invoice_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '已开金额',
  `settle_state` int NOT NULL DEFAULT '1' COMMENT '结算状态',
  `check_state` int NOT NULL DEFAULT '1' COMMENT '对账状态',
  `check_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '对账人',
  `check_lid` bigint DEFAULT NULL COMMENT '对账人lid',
  `check_time` datetime DEFAULT NULL COMMENT '对账时间',
  `to_paid_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '要付款金额',
  `task_lid` bigint DEFAULT NULL COMMENT '支付任务lid',
  `inspect_rdc_type` int DEFAULT '1' COMMENT '配送中心验货类型',
  `out_at` datetime DEFAULT NULL COMMENT '出库时间',
  `out_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '出库人',
  `inbound_lid` bigint DEFAULT NULL COMMENT '验货入库lid',
  `inbound_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '验货入库单号',
  `outbound_lid` bigint DEFAULT NULL COMMENT '配送出库lid',
  `outbound_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '配送出库单号',
  `inspect_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '验货人',
  `inspect_time` datetime DEFAULT NULL COMMENT '验货时间',
  `supplier_lid` bigint DEFAULT NULL COMMENT '供货商或者配送出库仓',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date_organ_lid` (`mid`,`report_date`,`organ_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3722 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='配送中心订货单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_rdc_order`
--

LOCK TABLES `sc_rdc_order` WRITE;
/*!40000 ALTER TABLE `sc_rdc_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_rdc_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_rdc_order_item`
--

DROP TABLE IF EXISTS `sc_rdc_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_rdc_order_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '订货日期',
  `rdc_order_lid` bigint NOT NULL COMMENT '配送中心订货单lid',
  `rdc_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '配送中心订货单号',
  `purchase_order_lid` bigint DEFAULT NULL COMMENT '采购单lid',
  `purchase_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '采购单号',
  `org_item_lid` bigint DEFAULT NULL COMMENT '原始物品lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `supplier_lid` bigint NOT NULL COMMENT '供货商lid',
  `organ_lid` bigint NOT NULL COMMENT '机构lid',
  `volume` decimal(24,6) NOT NULL COMMENT '订购数量',
  `indent_volume` decimal(24,6) NOT NULL COMMENT '订购数量',
  `price` decimal(24,6) NOT NULL COMMENT '订购价格',
  `amount` decimal(24,6) NOT NULL COMMENT '订购总额',
  `org_volume` decimal(24,6) NOT NULL COMMENT '原订购数量',
  `org_price` decimal(24,6) NOT NULL COMMENT '原订购价格',
  `org_amount` decimal(24,6) NOT NULL COMMENT '原订购总额',
  `total_amount` decimal(24,6) NOT NULL COMMENT '合计数量',
  `total_volume` decimal(24,6) NOT NULL COMMENT '合计金额',
  `tax_rate` decimal(24,6) NOT NULL COMMENT '税率',
  `arrival_time` datetime NOT NULL COMMENT '到货日期',
  `delivery_type` int NOT NULL COMMENT '配送方式',
  `order_type` int NOT NULL COMMENT '订货单类型',
  `order_state` int NOT NULL COMMENT '订单状态',
  `submitted` tinyint(1) DEFAULT NULL COMMENT '已提交',
  `submitted_lid` bigint DEFAULT NULL COMMENT '提交人lid',
  `submitted_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '提交人',
  `submitted_time` datetime DEFAULT NULL COMMENT '提交时间',
  `split_lid` bigint DEFAULT NULL COMMENT '拆单人lid',
  `split_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '拆单人',
  `split_time` datetime DEFAULT NULL COMMENT '拆单时间',
  `parented` tinyint(1) NOT NULL COMMENT '主单',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `inspect_volume` decimal(24,6) DEFAULT NULL COMMENT '验货数量',
  `inspect_price` decimal(24,6) DEFAULT NULL COMMENT '验货单价',
  `inspect_amount` decimal(24,6) DEFAULT NULL COMMENT '验货金额',
  `inspected_volume` decimal(24,6) DEFAULT NULL COMMENT '已验货数量',
  `inspect_lid` bigint DEFAULT NULL COMMENT '验货人lid',
  `inspect_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '验货人',
  `inspect_time` datetime DEFAULT NULL COMMENT '验货时间',
  `out_volume` decimal(24,6) DEFAULT NULL COMMENT '发货数量',
  `inbound_lid` bigint DEFAULT NULL COMMENT '入库单lid',
  `inbound_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '入库单编号',
  `production_date` datetime DEFAULT NULL COMMENT '生产日期',
  `batch_no` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '批次号',
  `inspect_remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '验货备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `out_remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发货备注',
  `weighted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已称重',
  `scarce` tinyint(1) NOT NULL DEFAULT '0' COMMENT '物品缺货',
  `out_state` int NOT NULL DEFAULT '1' COMMENT '发货状态',
  `out_at` datetime DEFAULT NULL COMMENT '发货时间',
  `out_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发货人',
  `outbound_lid` bigint DEFAULT NULL COMMENT '出库单lid',
  `outbound_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '出库单编号',
  `payed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否付款',
  `delivery_fee` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '配送费',
  `counting_volume` decimal(24,6) DEFAULT NULL COMMENT '计量数量',
  `reject` tinyint(1) DEFAULT '0' COMMENT '拒收',
  `reject_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '拒收人',
  `reject_at` datetime DEFAULT NULL COMMENT '拒收时间',
  `reject_for` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '拒收原因',
  `cancel` tinyint(1) DEFAULT '0' COMMENT '取消',
  `cancel_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '取消人',
  `cancel_at` datetime DEFAULT NULL COMMENT '取消时间',
  `cancel_for` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '取消原因',
  `refund_state` int DEFAULT '0' COMMENT '退货状态',
  `refund_volume` decimal(24,6) DEFAULT NULL COMMENT '退货数量',
  `refund_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退货人',
  `refund_at` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退货时间',
  `refund_for` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退货原因',
  `refund_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退货单号',
  `share_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '分享汇总单号',
  `share_lid` bigint DEFAULT NULL COMMENT '分享汇总单号lid',
  `share_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '分享人',
  `share_at` datetime DEFAULT NULL COMMENT '分享时间',
  `inspect_indent_volume` decimal(24,6) DEFAULT NULL COMMENT '订购验货数量',
  `printed` tinyint(1) DEFAULT '0' COMMENT '打印状态',
  `print_state` int DEFAULT '0' COMMENT '打印状态（位标志组合）',
  `sort_status` int DEFAULT '0' COMMENT '分拣状态：0-未分拣，1-已分拣',
  `edited` tinyint(1) DEFAULT NULL COMMENT '是否编辑',
  `inspect_rdc_type` int DEFAULT '1' COMMENT '配送中心验货类型',
  `diff_amount` decimal(24,10) DEFAULT NULL COMMENT '差异金额',
  `diff_volume` decimal(24,10) DEFAULT NULL COMMENT '差异数量',
  `store_order_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '订货单号',
  `reject_volume` decimal(24,10) DEFAULT NULL COMMENT '驳回数量',
  `cancel_volume` decimal(24,10) DEFAULT NULL COMMENT '报损数量',
  `outbound_amount` decimal(24,10) DEFAULT NULL COMMENT '配送出库金额',
  `edited_by_shop` tinyint DEFAULT '0' COMMENT '门店是否已编辑',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date_rdc_order_lid` (`mid`,`report_date`,`rdc_order_id`) USING BTREE,
  KEY `idx_mid_report_date_lid` (`mid`,`report_date`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=88965 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='配送中心订货单物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_rdc_order_item`
--

LOCK TABLES `sc_rdc_order_item` WRITE;
/*!40000 ALTER TABLE `sc_rdc_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_rdc_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_sale_cost_relate`
--

DROP TABLE IF EXISTS `sc_sale_cost_relate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_sale_cost_relate` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `relate_lid` bigint NOT NULL COMMENT '销售成本分析lid',
  `bill_lid` bigint NOT NULL COMMENT '账单lid',
  `item_lid` bigint NOT NULL COMMENT '账单物品lid',
  `volume` bigint NOT NULL COMMENT '用量',
  `price` decimal(24,6) NOT NULL COMMENT '均价',
  `amount` decimal(24,6) NOT NULL COMMENT '金额',
  `type` int NOT NULL COMMENT '类型 扣库/盘点',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_relate_lid` (`mid`,`relate_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品成本关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_sale_cost_relate`
--

LOCK TABLES `sc_sale_cost_relate` WRITE;
/*!40000 ALTER TABLE `sc_sale_cost_relate` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_sale_cost_relate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_st_account_period`
--

DROP TABLE IF EXISTS `sc_st_account_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_st_account_period` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '会计周期名称',
  `begin_date` datetime DEFAULT NULL COMMENT '开始日期',
  `end_date` datetime DEFAULT NULL COMMENT '结束日期',
  `post_date` datetime DEFAULT NULL COMMENT '转结日期',
  `posted` tinyint(1) DEFAULT NULL COMMENT '是否转结',
  `last_period_lid` bigint DEFAULT NULL COMMENT '上一会计周期',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='会计周期';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_st_account_period`
--

LOCK TABLES `sc_st_account_period` WRITE;
/*!40000 ALTER TABLE `sc_st_account_period` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_st_account_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_st_bill`
--

DROP TABLE IF EXISTS `sc_st_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_st_bill` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL DEFAULT '-1' COMMENT '门店sid',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单据编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year` int NOT NULL COMMENT '年',
  `month` int NOT NULL COMMENT '月',
  `day` int NOT NULL COMMENT '日',
  `type_` int NOT NULL COMMENT '票据类型',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `client` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '客户',
  `client_lid` bigint DEFAULT NULL COMMENT '客户编号',
  `applicant_lid` bigint DEFAULT NULL COMMENT '申请人编号',
  `applicant` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '申请人',
  `keeper_lid` bigint DEFAULT NULL COMMENT '库管员编号',
  `keeper` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '库管员',
  `purchase_order_lid` bigint DEFAULT NULL COMMENT '采购订单lid',
  `maker_lid` bigint DEFAULT NULL COMMENT '制单人编号',
  `maker` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '制单人',
  `manual_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '手工单号',
  `supplier_lid` bigint NOT NULL DEFAULT '-1' COMMENT '供货商lid',
  `manager_lid` bigint DEFAULT NULL COMMENT '经办人编号',
  `manager` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '经办人',
  `arrival_time` datetime DEFAULT NULL COMMENT '到货日期',
  `make_time` datetime DEFAULT NULL COMMENT '开票时间',
  `post_time` datetime DEFAULT NULL COMMENT '过帐日期',
  `poster_lid` bigint DEFAULT NULL COMMENT '过账人编号',
  `poster` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '过账人',
  `posted` int NOT NULL COMMENT '是否过账',
  `post_id` bigint DEFAULT NULL COMMENT '过账顺序;用于单据排序',
  `last_mod_time` datetime DEFAULT NULL COMMENT '上一次修改的时间',
  `total_amount` decimal(24,6) DEFAULT NULL COMMENT '金额合计',
  `total_volume` decimal(24,6) DEFAULT NULL COMMENT '数量合计',
  `ref_flag` int NOT NULL COMMENT '是否冲红',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库编号',
  `take_warehouse_lid` bigint DEFAULT NULL COMMENT '领用仓库编号',
  `in_bill_lid` bigint DEFAULT NULL COMMENT '调入仓库单据编号',
  `in_warehouse_lid` bigint DEFAULT NULL COMMENT '调入仓库编号',
  `out_bill_lid` bigint DEFAULT NULL COMMENT '调出仓库单据编号',
  `out_warehouse_lid` bigint DEFAULT NULL COMMENT '调出仓库编号',
  `org_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '原始单号',
  `shipper` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发货方',
  `consignee` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收货方',
  `in_out_flag` int DEFAULT NULL COMMENT '进出仓库的标志位',
  `check_bill_lid` bigint DEFAULT NULL COMMENT '盘点单lid',
  `org_bill_lid` bigint DEFAULT NULL COMMENT '原订单编号',
  `account_period_lid` bigint DEFAULT NULL COMMENT '所属会计期间编号',
  `order_src` int NOT NULL COMMENT '单据来源',
  `purchaser_lid` bigint DEFAULT NULL COMMENT '采购商商户id',
  `relate_bill_lid` bigint DEFAULT NULL COMMENT '关联单据编号,入库和关联供货商单使用',
  `relate_bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '关联单号',
  `shipment_bill_lid` bigint DEFAULT NULL COMMENT '发货单号',
  `receipt_bill_lid` bigint DEFAULT NULL COMMENT '收货单号',
  `tax_amount` decimal(24,6) NOT NULL COMMENT '税额',
  `qi_state` int NOT NULL COMMENT '质检状态',
  `print_state` int NOT NULL COMMENT '打印状态',
  `promotion_amount` decimal(24,6) NOT NULL COMMENT '优惠金额',
  `paid_amount` decimal(24,6) NOT NULL COMMENT '已付款金额',
  `checked_amount` decimal(24,6) NOT NULL COMMENT '已核销金额',
  `invoice_amount` decimal(24,6) NOT NULL COMMENT '已开金额',
  `settle_state` int NOT NULL COMMENT '结算状态',
  `check_state` int NOT NULL COMMENT '对账状态',
  `check_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '对账人',
  `check_lid` bigint DEFAULT NULL COMMENT '对账人lid',
  `check_time` datetime DEFAULT NULL COMMENT '对账时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint NOT NULL COMMENT '是否删除',
  `delivery_type` int DEFAULT '1' COMMENT '配送方式',
  `process_factory_lid` bigint DEFAULT NULL COMMENT '加工厂lid',
  `dest_sid` bigint DEFAULT NULL COMMENT '目的仓库sid',
  `amount_sub` tinyint DEFAULT '0' COMMENT '是否按金额扣减',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=67482 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='仓库单据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_st_bill`
--

LOCK TABLES `sc_st_bill` WRITE;
/*!40000 ALTER TABLE `sc_st_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_st_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_st_bill_item`
--

DROP TABLE IF EXISTS `sc_st_bill_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_st_bill_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL DEFAULT '-1' COMMENT '门店sid',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year` int NOT NULL COMMENT '年',
  `month` int NOT NULL COMMENT '月',
  `day` int NOT NULL COMMENT '日',
  `bill_type_` int NOT NULL COMMENT '票据类型',
  `st_bill_lid` bigint NOT NULL COMMENT '仓库单据lid',
  `st_bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '仓库单据编号',
  `make_time` datetime NOT NULL COMMENT '开票时间',
  `post_time` datetime DEFAULT NULL COMMENT '过帐日期',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `supplier_lid` bigint NOT NULL DEFAULT '-1' COMMENT '供货商lid',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库lid',
  `take_warehouse_lid` bigint DEFAULT NULL COMMENT '领用仓库编号',
  `goods_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物品编号',
  `unit_lid` bigint NOT NULL COMMENT '单位lid',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '单位',
  `unit_type` int NOT NULL COMMENT '单位类型',
  `actual_volume` decimal(24,6) DEFAULT NULL COMMENT '到货数量（用于采购订货）',
  `volume` decimal(24,6) NOT NULL COMMENT '数量',
  `price` decimal(24,6) NOT NULL COMMENT '单价',
  `amount` decimal(24,6) NOT NULL COMMENT '金额',
  `base_unit_lid` bigint NOT NULL COMMENT '基本单位lid',
  `base_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '基本单位',
  `volume_of_base_unit` decimal(24,6) NOT NULL COMMENT '基本数量',
  `price_of_base_unit` decimal(24,6) NOT NULL COMMENT '基本单价',
  `old_price` decimal(24,6) DEFAULT NULL COMMENT '原库存价',
  `new_price` decimal(24,6) DEFAULT NULL COMMENT '新库存价',
  `beginning_volume_of_in_warehouse` decimal(24,6) DEFAULT NULL COMMENT '入库仓库期初数量',
  `beginning_amount_of_in_warehouse` decimal(24,6) DEFAULT NULL COMMENT '入库仓库期初金额',
  `beginning_volume_of_out_warehouse` decimal(24,6) DEFAULT NULL COMMENT '出库仓库期初数量',
  `beginning_amount_of_out_warehouse` decimal(24,6) DEFAULT NULL COMMENT '出库仓库期初金额',
  `in_volume_of_warehouse` decimal(24,6) DEFAULT NULL COMMENT '仓库收入数量',
  `in_amount_of_warehouse` decimal(24,6) DEFAULT NULL COMMENT '仓库收入金额',
  `out_volume_of_warehouse` decimal(24,6) DEFAULT NULL COMMENT '仓库发出数量',
  `out_amount_of_warehouse` decimal(24,6) DEFAULT NULL COMMENT '仓库发出金额',
  `ending_volume_of_in_warehouse` decimal(24,6) DEFAULT NULL COMMENT '入库仓库结存数量',
  `ending_amount_of_in_warehouse` decimal(24,6) DEFAULT NULL COMMENT '入库仓库结存金额',
  `ending_volume_of_out_warehouse` decimal(24,6) DEFAULT NULL COMMENT '出库仓库结存数量',
  `ending_amount_of_out_warehouse` decimal(24,6) DEFAULT NULL COMMENT '出库仓库结存金额',
  `account_period_lid` bigint NOT NULL COMMENT '所属会计期间编号',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `production_date` datetime DEFAULT NULL COMMENT '生产日期',
  `batch_no` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '批次号',
  `tax_rate` decimal(24,6) NOT NULL COMMENT '税率',
  `posted` int NOT NULL COMMENT '是否过账',
  `ref_flag` int NOT NULL COMMENT '是否冲红',
  `qi_state` int NOT NULL COMMENT '质检状态',
  `qi_volume` tinyint(1) NOT NULL COMMENT '质检-数量',
  `qi_time` tinyint(1) NOT NULL COMMENT '质检-时间',
  `qi_mass` tinyint(1) NOT NULL COMMENT '质检-质量',
  `qi_remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '质检备注',
  `org_item_lid` bigint DEFAULT NULL COMMENT '原物品lid',
  `delivery_price` decimal(24,6) DEFAULT NULL COMMENT '配送单价',
  `delivery_amount` decimal(24,6) DEFAULT NULL COMMENT '配送金额',
  `delivery_tax` decimal(24,6) DEFAULT NULL COMMENT '配送税率',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint NOT NULL COMMENT '是否删除',
  `org_volume` decimal(24,6) DEFAULT NULL COMMENT '原物品数量',
  `org_price` decimal(24,6) DEFAULT NULL COMMENT '原物品价格',
  `org_amount` decimal(24,6) DEFAULT NULL COMMENT '原物品金额',
  `weighted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已称重',
  `out_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '发货数量',
  `delivery_type` int DEFAULT '1' COMMENT '配送方式',
  `rdc_order_lid` bigint DEFAULT NULL COMMENT '配送单lid',
  `last_order_price` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '最后一次入库价格',
  `rdc_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '配送单编号',
  `poster` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核人',
  `volume_for_counting` decimal(24,6) DEFAULT NULL COMMENT '基于计数单位的数量',
  `beginning_counting_volume_of_in_warehouse` decimal(24,6) DEFAULT NULL COMMENT '入库仓库期初数量',
  `beginning_counting_volume_of_out_warehouse` decimal(24,6) DEFAULT NULL COMMENT '出库仓库期初数量',
  `in_counting_volume_of_warehouse` decimal(24,6) DEFAULT NULL COMMENT '仓库收入数量',
  `out_counting_volume_of_warehouse` decimal(24,6) DEFAULT NULL COMMENT '仓库发出数量',
  `ending_counting_volume_of_in_warehouse` decimal(24,6) DEFAULT NULL COMMENT '入库仓库结存数量',
  `ending_counting_volume_of_out_warehouse` decimal(24,6) DEFAULT NULL COMMENT '出库仓库结存数量',
  `counting_unit_lid` bigint DEFAULT NULL COMMENT '计数单位lid',
  `counting_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '计数单位',
  `last_out_price` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '最后一次出库单价',
  `small_type_lid` bigint DEFAULT NULL COMMENT '小类lid',
  `supper_type_lid` bigint DEFAULT NULL COMMENT '大类lid',
  `indent_volume` decimal(19,10) DEFAULT NULL COMMENT '订购数量',
  `tax_price` decimal(24,6) DEFAULT NULL COMMENT '含税价格',
  `tax_amount` decimal(24,6) DEFAULT NULL COMMENT '含税金额',
  `process_factory_lid` bigint DEFAULT NULL COMMENT '加工厂lid',
  `idx` int DEFAULT NULL COMMENT '物品顺序',
  `dest_sid` bigint DEFAULT NULL COMMENT '目的仓库sid',
  `rdc_order_item_lid` bigint DEFAULT NULL COMMENT '配送物品lid',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_bill_lid` (`mid`,`st_bill_lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE,
  KEY `idx_mid_period_lid` (`mid`,`account_period_lid`) USING BTREE,
  KEY `idx_mid_post_time` (`mid`,`post_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=484791 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='单据物品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_st_bill_item`
--

LOCK TABLES `sc_st_bill_item` WRITE;
/*!40000 ALTER TABLE `sc_st_bill_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_st_bill_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_st_check_bill`
--

DROP TABLE IF EXISTS `sc_st_check_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_st_check_bill` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单据编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year` int NOT NULL COMMENT '年',
  `month` int NOT NULL COMMENT '月',
  `day` int NOT NULL COMMENT '日',
  `begin_date` datetime DEFAULT NULL COMMENT '开始时间',
  `end_date` datetime DEFAULT NULL COMMENT '完成时间',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库/部门编号',
  `check_for_beginning` tinyint(1) DEFAULT NULL COMMENT '是否为期初盘点',
  `check_for_month_end` tinyint(1) DEFAULT NULL COMMENT '是否为月末盘点',
  `finished` tinyint(1) DEFAULT NULL COMMENT '是否已过账',
  `finisher_lid` bigint DEFAULT NULL COMMENT '过账人lid',
  `finisher` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '过账人',
  `amount_of_balance` decimal(24,6) DEFAULT NULL COMMENT '结存金额',
  `amount_of_rofitand_loss` decimal(24,6) DEFAULT NULL COMMENT '盈亏金额',
  `check_in_type` int DEFAULT NULL COMMENT '盘点类型',
  `account_period_lid` bigint DEFAULT NULL COMMENT '所属会计期间lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint NOT NULL COMMENT '是否删除',
  `pyd_lid` bigint DEFAULT NULL COMMENT '盘盈单lid',
  `pkd_lid` bigint DEFAULT NULL COMMENT '盘亏单lid',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_lid_report_date` (`mid`,`report_date`,`lid`) USING BTREE,
  KEY `idx_mid_id_report_date` (`mid`,`report_date`,`id`) USING BTREE,
  KEY `idx_mid_account_lid_report_date` (`mid`,`report_date`,`account_period_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2067 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='盘点单据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_st_check_bill`
--

LOCK TABLES `sc_st_check_bill` WRITE;
/*!40000 ALTER TABLE `sc_st_check_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_st_check_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_st_check_bill_item`
--

DROP TABLE IF EXISTS `sc_st_check_bill_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_st_check_bill_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `goods_lid` bigint NOT NULL COMMENT '被盘物品lid',
  `goods_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '被盘物品编号',
  `check_bill_lid` bigint NOT NULL COMMENT '盘点单编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year` int NOT NULL COMMENT '年',
  `month` int NOT NULL COMMENT '月',
  `day` int NOT NULL COMMENT '日',
  `unit_lid` bigint NOT NULL COMMENT '单位lid',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '单位',
  `volume` decimal(24,6) DEFAULT NULL COMMENT '数量',
  `price` decimal(24,6) DEFAULT NULL COMMENT '价格',
  `amount` decimal(24,6) DEFAULT NULL COMMENT '金额',
  `real_unit_lid` bigint NOT NULL COMMENT '实盘单位lid',
  `real_unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '实盘单位',
  `real_volume` decimal(24,6) DEFAULT NULL COMMENT '实盘数量',
  `real_amount` decimal(24,6) DEFAULT NULL COMMENT '实盘金额',
  `org_price` decimal(24,6) DEFAULT NULL COMMENT '库存单价',
  `org_volume` decimal(24,6) DEFAULT NULL COMMENT '库存数量',
  `org_amount` decimal(24,6) DEFAULT NULL COMMENT '库存金额',
  `volmun_of_rofitand_loss` decimal(24,6) DEFAULT NULL COMMENT '盈亏数量',
  `amount_of_rofitand_loss` decimal(24,6) DEFAULT NULL COMMENT '盈亏金额',
  `prohibit` tinyint(1) DEFAULT NULL COMMENT '是否禁盘',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint NOT NULL COMMENT '是否删除',
  `goods_type_lid` bigint NOT NULL DEFAULT '-1' COMMENT '物品类别',
  `real_volume_for_counting` decimal(24,6) DEFAULT NULL COMMENT '基于计数单位的实盘数量',
  `org_volume_for_counting` decimal(24,6) DEFAULT NULL COMMENT '基于计数单位的库存数量',
  `volmun_of_rofitand_loss_for_counting` decimal(24,6) DEFAULT NULL COMMENT '基于计数单位的盈亏数量',
  `counting_unit_lid` bigint DEFAULT NULL COMMENT '计数单位lid',
  `counting_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '计数单位',
  `unit_type` int NOT NULL DEFAULT '1' COMMENT '单位类型',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_lid_report_date` (`mid`,`report_date`,`lid`) USING BTREE,
  KEY `idx_mid_check_bill_lid_report_date` (`mid`,`report_date`,`check_bill_lid`) USING BTREE,
  KEY `sc_st_check_bill_item_lid_IDX` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=429967 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='盘点单据物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_st_check_bill_item`
--

LOCK TABLES `sc_st_check_bill_item` WRITE;
/*!40000 ALTER TABLE `sc_st_check_bill_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_st_check_bill_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_st_goods_day_book`
--

DROP TABLE IF EXISTS `sc_st_goods_day_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_st_goods_day_book` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year` int NOT NULL COMMENT '年',
  `month` int NOT NULL COMMENT '月',
  `day` int NOT NULL COMMENT '日',
  `bill_type_` int NOT NULL COMMENT '票据类型',
  `st_bill_lid` bigint NOT NULL COMMENT '仓库单据lid',
  `st_bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '仓库单据编号',
  `make_time` datetime NOT NULL COMMENT '开票时间',
  `post_time` datetime DEFAULT NULL COMMENT '过帐日期',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `supplier_lid` bigint DEFAULT NULL COMMENT '供货商lid',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库lid',
  `take_warehouse_lid` bigint DEFAULT NULL COMMENT '领用仓库编号',
  `goods_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物品编号',
  `unit_lid` bigint NOT NULL COMMENT '单位lid',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '单位',
  `unit_type` int NOT NULL COMMENT '单位类型',
  `actual_volume` decimal(24,6) DEFAULT NULL COMMENT '到货数量（用于采购订货）',
  `volume` decimal(24,6) NOT NULL COMMENT '数量',
  `price` decimal(24,6) NOT NULL COMMENT '单价',
  `amount` decimal(24,6) NOT NULL COMMENT '金额',
  `base_unit_lid` bigint NOT NULL COMMENT '基本单位lid',
  `base_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '基本单位',
  `volume_of_base_unit` decimal(24,6) NOT NULL COMMENT '基本数量',
  `price_of_base_unit` decimal(24,6) NOT NULL COMMENT '基本单价',
  `old_price` decimal(24,6) DEFAULT NULL COMMENT '原库存价',
  `new_price` decimal(24,6) DEFAULT NULL COMMENT '新库存价',
  `beginning_volume_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库期初数量',
  `beginning_amount_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库期初金额',
  `in_volume_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库收入数量',
  `in_amount_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库收入金额',
  `out_volume_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库发出数量',
  `out_amount_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库发出金额',
  `ending_volume_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库结存数量',
  `ending_amount_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库结存金额',
  `account_period_lid` bigint NOT NULL COMMENT '所属会计期间编号',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `production_date` datetime DEFAULT NULL COMMENT '生产日期',
  `batch_no` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '批次号',
  `tax_rate` decimal(24,6) NOT NULL COMMENT '税率',
  `posted` int NOT NULL COMMENT '是否过账',
  `ref_flag` int NOT NULL COMMENT '是否冲红',
  `qi_state` int NOT NULL COMMENT '质检状态',
  `qi_volume` tinyint(1) NOT NULL COMMENT '质检-数量',
  `qi_time` tinyint(1) NOT NULL COMMENT '质检-时间',
  `qi_mass` tinyint(1) NOT NULL COMMENT '质检-质量',
  `qi_remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '质检备注',
  `org_item_lid` bigint DEFAULT NULL COMMENT '原物品lid',
  `delivery_price` decimal(24,6) DEFAULT NULL COMMENT '配送单价',
  `delivery_amount` decimal(24,6) DEFAULT NULL COMMENT '配送金额',
  `delivery_tax` decimal(24,6) DEFAULT NULL COMMENT '配送税率',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint NOT NULL COMMENT '是否删除',
  `delivery_type` int DEFAULT '1' COMMENT '配送方式',
  `small_type_lid` bigint DEFAULT NULL COMMENT '物品小类lid',
  `supper_type_lid` bigint DEFAULT NULL COMMENT '物品大类lid',
  `org_volume` decimal(24,6) DEFAULT NULL COMMENT '原订购数量',
  `org_price` decimal(24,6) DEFAULT NULL COMMENT '原订购价格',
  `org_amount` decimal(24,6) DEFAULT NULL COMMENT '原订购总额',
  `bill_date` datetime DEFAULT NULL COMMENT '开票日期',
  `volume_for_counting` decimal(24,6) DEFAULT NULL COMMENT '基于计数单位基本数量',
  `beginning_counting_volume_of_warehouse` decimal(24,6) DEFAULT NULL COMMENT '仓库期初数量',
  `in_counting_volume_of_warehouse` decimal(24,6) DEFAULT NULL COMMENT '仓库收入数量',
  `out_counting_volume_of_warehouse` decimal(24,6) DEFAULT NULL COMMENT '仓库发出数量',
  `ending_counting_volume_of_warehouse` decimal(24,6) DEFAULT NULL COMMENT '仓库结存数量',
  `dest_sid` bigint DEFAULT NULL COMMENT '目的仓库sid',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_report_date_goods_lid` (`mid`,`report_date`,`goods_lid`) USING BTREE,
  KEY `idx_mid_report_date_warehouse_lid` (`mid`,`report_date`,`warehouse_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=568086 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品流水账';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_st_goods_day_book`
--

LOCK TABLES `sc_st_goods_day_book` WRITE;
/*!40000 ALTER TABLE `sc_st_goods_day_book` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_st_goods_day_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_st_goods_summary`
--

DROP TABLE IF EXISTS `sc_st_goods_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_st_goods_summary` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year` int NOT NULL COMMENT '年',
  `month` int NOT NULL COMMENT '月',
  `day` int NOT NULL COMMENT '日',
  `period_lid` bigint NOT NULL COMMENT '会计周期lid',
  `goods_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '物品编号',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `small_type_lid` bigint DEFAULT NULL COMMENT '物品小类lid',
  `supper_type_lid` bigint DEFAULT NULL COMMENT '物品大类lid',
  `unit_lid` bigint DEFAULT NULL COMMENT '单位lid',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '单位',
  `volume_for_counting` decimal(24,6) DEFAULT NULL COMMENT '基于计数单位的数量',
  `volume` decimal(24,6) DEFAULT NULL COMMENT '数量',
  `price` decimal(24,6) DEFAULT NULL COMMENT '单价',
  `amount` decimal(24,6) DEFAULT NULL COMMENT '金额',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库lid',
  `beginning_volume_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库期初数量',
  `beginning_amount_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库期初金额',
  `in_volume_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库收入数量',
  `in_amount_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库收入金额',
  `out_volume_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库发出数量',
  `out_amount_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库发出金额',
  `ending_volume_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库结存数量',
  `ending_amount_of_warehouse` decimal(24,6) NOT NULL COMMENT '仓库结存金额',
  `check_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库盘点数量',
  `check_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库盘点金额',
  `check_in_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库盘点盈收数量',
  `check_in_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库盘点盈收金额',
  `check_out_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库盘点亏损数量',
  `check_out_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库盘点亏损金额',
  `init_check_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库期初数量',
  `init_check_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库期初金额',
  `revision` int DEFAULT '0' COMMENT '乐观锁',
  `beginning_counting_volume_of_warehouse` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库期初数量',
  `in_counting_volume_of_warehouse` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库收入数量',
  `out_counting_volume_of_warehouse` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库发出数量',
  `ending_counting_volume_of_warehouse` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库结存数量',
  `check_counting_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库盘点数量',
  `check_in_counting_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库盘点盈收数量',
  `check_out_counting_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库盘点亏损数量',
  `init_check_counting_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '仓库期初数量',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_period_lid_goods` (`mid`,`period_lid`,`goods_lid`) USING BTREE,
  KEY `idx_mid_period_lid_warehoue` (`mid`,`period_lid`,`warehouse_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=885470 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品汇总账';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_st_goods_summary`
--

LOCK TABLES `sc_st_goods_summary` WRITE;
/*!40000 ALTER TABLE `sc_st_goods_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_st_goods_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_st_type_summary`
--

DROP TABLE IF EXISTS `sc_st_type_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_st_type_summary` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `year` int NOT NULL COMMENT '年',
  `month` int NOT NULL COMMENT '月',
  `day` int NOT NULL COMMENT '日',
  `type_` int NOT NULL COMMENT '单据类型',
  `period_lid` bigint NOT NULL COMMENT '会计周期lid',
  `small_type_lid` bigint DEFAULT NULL COMMENT '物品小类lid',
  `supper_type_lid` bigint DEFAULT NULL COMMENT '物品大类lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库lid',
  `in_out_flag` int NOT NULL DEFAULT '0' COMMENT '出入库标识',
  `volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '数量',
  `counting_volume` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '计量数量',
  `amount` decimal(24,6) NOT NULL COMMENT '金额',
  `revision` int NOT NULL DEFAULT '0' COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_period_lid_warehouse` (`mid`,`period_lid`,`warehouse_lid`) USING BTREE,
  KEY `idx_mid_period_lid_goods` (`mid`,`period_lid`,`goods_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=380967 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品单据类型汇总';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_st_type_summary`
--

LOCK TABLES `sc_st_type_summary` WRITE;
/*!40000 ALTER TABLE `sc_st_type_summary` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_st_type_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_stock_snapshot_of_month`
--

DROP TABLE IF EXISTS `sc_stock_snapshot_of_month`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_stock_snapshot_of_month` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `period_lid` bigint NOT NULL COMMENT '会计区间lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库lid',
  `price` decimal(24,6) NOT NULL COMMENT '库存价格',
  `volume` decimal(24,6) NOT NULL COMMENT '当前数量',
  `amount` decimal(24,6) NOT NULL COMMENT '当前金额',
  `unit_lid` bigint NOT NULL COMMENT '单位lid',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '单位',
  `bill_lid` bigint NOT NULL COMMENT '单据lid',
  `item_lid` bigint NOT NULL COMMENT '物品的lid',
  `last_stock_time` datetime NOT NULL COMMENT '入库时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `volume_for_counting` decimal(24,6) DEFAULT NULL COMMENT '当前数量',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_period_lid_goods_lid` (`mid`,`period_lid`,`goods_lid`) USING BTREE,
  KEY `idx_mid_period_lid_warehouse_lid` (`mid`,`period_lid`,`warehouse_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=487843 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='月末转结快照';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_stock_snapshot_of_month`
--

LOCK TABLES `sc_stock_snapshot_of_month` WRITE;
/*!40000 ALTER TABLE `sc_stock_snapshot_of_month` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_stock_snapshot_of_month` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_store_order`
--

DROP TABLE IF EXISTS `sc_store_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_store_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '订单编号',
  `rdc_order_lid` bigint DEFAULT NULL COMMENT '配送中心订货单lid',
  `rdc_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '配送中心订货单编号',
  `merge_order_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '合并后订单id',
  `merge_order_lid` bigint DEFAULT NULL COMMENT '合并后的订单lid',
  `report_date` datetime NOT NULL COMMENT '订货日期',
  `organ_lid` bigint NOT NULL COMMENT '机构lid',
  `order_type` int NOT NULL COMMENT '订货单类型',
  `order_state` int NOT NULL COMMENT '订单状态',
  `rows` int NOT NULL COMMENT '记录数',
  `volume` decimal(24,6) NOT NULL COMMENT '总数量',
  `tax_amount` decimal(24,6) NOT NULL COMMENT '含税金额',
  `amount` decimal(24,6) NOT NULL COMMENT '总金额',
  `indent_volume` decimal(24,6) NOT NULL COMMENT '订购数量',
  `audit_lid` bigint DEFAULT NULL COMMENT '审核人lid',
  `audit_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核人',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `reject_lid` bigint DEFAULT NULL COMMENT '驳回人lid',
  `reject_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '驳回人',
  `reject_time` datetime DEFAULT NULL COMMENT '驳回时间',
  `submit_lid` bigint DEFAULT NULL COMMENT '提交人lid',
  `submit_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '提交人',
  `submit_time` datetime DEFAULT NULL COMMENT '提交时间',
  `rdc_audit_lid` bigint DEFAULT NULL COMMENT '配送中心审核人lid',
  `rdc_audit_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '配送中心审核人',
  `rdc_audit_time` datetime DEFAULT NULL COMMENT '配送中心审核时间',
  `receive_lid` bigint DEFAULT NULL COMMENT '接单人lid',
  `receive_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '接单人',
  `receive_time` datetime DEFAULT NULL COMMENT '接单时间',
  `split_lid` bigint DEFAULT NULL COMMENT '拆单人lid',
  `split_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '拆单人',
  `split_time` datetime DEFAULT NULL COMMENT '拆单时间',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date_organ_lid` (`mid`,`report_date`,`organ_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4534 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='门店订货单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_store_order`
--

LOCK TABLES `sc_store_order` WRITE;
/*!40000 ALTER TABLE `sc_store_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_store_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_store_order_item`
--

DROP TABLE IF EXISTS `sc_store_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_store_order_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '订货日期',
  `store_order_lid` bigint NOT NULL COMMENT '门店订货单lid',
  `store_order_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '门店订货单编号',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `supplier_lid` bigint NOT NULL COMMENT '供货商lid',
  `organ_lid` bigint NOT NULL COMMENT '机构lid',
  `indent_volume` decimal(24,6) NOT NULL COMMENT '订购数量',
  `volume` decimal(24,6) NOT NULL COMMENT '订购数量',
  `price` decimal(24,6) NOT NULL COMMENT '订购价格',
  `amount` decimal(24,6) NOT NULL COMMENT '订购总额',
  `org_volume` decimal(24,6) NOT NULL COMMENT '原订购数量',
  `org_price` decimal(24,6) NOT NULL COMMENT '原订购价格',
  `org_amount` decimal(24,6) NOT NULL COMMENT '原订购总额',
  `tax_rate` decimal(24,6) NOT NULL COMMENT '税率',
  `arrival_time` datetime NOT NULL COMMENT '到货日期',
  `delivery_type` int NOT NULL COMMENT '配送方式',
  `order_type` int NOT NULL COMMENT '订货单类型',
  `order_state` int NOT NULL COMMENT '订单状态',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date_store_order_lid` (`mid`,`report_date`,`store_order_lid`) USING BTREE,
  KEY `idx_mid_report_date_lid` (`mid`,`report_date`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=102802 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='门店订货单物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_store_order_item`
--

LOCK TABLES `sc_store_order_item` WRITE;
/*!40000 ALTER TABLE `sc_store_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_store_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_supplier`
--

DROP TABLE IF EXISTS `sc_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_supplier` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '名称',
  `supplier_type_lid` bigint DEFAULT NULL COMMENT '供应商类别lid',
  `principal` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '负责人',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '负责人电话',
  `longitude` decimal(24,6) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(24,6) DEFAULT NULL COMMENT '纬度',
  `province` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '所在省',
  `province_code` bigint DEFAULT NULL COMMENT '省编码',
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '所在市',
  `city_code` bigint DEFAULT NULL COMMENT '市编码',
  `county` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '所在区县',
  `county_code` bigint DEFAULT NULL COMMENT '所在区县编码',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '详细地址',
  `enable` tinyint(1) DEFAULT NULL COMMENT '启用/禁用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `is_suit_all` tinyint(1) NOT NULL DEFAULT '1' COMMENT '适用所有店铺',
  `pinyin` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '拼音',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '供应商编号',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE,
  KEY `idx_mid_supplier_type_lid` (`mid`,`supplier_type_lid`) USING BTREE,
  KEY `idx_mid_id` (`mid`,`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1339 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供应商';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_supplier`
--

LOCK TABLES `sc_supplier` WRITE;
/*!40000 ALTER TABLE `sc_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_supplier_apply`
--

DROP TABLE IF EXISTS `sc_supplier_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_supplier_apply` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `apply_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '申请账号',
  `apply_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '申请人',
  `apply_at` datetime NOT NULL COMMENT '申请时间',
  `apply_phone` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '申请电话',
  `audit_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核人',
  `audit_at` datetime DEFAULT NULL COMMENT '审核时间',
  `apply_state` int NOT NULL DEFAULT '0' COMMENT '状态',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `supplier_lid` bigint NOT NULL DEFAULT '-1' COMMENT '供货商lid',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid` (`mid`,`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供货商申请关联记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_supplier_apply`
--

LOCK TABLES `sc_supplier_apply` WRITE;
/*!40000 ALTER TABLE `sc_supplier_apply` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_supplier_apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_supplier_quote`
--

DROP TABLE IF EXISTS `sc_supplier_quote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_supplier_quote` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '适用门店',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `quote_order_lid` bigint NOT NULL COMMENT '报价单lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `price` decimal(24,6) NOT NULL COMMENT '报价',
  `added_tax_type` int NOT NULL COMMENT '采购税率',
  `supplier_lid` bigint NOT NULL COMMENT '供货商lid',
  `begin_date` datetime NOT NULL COMMENT '价格生效日期',
  `end_date` datetime NOT NULL COMMENT '价格失效日期',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_sid` (`mid`,`sid`) USING BTREE,
  KEY `idx_mid_supplier_lid` (`mid`,`supplier_lid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供货商报价';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_supplier_quote`
--

LOCK TABLES `sc_supplier_quote` WRITE;
/*!40000 ALTER TABLE `sc_supplier_quote` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_supplier_quote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_supplier_relate`
--

DROP TABLE IF EXISTS `sc_supplier_relate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_supplier_relate` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商户企业账号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商户名称',
  `phone` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '商户手机号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供货商与商户关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_supplier_relate`
--

LOCK TABLES `sc_supplier_relate` WRITE;
/*!40000 ALTER TABLE `sc_supplier_relate` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_supplier_relate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_supplier_store`
--

DROP TABLE IF EXISTS `sc_supplier_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_supplier_store` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `store_lid` bigint NOT NULL COMMENT '门店lid',
  `supplier_lid` bigint NOT NULL COMMENT '供应商lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_supplier_store` (`mid`,`store_lid`) USING BTREE,
  KEY `idx_supplier_supplier` (`mid`,`supplier_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=299 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供应商和门店关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_supplier_store`
--

LOCK TABLES `sc_supplier_store` WRITE;
/*!40000 ALTER TABLE `sc_supplier_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_supplier_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_supplier_type`
--

DROP TABLE IF EXISTS `sc_supplier_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_supplier_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '供应商名称',
  `parent_lid` bigint DEFAULT NULL COMMENT '上一级分类',
  `level` int DEFAULT NULL COMMENT '层级',
  `enable` tinyint(1) DEFAULT NULL COMMENT '启用/禁用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '供应商类型编号',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE,
  KEY `idx_mid_id` (`mid`,`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=413 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供应商类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_supplier_type`
--

LOCK TABLES `sc_supplier_type` WRITE;
/*!40000 ALTER TABLE `sc_supplier_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_supplier_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_tbl_area`
--

DROP TABLE IF EXISTS `sc_tbl_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_tbl_area` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '台区编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '台区名称',
  `idx` int NOT NULL COMMENT '台区顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17544 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='台区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_tbl_area`
--

LOCK TABLES `sc_tbl_area` WRITE;
/*!40000 ALTER TABLE `sc_tbl_area` DISABLE KEYS */;
INSERT INTO `sc_tbl_area` VALUES (17516,1978646278361620480,2038896375379398658,2038924236997410817,'2038924236997410817','A区',0,NULL,NULL,'2026-03-31 10:19:54',NULL,NULL,0),(17517,1978646278361620480,2038896375379398658,2038924264977612802,'2038924264977612802','B区',0,NULL,NULL,'2026-03-31 10:20:00',NULL,NULL,0),(17518,1940284000182472704,1940287289892687874,2039586650974720001,'2039586650974720001','东',0,NULL,NULL,'2026-04-02 06:12:06',NULL,NULL,0),(17522,1940284000182472704,1940287289892687874,2042544092134117377,'2042544092134117377','1234',0,NULL,NULL,'2026-04-10 10:03:54',NULL,NULL,0),(17523,1940284000182472704,2042804773847437313,2042820457333657601,'2042820457333657601','123',0,NULL,NULL,'2026-04-11 04:22:05',NULL,NULL,0),(17524,1940284000182472704,1985885291726794753,2053722949964533762,'2053722949964533762','A区',0,NULL,NULL,'2026-05-11 06:24:42',NULL,NULL,0),(17525,1940284000182472704,1985885291726794753,2053722970311102465,'2053722970311102465','B区',0,NULL,NULL,'2026-05-11 06:24:47',NULL,NULL,0),(17526,1940284000182472704,1979737429467095041,2039942968928768002,'2039942968928768002','东南',0,NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,0),(17527,1931184606120251392,1931195785000005634,2056926469177741313,'2056926469177741313','A',0,NULL,NULL,'2026-05-20 02:34:21',NULL,NULL,0),(17543,1940284000182472704,1942885905090105345,2039943007168237570,'2039943007168237570','东南',0,NULL,NULL,'2026-08-11 17:55:49',NULL,NULL,0);
/*!40000 ALTER TABLE `sc_tbl_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_warehouse`
--

DROP TABLE IF EXISTS `sc_warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_warehouse` (
  `pid` bigint NOT NULL AUTO_INCREMENT,
  `mid` bigint NOT NULL COMMENT '集团;',
  `sid` bigint DEFAULT NULL COMMENT '所属门店;',
  `lid` bigint NOT NULL COMMENT 'lmn内部编号',
  `init_bill_lid` bigint DEFAULT NULL COMMENT '仓库期初编号',
  `check_bill_lid` bigint DEFAULT NULL COMMENT '仓库盘点单号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '仓库名称',
  `type_` int DEFAULT NULL COMMENT '类型',
  `principal` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '负责人',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '手机号',
  `enable` tinyint(1) DEFAULT NULL COMMENT '启用/禁用',
  `address` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '仓库地址',
  `reduce_level` int DEFAULT NULL COMMENT '扣减顺序',
  `inited` tinyint(1) DEFAULT NULL COMMENT '是否期初',
  `checking` tinyint(1) DEFAULT NULL COMMENT '正在盘点',
  `for_default` tinyint(1) DEFAULT NULL COMMENT '默认仓库',
  `last_inventory_time` datetime DEFAULT NULL COMMENT '最近盘点日期',
  `last_order_time` datetime DEFAULT NULL COMMENT '最近订货日期',
  `time_of_last_bill` datetime DEFAULT NULL COMMENT '最近库存单据日期',
  `time_of_last_auto_out` datetime DEFAULT NULL COMMENT '最后自动出库日期',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `init_time` datetime DEFAULT NULL COMMENT '仓库期初时间',
  `owner_shop_id` bigint DEFAULT NULL COMMENT '所属店铺编号',
  `owner_shop` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '所属店铺',
  `longitude` decimal(24,6) DEFAULT NULL COMMENT '经度',
  `latitude` decimal(24,6) DEFAULT NULL COMMENT '纬度',
  `province` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '所在省',
  `province_code` bigint DEFAULT NULL COMMENT '省编码',
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '所在市',
  `city_code` bigint DEFAULT NULL COMMENT '市编码',
  `county` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '所在区县',
  `county_code` bigint DEFAULT NULL COMMENT '所在区县编码',
  `receiver` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收货人',
  `receiver_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收货人联系方式',
  `receiver_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收货地址',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '仓库编号',
  `alias` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '别名',
  `outbound` tinyint(1) DEFAULT NULL COMMENT '物品审核入库即耗用',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE,
  KEY `idx_mid_owner_shop_id` (`mid`,`owner_shop_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1083 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='仓库';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_warehouse`
--

LOCK TABLES `sc_warehouse` WRITE;
/*!40000 ALTER TABLE `sc_warehouse` DISABLE KEYS */;
INSERT INTO `sc_warehouse` VALUES (1065,1978646278361620480,NULL,2038896375379398658,NULL,NULL,'测试门店',3,NULL,'13115975348',1,'广州市黄埔区',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2038896375379398658,'测试门店',NULL,NULL,'广东省',NULL,'广州市',NULL,'黄埔区',NULL,NULL,NULL,NULL,'自动创建','2026-03-31 08:29:12',NULL,NULL,0,NULL,NULL,NULL),(1066,1940284000182472704,NULL,2042804773847437313,NULL,NULL,'123',3,NULL,'19198074442',1,'123',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2042804773847437313,'123',NULL,12.000000,'北京市',NULL,'北京市',NULL,'西城区',NULL,NULL,NULL,NULL,'自动创建','2026-04-11 03:19:46',NULL,NULL,0,NULL,NULL,NULL),(1067,1940284000182472704,NULL,2069309380170092545,NULL,NULL,'永庆坊店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309380170092545,'永庆坊店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:37',NULL,NULL,0,NULL,NULL,NULL),(1071,1940284000182472704,NULL,2069309384725106689,NULL,NULL,'奥体店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309384725106689,'奥体店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:37',NULL,NULL,0,NULL,NULL,NULL),(1072,1940284000182472704,NULL,2069309386209890306,NULL,NULL,'万民城店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309386209890306,'万民城店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:38',NULL,NULL,0,NULL,NULL,NULL),(1073,1940284000182472704,NULL,2069309387703062529,NULL,NULL,'燕汇店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309387703062529,'燕汇店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:38',NULL,NULL,0,NULL,NULL,NULL),(1074,1940284000182472704,NULL,2069309389309480961,NULL,NULL,'西丽店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309389309480961,'西丽店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:39',NULL,NULL,0,NULL,NULL,NULL),(1075,1940284000182472704,NULL,2069309390785875969,NULL,NULL,'太阳城店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309390785875969,'太阳城店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:39',NULL,NULL,0,NULL,NULL,NULL),(1076,1940284000182472704,NULL,2069309392262270977,NULL,NULL,'信达金茂店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309392262270977,'信达金茂店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:39',NULL,NULL,0,NULL,NULL,NULL),(1077,1940284000182472704,NULL,2069309393730277378,NULL,NULL,'敏捷广场店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309393730277378,'敏捷广场店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:40',NULL,NULL,0,NULL,NULL,NULL),(1078,1940284000182472704,NULL,2069309395206672385,NULL,NULL,'北京路店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309395206672385,'北京路店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:40',NULL,NULL,0,NULL,NULL,NULL),(1079,1940284000182472704,NULL,2069309400239837185,NULL,NULL,'南沙coco店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309400239837185,'南沙coco店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:41',NULL,NULL,0,NULL,NULL,NULL),(1080,1940284000182472704,NULL,2069309408972378114,NULL,NULL,'大良悦然店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309408972378114,'大良悦然店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:43',NULL,NULL,0,NULL,NULL,NULL),(1081,1940284000182472704,NULL,2069309410448773122,NULL,NULL,'5号停机坪店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309410448773122,'5号停机坪店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:44',NULL,NULL,0,NULL,NULL,NULL),(1082,1940284000182472704,NULL,2069309414605328385,NULL,NULL,'国美智慧城店',3,'自动化测试','13800138000',1,'自动化测试门店地址',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2069309414605328385,'国美智慧城店',NULL,NULL,'广东省',NULL,'广州市',NULL,'番禺区',NULL,NULL,NULL,NULL,'自动创建','2026-06-23 14:39:45',NULL,NULL,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sc_warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_weight_img`
--

DROP TABLE IF EXISTS `sc_weight_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_weight_img` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '日期',
  `order_lid` bigint NOT NULL COMMENT '订单lid',
  `item_lid` bigint NOT NULL COMMENT '订单物品lid',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '图片地址',
  `idx` int NOT NULL DEFAULT '0' COMMENT '拍照索引',
  `type_` int NOT NULL DEFAULT '0' COMMENT '类型 0订货单 1入库单',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_lid` (`mid`,`order_lid`) USING BTREE,
  KEY `idx_mid_item_lid` (`mid`,`item_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='称重图片拍照';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_weight_img`
--

LOCK TABLES `sc_weight_img` WRITE;
/*!40000 ALTER TABLE `sc_weight_img` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_weight_img` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_weight_record`
--

DROP TABLE IF EXISTS `sc_weight_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_weight_record` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '日期',
  `order_lid` bigint NOT NULL COMMENT '订单lid',
  `item_lid` bigint NOT NULL COMMENT '订单物品lid',
  `measure` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '读数',
  `tare` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '皮重',
  `weight_type` int NOT NULL DEFAULT '0' COMMENT '称重单位类型',
  `idx` int NOT NULL COMMENT '称重索引',
  `type_` int NOT NULL DEFAULT '0' COMMENT '类型 0订货单 1入库单',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_lid` (`mid`,`order_lid`) USING BTREE,
  KEY `idx_mid_item_lid` (`mid`,`item_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='称重记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_weight_record`
--

LOCK TABLES `sc_weight_record` WRITE;
/*!40000 ALTER TABLE `sc_weight_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `sc_weight_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_bom`
--

DROP TABLE IF EXISTS `wms_bom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_bom` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint DEFAULT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `dish_id` bigint DEFAULT NULL COMMENT '商品编号',
  `dish_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '商品',
  `hide` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '隐藏（酒水）',
  `audit_time` datetime DEFAULT NULL COMMENT '审核时间',
  `audited` tinyint(1) DEFAULT NULL COMMENT '已审核',
  `audit_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核人',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE,
  KEY `idx_mid_dish_id` (`mid`,`dish_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物料清单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_bom`
--

LOCK TABLES `wms_bom` WRITE;
/*!40000 ALTER TABLE `wms_bom` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_bom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_bom_item`
--

DROP TABLE IF EXISTS `wms_bom_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_bom_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint DEFAULT NULL COMMENT '逻辑编号',
  `bom_id` bigint DEFAULT NULL COMMENT '物料清单编号',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '商品单位',
  `goods_id` bigint DEFAULT NULL COMMENT '物品编号',
  `goods` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '物品名称',
  `goods_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '物品单位',
  `goods_cost` decimal(24,6) DEFAULT NULL COMMENT '物品用量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_bom_id` (`mid`,`bom_id`) USING BTREE,
  KEY `idx_mid_bom_id_unit` (`mid`,`bom_id`,`unit`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物料清单明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_bom_item`
--

LOCK TABLES `wms_bom_item` WRITE;
/*!40000 ALTER TABLE `wms_bom_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_bom_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_cost_order`
--

DROP TABLE IF EXISTS `wms_cost_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_cost_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '报损单号',
  `report_date` datetime DEFAULT NULL COMMENT '订单日期',
  `order_type` int DEFAULT NULL COMMENT '报损单类型',
  `rows` int DEFAULT NULL COMMENT '物品总数',
  `volume` decimal(24,6) DEFAULT NULL COMMENT '总数量',
  `amount` decimal(24,6) DEFAULT NULL COMMENT '总金额',
  `review` tinyint(1) DEFAULT NULL COMMENT '审核',
  `review_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核人',
  `review_at` datetime DEFAULT NULL COMMENT '审核时间',
  `reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '报损原因',
  `remark` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '报损备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='成本报损单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_cost_order`
--

LOCK TABLES `wms_cost_order` WRITE;
/*!40000 ALTER TABLE `wms_cost_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_cost_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_cost_order_item`
--

DROP TABLE IF EXISTS `wms_cost_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_cost_order_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime DEFAULT NULL COMMENT '订单日期',
  `order_type` int DEFAULT NULL COMMENT '报损单类型',
  `cost_order_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '成本单号',
  `cost_order_lid` bigint DEFAULT NULL COMMENT '成本单lid',
  `small_type_lid` bigint DEFAULT NULL COMMENT '商品小类lid',
  `small_type` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品小类名称',
  `super_type_lid` bigint DEFAULT NULL COMMENT '商品大类lid',
  `super_type` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品大类名称',
  `product_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品id',
  `product_lid` bigint DEFAULT NULL COMMENT '商品lid',
  `product_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品名称',
  `product_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品单位',
  `product_volume` decimal(24,6) DEFAULT NULL COMMENT '商品数量',
  `product_price` decimal(24,6) DEFAULT NULL COMMENT '商品单价',
  `product_amount` decimal(24,6) DEFAULT NULL COMMENT '商品金额',
  `remark` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品备注',
  `review` tinyint(1) DEFAULT NULL COMMENT '审核',
  `review_at` datetime DEFAULT NULL COMMENT '审核时间',
  `review_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '审核人',
  `raw_rows` bigint DEFAULT NULL COMMENT '报损原材料数',
  `raw_volume` decimal(24,6) DEFAULT NULL COMMENT '原料材料扣库数量',
  `raw_amount` decimal(24,6) DEFAULT NULL COMMENT '原料材料扣库金额',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='成本报损单物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_cost_order_item`
--

LOCK TABLES `wms_cost_order_item` WRITE;
/*!40000 ALTER TABLE `wms_cost_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_cost_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_deduct_setting`
--

DROP TABLE IF EXISTS `wms_deduct_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_deduct_setting` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `dish_id` bigint DEFAULT NULL COMMENT '商品号',
  `dish` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '商品',
  `dish_super_type_id` bigint DEFAULT NULL COMMENT '商品大类编号',
  `dish_super_type` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '商品大类',
  `dish_type_id` bigint DEFAULT NULL COMMENT '商品小类编号',
  `dish_type` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '商品小类',
  `tbl_area_id` bigint DEFAULT NULL COMMENT '台区编号',
  `tbl_area` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '台区',
  `warehouse_id` bigint DEFAULT NULL COMMENT '仓库编号',
  `warehouse` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '仓库',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='商品扣仓设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_deduct_setting`
--

LOCK TABLES `wms_deduct_setting` WRITE;
/*!40000 ALTER TABLE `wms_deduct_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_deduct_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_depart_goods`
--

DROP TABLE IF EXISTS `wms_depart_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_depart_goods` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `warehouse_lid` bigint NOT NULL COMMENT '仓库lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_warehouse_lid` (`mid`,`warehouse_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4536 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='部门/仓库物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_depart_goods`
--

LOCK TABLES `wms_depart_goods` WRITE;
/*!40000 ALTER TABLE `wms_depart_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_depart_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_goods_last_price`
--

DROP TABLE IF EXISTS `wms_goods_last_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_goods_last_price` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `price` decimal(24,6) DEFAULT NULL COMMENT '价格',
  `type_` int NOT NULL DEFAULT '1' COMMENT '价格类型',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `warehouse_lid` bigint NOT NULL DEFAULT '-1' COMMENT '仓库lid',
  `item_lid` bigint DEFAULT NULL COMMENT '单据物品lid',
  `bill_lid` bigint DEFAULT NULL COMMENT '单据lid',
  `bill_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '单据id',
  `report_date` datetime DEFAULT NULL COMMENT '最后一次价格订单日期',
  PRIMARY KEY (`pid`,`mid`,`sid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid_goods_lid_type_` (`mid`,`sid`,`goods_lid`,`type_`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25876 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='物品上次入库价格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_goods_last_price`
--

LOCK TABLES `wms_goods_last_price` WRITE;
/*!40000 ALTER TABLE `wms_goods_last_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_goods_last_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_label_unit`
--

DROP TABLE IF EXISTS `wms_label_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_label_unit` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `remark` varchar(900) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `type_` int DEFAULT NULL COMMENT '类型',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE,
  KEY `idx_mid_type` (`mid`,`type_`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=435 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='单位/标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_label_unit`
--

LOCK TABLES `wms_label_unit` WRITE;
/*!40000 ALTER TABLE `wms_label_unit` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_label_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wms_user_goods`
--

DROP TABLE IF EXISTS `wms_user_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wms_user_goods` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `user_lid` bigint NOT NULL COMMENT '用户lid',
  `goods_lid` bigint NOT NULL COMMENT '物品lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_user_lid` (`mid`,`user_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10576 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='用户常用物品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wms_user_goods`
--

LOCK TABLES `wms_user_goods` WRITE;
/*!40000 ALTER TABLE `wms_user_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `wms_user_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_card_jump`
--

DROP TABLE IF EXISTS `wx_card_jump`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_card_jump` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `card_lid` bigint NOT NULL COMMENT '微信卡券lid',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `tips` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '提示',
  `type_` int NOT NULL COMMENT '跳转类型',
  `page` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '页面',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '路径',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_card_lid` (`card_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='会员卡券跳转';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_card_jump`
--

LOCK TABLES `wx_card_jump` WRITE;
/*!40000 ALTER TABLE `wx_card_jump` DISABLE KEYS */;
/*!40000 ALTER TABLE `wx_card_jump` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'a_wms'
--

--
-- Dumping routines for database 'a_wms'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-13 10:48:05
