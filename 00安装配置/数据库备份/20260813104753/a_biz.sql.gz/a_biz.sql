-- MySQL dump 10.13  Distrib 8.4.7, for Linux (x86_64)
--
-- Host: localhost    Database: a_biz
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `a_biz`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `a_biz` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `a_biz`;

--
-- Table structure for table `biz_key_value`
--

DROP TABLE IF EXISTS `biz_key_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biz_key_value` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '内容',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=186644 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='键值对表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biz_key_value`
--

LOCK TABLES `biz_key_value` WRITE;
/*!40000 ALTER TABLE `biz_key_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `biz_key_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biz_receipt_bind`
--

DROP TABLE IF EXISTS `biz_receipt_bind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biz_receipt_bind` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `user_lid` bigint NOT NULL COMMENT '用户lid',
  `user_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户id',
  `user_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名称',
  `open_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '公众号openId',
  `receipt_type` int NOT NULL COMMENT '接收业务类型',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid_type` (`mid`,`sid`,`receipt_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='业务接收绑定设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biz_receipt_bind`
--

LOCK TABLES `biz_receipt_bind` WRITE;
/*!40000 ALTER TABLE `biz_receipt_bind` DISABLE KEYS */;
/*!40000 ALTER TABLE `biz_receipt_bind` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biz_shop_group`
--

DROP TABLE IF EXISTS `biz_shop_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biz_shop_group` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `shop_json` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '门店列表',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='门店分组';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biz_shop_group`
--

LOCK TABLES `biz_shop_group` WRITE;
/*!40000 ALTER TABLE `biz_shop_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `biz_shop_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biz_sms_config`
--

DROP TABLE IF EXISTS `biz_sms_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biz_sms_config` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '门店名',
  `sign` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '签名',
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '账号',
  `user` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '用户名',
  `pwd` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '密码',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `channel` int DEFAULT NULL COMMENT '渠道',
  `extra_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '额外信息',
  PRIMARY KEY (`pid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='门店的短信网关配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biz_sms_config`
--

LOCK TABLES `biz_sms_config` WRITE;
/*!40000 ALTER TABLE `biz_sms_config` DISABLE KEYS */;
INSERT INTO `biz_sms_config` VALUES (145,1940284000182472704,1940287289892687874,2043646122112454658,'广州店','123',NULL,NULL,NULL,NULL,NULL,'2026-04-13 11:02:59',NULL,NULL,0,3,NULL);
/*!40000 ALTER TABLE `biz_sms_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biz_sms_send_record`
--

DROP TABLE IF EXISTS `biz_sms_send_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biz_sms_send_record` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `shop_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '门店名称',
  `error_msg` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发送错误消息',
  `success` tinyint(1) DEFAULT NULL COMMENT '是否发送成功',
  `phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '手机号',
  `content` varchar(4096) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发送内容',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='短信发送记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biz_sms_send_record`
--

LOCK TABLES `biz_sms_send_record` WRITE;
/*!40000 ALTER TABLE `biz_sms_send_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `biz_sms_send_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `biz_user_storage`
--

DROP TABLE IF EXISTS `biz_user_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `biz_user_storage` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `user_lid` bigint NOT NULL COMMENT '用户lid',
  `key_` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '键',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '值',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_user_lid_key` (`mid`,`user_lid`,`key_`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='用户历史信息存储';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `biz_user_storage`
--

LOCK TABLES `biz_user_storage` WRITE;
/*!40000 ALTER TABLE `biz_user_storage` DISABLE KEYS */;
INSERT INTO `biz_user_storage` VALUES (15,1940284000182472704,1,2045349791346462721,1940284000190861312,'/reportformscenter/jdy/food-category-sale-summary','[]',NULL,NULL,'2026-04-18 03:52:45',NULL,'2026-04-18 06:53:40',0),(16,1940284000182472704,1,2045394229002899457,1940284000190861312,'/reportformscenter/jdy/food-cancel-and-send-summary','{\"columns\":[{\"dataIndex\":\"xuhao\",\"title\":\"序号\",\"hidden\":false,\"fixed\":\"left\",\"collapsed\":false,\"width\":50},{\"dataIndex\":\"shop_name\",\"title\":\"组织机构\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":200},{\"dataIndex\":\"department_name\",\"title\":\"部门名称\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"food_super_category_name\",\"title\":\"食品类别\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":243},{\"dataIndex\":\"food_category_name\",\"title\":\"食品小类\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"food_code\",\"title\":\"食品编码\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"food_name\",\"title\":\"食品名称\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":150},{\"dataIndex\":\"food_pro_price\",\"title\":\"平均单价\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"food_number\",\"title\":\"下单数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"food_amount\",\"title\":\"下单金额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"cancel_number\",\"title\":\"取消数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"cancel_amount\",\"title\":\"取消金额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"cancel_rate\",\"title\":\"取消金额/下单金额%\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100},{\"dataIndex\":\"send_number\",\"title\":\"招待数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"send_amount\",\"title\":\"招待金额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"send_rate\",\"title\":\"招待金额/下单金额%\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100}],\"sorts\":[]}',NULL,NULL,'2026-04-18 06:49:20',NULL,NULL,0),(17,1940284000182472704,1,2053779838040281089,1940284000190861312,'/reportformscenter/memberstatement/memberpointsdetails','{\"columns\":[{\"dataIndex\":\"xuhao\",\"title\":\"序号\",\"hidden\":false,\"fixed\":\"left\",\"collapsed\":false,\"width\":50},{\"dataIndex\":\"shop_name\",\"title\":\"发生门店\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":60},{\"dataIndex\":\"yingyeriqi\",\"title\":\"交易日期\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":96},{\"dataIndex\":\"create_time\",\"title\":\"记账时间\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":143},{\"dataIndex\":\"member_name\",\"title\":\"会员姓名\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":88},{\"dataIndex\":\"member_phone\",\"title\":\"会员手机\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":92},{\"dataIndex\":\"card_no\",\"title\":\"会员卡号\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":69},{\"dataIndex\":\"points_type\",\"title\":\"记账方向\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":87},{\"dataIndex\":\"operation_model\",\"title\":\"业务类型\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":79},{\"dataIndex\":\"balance_before\",\"title\":\"变动前余额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"amount\",\"title\":\"发生额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":60},{\"dataIndex\":\"balance_after\",\"title\":\"变动后余额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80}],\"sorts\":[]}',NULL,NULL,'2026-05-11 10:10:45',NULL,'2026-05-14 08:23:10',0),(18,1940284000182472704,1,2055112415364517889,1940284000190861312,'/reportformscenter/memberstatement/couponissuedetail','[]',NULL,NULL,'2026-05-15 02:25:56',NULL,'2026-06-09 10:21:39',0),(19,1940284000182472704,1,2055189328413855745,1940284000190861312,'/reportformscenter/memberstatement/couponissuesummary','{\"columns\":[{\"dataIndex\":\"xuhao\",\"title\":\"序号\",\"hidden\":false,\"fixed\":\"left\",\"collapsed\":false,\"width\":50},{\"dataIndex\":\"merchant_name\",\"title\":\"发行组织\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":140},{\"dataIndex\":\"coupon_code\",\"title\":\"券模板ID\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":415},{\"dataIndex\":\"coupon\",\"title\":\"券名称\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":109},{\"dataIndex\":\"type\",\"title\":\"券类型\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":60},{\"dataIndex\":\"coupon_mode\",\"title\":\"券模式\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":60},{\"dataIndex\":\"unwritten_off_count\",\"title\":\"未核销数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":400,\"children\":[{\"dataIndex\":\"inactive_count\",\"title\":\"未生效数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"active_count\",\"title\":\"已生效数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"expiring_count\",\"title\":\"即将过期数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"expired_count\",\"title\":\"已过期数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"unwritten_off_count\",\"title\":\"合计\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80}]},{\"dataIndex\":\"written_off_count\",\"title\":\"已核销数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"abandoned_count\",\"title\":\"已作废数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"history_count\",\"title\":\"历史券数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"total_count\",\"title\":\"总数量\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80}],\"sorts\":[]}',NULL,NULL,'2026-05-15 07:31:34',NULL,'2026-05-15 07:37:17',0),(20,1940284000182472704,1,2058702010151342081,1940284000190861312,'/reportformscenter/memberstatement/memberconsumedetails','[]',NULL,NULL,'2026-05-25 08:09:42',NULL,'2026-05-25 16:47:34',0),(21,1940284000182472704,1,2058723424086528002,1940284000190861312,'/reportformscenter/memberstatement/memberrechargedetails','[]',NULL,NULL,'2026-05-25 09:34:48',NULL,'2026-05-28 14:06:11',0),(22,1940284000182472704,1,2058727528229769218,1940284000190861312,'/reportformscenter/memberstatement/memberaccountdetails','[]',NULL,NULL,'2026-05-25 09:51:06',NULL,'2026-05-25 16:48:11',0),(23,1940284000182472704,1,2059085046607646721,1940284000190861312,'/reportformscenter/memberstatement/couponredeemdetail','{\"columns\":[{\"dataIndex\":\"xuhao\",\"title\":\"序号\",\"hidden\":false,\"fixed\":\"left\",\"collapsed\":false,\"width\":50},{\"dataIndex\":\"merchant_name\",\"title\":\"发行组织\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":140},{\"dataIndex\":\"lid\",\"title\":\"券号\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":200},{\"dataIndex\":\"coupon\",\"title\":\"券名称\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":336},{\"dataIndex\":\"type\",\"title\":\"券类型\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":120},{\"dataIndex\":\"coupon_mode\",\"title\":\"券模式\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":77},{\"dataIndex\":\"face_value\",\"title\":\"券面值\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":75},{\"dataIndex\":\"redeemed_face_value\",\"title\":\"实际核销面额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"bill_amount\",\"title\":\"消费单金额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"discount_rate\",\"title\":\"折扣率(%)\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"unionid\",\"title\":\"会员手机号\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":160},{\"dataIndex\":\"member\",\"title\":\"会员名称\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":160},{\"dataIndex\":\"write_off_time\",\"title\":\"核销日期\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":200},{\"dataIndex\":\"used_shop\",\"title\":\"核销门店\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":160},{\"dataIndex\":\"write_off_staff\",\"title\":\"核销员\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":140},{\"dataIndex\":\"order_bill_id\",\"title\":\"核销订单号\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":200},{\"dataIndex\":\"get_channel\",\"title\":\"发放渠道\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":140}],\"sorts\":[]}',NULL,NULL,'2026-05-26 09:31:45',NULL,'2026-05-29 09:11:50',0),(24,1940284000182472704,1,2059120808552173570,1940284000190861312,'/reportformscenter/memberstatement/memberpointsconsumerdetails','[]',NULL,NULL,'2026-05-26 11:53:52',NULL,'2026-05-29 10:35:56',0),(25,1940284000182472704,1,2059567350243659778,1940284000190861312,'/reportformscenter/memberstatement/memberrechargesummary','{\"columns\":[{\"dataIndex\":\"xuhao\",\"title\":\"序号\",\"hidden\":false,\"fixed\":\"left\",\"collapsed\":false,\"width\":50},{\"dataIndex\":\"shopName\",\"title\":\"门店名称\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":200},{\"dataIndex\":\"memberName\",\"title\":\"会员姓名\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":60},{\"dataIndex\":\"phone\",\"title\":\"会员手机\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":141},{\"dataIndex\":\"amount\",\"title\":\"储值金额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":129},{\"dataIndex\":\"giveAmount\",\"title\":\"储值赠送\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":108},{\"dataIndex\":\"principalAmount\",\"title\":\"储值本金\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80}],\"sorts\":[]}',NULL,NULL,'2026-05-27 17:28:15',NULL,'2026-06-04 22:34:30',0),(26,1940284000182472704,1,2061342821528768514,1940284000190861312,'/reportformscenter/memberstatement/memberbalancesummary','[]',NULL,NULL,'2026-06-01 15:03:21',NULL,'2026-06-01 15:07:28',0),(27,1940284000182472704,1,2063094933313163266,1940284000190861312,'/reportformscenter/jdy/query-bill','{\"columns\":[{\"dataIndex\":\"xuhao\",\"title\":\"序号\",\"hidden\":false,\"fixed\":\"left\",\"collapsed\":false,\"width\":50},{\"dataIndex\":\"shopName\",\"title\":\"组织\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":200},{\"dataIndex\":\"reportDate\",\"title\":\"营业日期\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"shiftName\",\"title\":\"班次\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100},{\"dataIndex\":\"saasOrderKey\",\"title\":\"账单编号\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":110},{\"dataIndex\":\"areaName\",\"title\":\"楼层名称\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"tableName\",\"title\":\"房台名称\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"checkoutTimeName\",\"title\":\"餐段\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"personNum\",\"title\":\"人数\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":60},{\"dataIndex\":\"9ae44464b750efab9276b55e3703dcdf\",\"title\":\"销售额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":600,\"children\":[{\"dataIndex\":\"grossSalesAmt\",\"title\":\"毛销售额\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"returnedAmt\",\"title\":\"退菜金额\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"freeAmt\",\"title\":\"赠送金额\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"netSalesAmt\",\"title\":\"净销售额\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"foodProcessingFeeAmt\",\"title\":\"加工费\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"salesAmt\",\"title\":\"小计\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100}]},{\"dataIndex\":\"5d7dbac5d353bf2887ca06030e134844\",\"title\":\"服务费\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":300,\"children\":[{\"dataIndex\":\"foodServiceChargeAmt\",\"title\":\"食品服务费\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"processingServiceChargeAmt\",\"title\":\"加工服务费\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"serviceFeeAmt\",\"title\":\"小计\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100}]},{\"dataIndex\":\"bf0a6a83797d4a883bd54cccc0ce9535\",\"title\":\"菜品优惠\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":1000,\"children\":[{\"dataIndex\":\"foodDiscountAmt\",\"title\":\"食品折扣额\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"processingFeeDiscountAmt\",\"title\":\"加工费折扣额\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"37d4fd2c47318a2b3b0436ff8b37c80e\",\"title\":\"外卖优惠\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":300,\"children\":[{\"dataIndex\":\"platformDiscountAmtForM\",\"title\":\"美团\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100},{\"dataIndex\":\"platformDiscountAmtForE\",\"title\":\"饿了么\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100},{\"dataIndex\":\"platformDiscountAmtForJ\",\"title\":\"京东\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100}]},{\"dataIndex\":\"memberGiftVirtualIncome\",\"title\":\"会员赠送扣款\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"otherVirtualIncome\",\"title\":\"其他（团购/免单/券等）\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"fractionAmt\",\"title\":\"零头\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"mantissaAmt\",\"title\":\"尾数\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"foodPromotionAmt\",\"title\":\"小计\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100}]},{\"dataIndex\":\"b573ded041c0c418637b6cb76a85a3b3\",\"title\":\"收入合计\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":300,\"children\":[{\"dataIndex\":\"receivableAmtForV\",\"title\":\"虚收\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"receivableAmtForA\",\"title\":\"实收\",\"hidden\":false,\"fixed\":false,\"collapsed\":true,\"width\":100},{\"dataIndex\":\"receivableAmt\",\"title\":\"小计\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100}]},{\"dataIndex\":\"payName\",\"title\":\"结账方式\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":454},{\"dataIndex\":\"paidAmount\",\"title\":\"账单金额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"checkoutTime\",\"title\":\"结账时间\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":130},{\"dataIndex\":\"startTime\",\"title\":\"开台时间\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":130},{\"dataIndex\":\"checkoutBy\",\"title\":\"收银员\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"deviceCode\",\"title\":\"站点编号\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"deviceName\",\"title\":\"站点名称\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"taxFoodAmount\",\"title\":\"不含税食品费\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"taxServiceChargeAmount\",\"title\":\"不含税服务费\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"taxPaidAmount\",\"title\":\"不含税账单金额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"tax\",\"title\":\"税额\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"discountBy\",\"title\":\"折扣授权人\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80},{\"dataIndex\":\"discountRange\",\"title\":\"折扣类型\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":80}],\"sorts\":[]}',NULL,NULL,'2026-06-06 11:05:37',NULL,NULL,0),(28,1940284000182472704,1,2063187053608701953,1940284000190861312,'/reportformscenter/jdy/business-overview','{\"columns\":[{\"dataIndex\":\"key0\",\"title\":\"\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":100},{\"dataIndex\":\"val0\",\"title\":\"\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":50},{\"dataIndex\":\"key1\",\"title\":\"\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":473},{\"dataIndex\":\"val1\",\"title\":\"\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":150},{\"dataIndex\":\"key2\",\"title\":\"\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":151},{\"dataIndex\":\"val2\",\"title\":\"\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":150},{\"dataIndex\":\"key3\",\"title\":\"\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":150},{\"dataIndex\":\"val3\",\"title\":\"\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":150},{\"dataIndex\":\"key4\",\"title\":\"\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":50},{\"dataIndex\":\"val4\",\"title\":\"\",\"hidden\":false,\"fixed\":false,\"collapsed\":false,\"width\":200}],\"sorts\":[]}',NULL,NULL,'2026-06-06 17:11:40',NULL,'2026-06-09 15:28:06',0);
/*!40000 ALTER TABLE `biz_user_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dou_area`
--

DROP TABLE IF EXISTS `dou_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dou_area` (
  `area_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` smallint unsigned NOT NULL DEFAULT '0',
  `name` varchar(120) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`area_id`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4069 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dou_area`
--

LOCK TABLES `dou_area` WRITE;
/*!40000 ALTER TABLE `dou_area` DISABLE KEYS */;
/*!40000 ALTER TABLE `dou_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_info_store`
--

DROP TABLE IF EXISTS `invoice_info_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_info_store` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `taxpayer_num` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '销方纳税人识别号',
  `enterprise_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '销方企业名称',
  `legal_person_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '法人名称',
  `contacts_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '联系人名称',
  `contacts_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '联系人邮箱',
  `contacts_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '联系人手机号',
  `region_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '地区编码',
  `city_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '市(区)名',
  `enterprise_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '详细地址',
  `taxRegistration_certificate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '证件图片对应的cos地址',
  `review_opinion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核意见',
  `invoice_layout_file_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '电子发票版式文件类型;pdf：pdf 格式; ofd：ofd 格式。',
  `terminal_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '终端设备类型',
  `service_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '服务状态',
  `review_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核状态',
  `invoice_kind` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '开通的发票种类',
  `invitation_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '代理商邀请码',
  `item_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '开票项目',
  `tax_rate_value` decimal(24,6) DEFAULT NULL COMMENT '税率',
  `tax_classification_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '税收分类编码',
  `casher_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收款人',
  `reviewer_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '复核人',
  `drawer_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '开票人',
  `expire_day` int DEFAULT NULL COMMENT '二维码有效天数',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `invoice_unit` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发票单位',
  `dlzh` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '电子税局登录账号',
  `xfkhh` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '销方开户行名称',
  `xflxdh` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '销方联系方式',
  `xfyhzh` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '销方银行账号',
  `xfdz` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '销方地址',
  `invoice_type` int DEFAULT NULL COMMENT '通道类型',
  PRIMARY KEY (`pid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='门店的发票配置信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_info_store`
--

LOCK TABLES `invoice_info_store` WRITE;
/*!40000 ALTER TABLE `invoice_info_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_info_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plat_areas`
--

DROP TABLE IF EXISTS `plat_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plat_areas` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `code` bigint NOT NULL COMMENT '编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '名称',
  `city_code` bigint NOT NULL COMMENT '城市编号',
  `province_code` bigint NOT NULL COMMENT '省份编号',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_code` (`code`) USING BTREE,
  KEY `idx_province_code` (`province_code`) USING BTREE,
  KEY `idx_city_code` (`city_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2979 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='区县';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plat_areas`
--

LOCK TABLES `plat_areas` WRITE;
/*!40000 ALTER TABLE `plat_areas` DISABLE KEYS */;
/*!40000 ALTER TABLE `plat_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plat_cities`
--

DROP TABLE IF EXISTS `plat_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plat_cities` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `code` bigint NOT NULL COMMENT '编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '名称',
  `province_code` bigint NOT NULL COMMENT '省份编号',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_code` (`code`) USING BTREE,
  KEY `idx_province_code` (`province_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='城市';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plat_cities`
--

LOCK TABLES `plat_cities` WRITE;
/*!40000 ALTER TABLE `plat_cities` DISABLE KEYS */;
/*!40000 ALTER TABLE `plat_cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plat_provinces`
--

DROP TABLE IF EXISTS `plat_provinces`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plat_provinces` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `code` bigint NOT NULL COMMENT '编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '名称',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='省份';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plat_provinces`
--

LOCK TABLES `plat_provinces` WRITE;
/*!40000 ALTER TABLE `plat_provinces` DISABLE KEYS */;
/*!40000 ALTER TABLE `plat_provinces` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_intro_content`
--

DROP TABLE IF EXISTS `store_intro_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_intro_content` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '介绍内容/图片地址',
  `group_lid` bigint DEFAULT NULL COMMENT '分组编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  PRIMARY KEY (`pid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16537 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='店铺介绍分组内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_intro_content`
--

LOCK TABLES `store_intro_content` WRITE;
/*!40000 ALTER TABLE `store_intro_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `store_intro_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `store_intro_group`
--

DROP TABLE IF EXISTS `store_intro_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store_intro_group` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '分组名称',
  `type_` int DEFAULT NULL COMMENT '内容类型',
  `store_lid` bigint NOT NULL COMMENT '店铺编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `grid_cols` int NOT NULL DEFAULT '1' COMMENT '每行列数',
  `gap_x` int NOT NULL DEFAULT '0' COMMENT '左右间距',
  `gap_y` int NOT NULL DEFAULT '0' COMMENT '上下间距',
  `title_text_align` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'center' COMMENT '标题对齐方式',
  `address_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '地点名',
  `longitude` decimal(24,6) DEFAULT NULL COMMENT '精度',
  `latitude` decimal(24,6) DEFAULT NULL COMMENT '纬度',
  PRIMARY KEY (`pid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5304 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='店铺介绍分组';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store_intro_group`
--

LOCK TABLES `store_intro_group` WRITE;
/*!40000 ALTER TABLE `store_intro_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `store_intro_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_org_group`
--

DROP TABLE IF EXISTS `sys_org_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_org_group` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `stores` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '门店',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='门店分组';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_org_group`
--

LOCK TABLES `sys_org_group` WRITE;
/*!40000 ALTER TABLE `sys_org_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_org_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_color`
--

DROP TABLE IF EXISTS `wx_color`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_color` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `rgb` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '颜色',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `font_color` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '字体颜色',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='皮肤颜色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_color`
--

LOCK TABLES `wx_color` WRITE;
/*!40000 ALTER TABLE `wx_color` DISABLE KEYS */;
/*!40000 ALTER TABLE `wx_color` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_componet`
--

DROP TABLE IF EXISTS `wx_componet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_componet` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `page_lid` bigint DEFAULT NULL COMMENT '页面编号',
  `type_` int DEFAULT NULL COMMENT '类型',
  `style` int DEFAULT NULL COMMENT '样式',
  `arc` int DEFAULT NULL COMMENT '圆角弧度',
  `top_margin` int DEFAULT NULL COMMENT '上边距',
  `bottom_margin` int DEFAULT NULL COMMENT '下边距',
  `left_and_right_margin` int DEFAULT NULL COMMENT '左右边距',
  `bg_color` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '背景色',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `idx` int DEFAULT NULL COMMENT '索引',
  `title` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '组件标题',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '标题',
  `color` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '字体颜色',
  `text_align` int DEFAULT NULL COMMENT '位置',
  `font_size` int DEFAULT NULL COMMENT '字体大小',
  `per_row_num` int DEFAULT NULL COMMENT '每行组件数量',
  `top_left_arc` int DEFAULT NULL COMMENT '左上圆角',
  `top_right_arc` int DEFAULT NULL COMMENT '右上圆角',
  `bottom_left_arc` int DEFAULT NULL COMMENT '左下圆角',
  `bottom_right_arc` int DEFAULT NULL COMMENT '右下圆角',
  `height` int DEFAULT NULL COMMENT '组件高度',
  `page_path` int DEFAULT NULL COMMENT '跳转页面',
  `uri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'h5或公众号文章地址',
  `jump_type` int DEFAULT NULL COMMENT '跳转类型',
  `color2` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '字体颜色2',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '背景图片',
  `left_and_right_padding` int DEFAULT NULL COMMENT '左右内边距',
  `video` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '视频地址',
  `font_bold` int DEFAULT NULL COMMENT '字段粗细',
  `title_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '标题背景图',
  `auto` tinyint(1) NOT NULL DEFAULT '1' COMMENT '自动播放',
  `extra_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '额外信息',
  `top_bottom_padding` int DEFAULT NULL COMMENT '上下内边距',
  `avatar_size` int DEFAULT NULL COMMENT '会员头像大小',
  `icon_size` int DEFAULT NULL COMMENT '图标大小',
  `icon_x_gap` decimal(24,6) DEFAULT NULL COMMENT '组件间隙',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE,
  KEY `idx_mid_page_lid` (`mid`,`page_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33560 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='页面组件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_componet`
--

LOCK TABLES `wx_componet` WRITE;
/*!40000 ALTER TABLE `wx_componet` DISABLE KEYS */;
INSERT INTO `wx_componet` VALUES (33553,1940284000182472704,1979737429467095041,2054500901953343489,2054500901898817538,1,0,0,0,0,0,'',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,0,'轮播图','','#000',0,14,NULL,0,0,0,0,300,NULL,'',NULL,'','',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL),(33554,1940284000182472704,1979737429467095041,2054500901961732098,2054500901898817538,10,0,0,-50,0,10,'#000000',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,1,'卡权益','会员权益卡 | 超多权益，等你来拿','#ffffff',0,14,NULL,10,10,0,0,200,2,'https://www.baidu.com',1,'','',15,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL),(33555,1940284000182472704,1979737429467095041,2054500901965926401,2054500901898817538,9,0,0,0,0,10,'',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,2,'分组','','#000',0,14,4,0,0,10,10,200,NULL,'',NULL,'','',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL),(33556,1940284000182472704,1979737429467095041,2054500901965926402,2054500901898817538,6,0,0,0,0,0,'',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,3,'轮滑图','','#000',0,14,NULL,0,0,0,0,140,NULL,'',NULL,'','',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL),(33557,1940284000182472704,1979737429467095041,2054500901970120706,2054500901898817538,1,0,0,-10,0,0,'',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,4,'轮播图','','#000',0,14,NULL,0,0,0,0,140,NULL,'',NULL,'','',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL),(33558,1940284000182472704,1942885905090105345,2055530124137467905,2055530124066164737,1,0,0,0,0,0,'',NULL,NULL,'2026-05-16 06:05:46',NULL,NULL,0,0,'轮播图','','#000',0,14,NULL,0,0,0,0,200,NULL,'',NULL,'','',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL),(33559,1940284000182472704,2042804773847437313,2055532465561538562,2055532465553149954,1,0,0,0,0,0,'',NULL,NULL,'2026-05-16 06:15:04',NULL,NULL,0,0,'轮播图','','#000',0,14,NULL,0,0,0,0,200,NULL,'',NULL,'','',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `wx_componet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_componet_item`
--

DROP TABLE IF EXISTS `wx_componet_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_componet_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `componet_lid` bigint DEFAULT NULL COMMENT '组件编号',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '图片地址',
  `func` int DEFAULT NULL COMMENT '功能',
  `title` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '标题',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '描述',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `idx` int DEFAULT NULL COMMENT '索引',
  `page_lid` bigint DEFAULT NULL COMMENT '索引',
  `position_` int DEFAULT NULL COMMENT '位置',
  `uri` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'h5或公众号文章地址',
  `jump_type` int DEFAULT NULL COMMENT '跳转类型',
  `extra_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '额外信息',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE,
  KEY `idx_mid_page_lid` (`mid`,`page_lid`) USING BTREE,
  KEY `idx_mid_cpt_lid` (`mid`,`componet_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=52642 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='组件元素';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_componet_item`
--

LOCK TABLES `wx_componet_item` WRITE;
/*!40000 ALTER TABLE `wx_componet_item` DISABLE KEYS */;
INSERT INTO `wx_componet_item` VALUES (52625,1940284000182472704,1979737429467095041,2054500902020452354,2054500901953343489,'167108312607705269/167108312607805270/image/wx/cb563481f322150241154418ce4cf1cf.png',2,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,0,2054500901898817538,NULL,'',1,NULL),(52626,1940284000182472704,1979737429467095041,2054500902024646658,2054500901953343489,'167108312607705269/167108312607805270/image/wx/206af4e30f800211b8f24063712c2dd8.png',NULL,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,1,2054500901898817538,NULL,'',1,NULL),(52627,1940284000182472704,1979737429467095041,2054500902037229569,2054500901965926401,'167108312607705269/167108312607805270/image/wx/4e4627499fde8598cee09864c21225a3.png',5,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,0,2054500901898817538,1,'',1,NULL),(52628,1940284000182472704,1979737429467095041,2054500902037229570,2054500901965926401,'/wechat/page//points_mall.png',10,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,1,2054500901898817538,1,'',1,NULL),(52629,1940284000182472704,1979737429467095041,2054500902041423873,2054500901965926401,'/wechat/page//change_password.png',14,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,2,2054500901898817538,1,'',1,NULL),(52630,1940284000182472704,1979737429467095041,2054500902041423874,2054500901965926401,'/wechat/page//store_navigation.png',21,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,3,2054500901898817538,1,'',1,NULL),(52631,1940284000182472704,1979737429467095041,2054500902041423875,2054500901965926401,'/wechat/page//improve_information.png',12,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,4,2054500901898817538,1,'',1,NULL),(52632,1940284000182472704,1979737429467095041,2054500902041423876,2054500901965926401,'/wechat/page//order.png',3,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,5,2054500901898817538,1,'',1,NULL),(52633,1940284000182472704,1979737429467095041,2054500902041423877,2054500901965926401,'/wechat/page//collect_coupon.png',22,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,6,2054500901898817538,1,'',1,NULL),(52634,1940284000182472704,1979737429467095041,2054500902041423878,2054500901965926401,'/wechat/page//recharge.png',6,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,7,2054500901898817538,1,'',1,NULL),(52635,1940284000182472704,1979737429467095041,2054500902041423879,2054500901965926401,'/wechat/page//coupon.png',16,'券',NULL,NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,8,2054500901898817538,1,'',1,'{}'),(52636,1940284000182472704,1979737429467095041,2054500902054006785,2054500901965926402,'167108312607705269/167108312607805270/image/wx/ed2781453579318079a510d4f7c4960f.png',NULL,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,0,2054500901898817538,NULL,'',1,NULL),(52637,1940284000182472704,1979737429467095041,2054500902054006786,2054500901970120706,'167108312607705269/167108312607805270/image/wx/ed93ff43f19c5485e2a3b98dce0244fc.png',NULL,'图片','',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,0,2054500901898817538,NULL,'',1,NULL),(52638,1940284000182472704,1942885905090105345,2055530124179410946,2055530124137467905,'167108312607705269/167108312607805270/image/wx/2f629bccb49de2176063febf672690f9.png',NULL,'图片','',NULL,NULL,'2026-05-16 06:05:46',NULL,NULL,0,0,2055530124066164737,NULL,'',1,NULL),(52639,1940284000182472704,1942885905090105345,2055530124179410947,2055530124137467905,'167108312607705269/167108312607805270/image/wx/f1f92e684b323ba370ca1b4f5683dc7e.png',NULL,'图片','',NULL,NULL,'2026-05-16 06:05:46',NULL,NULL,0,1,2055530124066164737,NULL,'',1,NULL),(52640,1940284000182472704,2042804773847437313,2055532465565732866,2055532465561538562,'167108312607705269/167108312607805270/image/wx/2f629bccb49de2176063febf672690f9.png',NULL,'图片','',NULL,NULL,'2026-05-16 06:15:04',NULL,NULL,0,0,2055532465553149954,NULL,'',1,NULL),(52641,1940284000182472704,2042804773847437313,2055532465569927169,2055532465561538562,'167108312607705269/167108312607805270/image/wx/f1f92e684b323ba370ca1b4f5683dc7e.png',NULL,'图片','',NULL,NULL,'2026-05-16 06:15:04',NULL,NULL,0,1,2055532465553149954,NULL,'',1,NULL);
/*!40000 ALTER TABLE `wx_componet_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_navigation`
--

DROP TABLE IF EXISTS `wx_navigation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_navigation` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `idx` bigint DEFAULT NULL COMMENT '索引',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '未选中时的图标',
  `selected_icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '选中时的图标',
  `text` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `page_path` int DEFAULT NULL COMMENT '页面',
  `bg_color` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '背景色',
  `text_color` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '文字颜色',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2065 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='小程序底部导航';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_navigation`
--

LOCK TABLES `wx_navigation` WRITE;
/*!40000 ALTER TABLE `wx_navigation` DISABLE KEYS */;
/*!40000 ALTER TABLE `wx_navigation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_page`
--

DROP TABLE IF EXISTS `wx_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_page` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `type_` int DEFAULT NULL COMMENT '页面类型',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '标题',
  `style` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '样式',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `bg_color` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '背景颜色',
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '背景图',
  `full_screen` tinyint DEFAULT NULL COMMENT '占满屏幕',
  `bg_height` int DEFAULT NULL COMMENT '背景图高度',
  `ext_color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '预留颜色',
  `ext_color1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '预留颜色1',
  `ext_color2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '预留颜色2',
  `ext_color3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '预留颜色2',
  `extra_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '额外信息',
  `enable` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `device_ids` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '设备json数组',
  `vertical_screen` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否竖屏',
  `template_lid` bigint DEFAULT NULL COMMENT '模板lid',
  `template_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '模板名称',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_type` (`mid`,`type_`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1535 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='小程序页面';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_page`
--

LOCK TABLES `wx_page` WRITE;
/*!40000 ALTER TABLE `wx_page` DISABLE KEYS */;
INSERT INTO `wx_page` VALUES (1532,1940284000182472704,1979737429467095041,2054500901898817538,1,NULL,'',NULL,NULL,'2026-05-13 09:56:00',NULL,NULL,0,NULL,'',0,0,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL),(1533,1940284000182472704,1942885905090105345,2055530124066164737,10,NULL,'',NULL,NULL,'2026-05-16 06:05:46',NULL,NULL,0,NULL,'',0,0,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL),(1534,1940284000182472704,2042804773847437313,2055532465553149954,10,NULL,'',NULL,NULL,'2026-05-16 06:15:04',NULL,NULL,0,NULL,'',0,0,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `wx_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_program_template`
--

DROP TABLE IF EXISTS `wx_program_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_program_template` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '编号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '小程序代码上传记录名称',
  `appid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'appid',
  `commit_audit_time` datetime DEFAULT NULL COMMENT '上传时间',
  `operator` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '操作员',
  `template_ver` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '模板版本号',
  `template_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '模板描述',
  `template_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '模板编号',
  `template_create_time` datetime DEFAULT NULL COMMENT '模板创建时间',
  `submit_audit_time` datetime DEFAULT NULL COMMENT '提交审核时间',
  `auditid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核id',
  `audit_status` int DEFAULT NULL COMMENT '审核状态',
  `audit_reject_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核被拒绝原因',
  `audit_reject_screenshot` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审核失败的小程序截图示例',
  `released` tinyint(1) DEFAULT NULL COMMENT '已经发布',
  `release_time` datetime DEFAULT NULL COMMENT '发布时间',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1065 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='小程序代码模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_program_template`
--

LOCK TABLES `wx_program_template` WRITE;
/*!40000 ALTER TABLE `wx_program_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `wx_program_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_template_label`
--

DROP TABLE IF EXISTS `wx_template_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_template_label` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '名称',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '图片地址',
  `temp_lid` bigint DEFAULT NULL COMMENT '模板lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_name` (`mid`,`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='广告模板标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_template_label`
--

LOCK TABLES `wx_template_label` WRITE;
/*!40000 ALTER TABLE `wx_template_label` DISABLE KEYS */;
/*!40000 ALTER TABLE `wx_template_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'a_biz'
--

--
-- Dumping routines for database 'a_biz'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-13 10:47:55
