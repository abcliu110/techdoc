-- MySQL dump 10.13  Distrib 8.4.7, for Linux (x86_64)
--
-- Host: localhost    Database: a_ams
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `a_ams`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `a_ams` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `a_ams`;

--
-- Table structure for table `account_addr`
--

DROP TABLE IF EXISTS `account_addr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_addr` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `user_id` bigint DEFAULT NULL COMMENT '用户编号',
  `consignee` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收货人姓名',
  `email` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收货人邮箱',
  `mobile` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收货人手机',
  `country_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '国家编号',
  `country_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '国家名称',
  `province_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '省份编号',
  `province_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '省份名称',
  `city_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '城市编号',
  `city_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '城市名称',
  `county_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区县编号',
  `county_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '区县名称',
  `street_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '街道编号',
  `street_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '街道名称',
  `detailed_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '详细地址',
  `postal_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮编',
  `is_default` tinyint(1) DEFAULT NULL COMMENT '默认地址',
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签',
  `longitude` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '经度',
  `latitude` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '纬度',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_user_id` (`mid`,`user_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='用户地址';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_addr`
--

LOCK TABLES `account_addr` WRITE;
/*!40000 ALTER TABLE `account_addr` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_addr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_platform`
--

DROP TABLE IF EXISTS `account_platform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_platform` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `third_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '第三方平台的用户标识;比如微信公众号的OPENID',
  `user_id` bigint NOT NULL COMMENT '用户编号',
  `org_type` int NOT NULL COMMENT '组织类型',
  `user_type` int NOT NULL COMMENT '类型',
  `app_type` int NOT NULL COMMENT '平台类型',
  `app_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '平台id;比如微信公众号的appid',
  `nickname` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `created_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建者',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新者',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '删除标志;（0代表存在 1代表删除）',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_third_id` (`third_id`) USING BTREE,
  KEY `idx_user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14378 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='第三方平台用户信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_platform`
--

LOCK TABLES `account_platform` WRITE;
/*!40000 ALTER TABLE `account_platform` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_platform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_user`
--

DROP TABLE IF EXISTS `account_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_user` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `user_type` int NOT NULL COMMENT '类型',
  `username` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户名',
  `password` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '密码',
  `salt` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '盐',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '员工姓名',
  `email` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `gender` int DEFAULT NULL COMMENT '员工性别',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '员工头像(相对路径)',
  `nickname` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '员工昵称',
  `province_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '省份编号',
  `province_label` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '省份名称',
  `city_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '城市编号',
  `city_label` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '城市名称',
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '街道地址',
  `signature` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '个性签名',
  `resume` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '个人简介',
  `def` tinyint(1) DEFAULT NULL COMMENT '默认',
  `create_ip_at` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建ip',
  `last_login_at` datetime DEFAULT NULL COMMENT '最后一次登录时间',
  `last_login_ip_at` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '最后一次登录ip',
  `login_times` int DEFAULT '0' COMMENT '登录次数',
  `disable` tinyint(1) DEFAULT NULL COMMENT '禁用',
  `created_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建者',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新者',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '删除标志;（0代表存在 1代表删除）',
  `effective_time` datetime DEFAULT NULL COMMENT '生效时间',
  `expiry_time` datetime DEFAULT NULL COMMENT '失效时间',
  `business_type` int DEFAULT NULL COMMENT '业务类型',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_type_username` (`mid`,`user_type`,`username`) USING BTREE,
  KEY `idx_mid_type_phone` (`mid`,`user_type`,`phone`) USING BTREE,
  KEY `idx_mid_type_email` (`mid`,`user_type`,`email`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25046 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='账户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_user`
--

LOCK TABLES `account_user` WRITE;
/*!40000 ALTER TABLE `account_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '权限标识',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜单名称',
  `parent_id` bigint DEFAULT NULL COMMENT '父菜单ID',
  `order_num` int DEFAULT NULL COMMENT '显示顺序',
  `is_dir` tinyint(1) DEFAULT NULL COMMENT '目录',
  `invisible` tinyint(1) DEFAULT NULL COMMENT '隐藏',
  `def` tinyint(1) DEFAULT NULL COMMENT '默认',
  `created_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建者',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新者',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_id` (`mid`,`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='系统权限';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_item`
--

LOCK TABLES `auth_item` WRITE;
/*!40000 ALTER TABLE `auth_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_role`
--

DROP TABLE IF EXISTS `auth_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_role` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'id(权限字符)的md5',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '权限字符',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '角色名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '角色描述',
  `display_order` int DEFAULT NULL COMMENT '显示顺序',
  `data_scope` int DEFAULT NULL COMMENT '数据权限',
  `data_scope_set` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '数据权限集',
  `def` tinyint(1) DEFAULT NULL COMMENT '默认',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `auth_item_set` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '权限集合 多个值,号隔开',
  `disable` tinyint(1) DEFAULT NULL COMMENT '禁用',
  `created_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建者',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新者',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '删除标志;（0代表存在 1代表删除）',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_mid_lid` (`mid`,`lid`) USING BTREE,
  KEY `idx_mid_id_key` (`mid`,`id_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='员工角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_role`
--

LOCK TABLES `auth_role` WRITE;
/*!40000 ALTER TABLE `auth_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_role_staff`
--

DROP TABLE IF EXISTS `auth_role_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_role_staff` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint DEFAULT NULL COMMENT '逻辑编号',
  `staff_id` bigint NOT NULL COMMENT '员工id',
  `role_set` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '角色集合 多个值,号隔开',
  `disable` tinyint(1) DEFAULT NULL COMMENT '禁用',
  `created_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建者',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新者',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_staff_id` (`mid`,`staff_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25043 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='权限角色与员工关系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_role_staff`
--

LOCK TABLES `auth_role_staff` WRITE;
/*!40000 ALTER TABLE `auth_role_staff` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_role_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_balance`
--

DROP TABLE IF EXISTS `cap_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_balance` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `org_type` int NOT NULL COMMENT '机构类型',
  `use_type` int DEFAULT NULL COMMENT '用户类型',
  `cap_biz_type` int NOT NULL COMMENT '业务类型',
  `account_id` bigint NOT NULL COMMENT '账户id',
  `currency_type` int NOT NULL COMMENT '币种',
  `scale` int NOT NULL COMMENT '金额对应的小数位数;用于转成浮点数',
  `total` int NOT NULL COMMENT '总余额',
  `principal` int NOT NULL COMMENT '本金',
  `gift` int NOT NULL COMMENT '赠送金额',
  `state` int NOT NULL COMMENT '状态',
  `ver` int NOT NULL COMMENT '余额版本号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_account_id` (`mid`,`account_id`) USING BTREE,
  KEY `idx_mid_biz_type` (`mid`,`cap_biz_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=772701 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='余额表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_balance`
--

LOCK TABLES `cap_balance` WRITE;
/*!40000 ALTER TABLE `cap_balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `cap_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_balance_flow`
--

DROP TABLE IF EXISTS `cap_balance_flow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_balance_flow` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '流水id',
  `org_type` int NOT NULL COMMENT '机构类型',
  `use_type` int DEFAULT NULL COMMENT '用户类型',
  `cap_biz_type` int NOT NULL COMMENT '业务类型',
  `deal_type` int DEFAULT NULL COMMENT '交易类型;由各个业务模块自己定义，比如充值、退款',
  `voucher_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '凭证 ID;一般是业务单号（如订单 ID、退款单 ID 等）',
  `total` int NOT NULL COMMENT '发生总金额',
  `scale` int NOT NULL COMMENT '金额对应的小数位数;用于转成浮点数',
  `principal` int NOT NULL COMMENT '发生本金',
  `gift` int NOT NULL COMMENT '发生赠送金额',
  `total_before` int NOT NULL COMMENT '起始总金额',
  `principal_before` int NOT NULL COMMENT '起始本金',
  `gift_before` int NOT NULL COMMENT '起始赠送金额',
  `total_after` int NOT NULL COMMENT '终止总金额',
  `principal_after` int NOT NULL COMMENT '终止本金',
  `gift_after` int NOT NULL COMMENT '终止赠送金额',
  `direction` int NOT NULL COMMENT '变动方向',
  `is_rollback` tinyint(1) DEFAULT NULL COMMENT '回滚单;1为回滚单，0为正常单',
  `org_id` bigint DEFAULT NULL COMMENT '原始订单;撤销单时，才有值',
  `src_account_id` bigint NOT NULL COMMENT '源账户id',
  `dest_account_id` bigint DEFAULT NULL COMMENT '目的账号id',
  `currency_type` int NOT NULL COMMENT '币种',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `ver` int DEFAULT NULL COMMENT '余额版本号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `report_date` datetime DEFAULT NULL COMMENT '会计日期',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_voucher_id` (`voucher_id`) USING BTREE,
  KEY `idx_src_account_id` (`src_account_id`) USING BTREE,
  KEY `idx_mid_biz_type_report_time` (`mid`,`cap_biz_type`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=773334 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='余额流水表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_balance_flow`
--

LOCK TABLES `cap_balance_flow` WRITE;
/*!40000 ALTER TABLE `cap_balance_flow` DISABLE KEYS */;
/*!40000 ALTER TABLE `cap_balance_flow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_balance_task`
--

DROP TABLE IF EXISTS `cap_balance_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_balance_task` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `org_type` int NOT NULL COMMENT '机构类型',
  `use_type` int DEFAULT NULL COMMENT '用户类型',
  `cap_biz_type` int NOT NULL COMMENT '业务类型',
  `deal_type` int DEFAULT NULL COMMENT '交易类型',
  `voucher_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '凭证 ID;一般是业务单号（如订单 ID、退款单 ID 等）',
  `org_voucher_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '原始凭证 ID;撤销单该字段才有值，标识被撤销的原始单据',
  `total` int NOT NULL COMMENT '发生总金额',
  `scale` int NOT NULL COMMENT '金额对应的小数位数;用于转成浮点数',
  `principal` int NOT NULL COMMENT '发生本金',
  `gift` int NOT NULL COMMENT '发生赠送金额',
  `src_account_id` bigint NOT NULL COMMENT '源账户id',
  `dest_account_id` bigint DEFAULT NULL COMMENT '目的账号id',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `currency_type` int NOT NULL COMMENT '币种',
  `delay_time_to_check_for_rollback` int DEFAULT NULL COMMENT '延时检查时间',
  `redis_key_for_rollback` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '判断是否需要回滚的;延迟delay_time_to_check_for_rollback，如果key存在，就需要回滚',
  `rolled_back` tinyint(1) DEFAULT NULL COMMENT '已经回滚',
  `rollback_time` datetime DEFAULT NULL COMMENT '回滚时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_voucher_id` (`org_voucher_id`) USING BTREE,
  KEY `idx_mid_create_time` (`mid`,`created_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=915 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='余额变动任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_balance_task`
--

LOCK TABLES `cap_balance_task` WRITE;
/*!40000 ALTER TABLE `cap_balance_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `cap_balance_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_coupon`
--

DROP TABLE IF EXISTS `cap_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_coupon` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `category_id` bigint DEFAULT NULL COMMENT '目录',
  `title` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题',
  `state` int DEFAULT NULL COMMENT '发布状态',
  `image` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '图片',
  `price` int DEFAULT NULL COMMENT '价格',
  `user_limit` int DEFAULT NULL COMMENT '每人限领张数',
  `start_time` datetime DEFAULT NULL COMMENT '开始有效时间',
  `end_time` datetime DEFAULT NULL COMMENT '失效时间',
  `pulish_count` int DEFAULT NULL COMMENT '发行总数',
  `stock` int DEFAULT NULL COMMENT '当前库存',
  `condition_price` int DEFAULT NULL COMMENT '满多少才可以使用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_category` (`mid`,`category_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='优惠券';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_coupon`
--

LOCK TABLES `cap_coupon` WRITE;
/*!40000 ALTER TABLE `cap_coupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `cap_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_coupon_category`
--

DROP TABLE IF EXISTS `cap_coupon_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_coupon_category` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `title` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='优惠券类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_coupon_category`
--

LOCK TABLES `cap_coupon_category` WRITE;
/*!40000 ALTER TABLE `cap_coupon_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cap_coupon_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_coupon_record`
--

DROP TABLE IF EXISTS `cap_coupon_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_coupon_record` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `coupon_id` bigint DEFAULT NULL COMMENT '优惠券id',
  `coupon_name` bigint DEFAULT NULL COMMENT '优惠券标题',
  `state` int DEFAULT NULL COMMENT '状态',
  `user_id` bigint DEFAULT NULL COMMENT '用户id',
  `user_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户昵称',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `order_id` bigint DEFAULT NULL COMMENT '订单编号',
  `price` int DEFAULT NULL COMMENT '抵扣架构',
  `condition_price` int DEFAULT NULL COMMENT '满多少才可以使用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_user_id` (`mid`,`user_id`) USING BTREE,
  KEY `idx_mid_order_id` (`mid`,`order_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='领券记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_coupon_record`
--

LOCK TABLES `cap_coupon_record` WRITE;
/*!40000 ALTER TABLE `cap_coupon_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `cap_coupon_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_coupon_task`
--

DROP TABLE IF EXISTS `cap_coupon_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_coupon_task` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `coupon_record_id` bigint DEFAULT NULL COMMENT '优惠券记录id',
  `out_trade_no` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单号',
  `state` int DEFAULT NULL COMMENT '锁定状态',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_record_id` (`mid`,`coupon_record_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='优惠券记录锁定任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_coupon_task`
--

LOCK TABLES `cap_coupon_task` WRITE;
/*!40000 ALTER TABLE `cap_coupon_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `cap_coupon_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_rights`
--

DROP TABLE IF EXISTS `cap_rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_rights` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `org_type` int NOT NULL COMMENT '机构类型',
  `use_type` int DEFAULT NULL COMMENT '用户类型',
  `cap_biz_type` int NOT NULL COMMENT '业务类型',
  `account_id` bigint NOT NULL COMMENT '账户id',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `state` int NOT NULL COMMENT '状态',
  `ver` bigint DEFAULT NULL COMMENT '过期时间版本号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_biz_type_account_id` (`mid`,`cap_biz_type`,`account_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=652744 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='权益表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_rights`
--

LOCK TABLES `cap_rights` WRITE;
/*!40000 ALTER TABLE `cap_rights` DISABLE KEYS */;
INSERT INTO `cap_rights` VALUES (652743,1,1,2057366543261167616,4,1,25,1942885905090105345,'2026-06-05 15:43:03',1,1,NULL,NULL,'2026-05-21 15:43:02',NULL,'2026-05-21 15:43:02',0);
/*!40000 ALTER TABLE `cap_rights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_rights_flow`
--

DROP TABLE IF EXISTS `cap_rights_flow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_rights_flow` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '流水id',
  `org_type` int NOT NULL COMMENT '机构类型',
  `use_type` int DEFAULT NULL COMMENT '用户类型',
  `cap_biz_type` int NOT NULL COMMENT '业务类型',
  `deal_type` int DEFAULT NULL COMMENT '交易类型;由各个业务模块自己定义，比如充值、退款',
  `voucher_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '凭证 ID;一般是业务单号（如订单 ID、退款单 ID 等）',
  `time_value` int NOT NULL COMMENT '改变时间',
  `time_unit` int NOT NULL COMMENT '时间单位;用于转成浮点数',
  `expired_time_before` datetime NOT NULL COMMENT '变更前',
  `expired_time_after` datetime NOT NULL COMMENT '变更后',
  `direction` int NOT NULL COMMENT '变动方向;1为入账，0为出账',
  `is_rollback` tinyint(1) DEFAULT NULL COMMENT '回滚单;1为回滚单，0为正常单',
  `org_id` bigint DEFAULT NULL COMMENT '原始订单;退款单时，才有值',
  `src_account_id` bigint NOT NULL COMMENT '源账户id',
  `dest_account_id` bigint DEFAULT NULL COMMENT '目的账号id',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `ver` int DEFAULT NULL COMMENT '余额版本号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `report_date` datetime DEFAULT NULL COMMENT '会计日期',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_account_id_report_time` (`mid`,`cap_biz_type`,`src_account_id`,`report_date`) USING BTREE,
  KEY `idx_mid_voucher_id_report_time` (`mid`,`cap_biz_type`,`voucher_id`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=645200 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='权益流水表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_rights_flow`
--

LOCK TABLES `cap_rights_flow` WRITE;
/*!40000 ALTER TABLE `cap_rights_flow` DISABLE KEYS */;
INSERT INTO `cap_rights_flow` VALUES (645199,1,1,2057366543269556224,4,1,25,1,'2057366543206641664',14,7,'2026-05-21 15:43:03','2026-06-05 15:43:03',2,0,NULL,1942885905090105345,NULL,NULL,1,NULL,NULL,NULL,'2026-05-21 15:43:02',NULL,NULL,0);
/*!40000 ALTER TABLE `cap_rights_flow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_rights_task`
--

DROP TABLE IF EXISTS `cap_rights_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_rights_task` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `org_type` int NOT NULL COMMENT '机构类型',
  `use_type` int DEFAULT NULL COMMENT '用户类型',
  `cap_biz_type` int NOT NULL COMMENT '业务类型',
  `deal_type` int DEFAULT NULL COMMENT '交易类型',
  `voucher_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '凭证 ID;一般是业务单号（如订单 ID、退款单 ID 等）',
  `org_voucher_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '原始凭证 ID;撤销单该字段才有值，标识被撤销的原始单据',
  `time_value` int DEFAULT NULL COMMENT '变化时间',
  `time_unit` int DEFAULT NULL COMMENT '时间单位;用于转成浮点数',
  `expired_time` datetime DEFAULT NULL COMMENT '过期时间',
  `src_account_id` bigint DEFAULT NULL COMMENT '源账户id',
  `dest_account_id` bigint DEFAULT NULL COMMENT '目的账号id',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `delay_time_to_check_for_rollback` int DEFAULT NULL COMMENT '延时检查时间',
  `redis_key_for_rollback` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '判断是否需要回滚的;延迟delay_time_to_check_for_rollback，如果key存在，就需要回滚',
  `rolled_back` tinyint(1) DEFAULT NULL COMMENT '已经回滚',
  `rollback_time` datetime DEFAULT NULL COMMENT '回滚时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2096 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='权益表变动任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_rights_task`
--

LOCK TABLES `cap_rights_task` WRITE;
/*!40000 ALTER TABLE `cap_rights_task` DISABLE KEYS */;
INSERT INTO `cap_rights_task` VALUES (2095,1,1,2057366543655432192,4,1,25,1,'2057366543206641664',NULL,NULL,NULL,'2026-06-05 15:43:03',1942885905090105345,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'2026-05-21 15:43:02',NULL,NULL,0);
/*!40000 ALTER TABLE `cap_rights_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_traffic`
--

DROP TABLE IF EXISTS `cap_traffic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_traffic` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `org_type` int NOT NULL COMMENT '机构类型',
  `use_type` int DEFAULT NULL COMMENT '用户类型',
  `cap_biz_type` int NOT NULL COMMENT '业务类型',
  `account_id` bigint NOT NULL COMMENT '账户id',
  `expired_time` datetime NOT NULL COMMENT '过期时间',
  `spu_lid` bigint DEFAULT NULL COMMENT 'spu',
  `spu_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'spu名称',
  `sku_lid` bigint DEFAULT NULL COMMENT 'sku',
  `limit_times` int DEFAULT NULL COMMENT '限制次数',
  `used_times` int DEFAULT NULL COMMENT '已用次数',
  `app_trade_no` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商城订单号',
  `billing_type` int DEFAULT NULL COMMENT '计费类型',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_account_id` (`mid`,`account_id`) USING BTREE,
  KEY `idx_mid_app_trade_no` (`mid`,`app_trade_no`) USING BTREE,
  KEY `idx_expired_time` (`expired_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='流量包';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_traffic`
--

LOCK TABLES `cap_traffic` WRITE;
/*!40000 ALTER TABLE `cap_traffic` DISABLE KEYS */;
/*!40000 ALTER TABLE `cap_traffic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cap_traffic_task`
--

DROP TABLE IF EXISTS `cap_traffic_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cap_traffic_task` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `org_type` int NOT NULL COMMENT '机构类型',
  `use_type` int DEFAULT NULL COMMENT '用户类型',
  `cap_biz_type` int NOT NULL COMMENT '业务类型',
  `account_id` bigint NOT NULL COMMENT '账户id',
  `use_times` int NOT NULL COMMENT '扣减次数',
  `voucher_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '凭证 ID;一般是业务单号（如订单 ID、退款单 ID 等）',
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `delay_time_to_check_for_rollback` int DEFAULT NULL COMMENT '延时检查时间',
  `redis_key_for_rollback` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '判断是否需要回滚的;延迟delay_time_to_check_for_rollback，如果key存在，就需要回滚',
  `rolled_back` tinyint(1) DEFAULT NULL COMMENT '已经回滚',
  `rollback_time` datetime DEFAULT NULL COMMENT '回滚时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_voucher_id` (`voucher_id`) USING BTREE,
  KEY `idx_biz_type_account_id` (`mid`,`cap_biz_type`,`account_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='流量包任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cap_traffic_task`
--

LOCK TABLES `cap_traffic_task` WRITE;
/*!40000 ALTER TABLE `cap_traffic_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `cap_traffic_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_recharge_pkg`
--

DROP TABLE IF EXISTS `crm_recharge_pkg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_recharge_pkg` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `spu_lid` bigint DEFAULT NULL COMMENT 'spu',
  `sku_lid` bigint DEFAULT NULL COMMENT 'sku',
  `save_amount` bigint DEFAULT NULL COMMENT '充值金额',
  `give_amount` bigint DEFAULT NULL COMMENT '赠送金额',
  `give_point` bigint DEFAULT NULL COMMENT '赠送积分',
  `give_coupon_id` bigint DEFAULT NULL COMMENT '赠送券编号',
  `give_coupon_num` int DEFAULT NULL COMMENT '赠送券数量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  UNIQUE KEY `idx_mid_sku` (`mid`,`sku_lid`) USING BTREE,
  UNIQUE KEY `idx_mid_spu` (`mid`,`spu_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='充值套餐';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_recharge_pkg`
--

LOCK TABLES `crm_recharge_pkg` WRITE;
/*!40000 ALTER TABLE `crm_recharge_pkg` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_recharge_pkg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_rights_pkg`
--

DROP TABLE IF EXISTS `crm_rights_pkg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_rights_pkg` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `spu_lid` bigint DEFAULT NULL COMMENT 'spu',
  `sku_lid` bigint DEFAULT NULL COMMENT 'sku',
  `add_time` int DEFAULT NULL COMMENT '增加时间',
  `time_unit` int DEFAULT NULL COMMENT '时间单位',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sku` (`mid`,`sku_lid`) USING BTREE,
  KEY `idx_mid_spu` (`mid`,`spu_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='会员权益套餐';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_rights_pkg`
--

LOCK TABLES `crm_rights_pkg` WRITE;
/*!40000 ALTER TABLE `crm_rights_pkg` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_rights_pkg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crm_traffic_pkg`
--

DROP TABLE IF EXISTS `crm_traffic_pkg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crm_traffic_pkg` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `spu_lid` bigint DEFAULT NULL COMMENT 'spu',
  `sku_lid` bigint DEFAULT NULL COMMENT 'sku',
  `times` int DEFAULT NULL COMMENT '次数',
  `billing_type` int DEFAULT NULL COMMENT '计费类型',
  `valid_time` int DEFAULT NULL COMMENT '有效时间',
  `valid_time_unit` int DEFAULT NULL COMMENT '有效时间单位',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sku` (`mid`,`sku_lid`) USING BTREE,
  KEY `idx_mid_spu` (`mid`,`spu_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='流量包';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crm_traffic_pkg`
--

LOCK TABLES `crm_traffic_pkg` WRITE;
/*!40000 ALTER TABLE `crm_traffic_pkg` DISABLE KEYS */;
/*!40000 ALTER TABLE `crm_traffic_pkg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deal_order`
--

DROP TABLE IF EXISTS `deal_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deal_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `sn` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单编号',
  `src` int DEFAULT NULL COMMENT '来源',
  `user_id` bigint DEFAULT NULL COMMENT '用户编号',
  `user_lever` int DEFAULT NULL COMMENT '用户等级',
  `user_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户姓名',
  `user_gender` int DEFAULT NULL COMMENT '用户性别',
  `user_avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户头像',
  `skus_amount` int DEFAULT NULL COMMENT '商品总金额',
  `pay_amount` int DEFAULT NULL COMMENT '实际支付金额',
  `freight_amount` int DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` int DEFAULT NULL COMMENT '优惠金额',
  `integration_amount` int DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` int DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` int DEFAULT NULL COMMENT '管理调整金额',
  `used_integration` int DEFAULT NULL COMMENT '扣除积分',
  `status` int DEFAULT NULL COMMENT '订单状态',
  `type` int DEFAULT NULL COMMENT '订单类型',
  `biz_type` int DEFAULT NULL COMMENT '业务类型;对应ProductBizTypeEnum',
  `cap_biz_type` int DEFAULT NULL COMMENT '资金账户类型',
  `auto_confirm_day` int DEFAULT NULL COMMENT '自动确认时间;单位为天',
  `integration` int DEFAULT NULL COMMENT '可获积分',
  `growth` int DEFAULT NULL COMMENT '成长值',
  `promotion_info` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '活动信息',
  `invoice_type` int DEFAULT NULL COMMENT '发票类型',
  `invoice_header` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '发票抬头',
  `invoice_content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '发票内容',
  `invoice_receiver_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收票人电话',
  `invoice_receiver_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收票人邮箱',
  `paid` tinyint(1) DEFAULT NULL COMMENT '已支付',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `pay_method_map` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付方式',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评论时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单备注',
  `logistics_company` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '物流公司',
  `logistics_sn` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '物流单号',
  `consignee` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收货人姓名',
  `consignee_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收货人邮箱',
  `consignee_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收货人手机',
  `consignee_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '收货人地址',
  `summary` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '订单摘要',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `org_type` int DEFAULT NULL COMMENT '机构类型',
  `user_type` int DEFAULT NULL COMMENT '用户类型',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_id` (`mid`,`sn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deal_order`
--

LOCK TABLES `deal_order` WRITE;
/*!40000 ALTER TABLE `deal_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `deal_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deal_order_item`
--

DROP TABLE IF EXISTS `deal_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deal_order_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `order_lid` bigint DEFAULT NULL COMMENT '订单逻辑编号',
  `order_sn` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单条码',
  `sku_id` bigint DEFAULT NULL COMMENT 'sku_id',
  `sku_code` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'sku条码',
  `spu_id` bigint DEFAULT NULL COMMENT 'spu_id',
  `spu_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品图片',
  `spu_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品名称',
  `spu_category_id` bigint DEFAULT NULL COMMENT '商品类目编号',
  `spu_category_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品类目名称',
  `price` bigint DEFAULT NULL COMMENT '销售价格',
  `quantity` bigint DEFAULT NULL COMMENT '销售数量',
  `pay_amount` int DEFAULT NULL COMMENT '实际支付金额',
  `skus_amount` int DEFAULT NULL COMMENT '商品总金额',
  `freight_amount` int DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` int DEFAULT NULL COMMENT '优惠金额',
  `integration_amount` int DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` int DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` int DEFAULT NULL COMMENT '管理调整金额',
  `used_integration` int DEFAULT NULL COMMENT '扣除积分',
  `integration` int DEFAULT NULL COMMENT '可获积分',
  `growth` int DEFAULT NULL COMMENT '成长值',
  `attr_map` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '销售属性',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_sn` (`mid`,`order_sn`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='订单商品明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deal_order_item`
--

LOCK TABLES `deal_order_item` WRITE;
/*!40000 ALTER TABLE `deal_order_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `deal_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deal_order_pay`
--

DROP TABLE IF EXISTS `deal_order_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deal_order_pay` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `order_lid` bigint DEFAULT NULL COMMENT '订单逻辑编号',
  `order_sn` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '订单条码',
  `type` int DEFAULT NULL COMMENT '支付方式',
  `method` int DEFAULT NULL COMMENT '支付方式类型',
  `amount` bigint DEFAULT NULL COMMENT '支付金额',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_id` (`mid`,`order_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='订单支付明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deal_order_pay`
--

LOCK TABLES `deal_order_pay` WRITE;
/*!40000 ALTER TABLE `deal_order_pay` DISABLE KEYS */;
/*!40000 ALTER TABLE `deal_order_pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deal_shopping_cart`
--

DROP TABLE IF EXISTS `deal_shopping_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deal_shopping_cart` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `user_id` bigint DEFAULT NULL COMMENT '用户编号',
  `spu_id` bigint DEFAULT NULL COMMENT 'spu_id',
  `sku_id` bigint DEFAULT NULL COMMENT 'sku_id',
  `sku_code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品条码',
  `spu_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品名称',
  `price` bigint DEFAULT NULL COMMENT '价格',
  `quantity` int DEFAULT NULL COMMENT '数量',
  `attr_map` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '销售属性',
  `spu_main_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品主图',
  `spu_brand` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商品品牌',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_user_id` (`mid`,`user_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='购物车';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deal_shopping_cart`
--

LOCK TABLES `deal_shopping_cart` WRITE;
/*!40000 ALTER TABLE `deal_shopping_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `deal_shopping_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nms_online_log`
--

DROP TABLE IF EXISTS `nms_online_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nms_online_log` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `merchant` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户名称',
  `store` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '门店名称',
  `product` int DEFAULT NULL COMMENT '产品类型',
  `first_request` datetime DEFAULT NULL COMMENT '首次请求',
  `last_request` datetime DEFAULT NULL COMMENT '最后一次请求',
  `report_date` datetime DEFAULT NULL COMMENT '营业日期',
  `dev_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `inst` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '代理商',
  `inst_code` bigint DEFAULT NULL COMMENT '代理商编号',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_report_date` (`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=276950 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='在线记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nms_online_log`
--

LOCK TABLES `nms_online_log` WRITE;
/*!40000 ALTER TABLE `nms_online_log` DISABLE KEYS */;
INSERT INTO `nms_online_log` VALUES (276762,NULL,1942885905090105345,2043932970313584640,NULL,'东莞店',1,'2026-04-14 14:02:49','2026-04-14 14:02:49','2026-04-14 00:00:00',NULL,NULL,NULL,'2026-04-14 06:02:49',NULL,NULL,0,NULL,NULL),(276763,NULL,1983017347135201281,2049023659083165696,NULL,'深圳店',1,'2026-04-28 15:11:24','2026-04-28 15:11:24','2026-04-28 00:00:00',NULL,NULL,NULL,'2026-04-28 07:11:24',NULL,NULL,0,NULL,NULL),(276764,NULL,1942885905090105345,2049055674486616064,NULL,'东莞店',1,'2026-04-28 17:18:37','2026-04-28 17:18:37','2026-04-28 00:00:00',NULL,NULL,NULL,'2026-04-28 09:18:37',NULL,NULL,0,NULL,NULL),(276765,NULL,1942885905090105345,2049294475167776768,NULL,'东莞店',1,'2026-04-29 09:07:32','2026-04-29 09:07:32','2026-04-29 00:00:00',NULL,NULL,NULL,'2026-04-29 01:07:31',NULL,NULL,0,NULL,NULL),(276766,NULL,1942885905090105345,2049369150065840128,NULL,'东莞店',1,'2026-04-29 14:04:15','2026-04-29 14:04:15','2026-04-29 00:00:00',NULL,NULL,NULL,'2026-04-29 06:04:15',NULL,NULL,0,NULL,NULL),(276767,NULL,1942885905090105345,2052640371858419712,NULL,'东莞店',1,'2026-05-08 14:42:56','2026-05-08 14:42:56','2026-05-08 00:00:00',NULL,NULL,NULL,'2026-05-08 06:42:55',NULL,NULL,0,NULL,NULL),(276768,NULL,1985885291726794753,2053661474303889408,NULL,'巨焦',1,'2026-05-11 10:20:25','2026-05-11 10:20:25','2026-05-11 00:00:00',NULL,NULL,NULL,'2026-05-11 02:20:25',NULL,NULL,0,NULL,NULL),(276769,NULL,1942885905090105345,2053667766946877440,NULL,'东莞店',1,'2026-05-11 10:45:26','2026-05-11 10:45:26','2026-05-11 00:00:00',NULL,NULL,NULL,'2026-05-11 02:45:25',NULL,NULL,0,NULL,NULL),(276770,NULL,1985885291726794753,2053712026880520192,NULL,'巨焦',1,'2026-05-11 13:41:18','2026-05-11 13:41:18','2026-05-11 00:00:00',NULL,NULL,NULL,'2026-05-11 05:41:17',NULL,NULL,0,NULL,NULL),(276771,NULL,1942885905090105345,2053772777527783424,NULL,'东莞店',1,'2026-05-11 17:42:42','2026-05-11 17:42:42','2026-05-11 00:00:00',NULL,NULL,NULL,'2026-05-11 09:42:42',NULL,NULL,0,NULL,NULL),(276772,NULL,1979737429467095041,2053773957008011264,NULL,'演示中心',1,'2026-05-11 17:47:23','2026-05-11 17:47:23','2026-05-11 00:00:00',NULL,NULL,NULL,'2026-05-11 09:47:23',NULL,NULL,0,NULL,NULL),(276773,NULL,1979737429467095041,2054011378443567104,NULL,'中山市',1,'2026-05-12 09:30:49','2026-05-12 09:30:49','2026-05-12 00:00:00',NULL,NULL,NULL,'2026-05-12 01:30:48',NULL,NULL,0,NULL,NULL),(276774,NULL,1979737429467095041,2054080987454943232,NULL,'中山市',1,'2026-05-12 14:07:25','2026-05-12 14:07:25','2026-05-12 00:00:00',NULL,NULL,NULL,'2026-05-12 06:07:25',NULL,NULL,0,NULL,NULL),(276775,NULL,1942885905090105345,2054119248441290752,NULL,'东莞店',1,'2026-05-12 16:39:27','2026-05-12 16:39:27','2026-05-12 00:00:00',NULL,NULL,NULL,'2026-05-12 08:39:27',NULL,NULL,0,NULL,NULL),(276776,NULL,1942885905090105345,2054396933763674112,NULL,'东莞店',1,'2026-05-13 11:02:53','2026-05-13 11:02:53','2026-05-13 00:00:00',NULL,NULL,NULL,'2026-05-13 03:02:52',NULL,NULL,0,NULL,NULL),(276777,NULL,1979737429467095041,2054410997290151936,NULL,'中山市',1,'2026-05-13 11:58:46','2026-05-13 11:58:46','2026-05-13 00:00:00',NULL,NULL,NULL,'2026-05-13 03:58:45',NULL,NULL,0,NULL,NULL),(276778,NULL,1979737429467095041,2054438864089108481,NULL,'中山市',1,'2026-05-13 13:49:29','2026-05-13 13:49:29','2026-05-13 00:00:00',NULL,NULL,NULL,'2026-05-13 05:49:29',NULL,NULL,0,NULL,NULL),(276779,NULL,1942885905090105345,2054438864089108480,NULL,'东莞店',1,'2026-05-13 13:49:29','2026-05-13 13:49:29','2026-05-13 00:00:00',NULL,NULL,NULL,'2026-05-13 05:49:29',NULL,NULL,0,NULL,NULL),(276780,NULL,1942885905090105345,2054773501785874432,NULL,'东莞店',1,'2026-05-14 11:59:13','2026-05-14 11:59:13','2026-05-14 00:00:00',NULL,NULL,NULL,'2026-05-14 03:59:13',NULL,NULL,0,NULL,NULL),(276781,NULL,1942885905090105345,2054800562762457088,NULL,'东莞店',1,'2026-05-14 13:46:45','2026-05-14 13:46:45','2026-05-14 00:00:00',NULL,NULL,NULL,'2026-05-14 05:46:45',NULL,NULL,0,NULL,NULL),(276782,NULL,1942885905090105345,2055101812317544448,NULL,'东莞店',1,'2026-05-15 09:43:49','2026-05-15 09:43:49','2026-05-15 00:00:00',NULL,NULL,NULL,'2026-05-15 01:43:48',NULL,NULL,0,NULL,NULL),(276783,NULL,1942885905090105345,2055163541690880000,NULL,'东莞店',1,'2026-05-15 13:49:06','2026-05-15 13:49:06','2026-05-15 00:00:00',NULL,NULL,NULL,'2026-05-15 05:49:06',NULL,NULL,0,NULL,NULL),(276784,NULL,1979737429467095041,2055487805323403264,NULL,'中山市',1,'2026-05-16 11:17:37','2026-05-16 11:17:37','2026-05-16 00:00:00',NULL,NULL,NULL,'2026-05-16 03:17:36',NULL,NULL,0,NULL,NULL),(276785,NULL,1979737429467095041,2055551400014454784,NULL,'中山市',1,'2026-05-16 15:30:19','2026-05-16 15:30:19','2026-05-16 00:00:00',NULL,NULL,NULL,'2026-05-16 07:30:18',NULL,NULL,0,NULL,NULL),(276786,NULL,1942885905090105345,2055893610035744768,NULL,'东莞店',1,'2026-05-17 14:10:08','2026-05-17 14:10:08','2026-05-17 00:00:00',NULL,NULL,NULL,'2026-05-17 06:10:07',NULL,NULL,0,NULL,NULL),(276787,NULL,1940287289892687874,2056217333546852352,NULL,'广州店',1,'2026-05-18 11:36:30','2026-05-18 11:36:30','2026-05-18 00:00:00',NULL,NULL,NULL,'2026-05-18 03:36:29',NULL,NULL,0,NULL,NULL),(276788,NULL,1942885905090105345,2056275046100705280,NULL,'东莞店',1,'2026-05-18 15:25:49','2026-05-18 15:25:49','2026-05-18 00:00:00',NULL,NULL,NULL,'2026-05-18 07:25:49',NULL,NULL,0,NULL,NULL),(276789,NULL,1940287289892687874,2056275046100705281,NULL,'广州店',1,'2026-05-18 15:25:49','2026-05-18 15:25:49','2026-05-18 00:00:00',NULL,NULL,NULL,'2026-05-18 07:25:49',NULL,NULL,0,NULL,NULL),(276790,NULL,1979737429467095041,2056275800052015104,NULL,'中山市',1,'2026-05-18 15:28:49','2026-05-18 15:28:49','2026-05-18 00:00:00',NULL,NULL,NULL,'2026-05-18 07:28:49',NULL,NULL,0,NULL,NULL),(276791,NULL,1942885905090105345,2056404656648622080,NULL,'东莞店',1,'2026-05-19 00:00:51','2026-05-19 00:00:51','2026-05-19 00:00:00',NULL,NULL,NULL,'2026-05-18 16:00:50',NULL,NULL,0,NULL,NULL),(276792,NULL,1979737429467095041,2056558380046094336,NULL,'中山市',1,'2026-05-19 10:11:41','2026-05-19 10:11:41','2026-05-19 00:00:00',NULL,NULL,NULL,'2026-05-19 02:11:41',NULL,NULL,0,NULL,NULL),(276793,NULL,1940287289892687874,2056613062560260097,NULL,'广州店',1,'2026-05-19 13:48:59','2026-05-19 13:48:59','2026-05-19 00:00:00',NULL,NULL,NULL,'2026-05-19 05:48:58',NULL,NULL,0,NULL,NULL),(276794,NULL,1979737429467095041,2056613062560260096,NULL,'中山市',1,'2026-05-19 13:48:59','2026-05-19 13:48:59','2026-05-19 00:00:00',NULL,NULL,NULL,'2026-05-19 05:48:58',NULL,NULL,0,NULL,NULL),(276795,NULL,1942885905090105345,2056628728726102016,NULL,'东莞店',1,'2026-05-19 14:51:14','2026-05-19 14:51:14','2026-05-19 00:00:00',NULL,NULL,NULL,'2026-05-19 06:51:13',NULL,NULL,0,NULL,NULL),(276796,NULL,1942885905090105345,2056907231555596289,NULL,'东莞店',1,'2026-05-20 09:17:54','2026-05-20 09:17:54','2026-05-20 00:00:00',NULL,NULL,NULL,'2026-05-20 01:17:54',NULL,NULL,0,NULL,NULL),(276797,NULL,1940287289892687874,2056907231555596288,NULL,'广州店',1,'2026-05-20 09:17:54','2026-05-20 09:17:54','2026-05-20 00:00:00',NULL,NULL,NULL,'2026-05-20 01:17:54',NULL,NULL,0,NULL,NULL),(276798,NULL,1979737429467095041,2056917551711891456,NULL,'中山市',1,'2026-05-20 09:58:55','2026-05-20 09:58:55','2026-05-20 00:00:00',NULL,NULL,NULL,'2026-05-20 01:58:54',NULL,NULL,0,NULL,NULL),(276799,NULL,1940287289892687874,2056972702766563329,NULL,'广州店',1,'2026-05-20 13:38:04','2026-05-20 13:38:04','2026-05-20 00:00:00',NULL,NULL,NULL,'2026-05-20 05:38:03',NULL,NULL,0,NULL,NULL),(276800,NULL,1942885905090105345,2056972702766563330,NULL,'东莞店',1,'2026-05-20 13:38:04','2026-05-20 13:38:04','2026-05-20 00:00:00',NULL,NULL,NULL,'2026-05-20 05:38:03',NULL,NULL,0,NULL,NULL),(276801,NULL,1979737429467095041,2056972702766563328,NULL,'中山市',1,'2026-05-20 13:38:04','2026-05-20 13:38:04','2026-05-20 00:00:00',NULL,NULL,NULL,'2026-05-20 05:38:03',NULL,NULL,0,NULL,NULL),(276802,NULL,1942885905090105345,2057235220386775040,NULL,'东莞店',1,'2026-05-21 07:01:13','2026-05-21 07:01:13','2026-05-21 00:00:00',NULL,NULL,NULL,'2026-05-20 23:01:12',NULL,NULL,0,NULL,NULL),(276803,NULL,1940287289892687874,2057274178289524736,NULL,'广州店',1,'2026-05-21 09:36:01','2026-05-21 09:36:01','2026-05-21 00:00:00',NULL,NULL,NULL,'2026-05-21 01:36:01',NULL,NULL,0,NULL,NULL),(276804,NULL,1979737429467095041,2057317686411460608,NULL,'中山市',1,'2026-05-21 12:28:54','2026-05-21 12:28:54','2026-05-21 00:00:00',NULL,NULL,NULL,'2026-05-21 04:28:54',NULL,NULL,0,NULL,NULL),(276805,NULL,1940287289892687874,2057317686411460610,NULL,'广州店',1,'2026-05-21 12:28:54','2026-05-21 12:28:54','2026-05-21 00:00:00',NULL,NULL,NULL,'2026-05-21 04:28:54',NULL,NULL,0,NULL,NULL),(276806,NULL,1942885905090105345,2057317686411460609,NULL,'东莞店',1,'2026-05-21 12:28:54','2026-05-21 12:28:54','2026-05-21 00:00:00',NULL,NULL,NULL,'2026-05-21 04:28:54',NULL,NULL,0,NULL,NULL),(276807,NULL,1942885905090105345,2057335840108150784,NULL,'东莞店',1,'2026-05-21 13:41:02','2026-05-21 13:41:02','2026-05-21 00:00:00',NULL,NULL,NULL,'2026-05-21 05:41:02',NULL,NULL,0,NULL,NULL),(276808,NULL,1979737429467095041,2057335840108150786,NULL,'中山市',1,'2026-05-21 13:41:02','2026-05-21 13:41:02','2026-05-21 00:00:00',NULL,NULL,NULL,'2026-05-21 05:41:02',NULL,NULL,0,NULL,NULL),(276809,NULL,1940287289892687874,2057335840108150785,NULL,'广州店',1,'2026-05-21 13:41:02','2026-05-21 13:41:02','2026-05-21 00:00:00',NULL,NULL,NULL,'2026-05-21 05:41:02',NULL,NULL,0,NULL,NULL),(276810,NULL,1942885905090105345,2057366543194058752,NULL,'东莞店',25,'2026-05-21 15:43:03','2026-05-21 15:43:03','2026-05-21 00:00:00',NULL,NULL,NULL,'2026-05-21 15:43:02',NULL,NULL,0,NULL,NULL),(276811,NULL,1940287289892687874,2057631004711657472,NULL,'广州店',1,'2026-05-22 09:13:55','2026-05-22 09:13:55','2026-05-22 00:00:00',NULL,NULL,NULL,'2026-05-22 09:13:55',NULL,NULL,0,NULL,NULL),(276812,NULL,1942885905090105345,2057632075886567424,NULL,'东莞店',1,'2026-05-22 09:18:11','2026-05-22 09:18:11','2026-05-22 00:00:00',NULL,NULL,NULL,'2026-05-22 09:18:10',NULL,NULL,0,NULL,NULL),(276813,NULL,1979737429467095041,2057664977797812224,NULL,'中山市',1,'2026-05-22 11:28:55','2026-05-22 11:28:55','2026-05-22 00:00:00',NULL,NULL,NULL,'2026-05-22 11:28:54',NULL,NULL,0,NULL,NULL),(276814,NULL,1979737429467095041,2057697359891976193,NULL,'中山市',1,'2026-05-22 13:37:35','2026-05-22 13:37:35','2026-05-22 00:00:00',NULL,NULL,NULL,'2026-05-22 13:37:35',NULL,NULL,0,NULL,NULL),(276815,NULL,1940287289892687874,2057697359891976192,NULL,'广州店',1,'2026-05-22 13:37:35','2026-05-22 13:37:35','2026-05-22 00:00:00',NULL,NULL,NULL,'2026-05-22 13:37:35',NULL,NULL,0,NULL,NULL),(276816,NULL,1942885905090105345,2057698435768700928,NULL,'东莞店',1,'2026-05-22 13:41:52','2026-05-22 13:41:52','2026-05-22 00:00:00',NULL,NULL,NULL,'2026-05-22 13:41:51',NULL,NULL,0,NULL,NULL),(276817,NULL,1940287289892687874,2058001157010288640,NULL,'广州店',1,'2026-05-23 09:44:46','2026-05-23 09:44:46','2026-05-23 00:00:00',NULL,NULL,NULL,'2026-05-23 09:44:46',NULL,NULL,0,NULL,NULL),(276818,NULL,1979737429467095041,2058119364004990976,NULL,'中山市',1,'2026-05-23 17:34:29','2026-05-23 17:34:29','2026-05-23 00:00:00',NULL,NULL,NULL,'2026-05-23 17:34:29',NULL,NULL,0,NULL,NULL),(276819,NULL,1942885905090105345,2058123360266539008,NULL,'东莞店',1,'2026-05-23 17:50:22','2026-05-23 17:50:22','2026-05-23 00:00:00',NULL,NULL,NULL,'2026-05-23 17:50:21',NULL,NULL,0,NULL,NULL),(276820,NULL,1942885905090105345,2058312723162591232,NULL,'东莞店',1,'2026-05-24 06:22:49','2026-05-24 06:22:49','2026-05-24 00:00:00',NULL,NULL,NULL,'2026-05-24 06:22:49',NULL,NULL,0,NULL,NULL),(276821,NULL,1942885905090105345,2058384703810228224,NULL,'东莞店',1,'2026-05-24 11:08:51','2026-05-24 11:08:51','2026-05-24 00:00:00',NULL,NULL,NULL,'2026-05-24 11:08:50',NULL,NULL,0,NULL,NULL),(276822,NULL,1942885905090105345,2058624961546080256,NULL,'东莞店',1,'2026-05-25 03:03:33','2026-05-25 03:03:33','2026-05-25 00:00:00',NULL,NULL,NULL,'2026-05-25 03:03:32',NULL,NULL,0,NULL,NULL),(276823,NULL,1942885905090105345,2058786002676809728,NULL,'东莞店',1,'2026-05-25 13:43:28','2026-05-25 13:43:28','2026-05-25 00:00:00',NULL,NULL,NULL,'2026-05-25 13:43:28',NULL,NULL,0,NULL,NULL),(276824,NULL,1942885905090105345,2059077832379269120,NULL,'东莞店',1,'2026-05-26 09:03:06','2026-05-26 09:03:06','2026-05-26 00:00:00',NULL,NULL,NULL,'2026-05-26 09:03:05',NULL,NULL,0,NULL,NULL),(276825,NULL,1942885905090105345,2059148632253329408,NULL,'东莞店',1,'2026-05-26 13:44:26','2026-05-26 13:44:26','2026-05-26 00:00:00',NULL,NULL,NULL,'2026-05-26 13:44:25',NULL,NULL,0,NULL,NULL),(276826,NULL,1942885905090105345,2059354948866076672,NULL,'东莞店',1,'2026-05-27 03:24:15','2026-05-27 03:24:15','2026-05-27 00:00:00',NULL,NULL,NULL,'2026-05-27 03:24:15',NULL,NULL,0,NULL,NULL),(276827,NULL,1979737429467095041,2059472594341130240,NULL,'中山市',1,'2026-05-27 11:11:44','2026-05-27 11:11:44','2026-05-27 00:00:00',NULL,NULL,NULL,'2026-05-27 11:11:44',NULL,NULL,0,NULL,NULL),(276828,NULL,1942885905090105345,2059510552984145920,NULL,'东莞店',1,'2026-05-27 13:42:34','2026-05-27 13:42:34','2026-05-27 00:00:00',NULL,NULL,NULL,'2026-05-27 13:42:34',NULL,NULL,0,NULL,NULL),(276829,NULL,1979737429467095041,2059512041345503232,NULL,'中山市',1,'2026-05-27 13:48:29','2026-05-27 13:48:29','2026-05-27 00:00:00',NULL,NULL,NULL,'2026-05-27 13:48:29',NULL,NULL,0,NULL,NULL),(276830,NULL,1942885905090105345,2059669445806772224,NULL,'东莞店',1,'2026-05-28 00:13:57','2026-05-28 00:13:57','2026-05-28 00:00:00',NULL,NULL,NULL,'2026-05-28 00:13:57',NULL,NULL,0,NULL,NULL),(276831,NULL,1979737429467095041,2059831890974199808,NULL,'中山市',1,'2026-05-28 10:59:27','2026-05-28 10:59:27','2026-05-28 00:00:00',NULL,NULL,NULL,'2026-05-28 10:59:27',NULL,NULL,0,NULL,NULL),(276832,NULL,1942885905090105345,2059873111623397377,NULL,'东莞店',1,'2026-05-28 13:43:15','2026-05-28 13:43:15','2026-05-28 00:00:00',NULL,NULL,NULL,'2026-05-28 13:43:15',NULL,NULL,0,NULL,NULL),(276833,NULL,1979737429467095041,2059873111623397376,NULL,'中山市',1,'2026-05-28 13:43:15','2026-05-28 13:43:15','2026-05-28 00:00:00',NULL,NULL,NULL,'2026-05-28 13:43:15',NULL,NULL,0,NULL,NULL),(276834,NULL,1942885905090105345,2060079125442392064,NULL,'东莞店',1,'2026-05-29 03:21:53','2026-05-29 03:21:53','2026-05-29 00:00:00',NULL,NULL,NULL,'2026-05-29 03:21:52',NULL,NULL,0,NULL,NULL),(276835,NULL,1979737429467095041,2060193047726059520,NULL,'中山市',1,'2026-05-29 10:54:34','2026-05-29 10:54:34','2026-05-29 00:00:00',NULL,NULL,NULL,'2026-05-29 10:54:33',NULL,NULL,0,NULL,NULL),(276836,NULL,1942885905090105345,2060239083783696385,NULL,'东莞店',1,'2026-05-29 13:57:30','2026-05-29 13:57:30','2026-05-29 00:00:00',NULL,NULL,NULL,'2026-05-29 13:57:29',NULL,NULL,0,NULL,NULL),(276837,NULL,1979737429467095041,2060239083783696384,NULL,'中山市',1,'2026-05-29 13:57:30','2026-05-29 13:57:30','2026-05-29 00:00:00',NULL,NULL,NULL,'2026-05-29 13:57:29',NULL,NULL,0,NULL,NULL),(276838,NULL,1942885905090105345,2060404599806603264,NULL,'东莞店',1,'2026-05-30 00:55:12','2026-05-30 00:55:12','2026-05-30 00:00:00',NULL,NULL,NULL,'2026-05-30 00:55:11',NULL,NULL,0,NULL,NULL),(276839,NULL,1942885905090105345,2060597923120361472,NULL,'东莞店',1,'2026-05-30 13:43:24','2026-05-30 13:43:24','2026-05-30 00:00:00',NULL,NULL,NULL,'2026-05-30 13:43:23',NULL,NULL,0,NULL,NULL),(276840,NULL,1942885905090105345,2060755917808283648,NULL,'东莞店',1,'2026-05-31 00:11:12','2026-05-31 00:11:12','2026-05-31 00:00:00',NULL,NULL,NULL,'2026-05-31 00:11:12',NULL,NULL,0,NULL,NULL),(276841,NULL,1942885905090105345,2061025799235502080,NULL,'东莞店',1,'2026-05-31 18:03:37','2026-05-31 18:03:37','2026-05-31 00:00:00',NULL,NULL,NULL,'2026-05-31 18:03:37',NULL,NULL,0,NULL,NULL),(276842,NULL,1942885905090105345,2061257814111985664,NULL,'东莞店',1,'2026-06-01 09:25:34','2026-06-01 09:25:34','2026-06-01 00:00:00',NULL,NULL,NULL,'2026-06-01 09:25:33',NULL,NULL,0,NULL,NULL),(276843,NULL,1942885905090105345,2061324616908111872,NULL,'东莞店',1,'2026-06-01 13:51:01','2026-06-01 13:51:01','2026-06-01 00:00:00',NULL,NULL,NULL,'2026-06-01 13:51:00',NULL,NULL,0,NULL,NULL),(276844,NULL,1942885905090105345,2061527801246048256,NULL,'东莞店',1,'2026-06-02 03:18:24','2026-06-02 03:18:24','2026-06-02 00:00:00',NULL,NULL,NULL,'2026-06-02 03:18:23',NULL,NULL,0,NULL,NULL),(276845,NULL,1942885905090105345,2061696780317659136,NULL,'东莞店',1,'2026-06-02 14:29:52','2026-06-02 14:29:52','2026-06-02 00:00:00',NULL,NULL,NULL,'2026-06-02 14:29:51',NULL,NULL,0,NULL,NULL),(276846,NULL,1942885905090105345,2061714934718087168,NULL,'东莞店',1,'2026-06-02 15:42:00','2026-06-02 15:42:00','2026-06-02 00:00:00',NULL,NULL,NULL,'2026-06-02 15:41:59',NULL,NULL,0,NULL,NULL),(276847,NULL,1942885905090105345,2061843749352062976,NULL,'东莞店',1,'2026-06-03 00:13:52','2026-06-03 00:13:52','2026-06-03 00:00:00',NULL,NULL,NULL,'2026-06-03 00:13:51',NULL,NULL,0,NULL,NULL),(276848,NULL,1942885905090105345,2062047123464990720,NULL,'东莞店',1,'2026-06-03 13:42:00','2026-06-03 13:42:00','2026-06-03 00:00:00',NULL,NULL,NULL,'2026-06-03 13:41:59',NULL,NULL,0,NULL,NULL),(276849,NULL,1985885291726794753,2062108747894829056,NULL,'巨焦',1,'2026-06-03 17:46:52','2026-06-03 17:46:52','2026-06-03 00:00:00',NULL,NULL,NULL,'2026-06-03 17:46:52',NULL,NULL,0,NULL,NULL),(276850,NULL,1942885905090105345,2062131529261199360,NULL,'东莞店',25,'2026-06-03 19:17:24','2026-06-03 19:17:24','2026-06-03 00:00:00',NULL,NULL,NULL,'2026-06-03 19:17:23',NULL,NULL,0,NULL,NULL),(276851,NULL,1942885905090105345,2062309319591800832,NULL,'东莞店',1,'2026-06-04 07:03:52','2026-06-04 07:03:52','2026-06-04 00:00:00',NULL,NULL,NULL,'2026-06-04 07:03:52',NULL,NULL,0,NULL,NULL),(276852,NULL,1985885291726794753,2062345875627126784,NULL,'巨焦',1,'2026-06-04 09:29:08','2026-06-04 09:29:08','2026-06-04 00:00:00',NULL,NULL,NULL,'2026-06-04 09:29:07',NULL,NULL,0,NULL,NULL),(276853,NULL,1942885905090105345,2062410011839639552,NULL,'东莞店',1,'2026-06-04 13:43:59','2026-06-04 13:43:59','2026-06-04 00:00:00',NULL,NULL,NULL,'2026-06-04 13:43:59',NULL,NULL,0,NULL,NULL),(276854,NULL,1985885291726794753,2062434944326119424,NULL,'巨焦',1,'2026-06-04 15:23:04','2026-06-04 15:23:04','2026-06-04 00:00:00',NULL,NULL,NULL,'2026-06-04 15:23:03',NULL,NULL,0,NULL,NULL),(276855,NULL,1942885905090105345,2062567619837898752,NULL,'东莞店',1,'2026-06-05 00:10:16','2026-06-05 00:10:16','2026-06-05 00:00:00',NULL,NULL,NULL,'2026-06-05 00:10:15',NULL,NULL,0,NULL,NULL),(276856,NULL,1985885291726794753,2062702018394927104,NULL,'巨焦',1,'2026-06-05 09:04:19','2026-06-05 09:04:19','2026-06-05 00:00:00',NULL,NULL,NULL,'2026-06-05 09:04:18',NULL,NULL,0,NULL,NULL),(276857,NULL,1979737429467095041,2062731554637557760,NULL,'中山市',1,'2026-06-05 11:01:41','2026-06-05 11:01:41','2026-06-05 00:00:00',NULL,NULL,NULL,'2026-06-05 11:01:40',NULL,NULL,0,NULL,NULL),(276858,NULL,1985885291726794753,2062773424187228162,NULL,'巨焦',1,'2026-06-05 13:48:03','2026-06-05 13:48:03','2026-06-05 00:00:00',NULL,NULL,NULL,'2026-06-05 13:48:03',NULL,NULL,0,NULL,NULL),(276859,NULL,1979737429467095041,2062773424187228160,NULL,'中山市',1,'2026-06-05 13:48:03','2026-06-05 13:48:03','2026-06-05 00:00:00',NULL,NULL,NULL,'2026-06-05 13:48:03',NULL,NULL,0,NULL,NULL),(276860,NULL,1942885905090105345,2062773424187228161,NULL,'东莞店',1,'2026-06-05 13:48:03','2026-06-05 13:48:03','2026-06-05 00:00:00',NULL,NULL,NULL,'2026-06-05 13:48:03',NULL,NULL,0,NULL,NULL),(276861,NULL,1942885905090105345,2062930156121210880,NULL,'东莞店',1,'2026-06-06 00:10:51','2026-06-06 00:10:51','2026-06-06 00:00:00',NULL,NULL,NULL,'2026-06-06 00:10:51',NULL,NULL,0,NULL,NULL),(276862,NULL,1979737429467095041,2063102796697944064,NULL,'中山市',1,'2026-06-06 11:36:52','2026-06-06 11:36:52','2026-06-06 00:00:00',NULL,NULL,NULL,'2026-06-06 11:36:51',NULL,NULL,0,NULL,NULL),(276863,NULL,1942885905090105345,2063133773076946945,NULL,'东莞店',1,'2026-06-06 13:39:57','2026-06-06 13:39:57','2026-06-06 00:00:00',NULL,NULL,NULL,'2026-06-06 13:39:57',NULL,NULL,0,NULL,NULL),(276864,NULL,1979737429467095041,2063133773076946944,NULL,'中山市',1,'2026-06-06 13:39:57','2026-06-06 13:39:57','2026-06-06 00:00:00',NULL,NULL,NULL,'2026-06-06 13:39:57',NULL,NULL,0,NULL,NULL),(276865,NULL,1942885905090105345,2063337072417890304,NULL,'东莞店',1,'2026-06-07 03:07:48','2026-06-07 03:07:48','2026-06-07 00:00:00',NULL,NULL,NULL,'2026-06-07 03:07:47',NULL,NULL,0,NULL,NULL),(276866,NULL,1985885291726794753,2063427540916953088,NULL,'巨焦',1,'2026-06-07 09:07:17','2026-06-07 09:07:17','2026-06-07 00:00:00',NULL,NULL,NULL,'2026-06-07 09:07:17',NULL,NULL,0,NULL,NULL),(276867,NULL,1942885905090105345,2063654405090893824,NULL,'东莞店',1,'2026-06-08 00:08:46','2026-06-08 00:08:46','2026-06-08 00:00:00',NULL,NULL,NULL,'2026-06-08 00:08:45',NULL,NULL,0,NULL,NULL),(276868,NULL,1985885291726794753,2063789111736328192,NULL,'巨焦',1,'2026-06-08 09:04:02','2026-06-08 09:04:02','2026-06-08 00:00:00',NULL,NULL,NULL,'2026-06-08 09:04:02',NULL,NULL,0,NULL,NULL),(276869,NULL,1979737429467095041,2063817603907641344,NULL,'中山市',1,'2026-06-08 10:57:15','2026-06-08 10:57:15','2026-06-08 00:00:00',NULL,NULL,NULL,'2026-06-08 10:57:15',NULL,NULL,0,NULL,NULL),(276870,NULL,1985885291726794753,2063859579822469120,NULL,'巨焦',1,'2026-06-08 13:44:03','2026-06-08 13:44:03','2026-06-08 00:00:00',NULL,NULL,NULL,'2026-06-08 13:44:03',NULL,NULL,0,NULL,NULL),(276871,NULL,1979737429467095041,2063859579822469121,NULL,'中山市',1,'2026-06-08 13:44:03','2026-06-08 13:44:03','2026-06-08 00:00:00',NULL,NULL,NULL,'2026-06-08 13:44:03',NULL,NULL,0,NULL,NULL),(276872,NULL,1942885905090105345,2063859579822469122,NULL,'东莞店',1,'2026-06-08 13:44:03','2026-06-08 13:44:03','2026-06-08 00:00:00',NULL,NULL,NULL,'2026-06-08 13:44:03',NULL,NULL,0,NULL,NULL),(276873,NULL,1942885905090105345,2064060712293691392,NULL,'东莞店',1,'2026-06-09 03:03:17','2026-06-09 03:03:17','2026-06-09 00:00:00',NULL,NULL,NULL,'2026-06-09 03:03:16',NULL,NULL,0,NULL,NULL),(276874,NULL,1985885291726794753,2064152877086732288,NULL,'巨焦',1,'2026-06-09 09:09:31','2026-06-09 09:09:31','2026-06-09 00:00:00',NULL,NULL,NULL,'2026-06-09 09:09:30',NULL,NULL,0,NULL,NULL),(276875,NULL,1979737429467095041,2064167366100185088,NULL,'中山市',1,'2026-06-09 10:07:05','2026-06-09 10:07:05','2026-06-09 00:00:00',NULL,NULL,NULL,'2026-06-09 10:07:05',NULL,NULL,0,NULL,NULL),(276876,NULL,1979737429467095041,2064221009801310209,NULL,'中山市',1,'2026-06-09 13:40:15','2026-06-09 13:40:15','2026-06-09 00:00:00',NULL,NULL,NULL,'2026-06-09 13:40:14',NULL,NULL,0,NULL,NULL),(276877,NULL,1942885905090105345,2064221009801310208,NULL,'东莞店',1,'2026-06-09 13:40:15','2026-06-09 13:40:15','2026-06-09 00:00:00',NULL,NULL,NULL,'2026-06-09 13:40:14',NULL,NULL,0,NULL,NULL),(276878,NULL,1942885905090105345,2064388001636216832,NULL,'东莞店',1,'2026-06-10 00:43:49','2026-06-10 00:43:49','2026-06-10 00:00:00',NULL,NULL,NULL,'2026-06-10 00:43:48',NULL,NULL,0,NULL,NULL),(276879,NULL,1985885291726794753,2064514413072412672,NULL,'巨焦',1,'2026-06-10 09:06:08','2026-06-10 09:06:08','2026-06-10 00:00:00',NULL,NULL,NULL,'2026-06-10 09:06:07',NULL,NULL,0,NULL,NULL),(276880,NULL,1942885905090105345,2064583597202046976,NULL,'东莞店',1,'2026-06-10 13:41:02','2026-06-10 13:41:02','2026-06-10 00:00:00',NULL,NULL,NULL,'2026-06-10 13:41:02',NULL,NULL,0,NULL,NULL),(276881,NULL,1942885905090105345,2064739391562285056,NULL,'东莞店',1,'2026-06-11 00:00:07','2026-06-11 00:00:07','2026-06-11 00:00:00',NULL,NULL,NULL,'2026-06-11 00:00:06',NULL,NULL,0,NULL,NULL),(276882,NULL,1942885905090105345,2064946695832391680,NULL,'东莞店',1,'2026-06-11 13:43:52','2026-06-11 13:43:52','2026-06-11 00:00:00',NULL,NULL,NULL,'2026-06-11 13:43:51',NULL,NULL,0,NULL,NULL),(276883,NULL,1985885291726794753,2064955449156096000,NULL,'巨焦',1,'2026-06-11 14:18:39','2026-06-11 14:18:39','2026-06-11 00:00:00',NULL,NULL,NULL,'2026-06-11 14:18:38',NULL,NULL,0,NULL,NULL),(276884,NULL,1985885291726794753,2065239292303953920,NULL,'巨焦',1,'2026-06-12 09:06:32','2026-06-12 09:06:32','2026-06-12 00:00:00',NULL,NULL,NULL,'2026-06-12 09:06:32',NULL,NULL,0,NULL,NULL),(276885,NULL,1985885291726794753,2065308685557116928,NULL,'巨焦',1,'2026-06-12 13:42:17','2026-06-12 13:42:17','2026-06-12 00:00:00',NULL,NULL,NULL,'2026-06-12 13:42:16',NULL,NULL,0,NULL,NULL),(276886,NULL,1985885291726794753,2065962827718557696,NULL,'巨焦',1,'2026-06-14 09:01:37','2026-06-14 09:01:37','2026-06-14 00:00:00',NULL,NULL,NULL,'2026-06-14 09:01:36',NULL,NULL,0,NULL,NULL),(276887,NULL,1985885291726794753,2066731153619890176,NULL,'巨焦',1,'2026-06-16 11:54:40','2026-06-16 11:54:40','2026-06-16 00:00:00',NULL,NULL,NULL,'2026-06-16 11:54:39',NULL,NULL,0,NULL,NULL),(276888,NULL,1985885291726794753,2066757866796519424,NULL,'巨焦',1,'2026-06-16 13:40:49','2026-06-16 13:40:49','2026-06-16 00:00:00',NULL,NULL,NULL,'2026-06-16 13:40:48',NULL,NULL,0,NULL,NULL),(276889,NULL,1985885291726794753,2067051771291144192,NULL,'巨焦',1,'2026-06-17 09:08:41','2026-06-17 09:08:41','2026-06-17 00:00:00',NULL,NULL,NULL,'2026-06-17 09:08:40',NULL,NULL,0,NULL,NULL),(276890,NULL,1985885291726794753,2067135233271468032,NULL,'巨焦',1,'2026-06-17 14:40:20','2026-06-17 14:40:20','2026-06-17 00:00:00',NULL,NULL,NULL,'2026-06-17 14:40:19',NULL,NULL,0,NULL,NULL),(276891,NULL,1942885905090105345,2067937677181943808,NULL,'东莞店',1,'2026-06-19 19:48:57','2026-06-19 19:48:57','2026-06-19 00:00:00',NULL,NULL,NULL,'2026-06-19 19:48:57',NULL,NULL,0,NULL,NULL),(276892,NULL,1942885905090105345,2068011418184286208,NULL,'东莞店',1,'2026-06-20 00:41:59','2026-06-20 00:41:59','2026-06-20 00:00:00',NULL,NULL,NULL,'2026-06-20 00:41:58',NULL,NULL,0,NULL,NULL),(276893,NULL,1985885291726794753,2068137426661113856,NULL,'巨焦',1,'2026-06-20 09:02:41','2026-06-20 09:02:41','2026-06-20 00:00:00',NULL,NULL,NULL,'2026-06-20 09:02:41',NULL,NULL,0,NULL,NULL),(276894,NULL,1985885291726794753,2068500950751084544,NULL,'巨焦',1,'2026-06-21 09:07:12','2026-06-21 09:07:12','2026-06-21 00:00:00',NULL,NULL,NULL,'2026-06-21 09:07:12',NULL,NULL,0,NULL,NULL),(276895,NULL,1942885905090105345,2068506318331936768,NULL,'东莞店',1,'2026-06-21 09:28:32','2026-06-21 09:28:32','2026-06-21 00:00:00',NULL,NULL,NULL,'2026-06-21 09:28:31',NULL,NULL,0,NULL,NULL),(276896,NULL,1985885291726794753,2068896446804205568,NULL,'巨焦',1,'2026-06-22 11:18:46','2026-06-22 11:18:46','2026-06-22 00:00:00',NULL,NULL,NULL,'2026-06-22 11:18:45',NULL,NULL,0,NULL,NULL),(276897,NULL,1985885291726794753,2068932540472041472,NULL,'巨焦',1,'2026-06-22 13:42:11','2026-06-22 13:42:11','2026-06-22 00:00:00',NULL,NULL,NULL,'2026-06-22 13:42:11',NULL,NULL,0,NULL,NULL),(276898,NULL,1942885905090105345,2068933565970980864,NULL,'东莞店',1,'2026-06-22 13:46:16','2026-06-22 13:46:16','2026-06-22 00:00:00',NULL,NULL,NULL,'2026-06-22 13:46:15',NULL,NULL,0,NULL,NULL),(276899,NULL,1985885291726794753,2069226876967395328,NULL,'巨焦',1,'2026-06-23 09:11:47','2026-06-23 09:11:47','2026-06-23 00:00:00',NULL,NULL,NULL,'2026-06-23 09:11:46',NULL,NULL,0,NULL,NULL),(276900,NULL,1942885905090105345,2069230744547696640,NULL,'东莞店',1,'2026-06-23 09:27:09','2026-06-23 09:27:09','2026-06-23 00:00:00',NULL,NULL,NULL,'2026-06-23 09:27:08',NULL,NULL,0,NULL,NULL),(276901,NULL,1985885291726794753,2069294701895450625,NULL,'巨焦',1,'2026-06-23 13:41:17','2026-06-23 13:41:17','2026-06-23 00:00:00',NULL,NULL,NULL,'2026-06-23 13:41:17',NULL,NULL,0,NULL,NULL),(276902,NULL,1942885905090105345,2069294701895450624,NULL,'东莞店',1,'2026-06-23 13:41:17','2026-06-23 13:41:17','2026-06-23 00:00:00',NULL,NULL,NULL,'2026-06-23 13:41:17',NULL,NULL,0,NULL,NULL),(276903,NULL,1942885905090105345,2069496459578015744,NULL,'东莞店',1,'2026-06-24 03:03:00','2026-06-24 03:03:00','2026-06-24 00:00:00',NULL,NULL,NULL,'2026-06-24 03:03:00',NULL,NULL,0,NULL,NULL),(276904,NULL,1985885291726794753,2069586964320059392,NULL,'巨焦',1,'2026-06-24 09:02:38','2026-06-24 09:02:38','2026-06-24 00:00:00',NULL,NULL,NULL,'2026-06-24 09:02:38',NULL,NULL,0,NULL,NULL),(276905,NULL,1942885905090105345,2069659115325919232,NULL,'东莞店',1,'2026-06-24 13:49:20','2026-06-24 13:49:20','2026-06-24 00:00:00',NULL,NULL,NULL,'2026-06-24 13:49:20',NULL,NULL,0,NULL,NULL),(276906,NULL,1985885291726794753,2069679970642726912,NULL,'巨焦',1,'2026-06-24 15:12:12','2026-06-24 15:12:12','2026-06-24 00:00:00',NULL,NULL,NULL,'2026-06-24 15:12:12',NULL,NULL,0,NULL,NULL),(276907,NULL,1942885905090105345,2069956008852779009,NULL,'东莞店',1,'2026-06-25 09:29:05','2026-06-25 09:29:05','2026-06-25 00:00:00',NULL,NULL,NULL,'2026-06-25 09:29:05',NULL,NULL,0,NULL,NULL),(276908,NULL,1985885291726794753,2069956008852779008,NULL,'巨焦',1,'2026-06-25 09:29:05','2026-06-25 09:29:05','2026-06-25 00:00:00',NULL,NULL,NULL,'2026-06-25 09:29:05',NULL,NULL,0,NULL,NULL),(276909,NULL,1942885905090105345,2070018861360300033,NULL,'东莞店',1,'2026-06-25 13:38:50','2026-06-25 13:38:50','2026-06-25 00:00:00',NULL,NULL,NULL,'2026-06-25 13:38:50',NULL,NULL,0,NULL,NULL),(276910,NULL,1985885291726794753,2070018861360300032,NULL,'巨焦',1,'2026-06-25 13:38:50','2026-06-25 13:38:50','2026-06-25 00:00:00',NULL,NULL,NULL,'2026-06-25 13:38:50',NULL,NULL,0,NULL,NULL),(276911,NULL,1942885905090105345,2070318006079504384,NULL,'东莞店',1,'2026-06-26 09:27:32','2026-06-26 09:27:32','2026-06-26 00:00:00',NULL,NULL,NULL,'2026-06-26 09:27:31',NULL,NULL,0,NULL,NULL),(276912,NULL,1985885291726794753,2070334444626427904,NULL,'巨焦',1,'2026-06-26 10:32:51','2026-06-26 10:32:51','2026-06-26 00:00:00',NULL,NULL,NULL,'2026-06-26 10:32:51',NULL,NULL,0,NULL,NULL),(276913,NULL,1985885291726794753,2070381335214657537,NULL,'巨焦',1,'2026-06-26 13:39:11','2026-06-26 13:39:11','2026-06-26 00:00:00',NULL,NULL,NULL,'2026-06-26 13:39:10',NULL,NULL,0,NULL,NULL),(276914,NULL,1942885905090105345,2070381335214657536,NULL,'东莞店',1,'2026-06-26 13:39:11','2026-06-26 13:39:11','2026-06-26 00:00:00',NULL,NULL,NULL,'2026-06-26 13:39:10',NULL,NULL,0,NULL,NULL),(276915,NULL,1985885291726794753,2070452390234669056,NULL,'巨焦',1,'2026-06-26 18:21:32','2026-06-26 18:21:32','2026-06-26 00:00:00',NULL,NULL,NULL,'2026-06-26 18:21:31',NULL,NULL,0,NULL,NULL),(276916,NULL,1942885905090105345,2070452390234669057,NULL,'东莞店',1,'2026-06-26 18:21:32','2026-06-26 18:21:32','2026-06-26 00:00:00',NULL,NULL,NULL,'2026-06-26 18:21:31',NULL,NULL,0,NULL,NULL),(276917,NULL,1942885905090105345,2070491453066956800,NULL,'东莞店',1,'2026-06-26 20:56:45','2026-06-26 20:56:45','2026-06-26 00:00:00',NULL,NULL,NULL,'2026-06-26 20:56:44',NULL,NULL,0,NULL,NULL),(276918,NULL,1942885905090105345,2070684182292799488,NULL,'东莞店',1,'2026-06-27 09:42:35','2026-06-27 09:42:35','2026-06-27 00:00:00',NULL,NULL,NULL,'2026-06-27 09:42:35',NULL,NULL,0,NULL,NULL),(276919,NULL,1942885905090105345,2070744395367137280,NULL,'东莞店',1,'2026-06-27 13:41:51','2026-06-27 13:41:51','2026-06-27 00:00:00',NULL,NULL,NULL,'2026-06-27 13:41:51',NULL,NULL,0,NULL,NULL),(276920,NULL,1985885291726794753,2074006309008240640,NULL,'巨焦',1,'2026-07-06 13:43:32','2026-07-06 13:43:32','2026-07-06 00:00:00',NULL,NULL,NULL,'2026-07-06 13:43:31',NULL,NULL,0,NULL,NULL),(276921,NULL,1985885291726794753,2074307538328752128,NULL,'巨焦',1,'2026-07-07 09:40:31','2026-07-07 09:40:31','2026-07-07 00:00:00',NULL,NULL,NULL,'2026-07-07 09:40:30',NULL,NULL,0,NULL,NULL),(276922,NULL,1985885291726794753,2074666373571862528,NULL,'巨焦',1,'2026-07-08 09:26:24','2026-07-08 09:26:24','2026-07-08 00:00:00',NULL,NULL,NULL,'2026-07-08 09:26:23',NULL,NULL,0,NULL,NULL),(276923,NULL,1985885291726794753,2074742939413037056,NULL,'巨焦',1,'2026-07-08 14:30:38','2026-07-08 14:30:38','2026-07-08 00:00:00',NULL,NULL,NULL,'2026-07-08 14:30:38',NULL,NULL,0,NULL,NULL),(276924,NULL,1985885291726794753,2075029065384034304,NULL,'巨焦',1,'2026-07-09 09:27:36','2026-07-09 09:27:36','2026-07-09 00:00:00',NULL,NULL,NULL,'2026-07-09 09:27:36',NULL,NULL,0,NULL,NULL),(276925,NULL,1985885291726794753,2075136302704029696,NULL,'巨焦',1,'2026-07-09 16:33:43','2026-07-09 16:33:43','2026-07-09 00:00:00',NULL,NULL,NULL,'2026-07-09 16:33:43',NULL,NULL,0,NULL,NULL),(276926,NULL,1985885291726794753,2076498038758518784,NULL,'巨焦',1,'2026-07-13 10:44:47','2026-07-13 10:44:47','2026-07-13 00:00:00',NULL,NULL,NULL,'2026-07-13 10:44:46',NULL,NULL,0,NULL,NULL),(276927,NULL,1985885291726794753,2076937175216263168,NULL,'巨焦',1,'2026-07-14 15:49:45','2026-07-14 15:49:45','2026-07-14 00:00:00',NULL,NULL,NULL,'2026-07-14 15:49:44',NULL,NULL,0,NULL,NULL),(276928,NULL,1942885905090105345,2079053046968999936,NULL,'东莞店',1,'2026-07-20 11:57:28','2026-07-20 11:57:28','2026-07-20 00:00:00',NULL,NULL,NULL,'2026-07-20 11:57:27',NULL,NULL,0,NULL,NULL),(276929,NULL,1942885905090105345,2079080546650927104,NULL,'东莞店',1,'2026-07-20 13:46:44','2026-07-20 13:46:44','2026-07-20 00:00:00',NULL,NULL,NULL,'2026-07-20 13:46:44',NULL,NULL,0,NULL,NULL),(276930,NULL,1942885905090105345,2079279750811856896,NULL,'东莞店',1,'2026-07-21 02:58:18','2026-07-21 02:58:18','2026-07-21 00:00:00',NULL,NULL,NULL,'2026-07-21 02:58:18',NULL,NULL,0,NULL,NULL),(276931,NULL,1942885905090105345,2079395379295199232,NULL,'东莞店',1,'2026-07-21 10:37:46','2026-07-21 10:37:46','2026-07-21 00:00:00',NULL,NULL,NULL,'2026-07-21 10:37:46',NULL,NULL,0,NULL,NULL),(276932,NULL,1942885905090105345,2079442006521323520,NULL,'东莞店',1,'2026-07-21 13:43:03','2026-07-21 13:43:03','2026-07-21 00:00:00',NULL,NULL,NULL,'2026-07-21 13:43:03',NULL,NULL,0,NULL,NULL),(276933,NULL,1942885905090105345,2079636173721608192,NULL,'东莞店',1,'2026-07-22 02:34:36','2026-07-22 02:34:36','2026-07-22 00:00:00',NULL,NULL,NULL,'2026-07-22 02:34:36',NULL,NULL,0,NULL,NULL),(276934,NULL,1942885905090105345,2079740058111741952,NULL,'东莞店',1,'2026-07-22 09:27:24','2026-07-22 09:27:24','2026-07-22 00:00:00',NULL,NULL,NULL,'2026-07-22 09:27:24',NULL,NULL,0,NULL,NULL),(276935,NULL,1942885905090105345,2079804599603752960,NULL,'东莞店',1,'2026-07-22 13:43:52','2026-07-22 13:43:52','2026-07-22 00:00:00',NULL,NULL,NULL,'2026-07-22 13:43:52',NULL,NULL,0,NULL,NULL),(276936,NULL,1942885905090105345,2080100493106012160,NULL,'东莞店',1,'2026-07-23 09:19:39','2026-07-23 09:19:39','2026-07-23 00:00:00',NULL,NULL,NULL,'2026-07-23 09:19:38',NULL,NULL,0,NULL,NULL),(276937,NULL,1942885905090105345,2080166806687649792,NULL,'东莞店',1,'2026-07-23 13:43:09','2026-07-23 13:43:09','2026-07-23 00:00:00',NULL,NULL,NULL,'2026-07-23 13:43:09',NULL,NULL,0,NULL,NULL),(276938,NULL,1942885905090105345,2080289767098916864,NULL,'东莞店',1,'2026-07-23 21:51:45','2026-07-23 21:51:45','2026-07-23 00:00:00',NULL,NULL,NULL,'2026-07-23 21:51:45',NULL,NULL,0,NULL,NULL),(276939,NULL,1942885905090105345,2080466636547727360,NULL,'东莞店',1,'2026-07-24 09:34:34','2026-07-24 09:34:34','2026-07-24 00:00:00',NULL,NULL,NULL,'2026-07-24 09:34:34',NULL,NULL,0,NULL,NULL),(276940,NULL,1942885905090105345,2080548584754294784,NULL,'东莞店',1,'2026-07-24 15:00:12','2026-07-24 15:00:12','2026-07-24 00:00:00',NULL,NULL,NULL,'2026-07-24 15:00:11',NULL,NULL,0,NULL,NULL),(276941,NULL,1942885905090105345,2081368501546061824,NULL,'东莞店',1,'2026-07-26 21:18:15','2026-07-26 21:18:15','2026-07-26 00:00:00',NULL,NULL,NULL,'2026-07-26 21:18:15',NULL,NULL,0,NULL,NULL),(276942,NULL,1942885905090105345,2081422314449604608,NULL,'东莞店',1,'2026-07-27 00:52:05','2026-07-27 00:52:05','2026-07-27 00:00:00',NULL,NULL,NULL,'2026-07-27 00:52:05',NULL,NULL,0,NULL,NULL),(276943,NULL,1942885905090105345,2081552506992771072,NULL,'东莞店',1,'2026-07-27 09:29:26','2026-07-27 09:29:26','2026-07-27 00:00:00',NULL,NULL,NULL,'2026-07-27 09:29:25',NULL,NULL,0,NULL,NULL),(276944,NULL,1942885905090105345,2081619504812445696,NULL,'东莞店',1,'2026-07-27 13:55:39','2026-07-27 13:55:39','2026-07-27 00:00:00',NULL,NULL,NULL,'2026-07-27 13:55:39',NULL,NULL,0,NULL,NULL),(276945,NULL,1942885905090105345,2081776751664353280,NULL,'东莞店',1,'2026-07-28 00:20:30','2026-07-28 00:20:30','2026-07-28 00:00:00',NULL,NULL,NULL,'2026-07-28 00:20:29',NULL,NULL,0,NULL,NULL),(276946,NULL,1942885905090105345,2081984726279839744,NULL,'东莞店',1,'2026-07-28 14:06:55','2026-07-28 14:06:55','2026-07-28 00:00:00',NULL,NULL,NULL,'2026-07-28 14:06:54',NULL,NULL,0,NULL,NULL),(276947,NULL,1940287289892687874,2087740430209826816,NULL,'广州店',1,'2026-08-13 11:18:02','2026-08-13 11:18:02','2026-08-13 00:00:00',NULL,NULL,NULL,'2026-08-13 11:18:01',NULL,NULL,0,NULL,NULL),(276948,NULL,1940287289892687874,2087777085521068032,NULL,'广州店',1,'2026-08-13 13:43:41','2026-08-13 13:43:41','2026-08-13 00:00:00',NULL,NULL,NULL,'2026-08-13 13:43:40',NULL,NULL,0,NULL,NULL),(276949,NULL,1942885905090105345,2087788221456908288,NULL,'东莞店',1,'2026-08-13 14:27:56','2026-08-13 14:27:56','2026-08-13 00:00:00',NULL,NULL,NULL,'2026-08-13 14:27:55',NULL,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `nms_online_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nms_overtime_log`
--

DROP TABLE IF EXISTS `nms_overtime_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nms_overtime_log` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `merchant` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户名称',
  `store` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '门店名称',
  `product` int DEFAULT NULL COMMENT '产品类型',
  `expired` tinyint(1) DEFAULT NULL COMMENT '已经过期',
  `expired_time` datetime DEFAULT NULL COMMENT '过期时间',
  `surplus_days` int DEFAULT NULL COMMENT '剩余天数',
  `report_date` datetime DEFAULT NULL COMMENT '营业日期',
  `dev_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '设备编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `inst` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '代理商',
  `inst_code` bigint DEFAULT NULL COMMENT '代理商编号',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_report_date` (`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9712 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='产品过期记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nms_overtime_log`
--

LOCK TABLES `nms_overtime_log` WRITE;
/*!40000 ALTER TABLE `nms_overtime_log` DISABLE KEYS */;
INSERT INTO `nms_overtime_log` VALUES (9710,1940284000182472704,1942885905090105345,2057366543709958144,NULL,'东莞店',25,0,'2026-06-05 15:43:03',15,'2026-05-21 00:00:00',NULL,NULL,NULL,'2026-05-21 15:43:02',NULL,NULL,0,NULL,NULL),(9711,1940284000182472704,1942885905090105345,2062131529328308224,NULL,'东莞店',25,0,'2026-06-05 15:43:03',1,'2026-06-03 00:00:00',NULL,NULL,NULL,'2026-06-03 19:17:23',NULL,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `nms_overtime_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_channel`
--

DROP TABLE IF EXISTS `pay_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_channel` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `type` int DEFAULT NULL COMMENT '通道类型',
  `merchant_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户名称',
  `merchant_no` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户号',
  `terminal_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '终端号',
  `access_token` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '秘钥',
  `app_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'appId',
  `api_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '证书key',
  `api_cert` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '证书cert',
  `api_shop_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付门店号',
  `private_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '商户私钥',
  `public_key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '平台公钥',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='支付通道';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_channel`
--

LOCK TABLES `pay_channel` WRITE;
/*!40000 ALTER TABLE `pay_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_log_data`
--

DROP TABLE IF EXISTS `pay_log_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_log_data` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `app_trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '应用方订单号',
  `trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '本次交易唯一id;整个支付系统唯一，生成他的原因主要是 order_id对于其它应用来说可能重复',
  `request_params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '支付的请求参数',
  `type` int DEFAULT NULL COMMENT '类型',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  UNIQUE KEY `idx_sid_app_trade_no` (`sid`,`app_trade_no`) USING BTREE,
  KEY `trade_no` (`trade_no`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='交易日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_log_data`
--

LOCK TABLES `pay_log_data` WRITE;
/*!40000 ALTER TABLE `pay_log_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_log_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_refund`
--

DROP TABLE IF EXISTS `pay_refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_refund` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `pay_type` int DEFAULT NULL COMMENT '支付渠道',
  `pay_way` int DEFAULT NULL COMMENT '支付方式',
  `channel_type` int DEFAULT NULL COMMENT '通道类型',
  `channel_no` bigint DEFAULT NULL COMMENT '通道号',
  `merchant_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户',
  `merchant_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户号',
  `app_refund_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '应用方的退款id',
  `org_trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '源支付单号',
  `refund_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '退款单编号',
  `third_refund_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '第三方支付的退款单号',
  `channel_refund_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付通道退款单号',
  `bank_refund_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行退款单号',
  `refund_fee` decimal(10,0) DEFAULT NULL COMMENT '退款金额',
  `refund_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '退款理由',
  `refund_status` int DEFAULT NULL COMMENT '退款状态',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_sid_app_no` (`sid`,`app_refund_no`) USING BTREE,
  KEY `idx_org_trade_no` (`org_trade_no`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='退款单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_refund`
--

LOCK TABLES `pay_refund` WRITE;
/*!40000 ALTER TABLE `pay_refund` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_refund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_store_and_channel`
--

DROP TABLE IF EXISTS `pay_store_and_channel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_store_and_channel` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `channel_no` bigint DEFAULT NULL COMMENT '支付通道号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid` (`mid`,`sid`) USING BTREE,
  KEY `idx_channel_no` (`channel_no`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='门店的通道设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_store_and_channel`
--

LOCK TABLES `pay_store_and_channel` WRITE;
/*!40000 ALTER TABLE `pay_store_and_channel` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_store_and_channel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_transaction`
--

DROP TABLE IF EXISTS `pay_transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_transaction` (
  `pid` bigint NOT NULL AUTO_INCREMENT,
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `report_date` datetime DEFAULT NULL COMMENT '营业日期',
  `lid` bigint NOT NULL COMMENT '订单号',
  `pay_type` int DEFAULT NULL COMMENT '支付渠道',
  `pay_way` int DEFAULT NULL COMMENT '支付方式',
  `channel_type` int DEFAULT NULL COMMENT '通道类型',
  `channel_no` bigint DEFAULT NULL COMMENT '通道号',
  `merchant_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户',
  `merchant_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '商户号',
  `app_trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '应用方订单号',
  `trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '本次交易唯一id;整个支付系统唯一，生成他的原因主要是 order_id对于其它应用来说可能重复',
  `third_trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '第三方支付平台的单号',
  `channel_trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '通道订单号，微信订单号、支付宝订单号等，返回时不参与签名',
  `bank_trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '银行渠道订单号，微信支付时显示在支付成功页面的条码，可用作扫码查询和扫码退款时匹配',
  `terminal_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '终端号',
  `terminal_time` datetime DEFAULT NULL COMMENT '终端交易时间，yyyyMMddHHmmss，全局统一时间格式',
  `total_fee` int DEFAULT NULL COMMENT '金额，单位分',
  `receipt_fee` int DEFAULT NULL COMMENT '实收金额',
  `refund_fee` int DEFAULT NULL COMMENT '退款金额',
  `trade_state` int DEFAULT NULL COMMENT '交易状态',
  `return_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付后的跳转',
  `pay_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '二维码链接',
  `notify_time` datetime DEFAULT NULL COMMENT '支付平台回调时间',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `refund_time` datetime DEFAULT NULL COMMENT '退款时间',
  `close_time` datetime DEFAULT NULL COMMENT '关闭时间',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '顾客的邮箱',
  `user_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '付款方用户id，“微信openid”、“支付宝账户”、“qq号”等，返回时不参与签名',
  `attach` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '附加数据,原样返回',
  `notify_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '回调地址',
  `deal_type` int DEFAULT NULL COMMENT '支付种类',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_sid_app_trade_no` (`sid`,`app_trade_no`) USING BTREE,
  KEY `idx_trade_no` (`trade_no`) USING BTREE,
  KEY `idx_created_time` (`created_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='支付流水表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_transaction`
--

LOCK TABLES `pay_transaction` WRITE;
/*!40000 ALTER TABLE `pay_transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay_transaction_extension`
--

DROP TABLE IF EXISTS `pay_transaction_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pay_transaction_extension` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `trade_no` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '本次交易唯一id',
  `call_num` bigint DEFAULT NULL COMMENT '发起调用的次数;异步通知的时候回填给应用端',
  `extension_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '扩展内容',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_tarde_no` (`trade_no`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='交易扩展表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay_transaction_extension`
--

LOCK TABLES `pay_transaction_extension` WRITE;
/*!40000 ALTER TABLE `pay_transaction_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_transaction_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plat_area`
--

DROP TABLE IF EXISTS `plat_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plat_area` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `code` bigint NOT NULL COMMENT '编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名称',
  `city_code` bigint NOT NULL COMMENT '城市编号',
  `province_code` bigint NOT NULL COMMENT '省份编号',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_code` (`code`) USING BTREE,
  KEY `idx_province_code` (`province_code`) USING BTREE,
  KEY `idx_city_code` (`city_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2979 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='区县';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plat_area`
--

LOCK TABLES `plat_area` WRITE;
/*!40000 ALTER TABLE `plat_area` DISABLE KEYS */;
/*!40000 ALTER TABLE `plat_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plat_city`
--

DROP TABLE IF EXISTS `plat_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plat_city` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `code` bigint NOT NULL COMMENT '编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名称',
  `province_code` bigint NOT NULL COMMENT '省份编号',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_code` (`code`) USING BTREE,
  KEY `idx_province_code` (`province_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='城市';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plat_city`
--

LOCK TABLES `plat_city` WRITE;
/*!40000 ALTER TABLE `plat_city` DISABLE KEYS */;
/*!40000 ALTER TABLE `plat_city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plat_province`
--

DROP TABLE IF EXISTS `plat_province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plat_province` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `code` bigint NOT NULL COMMENT '编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '名称',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_code` (`code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='省份';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plat_province`
--

LOCK TABLES `plat_province` WRITE;
/*!40000 ALTER TABLE `plat_province` DISABLE KEYS */;
/*!40000 ALTER TABLE `plat_province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_attr`
--

DROP TABLE IF EXISTS `product_attr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_attr` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `category` bigint DEFAULT NULL COMMENT '类别编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '描述',
  `disable` tinyint(1) DEFAULT NULL COMMENT '停用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_category` (`mid`,`category`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='销售属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_attr`
--

LOCK TABLES `product_attr` WRITE;
/*!40000 ALTER TABLE `product_attr` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_attr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_attr_value`
--

DROP TABLE IF EXISTS `product_attr_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_attr_value` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `attr_id` bigint DEFAULT NULL COMMENT '属性编号',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '属性值',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '属性值描述',
  `disable` tinyint(1) DEFAULT NULL COMMENT '停用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_attr` (`mid`,`attr_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='销售属性值';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_attr_value`
--

LOCK TABLES `product_attr_value` WRITE;
/*!40000 ALTER TABLE `product_attr_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_attr_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_brands`
--

DROP TABLE IF EXISTS `product_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_brands` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '品牌名称',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '品牌描述',
  `logo_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'logo',
  `disable` tinyint(1) DEFAULT NULL COMMENT '停用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='品牌';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_brands`
--

LOCK TABLES `product_brands` WRITE;
/*!40000 ALTER TABLE `product_brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_category` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `biz_type` int DEFAULT NULL COMMENT '产品类型',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `pic_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片',
  `previous` bigint DEFAULT NULL COMMENT '上一级',
  `path` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '分类地址',
  `disable` tinyint(1) DEFAULT NULL COMMENT '停用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='商品类别';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_category`
--

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_sku`
--

DROP TABLE IF EXISTS `product_sku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_sku` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `spu_id` bigint DEFAULT NULL COMMENT 'SPU_ID',
  `biz_type` int DEFAULT NULL COMMENT '产品类型',
  `cap_biz_type` int DEFAULT NULL COMMENT '资金账户类型',
  `attrs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '销售属性值;{attr_value_id}-{attr_value_id} 多个销售属性值逗号分隔',
  `attrs_md5` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '销售属性值的md5',
  `disable` tinyint(1) DEFAULT NULL COMMENT '停用',
  `banner_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'banner图片;多个图片逗号分隔',
  `main_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '商品介绍主图;多个图片逗号分隔',
  `price_fee` int DEFAULT NULL COMMENT '售价;整数方式保存',
  `price_scale` bigint DEFAULT NULL COMMENT '售价;金额对应的小数位数',
  `market_price_fee` int DEFAULT NULL COMMENT '市场价;整数方式保存',
  `market_price_scale` bigint DEFAULT NULL COMMENT '市场价;金额对应的小数位数',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `amount_in_spu` int DEFAULT NULL COMMENT '对应spu包含的sku数量',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_spu` (`mid`,`spu_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='标准库存单位';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_sku`
--

LOCK TABLES `product_sku` WRITE;
/*!40000 ALTER TABLE `product_sku` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_sku` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_sku_stock`
--

DROP TABLE IF EXISTS `product_sku_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_sku_stock` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `sku_id` bigint DEFAULT NULL COMMENT 'SKU ID',
  `quantity` int DEFAULT NULL COMMENT '库存',
  `disable` tinyint(1) DEFAULT NULL COMMENT '停用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sku` (`mid`,`sku_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='库存表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_sku_stock`
--

LOCK TABLES `product_sku_stock` WRITE;
/*!40000 ALTER TABLE `product_sku_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_sku_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_spu`
--

DROP TABLE IF EXISTS `product_spu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_spu` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `biz_type` int DEFAULT NULL COMMENT '产品类型',
  `cap_biz_type` int DEFAULT NULL COMMENT '资金账户类型',
  `brand_id` bigint DEFAULT NULL COMMENT '品牌ID',
  `category_id` bigint DEFAULT NULL COMMENT '分类ID',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '描述',
  `selling_point` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '卖点',
  `unit` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '单位',
  `banner_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT 'banner图片;多个图片逗号分隔',
  `main_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '商品介绍主图;多个图片逗号分隔',
  `price_fee` int DEFAULT NULL COMMENT '售价;整数方式保存',
  `price_scale` bigint DEFAULT NULL COMMENT '售价;金额对应的小数位数',
  `market_price_fee` int DEFAULT NULL COMMENT '市场价;整数方式保存',
  `market_price_scale` bigint DEFAULT NULL COMMENT '市场价;金额对应的小数位数',
  `begin_time` datetime DEFAULT NULL COMMENT '生效时间',
  `end_time` datetime DEFAULT NULL COMMENT '终止时间',
  `disable` tinyint(1) DEFAULT NULL COMMENT '停用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `org_type` int DEFAULT NULL COMMENT '机构类型',
  `user_type` int DEFAULT NULL COMMENT '用户类型',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_brand` (`mid`,`brand_id`) USING BTREE,
  KEY `idx_mid_category` (`mid`,`category_id`) USING BTREE,
  KEY `idx_mid_biz_type` (`mid`,`biz_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='标准产品单位';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_spu`
--

LOCK TABLES `product_spu` WRITE;
/*!40000 ALTER TABLE `product_spu` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_spu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_spu_sku_attr_map`
--

DROP TABLE IF EXISTS `product_spu_sku_attr_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_spu_sku_attr_map` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `spu_id` bigint DEFAULT NULL COMMENT 'SPU ID',
  `sku_id` bigint DEFAULT NULL COMMENT 'SKU ID',
  `attr_id` bigint DEFAULT NULL COMMENT '销售属性ID',
  `attr_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '销售属性名称',
  `attr_value_id` bigint DEFAULT NULL COMMENT '销售属性值ID',
  `attr_value_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '销售属性值',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_spu` (`mid`,`spu_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='关联关系冗余表;-- 1. spu下 有哪些sku\r\n-- 2. spu下 有那些销售属性\r\n-- 3. spu下 每个销售属性对应的销售属性值(一对多)\r\n-- 4. spu下 每个销售属性值对应的sku(一对多)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_spu_sku_attr_map`
--

LOCK TABLES `product_spu_sku_attr_map` WRITE;
/*!40000 ALTER TABLE `product_spu_sku_attr_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_spu_sku_attr_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sc_dog_and_store`
--

DROP TABLE IF EXISTS `sc_dog_and_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sc_dog_and_store` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `dog_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加密狗号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `dog_pid` bigint DEFAULT NULL COMMENT '加密狗pid',
  `inst` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '代理商',
  `inst_code` bigint DEFAULT NULL COMMENT '代理商编号',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_dog_id` (`dog_id`) USING BTREE,
  KEY `idx_dog_pid` (`dog_pid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2443 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='加密狗和门店的隐射关系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sc_dog_and_store`
--

LOCK TABLES `sc_dog_and_store` WRITE;
/*!40000 ALTER TABLE `sc_dog_and_store` DISABLE KEYS */;
INSERT INTO `sc_dog_and_store` VALUES (2432,1940284000182472704,1942885905090105345,2043648547630866432,'d8bc82872426af9accb678a0862db6e3',NULL,NULL,'2026-04-13 11:12:37',NULL,NULL,0,NULL,NULL,NULL),(2433,1940284000182472704,1983017347135201281,2049023658886033408,'d8bc82872426af9accb678a0862db6e3',NULL,NULL,'2026-04-28 07:11:23',NULL,NULL,0,NULL,NULL,NULL),(2434,1940284000182472704,1985885291726794753,2053661474211614720,'ac0a201d2763fa0e7d737f4ff2b0fc47',NULL,NULL,'2026-05-11 02:20:25',NULL,NULL,0,NULL,NULL,NULL),(2435,1940284000182472704,1942885905090105345,2053667766800076800,'2102d1c929e9883e4d8df67fc79b0e39',NULL,NULL,'2026-05-11 02:45:25',NULL,NULL,0,NULL,NULL,NULL),(2436,1940284000182472704,1985885291726794753,2053682725508468736,'2102d1c929e9883e4d8df67fc79b0e39',NULL,NULL,'2026-05-11 03:44:51',NULL,NULL,0,NULL,NULL,NULL),(2437,1940284000182472704,1979737429467095041,2053773956995428352,'ac0a201d2763fa0e7d737f4ff2b0fc47',NULL,NULL,'2026-05-11 09:47:23',NULL,NULL,0,NULL,NULL,NULL),(2438,1940284000182472704,1940287289892687874,2056217333462966272,'12042c61c6a35f1253fe1de6f0035828',NULL,NULL,'2026-05-18 03:36:29',NULL,NULL,0,NULL,NULL,NULL),(2439,1940284000182472704,1942885905090105345,2068933565878706176,'0a834500-c50a-4d9d-8365-e8974492e588',NULL,NULL,'2026-06-22 13:46:15',NULL,NULL,0,NULL,NULL,NULL),(2440,1940284000182472704,1942885905090105345,2087788221364633600,'12042c61c6a35f1253fe1de6f0035828',NULL,NULL,'2026-08-13 14:27:55',NULL,NULL,0,NULL,NULL,NULL),(2441,1940284000182472704,1942885905090105345,2087796559678734336,'03560230-040f-0533-6206-270700080009',NULL,NULL,'2026-08-13 15:01:03',NULL,NULL,0,NULL,NULL,NULL),(2442,1940284000182472704,1940287289892687874,2087833013863776256,'2102d1c929e9883e4d8df67fc79b0e39',NULL,NULL,'2026-08-13 17:25:55',NULL,NULL,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sc_dog_and_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config_data`
--

DROP TABLE IF EXISTS `sys_config_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config_data` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号;',
  `mid` bigint NOT NULL COMMENT '商户号;',
  `sid` bigint DEFAULT NULL COMMENT '门店号;',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `type_id_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '键名;',
  `val` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '字符串值',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid_id_key` (`mid`,`sid`,`type_id_key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='配置参数';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config_data`
--

LOCK TABLES `sys_config_data` WRITE;
/*!40000 ALTER TABLE `sys_config_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_config_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_config_type`
--

DROP TABLE IF EXISTS `sys_config_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_config_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `module` int DEFAULT NULL COMMENT '模块',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '参数名称',
  `id_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '参数键名',
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '参数键名',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `type` int DEFAULT NULL COMMENT '类型',
  `enums` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '对应的枚举',
  `def_val` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '默认值',
  `def` tinyint(1) DEFAULT NULL COMMENT '系统内置',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_id_key` (`mid`,`id_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='参数列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_config_type`
--

LOCK TABLES `sys_config_type` WRITE;
/*!40000 ALTER TABLE `sys_config_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_config_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dict_data`
--

DROP TABLE IF EXISTS `sys_dict_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict_data` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型',
  `sort` int DEFAULT '0' COMMENT '排序',
  `code` int DEFAULT NULL COMMENT '字典编码',
  `label` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '键值',
  `def` tinyint(1) DEFAULT NULL COMMENT '系统内置',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_type` (`mid`,`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='字典数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict_data`
--

LOCK TABLES `sys_dict_data` WRITE;
/*!40000 ALTER TABLE `sys_dict_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_dict_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dict_type`
--

DROP TABLE IF EXISTS `sys_dict_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `id_key` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'id的md5',
  `id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型',
  `def` tinyint(1) DEFAULT NULL COMMENT '系统内置',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_id_key` (`mid`,`id_key`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='字典';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict_type`
--

LOCK TABLES `sys_dict_type` WRITE;
/*!40000 ALTER TABLE `sys_dict_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_dict_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_login_log`
--

DROP TABLE IF EXISTS `sys_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_login_log` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `user_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户账号',
  `user_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户姓名',
  `operator_group` int DEFAULT NULL COMMENT '操作员分组',
  `login_type` int DEFAULT NULL COMMENT '操作类型',
  `success` tinyint(1) DEFAULT NULL COMMENT '登录成功',
  `ip` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主机地址',
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '登录地点',
  `browser` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '浏览器',
  `os` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作系统',
  `msg` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作信息',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_data_type_mid_created_time` (`mid`,`created_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1556 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='登录日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_login_log`
--

LOCK TABLES `sys_login_log` WRITE;
/*!40000 ALTER TABLE `sys_login_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_op_log`
--

DROP TABLE IF EXISTS `sys_op_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_op_log` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `title` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务模块',
  `operator_group` int DEFAULT NULL COMMENT '操作员分组',
  `business_type` int DEFAULT NULL COMMENT '业务类型',
  `business_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '业务说明',
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '方法名称',
  `request_method` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求方式',
  `terminal_type` int DEFAULT NULL COMMENT '终端类型',
  `oper_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作人员',
  `dept_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '部门名称',
  `oper_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '请求url',
  `oper_ip` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主机地址',
  `oper_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作地点',
  `oper_param` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '请求参数',
  `json_result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '返回参数',
  `success` tinyint(1) DEFAULT NULL COMMENT '成功',
  `error_msg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '错误信息',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_data_type_mid_created_time` (`operator_group`,`mid`,`created_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3005 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='操作日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_op_log`
--

LOCK TABLES `sys_op_log` WRITE;
/*!40000 ALTER TABLE `sys_op_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_op_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_org`
--

DROP TABLE IF EXISTS `sys_org`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_org` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `app_type` int NOT NULL COMMENT '应用类型',
  `org_type` int NOT NULL COMMENT '组织类型',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `parent_lid` bigint DEFAULT NULL COMMENT '父编号',
  `principal` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '负责人',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_org_type` (`mid`,`org_type`) USING BTREE,
  KEY `idx_org_type_id` (`org_type`,`id`) USING BTREE,
  KEY `idx_parent_id_org_type` (`parent_lid`,`org_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19663 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='组织机构';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_org`
--

LOCK TABLES `sys_org` WRITE;
/*!40000 ALTER TABLE `sys_org` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_org` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `third_app_conf`
--

DROP TABLE IF EXISTS `third_app_conf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `third_app_conf` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `third_appid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '第三方平台 appid',
  `authorizer_appid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公众号或小程序的 appid',
  `app_type` int DEFAULT NULL COMMENT '应用类型',
  `bridge_model` int DEFAULT NULL COMMENT '对接模式',
  `secret` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '秘钥',
  `token` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'token',
  `aes_key` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'EncodingAESKey',
  `msg_data_format` int DEFAULT NULL COMMENT '消息格式',
  `nick_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `principal_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主体名称',
  `head_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `user_name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '原始 ID',
  `alias` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公众号所设置的微信号，可能为空',
  `service_type_info` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公众号或者小程序类型',
  `verify_type_info` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '公众号或者小程序认证类型',
  `qrcode_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '二维码图片的 URL',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_appid` (`authorizer_appid`) USING BTREE,
  KEY `idx_mid_sid_app_type` (`mid`,`sid`,`app_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='第三方平台配置数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `third_app_conf`
--

LOCK TABLES `third_app_conf` WRITE;
/*!40000 ALTER TABLE `third_app_conf` DISABLE KEYS */;
/*!40000 ALTER TABLE `third_app_conf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_menu`
--

DROP TABLE IF EXISTS `wx_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_menu` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `tag_id` bigint DEFAULT NULL COMMENT '用户标签的id',
  `show_order` int DEFAULT NULL COMMENT '显示顺序',
  `parent_lid` bigint DEFAULT NULL COMMENT '父编号',
  `type_` int DEFAULT NULL COMMENT '类型',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `key_` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'key',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'url',
  `appid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'appid',
  `pagepath` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'pagepath',
  `article_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'article_id',
  `media_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'media_id',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='公众号菜单栏';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_menu`
--

LOCK TABLES `wx_menu` WRITE;
/*!40000 ALTER TABLE `wx_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `wx_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_msg_tmpl`
--

DROP TABLE IF EXISTS `wx_msg_tmpl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_msg_tmpl` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `product_type` int DEFAULT NULL COMMENT '产品类型',
  `biz_type` int DEFAULT NULL COMMENT '业务类型',
  `template_id_short` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模板库中模板的编号，有“TM**”和“OPENTMTM**”等形式,对于类目模板，为纯数字ID',
  `first_category_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '一级类目',
  `second_category_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '二级类目',
  `class_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'class_id',
  `ref_cnt` int DEFAULT NULL COMMENT 'ref_cnt',
  `tid` int DEFAULT NULL COMMENT '编号',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标题',
  `type` int DEFAULT NULL COMMENT 'type',
  `version` int DEFAULT NULL COMMENT 'version',
  `disable` tinyint(1) DEFAULT NULL COMMENT '禁用',
  `template_id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模板ID',
  `jump_type` int DEFAULT NULL COMMENT '跳转类型',
  `appid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'appid',
  `page_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '跳转页面',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_biz_type` (`mid`,`biz_type`) USING BTREE,
  KEY `idx_mid_tid` (`mid`,`tid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='模板消息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_msg_tmpl`
--

LOCK TABLES `wx_msg_tmpl` WRITE;
/*!40000 ALTER TABLE `wx_msg_tmpl` DISABLE KEYS */;
/*!40000 ALTER TABLE `wx_msg_tmpl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_msg_tmpl_item`
--

DROP TABLE IF EXISTS `wx_msg_tmpl_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_msg_tmpl_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `biz_type` int DEFAULT NULL COMMENT '业务类型',
  `tmlp_lid` bigint DEFAULT NULL COMMENT '模板编号',
  `color` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '颜色',
  `editable` tinyint(1) DEFAULT NULL COMMENT '可以编辑',
  `content` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '内容',
  `example` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '示例',
  `kid` int DEFAULT NULL COMMENT 'kid',
  `name` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '关键字',
  `rule` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '值',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_biz_type` (`mid`,`biz_type`) USING BTREE,
  KEY `idx_mid_tmpl_lid` (`mid`,`tmlp_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='模板消息内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_msg_tmpl_item`
--

LOCK TABLES `wx_msg_tmpl_item` WRITE;
/*!40000 ALTER TABLE `wx_msg_tmpl_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `wx_msg_tmpl_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wx_user`
--

DROP TABLE IF EXISTS `wx_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wx_user` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `appid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'appid',
  `openid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'openid',
  `unionid` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'unionid',
  `nick_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '昵称',
  `gender` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '性别',
  `language` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '语言',
  `city` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '城市',
  `province` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '省份',
  `country` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '国家',
  `avatar_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '头像',
  `phone_number` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `pure_phone_number` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `country_code` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '国家码',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_openid` (`openid`) USING BTREE,
  KEY `idx_appid` (`appid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='微信用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wx_user`
--

LOCK TABLES `wx_user` WRITE;
/*!40000 ALTER TABLE `wx_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `wx_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'a_ams'
--

--
-- Dumping routines for database 'a_ams'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-13 10:47:54
