-- MySQL dump 10.13  Distrib 8.4.7, for Linux (x86_64)
--
-- Host: localhost    Database: a_product
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `a_product`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `a_product` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `a_product`;

--
-- Table structure for table `pt_area_in_period`
--

DROP TABLE IF EXISTS `pt_area_in_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_area_in_period` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `area_lid` bigint NOT NULL COMMENT '台区lid',
  `period_lid` bigint NOT NULL COMMENT '时段lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_period_lid` (`mid`,`period_lid`) USING BTREE,
  KEY `idx_mid_area_lid` (`mid`,`area_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=30999 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='销售时段中的台区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_area_in_period`
--

LOCK TABLES `pt_area_in_period` WRITE;
/*!40000 ALTER TABLE `pt_area_in_period` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_area_in_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_area_period`
--

DROP TABLE IF EXISTS `pt_area_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_area_period` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '名称',
  `begin_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime NOT NULL COMMENT '结束时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5186 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='区域销售时段';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_area_period`
--

LOCK TABLES `pt_area_period` WRITE;
/*!40000 ALTER TABLE `pt_area_period` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_area_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_card_type_free_rule`
--

DROP TABLE IF EXISTS `pt_card_type_free_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_card_type_free_rule` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '规则名称',
  `card_type_lid` bigint DEFAULT NULL COMMENT '会员编号',
  `free_content` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '免赠次数内容',
  `start_date` datetime DEFAULT NULL COMMENT '开始日期',
  `end_date` datetime DEFAULT NULL COMMENT '结束日期',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_card_type` (`mid`,`card_type_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='会员免赠规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_card_type_free_rule`
--

LOCK TABLES `pt_card_type_free_rule` WRITE;
/*!40000 ALTER TABLE `pt_card_type_free_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_card_type_free_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_cook_ref`
--

DROP TABLE IF EXISTS `pt_cook_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_cook_ref` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `cook_type_lid` bigint NOT NULL COMMENT '做法分类lid',
  `cook_lid` bigint NOT NULL COMMENT '做法lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_sid_cook_lid` (`mid`,`sid`,`cook_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2893103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='做法分类下的做法';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_cook_ref`
--

LOCK TABLES `pt_cook_ref` WRITE;
/*!40000 ALTER TABLE `pt_cook_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_cook_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_cook_type`
--

DROP TABLE IF EXISTS `pt_cook_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_cook_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '做法编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '做法名称',
  `order_idx` int NOT NULL COMMENT '排序号',
  `min_practice` int NOT NULL COMMENT '最小做法',
  `max_practice` int NOT NULL COMMENT '最大做法',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_sid` (`mid`,`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=158119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='做法分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_cook_type`
--

LOCK TABLES `pt_cook_type` WRITE;
/*!40000 ALTER TABLE `pt_cook_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_cook_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_data_sync_record`
--

DROP TABLE IF EXISTS `pt_data_sync_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_data_sync_record` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `src_sid` bigint DEFAULT NULL COMMENT '源门店',
  `src_store_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '原门店名称',
  `dest_sid` bigint DEFAULT NULL COMMENT '目标门店',
  `dest_store_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '目标门店名称',
  `back_up_sid` bigint DEFAULT NULL COMMENT '备份门店',
  `status` int DEFAULT NULL COMMENT '状态',
  `error_msg` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '错误信息',
  `report_date` datetime DEFAULT NULL COMMENT '营业日期',
  `end_time` datetime DEFAULT NULL COMMENT '完成时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid` (`mid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='数据同步记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_data_sync_record`
--

LOCK TABLES `pt_data_sync_record` WRITE;
/*!40000 ALTER TABLE `pt_data_sync_record` DISABLE KEYS */;
INSERT INTO `pt_data_sync_record` VALUES (20,1940284000182472704,NULL,2041353287642910721,1940287289892687874,'广州店',1942885905090105345,'东莞店',NULL,1,NULL,'2026-04-07 00:00:00',NULL,NULL,NULL,'2026-04-07 11:12:05',NULL,'2026-04-07 11:12:05',0);
/*!40000 ALTER TABLE `pt_data_sync_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_dish_area`
--

DROP TABLE IF EXISTS `pt_dish_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_dish_area` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `dish_code` bigint DEFAULT NULL COMMENT '菜品编号',
  `dish_type_code` bigint DEFAULT NULL COMMENT '小类编号',
  `dish_supper_type_code` bigint DEFAULT NULL COMMENT '大类编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '部位名称',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `not_inherit_common` tinyint DEFAULT '0' COMMENT '不继承通用做法：0-否，1-是',
  `not_multiple_choice` tinyint DEFAULT '0' COMMENT '不可多选：0-否，1-是',
  `not_show_practice` tinyint DEFAULT '0' COMMENT '不自动弹出：0-否，1-是',
  `fixed_cook` tinyint DEFAULT '0' COMMENT '做法不随菜谱变更：0-否，1-是',
  PRIMARY KEY (`pid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品部位';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_dish_area`
--

LOCK TABLES `pt_dish_area` WRITE;
/*!40000 ALTER TABLE `pt_dish_area` DISABLE KEYS */;
INSERT INTO `pt_dish_area` VALUES (132,1940284000182472704,1940287289892687874,2041352927605428225,NULL,NULL,2041349063640616962,'鱼头',NULL,NULL,'2026-04-07 03:10:39',NULL,NULL,NULL,0,0,0,0),(133,1940284000182472704,1940287289892687874,2041352995284717570,NULL,2041349265130786818,NULL,'头部',NULL,NULL,'2026-04-07 03:10:55',NULL,NULL,NULL,0,0,0,0),(134,1940284000182472704,1940287289892687874,2041353046794964994,2041352053147570178,NULL,NULL,'头部',NULL,NULL,'2026-04-07 03:11:07',NULL,NULL,NULL,0,0,0,0),(135,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-04-10 10:02:41',NULL,NULL,NULL,0,0,0,0),(136,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-04-10 10:02:50',NULL,NULL,NULL,0,0,0,0),(137,1940284000182472704,2042804773847437313,2042882064288976897,2042873704147718146,NULL,NULL,'猪肚',NULL,NULL,'2026-04-11 08:26:53',NULL,NULL,NULL,0,0,0,0),(138,1940284000182472704,1985885291726794753,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-05-11 06:24:17',NULL,NULL,NULL,0,0,0,0),(139,1940284000182472704,1985885291726794753,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-05-11 06:24:17',NULL,NULL,NULL,0,0,0,0),(140,1940284000182472704,1979737429467095041,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,NULL,0,0,0,0),(141,1940284000182472704,1979737429467095041,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-05-11 09:55:19',NULL,NULL,NULL,0,0,0,0),(144,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-07 17:08:56',NULL,NULL,NULL,0,0,0,0),(145,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-07 17:08:56',NULL,NULL,NULL,0,0,0,0),(146,1940284000182472704,1942885905090105345,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-07 17:11:13',NULL,NULL,NULL,0,0,0,0),(147,1940284000182472704,1942885905090105345,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-07 17:11:13',NULL,NULL,NULL,0,0,0,0),(148,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-10 11:33:13',NULL,NULL,NULL,0,0,0,0),(149,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-10 11:33:13',NULL,NULL,NULL,0,0,0,0),(150,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-10 11:34:21',NULL,NULL,NULL,0,0,0,0),(151,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-10 11:34:21',NULL,NULL,NULL,0,0,0,0),(152,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-10 11:35:20',NULL,NULL,NULL,0,0,0,0),(153,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-10 11:35:20',NULL,NULL,NULL,0,0,0,0),(154,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-10 11:35:54',NULL,NULL,NULL,0,0,0,0),(155,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-10 11:35:54',NULL,NULL,NULL,0,0,0,0),(156,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-10 13:53:55',NULL,NULL,NULL,0,0,0,0),(157,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-10 13:53:55',NULL,NULL,NULL,0,0,0,0),(158,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-10 13:54:27',NULL,NULL,NULL,0,0,0,0),(159,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-10 13:54:27',NULL,NULL,NULL,0,0,0,0),(160,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-10 13:57:13',NULL,NULL,NULL,0,0,0,0),(161,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-10 13:57:13',NULL,NULL,NULL,0,0,0,0),(162,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-10 14:00:28',NULL,NULL,NULL,0,0,0,0),(163,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-10 14:00:28',NULL,NULL,NULL,0,0,0,0),(164,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-10 14:02:02',NULL,NULL,NULL,0,0,0,0),(165,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-10 14:02:02',NULL,NULL,NULL,0,0,0,0),(166,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-10 14:37:27',NULL,NULL,NULL,0,0,0,0),(167,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-10 14:37:27',NULL,NULL,NULL,0,0,0,0),(168,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-11 15:44:52',NULL,NULL,NULL,0,0,0,0),(169,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-11 15:44:52',NULL,NULL,NULL,0,0,0,0),(170,1940284000182472704,2042543010529546242,2042543783403982850,NULL,NULL,2042543080333774850,'123',NULL,NULL,'2026-08-11 17:51:03',NULL,NULL,NULL,0,0,0,0),(171,1940284000182472704,2042543010529546242,2042543823753187329,NULL,2042543525278126082,NULL,'132',NULL,NULL,'2026-08-11 17:51:03',NULL,NULL,NULL,0,0,0,0);
/*!40000 ALTER TABLE `pt_dish_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_dish_flavor`
--

DROP TABLE IF EXISTS `pt_dish_flavor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_dish_flavor` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '口味名称',
  `flavor_type_code` bigint DEFAULT NULL COMMENT '类型编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8310 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品口味';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_dish_flavor`
--

LOCK TABLES `pt_dish_flavor` WRITE;
/*!40000 ALTER TABLE `pt_dish_flavor` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_dish_flavor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_dish_overtime`
--

DROP TABLE IF EXISTS `pt_dish_overtime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_dish_overtime` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `relate_lid` bigint DEFAULT NULL COMMENT '关联标识',
  `type_` int DEFAULT NULL COMMENT '类型 1菜品 2菜品小类 3菜品大类',
  `side_over_time` int DEFAULT NULL COMMENT '配菜超时时间（分钟）',
  `cook_over_time` int DEFAULT NULL COMMENT '制作超时时间（分钟）',
  `serve_over_time` int DEFAULT NULL COMMENT '传菜超时时间（分钟）',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid_relate_lid_type_` (`mid`,`sid`,`relate_lid`,`type_`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='商品超时设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_dish_overtime`
--

LOCK TABLES `pt_dish_overtime` WRITE;
/*!40000 ALTER TABLE `pt_dish_overtime` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_dish_overtime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_dish_table_price`
--

DROP TABLE IF EXISTS `pt_dish_table_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_dish_table_price` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `table_type_code` bigint DEFAULT NULL COMMENT '桌台类型',
  `dish_code` bigint DEFAULT NULL COMMENT '菜品编号',
  `dish_unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '菜品单位',
  `dish_price` decimal(24,6) DEFAULT NULL COMMENT '菜品价格',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_sid_dish_lid` (`mid`,`sid`,`dish_code`) USING BTREE,
  KEY `idx_mid_sid_type_lid_dish_lid` (`mid`,`sid`,`table_type_code`,`dish_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12780655 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='菜品房台价格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_dish_table_price`
--

LOCK TABLES `pt_dish_table_price` WRITE;
/*!40000 ALTER TABLE `pt_dish_table_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_dish_table_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_flavor_type`
--

DROP TABLE IF EXISTS `pt_flavor_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_flavor_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '类型名称',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=472 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='口味类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_flavor_type`
--

LOCK TABLES `pt_flavor_type` WRITE;
/*!40000 ALTER TABLE `pt_flavor_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_flavor_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_free_rule_dish`
--

DROP TABLE IF EXISTS `pt_free_rule_dish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_free_rule_dish` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `free_rule_lid` bigint DEFAULT NULL COMMENT '免赠规则lid',
  `dish_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `dish_lid` bigint DEFAULT NULL COMMENT '菜品lid',
  `dish_unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '单位',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_sid_rule_id` (`mid`,`sid`,`free_rule_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='免赠规则关联菜品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_free_rule_dish`
--

LOCK TABLES `pt_free_rule_dish` WRITE;
/*!40000 ALTER TABLE `pt_free_rule_dish` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_free_rule_dish` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_image_compress`
--

DROP TABLE IF EXISTS `pt_image_compress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_image_compress` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片md5值',
  `image_biz_type` int DEFAULT NULL COMMENT '业务类型',
  `origin_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '源路径',
  `target_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '目标路径',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `idx_mid_sid_id` (`mid`,`sid`,`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16031 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='图片压缩记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_image_compress`
--

LOCK TABLES `pt_image_compress` WRITE;
/*!40000 ALTER TABLE `pt_image_compress` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_image_compress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_label`
--

DROP TABLE IF EXISTS `pt_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_label` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '标签名称',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `type_` int DEFAULT NULL COMMENT '标签类型',
  `hideInWx` tinyint(1) DEFAULT NULL COMMENT '扫码下单隐藏',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='菜品标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_label`
--

LOCK TABLES `pt_label` WRITE;
/*!40000 ALTER TABLE `pt_label` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_member_price`
--

DROP TABLE IF EXISTS `pt_member_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_member_price` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `dish_lid` bigint DEFAULT NULL COMMENT '菜品Lid',
  `unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '菜品单位',
  `price` decimal(24,6) DEFAULT NULL COMMENT '菜品价格',
  `card_type_lid` bigint DEFAULT NULL COMMENT '会员卡类型Lid',
  `card_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '会员卡类型名称',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `mid_sid_card_type_lid` (`mid`,`sid`,`card_type_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3551297 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='会员价格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_member_price`
--

LOCK TABLES `pt_member_price` WRITE;
/*!40000 ALTER TABLE `pt_member_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_member_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_queue`
--

DROP TABLE IF EXISTS `pt_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_queue` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `id` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '队列编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '队列名称（取号首字母）',
  `min_people` int NOT NULL DEFAULT '1' COMMENT '最少可入座人数',
  `max_people` int NOT NULL DEFAULT '1' COMMENT '最多可入座人数',
  `enable` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `time_cost` int NOT NULL DEFAULT '0' COMMENT '预估耗时',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1158 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='排队队列';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_queue`
--

LOCK TABLES `pt_queue` WRITE;
/*!40000 ALTER TABLE `pt_queue` DISABLE KEYS */;
INSERT INTO `pt_queue` VALUES (1157,1940284000182472704,1940287289892687874,2042544130683965441,'A','1234',1,1,1,NULL,NULL,'2026-04-23 15:57:05',NULL,'2026-04-23 15:57:05',0,0);
/*!40000 ALTER TABLE `pt_queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_queue_open`
--

DROP TABLE IF EXISTS `pt_queue_open`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_queue_open` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '会员手机号',
  `open_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'open_id',
  `app_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT 'app_id',
  `type_` int NOT NULL COMMENT '类型',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `app_id_phone` (`app_id`,`phone`) USING BTREE,
  KEY `open_id` (`open_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1519 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='排队叫号openId';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_queue_open`
--

LOCK TABLES `pt_queue_open` WRITE;
/*!40000 ALTER TABLE `pt_queue_open` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_queue_open` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_queue_record`
--

DROP TABLE IF EXISTS `pt_queue_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_queue_record` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint NOT NULL COMMENT '租户号',
  `sid` bigint NOT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `queue_lid` bigint NOT NULL COMMENT '队列lid',
  `queue_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '队列名称',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '用户手机号',
  `nick_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '用户名称',
  `avatar` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '用户头像',
  `open_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '用户open_id',
  `period` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '时段名',
  `call_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '叫号人',
  `call_at` datetime DEFAULT NULL COMMENT '叫号时间',
  `call_num` int DEFAULT NULL COMMENT '叫号次数',
  `meal_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '就餐人',
  `meal_at` datetime DEFAULT NULL COMMENT '就餐时间',
  `over_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '过号人',
  `over_at` datetime DEFAULT NULL COMMENT '过号时间',
  `queue_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '排队序列号',
  `people` int NOT NULL COMMENT '人数',
  `queue_state` int NOT NULL DEFAULT '1' COMMENT '队列状态',
  `queue_channel` int NOT NULL DEFAULT '2' COMMENT '领号渠道',
  `wait_minute` int DEFAULT NULL COMMENT '等待分钟数',
  `qr_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '二维码链接',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `reserve` tinyint(1) NOT NULL DEFAULT '0' COMMENT '保留号码',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date_queue_lid` (`mid`,`report_date`,`queue_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=75256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='排队叫号记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_queue_record`
--

LOCK TABLES `pt_queue_record` WRITE;
/*!40000 ALTER TABLE `pt_queue_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_queue_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_tbl_area_dish`
--

DROP TABLE IF EXISTS `pt_tbl_area_dish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_tbl_area_dish` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `tbl_area_lid` bigint DEFAULT NULL COMMENT '区域lid',
  `dish_lid` bigint DEFAULT NULL COMMENT '菜品lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_sid_area_lid` (`mid`,`sid`,`tbl_area_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=35796718 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='区域菜品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_tbl_area_dish`
--

LOCK TABLES `pt_tbl_area_dish` WRITE;
/*!40000 ALTER TABLE `pt_tbl_area_dish` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_tbl_area_dish` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_x_spec_price`
--

DROP TABLE IF EXISTS `pt_x_spec_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pt_x_spec_price` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `dish_lid` bigint NOT NULL COMMENT '菜品lid',
  `price` decimal(24,6) NOT NULL COMMENT '价格',
  `start_val` decimal(24,6) NOT NULL COMMENT '开始份数',
  `end_val` decimal(24,6) NOT NULL COMMENT '结束份数',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '单位',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_mid_sid_dish_lid` (`mid`,`sid`,`dish_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4578 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='第X份特价';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_x_spec_price`
--

LOCK TABLES `pt_x_spec_price` WRITE;
/*!40000 ALTER TABLE `pt_x_spec_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_x_spec_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'a_product'
--

--
-- Dumping routines for database 'a_product'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-13 10:48:03
