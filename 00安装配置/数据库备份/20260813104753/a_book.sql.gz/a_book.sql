-- MySQL dump 10.13  Distrib 8.4.7, for Linux (x86_64)
--
-- Host: localhost    Database: a_book
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `a_book`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `a_book` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `a_book`;

--
-- Table structure for table `applet_invitation`
--

DROP TABLE IF EXISTS `applet_invitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applet_invitation` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `theme` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `picture` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '展示顶部图',
  `thumbnail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '缩略图',
  `state` tinyint(1) DEFAULT NULL COMMENT '状态',
  `theme_color` int DEFAULT NULL COMMENT '推荐主题',
  `font_color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '字体色',
  `background_color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '背景色',
  `border` tinyint(1) DEFAULT NULL COMMENT '子主题边框',
  `divider_line` int DEFAULT NULL COMMENT '分割线',
  `line_left` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '自定义左',
  `line_right` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '自定义右',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='小程序邀请函';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applet_invitation`
--

LOCK TABLES `applet_invitation` WRITE;
/*!40000 ALTER TABLE `applet_invitation` DISABLE KEYS */;
/*!40000 ALTER TABLE `applet_invitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_invoce`
--

DROP TABLE IF EXISTS `bill_invoce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_invoce` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `book_bill_id` bigint DEFAULT NULL COMMENT '预订订单编号',
  `pos_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'pos账单号',
  `checkout_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'pos结账方式',
  `actual_amount` int DEFAULT NULL COMMENT '实付金额',
  `invoce_amount` int DEFAULT NULL COMMENT '开票金额',
  `invoce_total_amount` int DEFAULT NULL COMMENT '开票总金额',
  `invoce_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '开票备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='账单开票';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_invoce`
--

LOCK TABLES `bill_invoce` WRITE;
/*!40000 ALTER TABLE `bill_invoce` DISABLE KEYS */;
/*!40000 ALTER TABLE `bill_invoce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_bill`
--

DROP TABLE IF EXISTS `book_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_bill` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客户姓名',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `order_time` datetime DEFAULT NULL COMMENT '下单时间',
  `dining_time` datetime DEFAULT NULL COMMENT '就餐时间',
  `meal_period_id` bigint DEFAULT NULL COMMENT '餐段编号',
  `order_channel` bigint DEFAULT NULL COMMENT '接单渠道',
  `follower` bigint DEFAULT NULL COMMENT '跟单人',
  `receptionist` bigint DEFAULT NULL COMMENT '接待人',
  `set_table_count` int DEFAULT NULL COMMENT '摆台桌数',
  `meal_standard` int DEFAULT NULL COMMENT '餐标',
  `customer_id` bigint DEFAULT NULL COMMENT '客户编号',
  `dish_preference` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '菜品偏好',
  `tbl_area_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '桌台区域编号',
  `tbl_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '桌台编号',
  `temporary_cunter` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '临时号台',
  `key_concern` tinyint(1) DEFAULT NULL COMMENT '重点关注',
  `cancel_time` datetime DEFAULT NULL COMMENT '撤单时间',
  `dining_count` int DEFAULT NULL COMMENT '就餐人数',
  `amount` int DEFAULT NULL COMMENT '消费金额',
  `pos_payment_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'pos结账方式',
  `pre_dicount_amount` int DEFAULT NULL COMMENT '折前金额',
  `tbl_count` int DEFAULT NULL COMMENT '实际消费桌数',
  `order_state` int DEFAULT NULL COMMENT '订单状态',
  `order_source` int DEFAULT NULL COMMENT '订单来源',
  `deposit` int DEFAULT NULL COMMENT '订金',
  `deposit_receipt_num` bigint DEFAULT NULL COMMENT '订金收据编号',
  `deposit_pay_method` int DEFAULT NULL COMMENT '订金支付方式',
  `deposit_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '订金备注',
  `operator` bigint DEFAULT NULL COMMENT '操作人',
  `banquet_type` int DEFAULT NULL COMMENT '宴会类型',
  `banquet_board` int DEFAULT NULL COMMENT '宴会水牌',
  `director` bigint DEFAULT NULL COMMENT '策划负责人',
  `sign_date` datetime DEFAULT NULL COMMENT '签约日期',
  `final_price` int DEFAULT NULL COMMENT '最终协议价',
  `principal_guest` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '主宾',
  `catering` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '餐饮',
  `wedding_company` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '婚庆公司',
  `preparation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '准备事项',
  `venue` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '会场',
  `guest_room` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客房',
  `guarantee` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '担保人',
  `celebration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '礼仪庆典',
  `wedding_photo_studio` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '婚纱照单位',
  `advance_payment` int DEFAULT NULL COMMENT '预付金额',
  `invoice_amount` int DEFAULT NULL COMMENT '发票金额',
  `service_tag` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '服务标签',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `cancel_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '撤单原因',
  `cancel_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '撤单备注',
  `last_update_time` datetime DEFAULT NULL COMMENT '最后修改时间',
  `festival_id` bigint DEFAULT NULL COMMENT '吉祥日编号',
  `contractual_unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '协议单位',
  `meal_standard_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '餐标类型',
  `verify` tinyint(1) DEFAULT NULL COMMENT '是否核餐',
  `kid_count` int DEFAULT NULL COMMENT '儿童人数',
  `reference_price` int DEFAULT NULL COMMENT '参考价',
  `per` int DEFAULT NULL COMMENT '人均',
  `unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '单位',
  `message` tinyint(1) DEFAULT NULL COMMENT '是否短信',
  `follow_customer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '随客信息',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_dining_time` (`dining_time`) USING BTREE,
  KEY `idx_meal_period` (`meal_period_id`) USING BTREE,
  KEY `idx_order_state` (`order_state`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='预订通知单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_bill`
--

LOCK TABLES `book_bill` WRITE;
/*!40000 ALTER TABLE `book_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `book_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_dish`
--

DROP TABLE IF EXISTS `book_dish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_dish` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `book_bill_id` bigint DEFAULT NULL COMMENT '预订单编号',
  `dish_id` bigint DEFAULT NULL COMMENT '菜品编号',
  `amount` decimal(24,6) DEFAULT NULL COMMENT '数量',
  `unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '单位',
  `auxiliary_amount` decimal(24,6) DEFAULT NULL COMMENT '辅助数量',
  `auxiliary_unit` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '辅助单位',
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '做法',
  `extra_charge` int DEFAULT NULL COMMENT '做法加价',
  `sell_amount` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '售价',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `order_remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '点菜备注',
  `specification` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '规格',
  `sub_total` int DEFAULT NULL COMMENT '小计',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='预点菜品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_dish`
--

LOCK TABLES `book_dish` WRITE;
/*!40000 ALTER TABLE `book_dish` DISABLE KEYS */;
/*!40000 ALTER TABLE `book_dish` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_record`
--

DROP TABLE IF EXISTS `call_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_record` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `call_date` datetime DEFAULT NULL COMMENT '来电日期',
  `call_phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '来电号码',
  `call_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '来电姓名',
  `call_state` int DEFAULT NULL COMMENT '来电状态',
  `handler` bigint DEFAULT NULL COMMENT '处理人',
  `handle_time` datetime DEFAULT NULL COMMENT '处理时间',
  `bill_state` int DEFAULT NULL COMMENT '订单状态',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='来电记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_record`
--

LOCK TABLES `call_record` WRITE;
/*!40000 ALTER TABLE `call_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_recontact`
--

DROP TABLE IF EXISTS `customer_recontact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_recontact` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `order_id` bigint DEFAULT NULL COMMENT '订单编号',
  `num` int DEFAULT NULL COMMENT '第几次回访',
  `recontact_staff` bigint DEFAULT NULL COMMENT '回访人',
  `recontact_time` datetime DEFAULT NULL COMMENT '回访时间',
  `recontact_result` int DEFAULT NULL COMMENT '回访结果',
  `recontact_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '回访内容',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_order_id` (`order_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='客人回访';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_recontact`
--

LOCK TABLES `customer_recontact` WRITE;
/*!40000 ALTER TABLE `customer_recontact` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_recontact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_wine_record`
--

DROP TABLE IF EXISTS `customer_wine_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_wine_record` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `type` int DEFAULT NULL COMMENT '存或取',
  `wine_state` int DEFAULT NULL COMMENT '存取酒状态',
  `shop_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '店铺名称',
  `customer_id` bigint DEFAULT NULL COMMENT '客户编号',
  `variety` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '品种名称',
  `count` int DEFAULT NULL COMMENT '数量',
  `remain` int DEFAULT NULL COMMENT '余量',
  `deposit_duration` int DEFAULT NULL COMMENT '寄存时长',
  `deposit_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '存酒房号',
  `deposit_date` datetime DEFAULT NULL COMMENT '存酒日期',
  `deposit_staff` bigint DEFAULT NULL COMMENT '存酒经办人',
  `deposit_bartender` bigint DEFAULT NULL COMMENT '存酒酒吧员',
  `withdrawal_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '取酒房号',
  `withdrawal_date` datetime DEFAULT NULL COMMENT '取酒日期',
  `withdrawal_staff` bigint DEFAULT NULL COMMENT '取酒经办人',
  `withdrawal_bartender` bigint DEFAULT NULL COMMENT '取酒酒吧员',
  `remark` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='客户存取酒登记';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_wine_record`
--

LOCK TABLES `customer_wine_record` WRITE;
/*!40000 ALTER TABLE `customer_wine_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_wine_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customization`
--

DROP TABLE IF EXISTS `customization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customization` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `order_id` bigint DEFAULT NULL COMMENT '订单编号',
  `theme` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '宴会主题',
  `doorplate` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '门牌',
  `sand_table` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '沙盘',
  `welcome_screen` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '欢迎屏',
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '图片',
  `video` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '视频',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_order_id` (`order_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='私人定制';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customization`
--

LOCK TABLES `customization` WRITE;
/*!40000 ALTER TABLE `customization` DISABLE KEYS */;
/*!40000 ALTER TABLE `customization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposit_trade_detail`
--

DROP TABLE IF EXISTS `deposit_trade_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposit_trade_detail` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `book_bill_id` bigint DEFAULT NULL COMMENT '预订订单编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '客户姓名',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `trade_time` datetime DEFAULT NULL COMMENT '交易时间',
  `trade_type` int DEFAULT NULL COMMENT '交易类型',
  `trade_amount` int DEFAULT NULL COMMENT '交易金额',
  `trade_state` int DEFAULT NULL COMMENT '交易状态',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='订金交易明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposit_trade_detail`
--

LOCK TABLES `deposit_trade_detail` WRITE;
/*!40000 ALTER TABLE `deposit_trade_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `deposit_trade_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fee_type`
--

DROP TABLE IF EXISTS `fee_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fee_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `tbl_id` bigint DEFAULT NULL COMMENT '桌台编号',
  `min_fee` int DEFAULT NULL COMMENT '最低消费',
  `service_fee` int DEFAULT NULL COMMENT '服务费',
  `per_fee` int DEFAULT NULL COMMENT '最低人均',
  `venue_fee` int DEFAULT NULL COMMENT '场地费',
  `room_fee` int DEFAULT NULL COMMENT '包间费',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_tbl` (`tbl_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='费用类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fee_type`
--

LOCK TABLES `fee_type` WRITE;
/*!40000 ALTER TABLE `fee_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `fee_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_setting`
--

DROP TABLE IF EXISTS `festival_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `festival_setting` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `festival_id` bigint DEFAULT NULL COMMENT '吉祥日编号',
  `festival_date` datetime DEFAULT NULL COMMENT '日期',
  `period_id` bigint DEFAULT NULL COMMENT '餐段编号',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='吉祥日设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_setting`
--

LOCK TABLES `festival_setting` WRITE;
/*!40000 ALTER TABLE `festival_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_type`
--

DROP TABLE IF EXISTS `festival_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `festival_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '吉祥日名称',
  `color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型颜色',
  `commission_ratio` decimal(24,6) DEFAULT NULL COMMENT '提成比例',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='吉祥日类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_type`
--

LOCK TABLES `festival_type` WRITE;
/*!40000 ALTER TABLE `festival_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meal_period_setting`
--

DROP TABLE IF EXISTS `meal_period_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meal_period_setting` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `period_id` bigint DEFAULT NULL COMMENT '餐段编号',
  `day_of_week` bigint DEFAULT NULL COMMENT '星期几',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `state` tinyint(1) DEFAULT NULL COMMENT '是否接受预订',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='餐段设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meal_period_setting`
--

LOCK TABLES `meal_period_setting` WRITE;
/*!40000 ALTER TABLE `meal_period_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `meal_period_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_setting`
--

DROP TABLE IF EXISTS `message_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_setting` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '消息名称',
  `sort_idx` int DEFAULT NULL COMMENT '排序',
  `trigger_condition` int DEFAULT NULL COMMENT '触发条件',
  `message_type` int DEFAULT NULL COMMENT '消息类型',
  `receiver` tinyint(1) DEFAULT NULL COMMENT '接单人',
  `receptionist` tinyint(1) DEFAULT NULL COMMENT '接待人',
  `follower` tinyint(1) DEFAULT NULL COMMENT '跟单人',
  `director` tinyint(1) DEFAULT NULL COMMENT '策划负责人',
  `department_header` tinyint(1) DEFAULT NULL COMMENT '准备部门负责人',
  `guarantor` tinyint(1) DEFAULT NULL COMMENT '担保人',
  `staff_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '员工消息',
  `customer` tinyint(1) DEFAULT NULL COMMENT '客户',
  `principal_guest` tinyint(1) DEFAULT NULL COMMENT '主宾',
  `all_guests` tinyint(1) DEFAULT NULL COMMENT '所有宾客',
  `customer_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '客户消息',
  `text` tinyint(1) DEFAULT NULL COMMENT '短信',
  `app` tinyint(1) DEFAULT NULL COMMENT '站内消息',
  `wechat` tinyint(1) DEFAULT NULL COMMENT '微信通知',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='消息设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_setting`
--

LOCK TABLES `message_setting` WRITE;
/*!40000 ALTER TABLE `message_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message_type`
--

DROP TABLE IF EXISTS `message_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `message_type` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `message_id` bigint DEFAULT NULL COMMENT '消息编号',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '类型名',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '字段名',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE,
  KEY `idx_message_id` (`message_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='消息类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message_type`
--

LOCK TABLES `message_type` WRITE;
/*!40000 ALTER TABLE `message_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `message_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `occupancy_table_setting`
--

DROP TABLE IF EXISTS `occupancy_table_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `occupancy_table_setting` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `occupancy_date` datetime DEFAULT NULL COMMENT '日期',
  `meal_period_id` bigint DEFAULT NULL COMMENT '餐段编号',
  `dish_table_type_id` bigint DEFAULT NULL COMMENT '桌台类型编号',
  `number` int DEFAULT NULL COMMENT '桌数',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='上座率标配桌数设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `occupancy_table_setting`
--

LOCK TABLES `occupancy_table_setting` WRITE;
/*!40000 ALTER TABLE `occupancy_table_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `occupancy_table_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserve_table`
--

DROP TABLE IF EXISTS `reserve_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reserve_table` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `reserve_date` datetime DEFAULT NULL COMMENT '预留日期',
  `meal_period_id` bigint DEFAULT NULL COMMENT '餐段',
  `table_id` bigint DEFAULT NULL COMMENT '桌台',
  `reserve_staff` bigint DEFAULT NULL COMMENT '预留人',
  `operator_id` bigint DEFAULT NULL COMMENT '操作人',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='预留桌台';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserve_table`
--

LOCK TABLES `reserve_table` WRITE;
/*!40000 ALTER TABLE `reserve_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `reserve_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subtheme_edit`
--

DROP TABLE IF EXISTS `subtheme_edit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subtheme_edit` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `theme_id` bigint DEFAULT NULL COMMENT '主题编号',
  `subtheme` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '子主题名',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `picture` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '图片',
  `video` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '视频',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='编辑子主题';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subtheme_edit`
--

LOCK TABLES `subtheme_edit` WRITE;
/*!40000 ALTER TABLE `subtheme_edit` DISABLE KEYS */;
/*!40000 ALTER TABLE `subtheme_edit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `table_lock_setting`
--

DROP TABLE IF EXISTS `table_lock_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `table_lock_setting` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '商户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `start_date` datetime DEFAULT NULL COMMENT '开始日期',
  `end_date` datetime DEFAULT NULL COMMENT '结束日期',
  `meal_period_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '餐段编号',
  `table_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '桌台编号',
  `lock_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '锁台原因',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_lid` (`lid`) USING BTREE,
  KEY `idx_sid` (`sid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC COMMENT='设置锁台';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `table_lock_setting`
--

LOCK TABLES `table_lock_setting` WRITE;
/*!40000 ALTER TABLE `table_lock_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `table_lock_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'a_book'
--

--
-- Dumping routines for database 'a_book'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-13 10:47:56
