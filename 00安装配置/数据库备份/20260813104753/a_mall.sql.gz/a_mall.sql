-- MySQL dump 10.13  Distrib 8.4.7, for Linux (x86_64)
--
-- Host: localhost    Database: a_mall
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `a_mall`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `a_mall` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `a_mall`;

--
-- Table structure for table `after_sale_pic`
--

DROP TABLE IF EXISTS `after_sale_pic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `after_sale_pic` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `after_sale_lid` bigint NOT NULL COMMENT '售后申请lid',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '售后申请图片地址',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE,
  KEY `idx_mid_sale_lid` (`sid`,`after_sale_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='售后申请图片';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `after_sale_pic`
--

LOCK TABLES `after_sale_pic` WRITE;
/*!40000 ALTER TABLE `after_sale_pic` DISABLE KEYS */;
/*!40000 ALTER TABLE `after_sale_pic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_address`
--

DROP TABLE IF EXISTS `mall_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_address` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `default_status` tinyint(1) DEFAULT NULL COMMENT '是否默认收货地址',
  `receive_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收发货人姓名',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收货人电话',
  `province_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '省份编码',
  `province` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '省/直辖市',
  `city_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '城市编码',
  `city` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '城市',
  `region_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '区编码',
  `region` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '区',
  `detail_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '详细地址',
  `addr_tag` int DEFAULT NULL COMMENT '地址标签',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_user_id` (`mid`,`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='收货地址';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_address`
--

LOCK TABLES `mall_address` WRITE;
/*!40000 ALTER TABLE `mall_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_after_sale`
--

DROP TABLE IF EXISTS `mall_after_sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_after_sale` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `after_sale_state` int NOT NULL COMMENT '售后状态',
  `after_sale_type` int NOT NULL COMMENT '售后类型',
  `order_item_lid` bigint NOT NULL COMMENT '商品lid',
  `order_lid` bigint NOT NULL DEFAULT '-1' COMMENT '订单lid',
  `reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '申请原因',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '售后备注',
  `tracking_number` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '快递单号',
  `user_id` bigint NOT NULL COMMENT '用户lid',
  `user_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '用户名称',
  `user_phone` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户手机号',
  `apply_at` datetime NOT NULL COMMENT '申请时间',
  `process_at` datetime DEFAULT NULL COMMENT '处理时间',
  `process_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '处理人',
  `refund` tinyint(1) NOT NULL DEFAULT '0' COMMENT '已退款',
  `refund_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退款人',
  `refund_at` datetime DEFAULT NULL COMMENT '退款时间',
  `receiver_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收货地址',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_item_lid` (`mid`,`order_item_lid`) USING BTREE,
  KEY `idx_mid_report_date_user_lid` (`mid`,`report_date`,`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='微商城售后';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_after_sale`
--

LOCK TABLES `mall_after_sale` WRITE;
/*!40000 ALTER TABLE `mall_after_sale` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_after_sale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_attr`
--

DROP TABLE IF EXISTS `mall_attr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_attr` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '描述',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='销售属性表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_attr`
--

LOCK TABLES `mall_attr` WRITE;
/*!40000 ALTER TABLE `mall_attr` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_attr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_attr_value`
--

DROP TABLE IF EXISTS `mall_attr_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_attr_value` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `attr_id` bigint DEFAULT NULL COMMENT '销售属性ID',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '销售属性值',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '销售属性值描述',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_attr_id` (`mid`,`attr_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='销售属性值';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_attr_value`
--

LOCK TABLES `mall_attr_value` WRITE;
/*!40000 ALTER TABLE `mall_attr_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_attr_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_brands`
--

DROP TABLE IF EXISTS `mall_brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_brands` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '品牌名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '品牌描述',
  `logo_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '品牌logo图片',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='品牌表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_brands`
--

LOCK TABLES `mall_brands` WRITE;
/*!40000 ALTER TABLE `mall_brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_category`
--

DROP TABLE IF EXISTS `mall_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_category` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `show_order` int DEFAULT NULL COMMENT '显示顺序',
  `obsolete` tinyint(1) DEFAULT NULL COMMENT '已经下架',
  `parent_id` bigint DEFAULT NULL COMMENT '父编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '描述',
  `pic_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '图片',
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '地址',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='类别表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_category`
--

LOCK TABLES `mall_category` WRITE;
/*!40000 ALTER TABLE `mall_category` DISABLE KEYS */;
INSERT INTO `mall_category` VALUES (88,1940284000182472704,NULL,2039176152903856129,NULL,0,NULL,'2121',NULL,'',NULL,NULL,NULL,'2026-04-01 03:00:55',NULL,NULL,1),(89,1940284000182472704,NULL,2039176261494386689,NULL,0,NULL,'gkl','121221','',NULL,NULL,NULL,'2026-04-01 03:01:21',NULL,NULL,1),(90,1940284000182472704,NULL,2039176837150027777,NULL,0,NULL,'ghj',NULL,'',NULL,NULL,NULL,'2026-04-01 03:03:38',NULL,NULL,0),(91,1940284000182472704,NULL,2055211371281649666,NULL,0,NULL,'饮料',NULL,'',NULL,NULL,NULL,'2026-05-15 08:59:09',NULL,NULL,0),(92,1940284000182472704,NULL,2055211425887293442,NULL,0,2055211371281649666,'汽水',NULL,'',NULL,NULL,NULL,'2026-05-15 08:59:22',NULL,NULL,0);
/*!40000 ALTER TABLE `mall_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_evaluation`
--

DROP TABLE IF EXISTS `mall_evaluation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_evaluation` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `order_lid` bigint NOT NULL COMMENT '订单编号',
  `user_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '收货人电话',
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收货人名称',
  `head_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '头像',
  `user_id` bigint NOT NULL COMMENT '用户id',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '评价',
  `eval_type` int NOT NULL COMMENT '评价类型',
  `reply` tinyint(1) DEFAULT '0' COMMENT '是否回复',
  `reply_by` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '回复人',
  `reply_at` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '回复时间',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date_spu_lid` (`mid`,`report_date`) USING BTREE,
  KEY `idx_mid_report_date_user_lid` (`mid`,`report_date`,`user_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='商品评价表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_evaluation`
--

LOCK TABLES `mall_evaluation` WRITE;
/*!40000 ALTER TABLE `mall_evaluation` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_evaluation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_evaluation_detail`
--

DROP TABLE IF EXISTS `mall_evaluation_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_evaluation_detail` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `eval_lid` bigint NOT NULL COMMENT '评价lid',
  `item_lid` bigint NOT NULL COMMENT '条目lid',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '条目名称',
  `star` decimal(24,6) NOT NULL COMMENT '星级',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_eval_lid` (`mid`,`eval_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='商品评价详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_evaluation_detail`
--

LOCK TABLES `mall_evaluation_detail` WRITE;
/*!40000 ALTER TABLE `mall_evaluation_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_evaluation_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_evaluation_img`
--

DROP TABLE IF EXISTS `mall_evaluation_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_evaluation_img` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `order_lid` bigint NOT NULL COMMENT '订单编号',
  `eval_lid` bigint NOT NULL COMMENT '评价lid',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '图片地址',
  `idx` int NOT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_eval_lid` (`mid`,`eval_lid`,`idx`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='评价图片';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_evaluation_img`
--

LOCK TABLES `mall_evaluation_img` WRITE;
/*!40000 ALTER TABLE `mall_evaluation_img` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_evaluation_img` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_evaluation_item`
--

DROP TABLE IF EXISTS `mall_evaluation_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_evaluation_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '条目名称',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='商品评价条目';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_evaluation_item`
--

LOCK TABLES `mall_evaluation_item` WRITE;
/*!40000 ALTER TABLE `mall_evaluation_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_evaluation_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_evaluation_ref`
--

DROP TABLE IF EXISTS `mall_evaluation_ref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_evaluation_ref` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `order_lid` bigint NOT NULL COMMENT '订单编号',
  `order_item_lid` bigint NOT NULL COMMENT '订单物品编号',
  `spu_lid` bigint NOT NULL COMMENT 'spu产品lid',
  `eval_lid` bigint NOT NULL COMMENT '评价lid',
  `sku_lid` bigint NOT NULL COMMENT '规格lid',
  `eval_type` int NOT NULL DEFAULT '1' COMMENT '评论类型',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_spu_lid_eval_lid` (`mid`,`spu_lid`,`eval_lid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='评价关联商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_evaluation_ref`
--

LOCK TABLES `mall_evaluation_ref` WRITE;
/*!40000 ALTER TABLE `mall_evaluation_ref` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_evaluation_ref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_evaluation_reply`
--

DROP TABLE IF EXISTS `mall_evaluation_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_evaluation_reply` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `eval_lid` bigint NOT NULL COMMENT '评价lid',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '回复内容',
  `type_` int NOT NULL COMMENT '类型 1商家回复用户 2用户回复商家',
  `parent_lid` bigint DEFAULT NULL COMMENT '上一级lid',
  `idx` int NOT NULL COMMENT '顺序',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_eval_lid_idx` (`mid`,`eval_lid`,`idx`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='商家评价回复';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_evaluation_reply`
--

LOCK TABLES `mall_evaluation_reply` WRITE;
/*!40000 ALTER TABLE `mall_evaluation_reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_evaluation_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_feedback`
--

DROP TABLE IF EXISTS `mall_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_feedback` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `user_lid` bigint NOT NULL COMMENT '反馈用户lid',
  `user_name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '反馈用户名称',
  `user_phone` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '反馈用户手机号码',
  `feedback` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '反馈内容',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_report_date` (`mid`,`report_date`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='商城意见反馈';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_feedback`
--

LOCK TABLES `mall_feedback` WRITE;
/*!40000 ALTER TABLE `mall_feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order`
--

DROP TABLE IF EXISTS `mall_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `task_lid` bigint DEFAULT NULL COMMENT '付款任务lid',
  `report_date` datetime DEFAULT NULL COMMENT '营业日期',
  `state` int DEFAULT NULL COMMENT '状态',
  `freight` decimal(24,6) DEFAULT NULL COMMENT '运费',
  `total_quantity` int DEFAULT NULL COMMENT '总数量',
  `total_amount` decimal(24,6) DEFAULT NULL COMMENT '总金额',
  `pay_amount` decimal(24,6) DEFAULT NULL COMMENT '实际支付金额',
  `total_points` decimal(24,6) DEFAULT NULL COMMENT '总积分',
  `pay_points` decimal(24,6) DEFAULT NULL COMMENT '耗用积分',
  `pay_type` int DEFAULT NULL COMMENT '支付类型',
  `nickname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '昵称',
  `head_img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '头像',
  `out_refund_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退款订单号',
  `out_trade_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '支付订单号',
  `delivery_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发货人',
  `delivery_at` datetime DEFAULT NULL COMMENT '发货时间',
  `receiving_at` datetime DEFAULT NULL COMMENT '收货时间',
  `delivery_method` int DEFAULT NULL COMMENT '配送方式',
  `user_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '用户名称',
  `open_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'openId',
  `app_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'appId',
  `user_id` bigint DEFAULT NULL COMMENT '用户id',
  `user_phone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收货电话',
  `addr_lid` bigint DEFAULT NULL COMMENT '收货地址lid',
  `receiver_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '收货地址',
  `cancel_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '取消人',
  `cancel_at` datetime DEFAULT NULL COMMENT '取消时间',
  `refund_at` datetime DEFAULT NULL COMMENT '退款时间',
  `refund_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '退款人',
  `order_remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '订单备注',
  `delivery_remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发货备注',
  `tracking_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '快递单号',
  `evaluated` tinyint(1) DEFAULT '0' COMMENT '是否已评价',
  `eval_lid` bigint DEFAULT NULL COMMENT '评价lid',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `refund` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否退款',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_report_date_mid_lid` (`report_date`,`mid`,`lid`) USING BTREE,
  KEY `idx_report_date_mid_user_id` (`report_date`,`mid`,`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=940 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order`
--

LOCK TABLES `mall_order` WRITE;
/*!40000 ALTER TABLE `mall_order` DISABLE KEYS */;
INSERT INTO `mall_order` VALUES (879,1940284000182472704,1,2055212010900426754,2055212054965784578,'2026-05-15 00:00:00',6,0.000000,1,0.000000,0.000000,30.000000,30.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-15 17:01:53',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 17:31:42','2026-05-15 17:31:42','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 09:01:42',NULL,'2026-05-15 09:31:42',0,1),(880,1940284000182472704,1,2055212152823091201,2055212527584153601,'2026-05-15 00:00:00',6,0.000000,1,0.000000,0.000000,30.000000,30.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-15 17:03:45',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 17:32:16','2026-05-15 17:32:16','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 09:02:15',NULL,'2026-05-15 09:32:15',0,1),(881,1940284000182472704,1,2055213122919469058,2055213229861638145,'2026-05-15 00:00:00',6,0.000000,1,1000.000000,1000.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-15 17:06:33',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 17:36:07','2026-05-15 17:36:07','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 09:06:07',NULL,'2026-05-15 09:36:07',0,1),(882,1940284000182472704,1,2055216371722489857,2055216386083786754,'2026-05-15 00:00:00',6,0.000000,1,1000.000000,1000.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-15 17:19:05',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 17:49:02','2026-05-15 17:49:02','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 09:19:01',NULL,'2026-05-15 09:49:01',0,1),(883,1940284000182472704,1,2055226133851803649,2055226158799523842,'2026-05-15 00:00:00',6,0.000000,1,1000.000000,1000.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-15 17:57:55',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 18:27:49','2026-05-15 18:27:49','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 09:57:49',NULL,'2026-05-15 10:27:49',0,1),(884,1940284000182472704,1,2055231380133384193,NULL,'2026-05-15 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 18:48:40','2026-05-15 18:48:40','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:18:40',NULL,'2026-05-15 10:48:40',0,1),(885,1940284000182472704,1,2055232154078941185,NULL,'2026-05-15 00:00:00',6,0.000000,1,4685.050000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 18:51:45','2026-05-15 18:51:45','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:21:44',NULL,'2026-05-15 10:51:44',0,1),(886,1940284000182472704,1,2055232341719519233,NULL,'2026-05-15 00:00:00',6,0.000000,1,3685.050000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 18:52:29','2026-05-15 18:52:29','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:22:29',NULL,'2026-05-15 10:52:29',0,1),(887,1940284000182472704,1,2055232399655440385,NULL,'2026-05-15 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 18:52:43','2026-05-15 18:52:43','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:22:43',NULL,'2026-05-15 10:52:43',0,1),(888,1940284000182472704,1,2055232707798372353,NULL,'2026-05-15 00:00:00',6,0.000000,1,3685.050000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 18:53:57','2026-05-15 18:53:57','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:23:56',NULL,'2026-05-15 10:53:56',0,1),(889,1940284000182472704,1,2055232955723681793,2055233015442182146,'2026-05-15 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-15 18:25:10',NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 18:54:56','2026-05-15 18:54:56','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:24:55',NULL,'2026-05-15 10:54:55',0,1),(890,1940284000182472704,1,2055233076800655361,NULL,'2026-05-15 00:00:00',6,0.000000,1,3685.050000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 18:55:25','2026-05-15 18:55:25','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:25:24',NULL,'2026-05-15 10:55:24',0,1),(891,1940284000182472704,1,2055237257900986370,NULL,'2026-05-15 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 19:12:01','2026-05-15 19:12:01','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:42:01',NULL,'2026-05-15 11:12:01',0,1),(892,1940284000182472704,1,2055237723573587969,NULL,'2026-05-15 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 19:13:53','2026-05-15 19:13:53','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:43:52',NULL,'2026-05-15 11:13:52',0,1),(893,1940284000182472704,1,2055238168031399938,NULL,'2026-05-15 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 19:15:38','2026-05-15 19:15:38','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:45:38',NULL,'2026-05-15 11:15:38',0,1),(894,1940284000182472704,1,2055239100425179137,2055239114270576642,'2026-05-15 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-15 18:49:24',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 19:19:21','2026-05-15 19:19:21','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:49:20',NULL,'2026-05-15 11:19:20',0,1),(895,1940284000182472704,1,2055239218318675970,NULL,'2026-05-15 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 19:19:49','2026-05-15 19:19:49','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:49:48',NULL,'2026-05-15 11:19:48',0,1),(896,1940284000182472704,1,2055239415962669057,NULL,'2026-05-15 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-15 19:20:36','2026-05-15 19:20:36','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-15 10:50:35',NULL,'2026-05-15 11:20:35',0,1),(897,1940284000182472704,1,2055464062912040961,NULL,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 10:13:16','2026-05-16 10:13:16','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 01:43:15',NULL,'2026-05-16 02:13:16',0,1),(898,1940284000182472704,1,2055466812571914242,NULL,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 10:24:12','2026-05-16 10:24:12','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 01:54:11',NULL,'2026-05-16 02:24:11',0,1),(899,1940284000182472704,1,2055467367201509377,2055468392155189250,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055468392155189251','系统自动','2026-05-16 10:00:50',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 10:26:24','2026-05-16 10:26:24','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 01:56:23',NULL,'2026-05-16 02:26:23',0,1),(900,1940284000182472704,1,2055526792989904897,NULL,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.000000,100.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:22:32','2026-05-16 14:22:32','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 05:52:32',NULL,'2026-05-16 06:22:32',0,1),(901,1940284000182472704,1,2055527191595585537,2055527393123504129,'2026-05-16 00:00:00',6,0.000000,1,4685.050000,4685.050000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055527393123504130','系统自动','2026-05-16 13:55:22',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:24:07','2026-05-16 14:24:07','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 05:54:06',NULL,'2026-05-16 06:24:07',0,1),(902,1940284000182472704,1,2055530289395273730,2055530569016938497,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055530569016938498','系统自动','2026-05-16 14:07:43',NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:16:33','2026-05-16 14:16:33','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 06:06:25',NULL,'2026-05-16 06:16:32',0,1),(903,1940284000182472704,1,2055530765679464450,2055530781240332290,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,100.000000,100.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055530781240332291',NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:18:24','2026-05-16 14:18:24','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 06:08:19',NULL,'2026-05-16 06:18:24',0,1),(904,1940284000182472704,1,2055531079950274562,2055531092482854914,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,100.000000,100.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055531092482854915',NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:19:39','2026-05-16 14:19:39','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 06:09:34',NULL,'2026-05-16 06:19:38',0,1),(905,1940284000182472704,1,2055531097134338049,2055531113651507201,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055531113651507202',NULL,NULL,NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:19:43','2026-05-16 14:19:43','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 06:09:38',NULL,'2026-05-16 06:19:42',0,1),(906,1940284000182472704,1,2055531266173177858,2055531276172398594,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,100.000000,100.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055531276172398595','系统自动','2026-05-16 14:10:29',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:40:18','2026-05-16 14:40:19','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 06:10:18',NULL,'2026-05-16 06:40:18',0,1),(907,1940284000182472704,1,2055532037384048642,2055532055096594433,'2026-05-16 00:00:00',6,0.000000,2,0.020000,0.020000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055532055096594434',NULL,NULL,NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:23:28','2026-05-16 14:23:28','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 06:13:22',NULL,'2026-05-16 06:23:27',0,1),(908,1940284000182472704,1,2055532571079872514,2055532586103869441,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055532586103869442',NULL,NULL,NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:25:35','2026-05-16 14:25:35','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 06:15:29',NULL,'2026-05-16 06:25:34',0,1),(909,1940284000182472704,1,2055533644054138881,2055533656943235074,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055533656943235075',NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:29:50','2026-05-16 14:29:50','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 06:19:45',NULL,'2026-05-16 06:29:49',0,1),(910,1940284000182472704,1,2055535490047021058,NULL,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 14:57:06','2026-05-16 14:57:06','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 06:27:05',NULL,'2026-05-16 06:57:05',0,1),(911,1940284000182472704,1,2055548006922985474,2055548047079251969,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055548047079251970',NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 15:17:06','2026-05-16 15:17:06','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 07:16:49',NULL,'2026-05-16 07:17:06',0,1),(912,1940284000182472704,1,2055548563683287042,2055548581479718913,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055548581479718914','系统自动','2026-05-16 15:19:17',NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 15:49:03','2026-05-16 15:49:03','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 07:19:02',NULL,'2026-05-16 07:49:02',0,1),(913,1940284000182472704,1,2055552706523176961,2055552723413639170,'2026-05-16 00:00:00',6,0.000000,1,1000.000000,1000.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-16 15:35:34',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 16:05:30','2026-05-16 16:05:30','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 07:35:30',NULL,'2026-05-16 08:05:30',0,1),(914,1940284000182472704,1,2055552789536841729,2055552825398140929,'2026-05-16 00:00:00',6,0.000000,1,0.000000,0.000000,30.000000,30.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-16 15:35:59',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 16:05:50','2026-05-16 16:05:50','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 07:35:50',NULL,'2026-05-16 08:05:50',0,1),(915,1940284000182472704,1,2055553609959481346,2055553626585702401,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055553626585702402','系统自动','2026-05-16 15:39:24',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 16:09:06','2026-05-16 16:09:06','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 07:39:05',NULL,'2026-05-16 08:09:05',0,1),(916,1940284000182472704,1,2055554252300361729,2055554312534761473,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.010000,100.000000,100.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055554312534761474','系统自动','2026-05-16 15:42:08',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 16:11:39','2026-05-16 16:11:39','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 07:41:38',NULL,'2026-05-16 08:11:38',0,1),(917,1940284000182472704,1,2055572068101529601,NULL,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 17:22:26','2026-05-16 17:22:26','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 08:52:26',NULL,'2026-05-16 09:22:26',0,1),(918,1940284000182472704,1,2055577565319802881,2055577592410812418,'2026-05-16 00:00:00',3,0.000000,1,0.010000,0.010000,100.000000,100.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2055577592410812419','系统自动','2026-05-16 17:14:31',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 09:14:17',NULL,'2026-05-16 09:14:31',0,0),(919,1940284000182472704,1,2055578368533213186,NULL,'2026-05-16 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 17:18:29','2026-05-16 17:18:29','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 09:17:28',NULL,'2026-05-16 09:18:28',0,1),(920,1940284000182472704,1,2055580566927323137,NULL,'2026-05-16 00:00:00',6,0.000000,1,0.000000,0.000000,30.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-16 17:27:13','2026-05-16 17:27:13','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 09:26:12',NULL,'2026-05-16 09:27:12',0,1),(921,1940284000182472704,1,2055581626479816706,2055581641478647810,'2026-05-16 00:00:00',3,0.000000,1,1000.000000,1000.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-16 17:30:29',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,NULL,NULL,NULL,'2026-05-16 09:30:25',NULL,'2026-05-16 09:30:28',0,0),(929,1940284000182472704,1,2056492650554593282,2056492674365657090,'2026-05-19 00:00:00',3,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-19 05:50:36',NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,NULL,NULL,NULL,'2026-05-18 21:50:30',NULL,'2026-05-18 21:50:36',0,0),(930,1940284000182472704,1,2056498524211777538,NULL,'2026-05-19 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,'订单未支付，系统自动处理','2026-05-19 06:14:51','2026-05-19 06:14:51','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-18 22:13:50',NULL,'2026-05-18 22:14:50',0,1),(931,1940284000182472704,1,2056505047927361538,2056505062947164162,'2026-05-19 00:00:00',3,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-19 06:39:50',NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,NULL,NULL,NULL,'2026-05-18 22:39:46',NULL,'2026-05-18 22:39:49',0,0),(932,1940284000182472704,1,2057293860241936386,NULL,'2026-05-21 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-21 10:55:14','2026-05-21 10:55:14','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-21 02:54:13',NULL,'2026-05-21 02:55:13',0,1),(933,1940284000182472704,1,2057295737293639682,2057295764841828353,'2026-05-21 00:00:00',3,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-21 11:01:48',NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,NULL,NULL,NULL,'2026-05-21 03:01:41',NULL,'2026-05-21 03:01:47',0,0),(934,1940284000182472704,1,2057295871922409473,2057295903492935682,'2026-05-21 00:00:00',3,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,'系统自动发货','2026-05-21 11:02:21',NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,NULL,NULL,NULL,'2026-05-21 03:02:13',NULL,'2026-05-21 03:02:20',0,0),(935,1940284000182472704,1,2057296069469933569,NULL,'2026-05-21 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,'订单未支付，系统自动处理','2026-05-21 11:04:00','2026-05-21 11:04:00','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-21 03:03:00',NULL,'2026-05-21 03:04:00',0,1),(936,1940284000182472704,1,2057296070170382337,NULL,'2026-05-21 00:00:00',6,0.000000,1,0.010000,0.000000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,NULL,NULL,NULL,NULL,2,'微信会员','oSJ6y7ahaaRQFn9H49OblDm0qBPY','wxa1617c32d294e518',2047945239853142017,'18923865943',NULL,NULL,'订单未支付，系统自动处理','2026-05-21 11:04:01','2026-05-21 11:04:01','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-21 03:03:00',NULL,'2026-05-21 03:04:00',0,1),(937,1940284000182472704,1,2057339895842480129,2057339905531322370,'2026-05-21 00:00:00',3,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2057339905531322371','系统自动','2026-05-21 13:57:28',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,NULL,NULL,NULL,'2026-05-21 05:57:09',NULL,'2026-05-21 05:57:28',0,0),(938,1940284000182472704,1,2057341082809540609,2057341132507848706,'2026-05-21 00:00:00',6,0.000000,1,0.010000,0.010000,0.000000,0.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2057341132507848707',NULL,NULL,NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,'订单未支付，系统自动处理','2026-05-21 14:02:52','2026-05-21 14:02:52','订单未支付，系统自动处理','',NULL,NULL,0,NULL,NULL,NULL,'2026-05-21 06:01:52',NULL,'2026-05-21 06:02:52',0,1),(939,1940284000182472704,1,2057348772183158786,2057348818408583170,'2026-05-21 00:00:00',3,0.000000,1,0.010000,0.010000,100.000000,100.000000,1,'微信会员','https://chain-pictures-01-1251303505.cos.ap-guangzhou.myqcloud.com/lemon/pub/pic/anonymous_user.png',NULL,'2057348818408583171','系统自动','2026-05-21 14:33:19',NULL,2,'微信会员','oSJ6y7U6K1fl6MKnI05-09R1xzQs','wxa1617c32d294e518',2047944929193627650,'19198074442',NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,NULL,NULL,NULL,'2026-05-21 14:32:25',NULL,'2026-05-21 14:33:19',0,0);
/*!40000 ALTER TABLE `mall_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order_item`
--

DROP TABLE IF EXISTS `mall_order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime DEFAULT NULL COMMENT '营业日期',
  `state` int NOT NULL COMMENT '状态',
  `order_id` bigint NOT NULL COMMENT '订单号',
  `sku_standard` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'sku规格',
  `sku_id` bigint NOT NULL COMMENT 'sku',
  `spu_id` bigint NOT NULL COMMENT '产品id',
  `spu_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品名称',
  `spu_imge` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品图片',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '单位',
  `buy_num` int DEFAULT NULL COMMENT '购买数量',
  `total_amount` decimal(24,6) DEFAULT NULL COMMENT '总金额',
  `total_points` decimal(24,6) DEFAULT NULL COMMENT '总积分',
  `price_fee` int DEFAULT NULL COMMENT '售价，整数方式保存',
  `price_scale` int DEFAULT NULL COMMENT '售价，金额对应的小数位数',
  `market_price_fee` int DEFAULT NULL COMMENT '市场价，整数方式保存',
  `market_price_scale` int DEFAULT NULL COMMENT '市场价，金额对应的小数位数',
  `points_fee` int DEFAULT NULL COMMENT '所需积分，整数方式保存',
  `points_scale` int DEFAULT NULL COMMENT '所需积分，金额对应的小数位数',
  `after_sale_lid` bigint DEFAULT NULL COMMENT '售后lid',
  `type` int DEFAULT NULL COMMENT '商品类型',
  `type_lid` bigint DEFAULT NULL COMMENT '其他类型商品的lid',
  `type_num` decimal(24,6) DEFAULT NULL COMMENT '其他类型商品的数量',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  `user_id` bigint NOT NULL DEFAULT '-1' COMMENT '用户lid',
  PRIMARY KEY (`pid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_lid` (`mid`,`order_id`) USING BTREE,
  KEY `idx_mid_user_id_sku_lid` (`mid`,`user_id`,`sku_id`) USING BTREE,
  KEY `idx_mid_date_user_sku` (`mid`,`report_date`,`user_id`,`sku_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=953 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='订单明细';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order_item`
--

LOCK TABLES `mall_order_item` WRITE;
/*!40000 ALTER TABLE `mall_order_item` DISABLE KEYS */;
INSERT INTO `mall_order_item` VALUES (891,1940284000182472704,1,2055212010925592578,'2026-05-15 00:00:00',6,2055212010900426754,NULL,2055211654657216513,2055211654627856386,'雪碧','','瓶',1,0.000000,30.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 09:01:42',NULL,'2026-05-15 09:31:42',0,2047944929193627650),(892,1940284000182472704,1,2055212152827285505,'2026-05-15 00:00:00',6,2055212152823091201,NULL,2055211654657216513,2055211654627856386,'雪碧','','瓶',1,0.000000,30.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 09:02:15',NULL,'2026-05-15 09:32:15',0,2047944929193627650),(893,1940284000182472704,1,2055213122923663361,'2026-05-15 00:00:00',6,2055213122919469058,NULL,2055212974030065665,2055212973975539713,'可乐','','瓶',1,1000.000000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 09:06:07',NULL,'2026-05-15 09:36:07',0,2047944929193627650),(894,1940284000182472704,1,2055216371726684161,'2026-05-15 00:00:00',6,2055216371722489857,NULL,2055212974030065665,2055212973975539713,'可乐','','瓶',1,1000.000000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 09:19:01',NULL,'2026-05-15 09:49:01',0,2047944929193627650),(895,1940284000182472704,1,2055226133860192257,'2026-05-15 00:00:00',6,2055226133851803649,NULL,2055212974030065665,2055212973975539713,'可乐','','瓶',1,1000.000000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 09:57:49',NULL,'2026-05-15 10:27:49',0,2047944929193627650),(896,1940284000182472704,1,2055231380137578498,'2026-05-15 00:00:00',6,2055231380133384193,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:18:40',NULL,'2026-05-15 10:48:40',0,2047944929193627650),(897,1940284000182472704,1,2055232154083135489,'2026-05-15 00:00:00',6,2055232154078941185,NULL,2055231901971910658,2055231901967716353,'天价雪碧','','瓶',1,4685.050000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:21:44',NULL,'2026-05-15 10:51:44',0,2047944929193627650),(898,1940284000182472704,1,2055232341723713537,'2026-05-15 00:00:00',6,2055232341719519233,NULL,2055231901971910658,2055231901967716353,'天价雪碧','','瓶',1,3685.050000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:22:29',NULL,'2026-05-15 10:52:29',0,2047944929193627650),(899,1940284000182472704,1,2055232399659634690,'2026-05-15 00:00:00',6,2055232399655440385,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:22:43',NULL,'2026-05-15 10:52:43',0,2047945239853142017),(900,1940284000182472704,1,2055232707802566658,'2026-05-15 00:00:00',6,2055232707798372353,NULL,2055231901971910658,2055231901967716353,'天价雪碧','','瓶',1,3685.050000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:23:56',NULL,'2026-05-15 10:53:56',0,2047944929193627650),(901,1940284000182472704,1,2055232955727876097,'2026-05-15 00:00:00',6,2055232955723681793,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:24:55',NULL,'2026-05-15 10:54:55',0,2047945239853142017),(902,1940284000182472704,1,2055233076804849666,'2026-05-15 00:00:00',6,2055233076800655361,NULL,2055231901971910658,2055231901967716353,'天价雪碧','','瓶',1,3685.050000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:25:24',NULL,'2026-05-15 10:55:24',0,2047944929193627650),(903,1940284000182472704,1,2055237257905180673,'2026-05-15 00:00:00',6,2055237257900986370,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:42:01',NULL,'2026-05-15 11:12:01',0,2047944929193627650),(904,1940284000182472704,1,2055237723577782273,'2026-05-15 00:00:00',6,2055237723573587969,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:43:52',NULL,'2026-05-15 11:13:52',0,2047944929193627650),(905,1940284000182472704,1,2055238168035594241,'2026-05-15 00:00:00',6,2055238168031399938,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:45:38',NULL,'2026-05-15 11:15:38',0,2047944929193627650),(906,1940284000182472704,1,2055239100429373442,'2026-05-15 00:00:00',6,2055239100425179137,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:49:20',NULL,'2026-05-15 11:19:20',0,2047944929193627650),(907,1940284000182472704,1,2055239218322870273,'2026-05-15 00:00:00',6,2055239218318675970,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:49:48',NULL,'2026-05-15 11:19:48',0,2047944929193627650),(908,1940284000182472704,1,2055239415966863361,'2026-05-15 00:00:00',6,2055239415962669057,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-15 10:50:35',NULL,'2026-05-15 11:20:35',0,2047944929193627650),(909,1940284000182472704,1,2055464062941401090,'2026-05-16 00:00:00',6,2055464062912040961,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 01:43:15',NULL,'2026-05-16 02:13:16',0,2047944929193627650),(910,1940284000182472704,1,2055466812576108546,'2026-05-16 00:00:00',6,2055466812571914242,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 01:54:11',NULL,'2026-05-16 02:24:11',0,2047944929193627650),(911,1940284000182472704,1,2055467367209897985,'2026-05-16 00:00:00',6,2055467367201509377,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 01:56:23',NULL,'2026-05-16 02:26:23',0,2047944929193627650),(912,1940284000182472704,1,2055526793019265026,'2026-05-16 00:00:00',6,2055526792989904897,NULL,2055231086062342146,2055231086058147842,'一分钱雪碧（加100积分）','','瓶',1,0.010000,100.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 05:52:32',NULL,'2026-05-16 06:22:32',0,2047944929193627650),(913,1940284000182472704,1,2055527191599779842,'2026-05-16 00:00:00',6,2055527191595585537,NULL,2055231901971910658,2055231901967716353,'天价雪碧','','瓶',1,4685.050000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 05:54:06',NULL,'2026-05-16 06:24:07',0,2047944929193627650),(914,1940284000182472704,1,2055530289399468034,'2026-05-16 00:00:00',6,2055530289395273730,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 06:06:25',NULL,'2026-05-16 06:16:32',0,2047945239853142017),(915,1940284000182472704,1,2055530765683658754,'2026-05-16 00:00:00',6,2055530765679464450,NULL,2055231086062342146,2055231086058147842,'一分钱雪碧（加100积分）','','瓶',1,0.010000,100.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 06:08:19',NULL,'2026-05-16 06:18:24',0,2047944929193627650),(916,1940284000182472704,1,2055531079954468866,'2026-05-16 00:00:00',6,2055531079950274562,NULL,2055231086062342146,2055231086058147842,'一分钱雪碧（加100积分）','','瓶',1,0.010000,100.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 06:09:34',NULL,'2026-05-16 06:19:38',0,2047944929193627650),(917,1940284000182472704,1,2055531097138532353,'2026-05-16 00:00:00',6,2055531097134338049,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 06:09:38',NULL,'2026-05-16 06:19:42',0,2047945239853142017),(918,1940284000182472704,1,2055531266177372161,'2026-05-16 00:00:00',6,2055531266173177858,NULL,2055231086062342146,2055231086058147842,'一分钱雪碧（加100积分）','','瓶',1,0.010000,100.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 06:10:18',NULL,'2026-05-16 06:40:18',0,2047944929193627650),(919,1940284000182472704,1,2055532037388242946,'2026-05-16 00:00:00',6,2055532037384048642,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',2,0.020000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 06:13:22',NULL,'2026-05-16 06:23:27',0,2047945239853142017),(920,1940284000182472704,1,2055532571084066818,'2026-05-16 00:00:00',6,2055532571079872514,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 06:15:29',NULL,'2026-05-16 06:25:34',0,2047945239853142017),(921,1940284000182472704,1,2055533644058333185,'2026-05-16 00:00:00',6,2055533644054138881,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 06:19:45',NULL,'2026-05-16 06:29:49',0,2047944929193627650),(922,1940284000182472704,1,2055535490047021059,'2026-05-16 00:00:00',6,2055535490047021058,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 06:27:05',NULL,'2026-05-16 06:57:05',0,2047944929193627650),(923,1940284000182472704,1,2055548007057203202,'2026-05-16 00:00:00',6,2055548006922985474,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 07:16:49',NULL,'2026-05-16 07:17:06',0,2047944929193627650),(924,1940284000182472704,1,2055548563691675650,'2026-05-16 00:00:00',6,2055548563683287042,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 07:19:02',NULL,'2026-05-16 07:49:02',0,2047945239853142017),(925,1940284000182472704,1,2055552706527371266,'2026-05-16 00:00:00',6,2055552706523176961,NULL,2055212974030065665,2055212973975539713,'可乐','','瓶',1,1000.000000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 07:35:30',NULL,'2026-05-16 08:05:30',0,2047944929193627650),(926,1940284000182472704,1,2055552789541036033,'2026-05-16 00:00:00',6,2055552789536841729,NULL,2055211654657216513,2055211654627856386,'雪碧','','瓶',1,0.000000,30.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 07:35:50',NULL,'2026-05-16 08:05:50',0,2047944929193627650),(927,1940284000182472704,1,2055553609963675649,'2026-05-16 00:00:00',6,2055553609959481346,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 07:39:05',NULL,'2026-05-16 08:09:05',0,2047944929193627650),(928,1940284000182472704,1,2055554252308750337,'2026-05-16 00:00:00',6,2055554252300361729,NULL,2055231086062342146,2055231086058147842,'一分钱雪碧（加100积分）','','瓶',1,0.010000,100.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 07:41:38',NULL,'2026-05-16 08:11:38',0,2047944929193627650),(929,1940284000182472704,1,2055572068105723906,'2026-05-16 00:00:00',6,2055572068101529601,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 08:52:26',NULL,'2026-05-16 09:22:26',0,2047944929193627650),(930,1940284000182472704,1,2055577565412077569,'2026-05-16 00:00:00',3,2055577565319802881,NULL,2055231086062342146,2055231086058147842,'一分钱雪碧（加100积分）','','瓶',1,0.010000,100.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 09:14:17',NULL,'2026-05-16 09:14:31',0,2047944929193627650),(931,1940284000182472704,1,2055578368537407490,'2026-05-16 00:00:00',6,2055578368533213186,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 09:17:28',NULL,'2026-05-16 09:18:28',0,2047944929193627650),(932,1940284000182472704,1,2055580566931517442,'2026-05-16 00:00:00',6,2055580566927323137,NULL,2055211654657216513,2055211654627856386,'雪碧','','瓶',1,0.000000,30.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 09:26:12',NULL,'2026-05-16 09:27:12',0,2047944929193627650),(933,1940284000182472704,1,2055581626484011010,'2026-05-16 00:00:00',3,2055581626479816706,NULL,2055212974030065665,2055212973975539713,'可乐','','瓶',1,1000.000000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-16 09:30:25',NULL,'2026-05-16 09:30:28',0,2047944929193627650),(942,1940284000182472704,1,2056492650583953410,'2026-05-19 00:00:00',3,2056492650554593282,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-18 21:50:30',NULL,'2026-05-18 21:50:36',0,2047945239853142017),(943,1940284000182472704,1,2056498524220166146,'2026-05-19 00:00:00',6,2056498524211777538,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-18 22:13:50',NULL,'2026-05-18 22:14:50',0,2047945239853142017),(944,1940284000182472704,1,2056505047935750146,'2026-05-19 00:00:00',3,2056505047927361538,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-18 22:39:46',NULL,'2026-05-18 22:39:49',0,2047945239853142017),(945,1940284000182472704,1,2057293860267102209,'2026-05-21 00:00:00',6,2057293860241936386,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-21 02:54:13',NULL,'2026-05-21 02:55:13',0,2047944929193627650),(946,1940284000182472704,1,2057295737297833986,'2026-05-21 00:00:00',3,2057295737293639682,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-21 03:01:41',NULL,'2026-05-21 03:01:47',0,2047945239853142017),(947,1940284000182472704,1,2057295871922409474,'2026-05-21 00:00:00',3,2057295871922409473,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-21 03:02:13',NULL,'2026-05-21 03:02:20',0,2047945239853142017),(948,1940284000182472704,1,2057296069474127873,'2026-05-21 00:00:00',6,2057296069469933569,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-21 03:03:00',NULL,'2026-05-21 03:04:00',0,2047945239853142017),(949,1940284000182472704,1,2057296070174576642,'2026-05-21 00:00:00',6,2057296070170382337,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-21 03:03:00',NULL,'2026-05-21 03:04:00',0,2047945239853142017),(950,1940284000182472704,1,2057339895871840257,'2026-05-21 00:00:00',3,2057339895842480129,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-21 05:57:09',NULL,'2026-05-21 05:57:28',0,2047944929193627650),(951,1940284000182472704,1,2057341082813734913,'2026-05-21 00:00:00',6,2057341082809540609,NULL,2055230835414929410,2055230835406540802,'一分钱雪碧','','瓶',1,0.010000,0.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-21 06:01:52',NULL,'2026-05-21 06:02:52',0,2047944929193627650),(952,1940284000182472704,1,2057348772208324610,'2026-05-21 00:00:00',3,2057348772183158786,NULL,2055231086062342146,2055231086058147842,'一分钱雪碧（加100积分）','','瓶',1,0.010000,100.000000,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,'2026-05-21 14:32:25',NULL,'2026-05-21 14:33:19',0,2047944929193627650);
/*!40000 ALTER TABLE `mall_order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_order_task`
--

DROP TABLE IF EXISTS `mall_order_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_order_task` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime NOT NULL COMMENT '营业日期',
  `out_trans_no` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '支付订单号',
  `points` decimal(24,6) NOT NULL COMMENT '积分',
  `order_id` bigint NOT NULL COMMENT '订单lid',
  `deal_state` int NOT NULL COMMENT '处理状态',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_id` (`mid`,`order_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=784 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='订单处理记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_order_task`
--

LOCK TABLES `mall_order_task` WRITE;
/*!40000 ALTER TABLE `mall_order_task` DISABLE KEYS */;
INSERT INTO `mall_order_task` VALUES (748,1940284000182472704,1,2055212054965784578,'2026-05-15 00:00:00',NULL,30.000000,2055212010900426754,3,NULL,NULL,'2026-05-15 09:01:52',NULL,'2026-05-15 09:31:42',0),(749,1940284000182472704,1,2055212527584153601,'2026-05-15 00:00:00',NULL,30.000000,2055212152823091201,3,NULL,NULL,'2026-05-15 09:03:45',NULL,'2026-05-15 09:32:15',0),(750,1940284000182472704,1,2055213229861638145,'2026-05-15 00:00:00',NULL,0.000000,2055213122919469058,3,NULL,NULL,'2026-05-15 09:06:32',NULL,'2026-05-15 09:36:07',0),(751,1940284000182472704,1,2055216386083786754,'2026-05-15 00:00:00',NULL,0.000000,2055216371722489857,3,NULL,NULL,'2026-05-15 09:19:05',NULL,'2026-05-15 09:49:01',0),(752,1940284000182472704,1,2055226158799523842,'2026-05-15 00:00:00',NULL,0.000000,2055226133851803649,3,NULL,NULL,'2026-05-15 09:57:55',NULL,'2026-05-15 10:27:49',0),(753,1940284000182472704,1,2055233015442182146,'2026-05-15 00:00:00',NULL,0.000000,2055232955723681793,3,NULL,NULL,'2026-05-15 10:25:09',NULL,'2026-05-15 10:54:55',0),(754,1940284000182472704,1,2055239114270576642,'2026-05-15 00:00:00',NULL,0.000000,2055239100425179137,3,NULL,NULL,'2026-05-15 10:49:23',NULL,'2026-05-15 11:19:20',0),(755,1940284000182472704,1,2055468392155189250,'2026-05-16 00:00:00','2055468392155189251',0.000000,2055467367201509377,2,NULL,NULL,'2026-05-16 02:00:29',NULL,'2026-05-16 02:00:49',0),(756,1940284000182472704,1,2055527393123504129,'2026-05-16 00:00:00','2055527393123504130',0.000000,2055527191595585537,2,NULL,NULL,'2026-05-16 05:54:56',NULL,'2026-05-16 05:55:22',0),(757,1940284000182472704,1,2055530305790808066,'2026-05-16 00:00:00','2055530305790808067',0.000000,2055530289395273730,3,NULL,NULL,'2026-05-16 06:06:32',NULL,'2026-05-16 06:06:43',0),(758,1940284000182472704,1,2055530569016938497,'2026-05-16 00:00:00','2055530569016938498',0.000000,2055530289395273730,2,NULL,NULL,'2026-05-16 06:07:32',NULL,'2026-05-16 06:07:43',0),(759,1940284000182472704,1,2055530781240332290,'2026-05-16 00:00:00','2055530781240332291',100.000000,2055530765679464450,3,NULL,NULL,'2026-05-16 06:08:23',NULL,'2026-05-16 06:18:24',0),(760,1940284000182472704,1,2055531092482854914,'2026-05-16 00:00:00','2055531092482854915',100.000000,2055531079950274562,3,NULL,NULL,'2026-05-16 06:09:38',NULL,'2026-05-16 06:09:46',0),(761,1940284000182472704,1,2055531113651507201,'2026-05-16 00:00:00','2055531113651507202',0.000000,2055531097134338049,3,NULL,NULL,'2026-05-16 06:09:42',NULL,'2026-05-16 06:09:47',0),(762,1940284000182472704,1,2055531276172398594,'2026-05-16 00:00:00','2055531276172398595',100.000000,2055531266173177858,2,NULL,NULL,'2026-05-16 06:10:21',NULL,'2026-05-16 06:10:28',0),(763,1940284000182472704,1,2055532055096594433,'2026-05-16 00:00:00','2055532055096594434',0.000000,2055532037384048642,3,NULL,NULL,'2026-05-16 06:13:27',NULL,'2026-05-16 06:13:32',0),(764,1940284000182472704,1,2055532586103869441,'2026-05-16 00:00:00','2055532586103869442',0.000000,2055532571079872514,3,NULL,NULL,'2026-05-16 06:15:34',NULL,'2026-05-16 06:15:38',0),(765,1940284000182472704,1,2055533656943235074,'2026-05-16 00:00:00','2055533656943235075',0.000000,2055533644054138881,3,NULL,NULL,'2026-05-16 06:19:48',NULL,'2026-05-16 06:20:05',0),(766,1940284000182472704,1,2055548030742437890,'2026-05-16 00:00:00','2055548030742437891',0.000000,2055548006922985474,3,NULL,NULL,'2026-05-16 07:16:59',NULL,'2026-05-16 07:17:06',0),(767,1940284000182472704,1,2055548047079251969,'2026-05-16 00:00:00','2055548047079251970',0.000000,2055548006922985474,3,NULL,NULL,'2026-05-16 07:16:59',NULL,'2026-05-16 07:17:06',0),(768,1940284000182472704,1,2055548581479718913,'2026-05-16 00:00:00','2055548581479718914',0.000000,2055548563683287042,2,NULL,NULL,'2026-05-16 07:19:07',NULL,'2026-05-16 07:19:16',0),(769,1940284000182472704,1,2055552723413639170,'2026-05-16 00:00:00',NULL,0.000000,2055552706523176961,3,NULL,NULL,'2026-05-16 07:35:34',NULL,'2026-05-16 08:05:30',0),(770,1940284000182472704,1,2055552825398140929,'2026-05-16 00:00:00',NULL,30.000000,2055552789536841729,3,NULL,NULL,'2026-05-16 07:35:58',NULL,'2026-05-16 08:05:50',0),(771,1940284000182472704,1,2055553626585702401,'2026-05-16 00:00:00','2055553626585702402',0.000000,2055553609959481346,2,NULL,NULL,'2026-05-16 07:39:12',NULL,'2026-05-16 07:39:24',0),(772,1940284000182472704,1,2055554312534761473,'2026-05-16 00:00:00','2055554312534761474',100.000000,2055554252300361729,2,NULL,NULL,'2026-05-16 07:41:54',NULL,'2026-05-16 07:42:08',0),(773,1940284000182472704,1,2055577592410812418,'2026-05-16 00:00:00','2055577592410812419',100.000000,2055577565319802881,2,NULL,NULL,'2026-05-16 09:14:24',NULL,'2026-05-16 09:14:31',0),(774,1940284000182472704,1,2055581641478647810,'2026-05-16 00:00:00',NULL,0.000000,2055581626479816706,1,NULL,NULL,'2026-05-16 09:30:28',NULL,NULL,0),(775,1940284000182472704,1,2056492674365657090,'2026-05-19 00:00:00',NULL,0.000000,2056492650554593282,1,NULL,NULL,'2026-05-18 21:50:36',NULL,NULL,0),(776,1940284000182472704,1,2056505062947164162,'2026-05-19 00:00:00',NULL,0.000000,2056505047927361538,1,NULL,NULL,'2026-05-18 22:39:49',NULL,NULL,0),(777,1940284000182472704,1,2057295764841828353,'2026-05-21 00:00:00',NULL,0.000000,2057295737293639682,1,NULL,NULL,'2026-05-21 03:01:47',NULL,NULL,0),(778,1940284000182472704,1,2057295903492935682,'2026-05-21 00:00:00',NULL,0.000000,2057295871922409473,1,NULL,NULL,'2026-05-21 03:02:20',NULL,NULL,0),(779,1940284000182472704,1,2057339905531322370,'2026-05-21 00:00:00','2057339905531322371',0.000000,2057339895842480129,2,NULL,NULL,'2026-05-21 05:57:15',NULL,'2026-05-21 05:57:28',0),(780,1940284000182472704,1,2057341120910598146,'2026-05-21 00:00:00','2057341120910598147',0.000000,2057341082809540609,3,NULL,NULL,'2026-05-21 06:02:04',NULL,'2026-05-21 06:02:09',0),(781,1940284000182472704,1,2057341132507848706,'2026-05-21 00:00:00','2057341132507848707',0.000000,2057341082809540609,3,NULL,NULL,'2026-05-21 06:02:04',NULL,'2026-05-21 06:02:12',0),(782,1940284000182472704,1,2057348802197598209,'2026-05-21 00:00:00','2057348802197598210',100.000000,2057348772183158786,2,NULL,NULL,'2026-05-21 14:32:36',NULL,'2026-05-21 14:33:19',0),(783,1940284000182472704,1,2057348818408583170,'2026-05-21 00:00:00','2057348818408583171',100.000000,2057348772183158786,3,NULL,NULL,'2026-05-21 14:32:37',NULL,'2026-05-21 14:32:49',0);
/*!40000 ALTER TABLE `mall_order_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_pay_item`
--

DROP TABLE IF EXISTS `mall_pay_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_pay_item` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `report_date` datetime DEFAULT NULL COMMENT '营业日期',
  `amount` decimal(24,6) NOT NULL COMMENT '支付金额',
  `give_amount` decimal(24,6) NOT NULL COMMENT '赠送金额',
  `refund_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '已退款金额',
  `refund_give_amount` decimal(24,6) NOT NULL DEFAULT '0.000000' COMMENT '已退款赠送金额',
  `order_lid` bigint NOT NULL COMMENT '订单lid',
  `task_lid` bigint NOT NULL COMMENT '付款任务lid',
  `card_task_lid` bigint DEFAULT NULL COMMENT '会员卡扣款lid',
  `type_` int NOT NULL COMMENT '支付方式',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_order_lid_task_lid` (`mid`,`order_lid`,`task_lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1539 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='订单支付记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_pay_item`
--

LOCK TABLES `mall_pay_item` WRITE;
/*!40000 ALTER TABLE `mall_pay_item` DISABLE KEYS */;
INSERT INTO `mall_pay_item` VALUES (1492,1940284000182472704,1,5795208240612992069,'2026-05-15 00:00:00',0.000000,0.000000,0.000000,0.000000,2055212010900426754,2055212054965784578,NULL,3,NULL,NULL,'2026-05-15 09:01:52',NULL,NULL,0),(1493,1940284000182472704,1,5795208240612993093,'2026-05-15 00:00:00',30.000000,0.000000,30.000000,0.000000,2055212010900426754,2055212054965784578,NULL,5,NULL,NULL,'2026-05-15 09:01:52',NULL,'2026-05-15 09:31:42',0),(1494,1940284000182472704,1,5795208240728379461,'2026-05-15 00:00:00',0.000000,0.000000,0.000000,0.000000,2055212152823091201,2055212527584153601,NULL,3,NULL,NULL,'2026-05-15 09:03:45',NULL,NULL,0),(1495,1940284000182472704,1,5795208240728379462,'2026-05-15 00:00:00',30.000000,0.000000,30.000000,0.000000,2055212152823091201,2055212527584153601,NULL,5,NULL,NULL,'2026-05-15 09:03:45',NULL,'2026-05-15 09:32:15',0),(1496,1940284000182472704,1,5795208240899832901,'2026-05-15 00:00:00',1000.000000,0.000000,1000.000000,0.000000,2055213122919469058,2055213229861638145,2055213230082756610,3,NULL,NULL,'2026-05-15 09:06:32',NULL,'2026-05-15 09:36:07',0),(1497,1940284000182472704,1,5795208241670394949,'2026-05-15 00:00:00',1000.000000,0.000000,1000.000000,0.000000,2055216371722489857,2055216386083786754,2055216386166493186,3,NULL,NULL,'2026-05-15 09:19:05',NULL,'2026-05-15 09:49:01',0),(1498,1940284000182472704,1,5795208244056311877,'2026-05-15 00:00:00',1000.000000,0.000000,1000.000000,0.000000,2055226133851803649,2055226158799523842,2055226158831898625,3,NULL,NULL,'2026-05-15 09:57:55',NULL,'2026-05-15 10:27:49',0),(1499,1940284000182472704,1,5795208245730296901,'2026-05-15 00:00:00',0.010000,0.000000,0.010000,0.000000,2055232955723681793,2055233015442182146,2055233015499722753,3,NULL,NULL,'2026-05-15 10:25:09',NULL,'2026-05-15 10:54:55',0),(1500,1940284000182472704,1,5795208247219269701,'2026-05-15 00:00:00',0.010000,0.000000,0.010000,0.000000,2055239100425179137,2055239114270576642,2055239114323922946,3,NULL,NULL,'2026-05-15 10:49:24',NULL,'2026-05-15 11:19:20',0),(1501,1940284000182472704,1,5795489778172024901,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055467367201509377,2055468392155189250,NULL,1,NULL,NULL,'2026-05-16 02:00:29',NULL,NULL,0),(1502,1940284000182472704,1,5795489792576559173,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055527191595585537,2055527393123504129,NULL,1,NULL,NULL,'2026-05-16 05:54:56',NULL,NULL,0),(1503,1940284000182472704,1,5795489792576559174,'2026-05-16 00:00:00',4685.040000,1410.000000,0.000000,0.000000,2055527191595585537,2055527393123504129,2055527400091029506,3,NULL,NULL,'2026-05-16 05:54:56',NULL,NULL,0),(1504,1940284000182472704,1,5795489793287658565,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055530289395273730,2055530305790808066,NULL,1,NULL,NULL,'2026-05-16 06:06:32',NULL,NULL,1),(1505,1940284000182472704,1,5795489793351923781,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055530289395273730,2055530569016938497,NULL,1,NULL,NULL,'2026-05-16 06:07:32',NULL,NULL,0),(1506,1940284000182472704,1,5795489793403735109,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055530765679464450,2055530781240332290,NULL,1,NULL,NULL,'2026-05-16 06:08:23',NULL,NULL,0),(1507,1940284000182472704,1,5795489793403735110,'2026-05-16 00:00:00',100.000000,0.000000,100.000000,0.000000,2055530765679464450,2055530781240332290,NULL,5,NULL,NULL,'2026-05-16 06:08:23',NULL,'2026-05-16 06:18:24',0),(1508,1940284000182472704,1,5795489793479723077,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055531079950274562,2055531092482854914,NULL,1,NULL,NULL,'2026-05-16 06:09:38',NULL,NULL,1),(1509,1940284000182472704,1,5795489793479723078,'2026-05-16 00:00:00',100.000000,0.000000,0.000000,0.000000,2055531079950274562,2055531092482854914,NULL,5,NULL,NULL,'2026-05-16 06:09:38',NULL,NULL,1),(1510,1940284000182472704,1,5795489793484890181,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055531097134338049,2055531113651507201,NULL,1,NULL,NULL,'2026-05-16 06:09:42',NULL,NULL,1),(1511,1940284000182472704,1,5795489793524568133,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055531266173177858,2055531276172398594,NULL,1,NULL,NULL,'2026-05-16 06:10:21',NULL,NULL,0),(1512,1940284000182472704,1,5795489793524568134,'2026-05-16 00:00:00',100.000000,0.000000,0.000000,0.000000,2055531266173177858,2055531276172398594,NULL,5,NULL,NULL,'2026-05-16 06:10:21',NULL,NULL,0),(1513,1940284000182472704,1,5795489793714735173,'2026-05-16 00:00:00',0.020000,0.000000,0.000000,0.000000,2055532037384048642,2055532055096594433,NULL,1,NULL,NULL,'2026-05-16 06:13:27',NULL,NULL,1),(1514,1940284000182472704,1,5795489793844375621,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055532571079872514,2055532586103869441,NULL,1,NULL,NULL,'2026-05-16 06:15:34',NULL,NULL,1),(1515,1940284000182472704,1,5795489794105812037,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055533644054138881,2055533656943235074,NULL,1,NULL,NULL,'2026-05-16 06:19:48',NULL,NULL,1),(1516,1940284000182472704,1,5795489797615039621,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055548006922985474,2055548030742437890,NULL,1,NULL,NULL,'2026-05-16 07:16:59',NULL,NULL,1),(1517,1940284000182472704,1,5795489797619028101,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055548006922985474,2055548047079251969,NULL,1,NULL,NULL,'2026-05-16 07:16:59',NULL,NULL,0),(1518,1940284000182472704,1,5795489797749497989,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055548563683287042,2055548581479718913,NULL,1,NULL,NULL,'2026-05-16 07:19:07',NULL,NULL,0),(1519,1940284000182472704,1,5795489798760712325,'2026-05-16 00:00:00',1000.000000,0.000000,1000.000000,0.000000,2055552706523176961,2055552723413639170,2055552723576037378,3,NULL,NULL,'2026-05-16 07:35:34',NULL,'2026-05-16 08:05:30',0),(1520,1940284000182472704,1,5795489798785610885,'2026-05-16 00:00:00',0.000000,0.000000,0.000000,0.000000,2055552789536841729,2055552825398140929,NULL,3,NULL,NULL,'2026-05-16 07:35:58',NULL,NULL,0),(1521,1940284000182472704,1,5795489798785610886,'2026-05-16 00:00:00',30.000000,0.000000,30.000000,0.000000,2055552789536841729,2055552825398140929,NULL,5,NULL,NULL,'2026-05-16 07:35:58',NULL,'2026-05-16 08:05:50',0),(1522,1940284000182472704,1,5795489798981213317,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055553609959481346,2055553626585702401,NULL,1,NULL,NULL,'2026-05-16 07:39:12',NULL,NULL,0),(1523,1940284000182472704,1,5795489799148681349,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055554252300361729,2055554312534761473,NULL,1,NULL,NULL,'2026-05-16 07:41:54',NULL,NULL,0),(1524,1940284000182472704,1,5795489799148681350,'2026-05-16 00:00:00',100.000000,0.000000,0.000000,0.000000,2055554252300361729,2055554312534761473,NULL,5,NULL,NULL,'2026-05-16 07:41:54',NULL,NULL,0),(1525,1940284000182472704,1,5795489804832242885,'2026-05-16 00:00:00',0.010000,0.000000,0.000000,0.000000,2055577565319802881,2055577592410812418,NULL,1,NULL,NULL,'2026-05-16 09:14:24',NULL,NULL,0),(1526,1940284000182472704,1,5795489804832243909,'2026-05-16 00:00:00',100.000000,0.000000,0.000000,0.000000,2055577565319802881,2055577592410812418,NULL,5,NULL,NULL,'2026-05-16 09:14:24',NULL,NULL,0),(1527,1940284000182472704,1,5795489805820785861,'2026-05-16 00:00:00',1000.000000,0.000000,0.000000,0.000000,2055581626479816706,2055581641478647810,2055581641536315394,3,NULL,NULL,'2026-05-16 09:30:28',NULL,NULL,0),(1528,1940284000182472704,1,5796334453171055685,'2026-05-19 00:00:00',0.010000,0.000000,0.000000,0.000000,2056492650554593282,2056492674365657090,2056492674772508674,3,NULL,NULL,'2026-05-18 21:50:36',NULL,NULL,0),(1529,1940284000182472704,1,5796334456195613765,'2026-05-19 00:00:00',0.010000,0.000000,0.000000,0.000000,2056505047927361538,2056505062947164162,2056505062997499905,3,NULL,NULL,'2026-05-18 22:39:49',NULL,NULL,0),(1530,1940284000182472704,1,5796897599191489605,'2026-05-21 00:00:00',0.010000,0.000000,0.000000,0.000000,2057295737293639682,2057295764841828353,2057295765028868098,3,NULL,NULL,'2026-05-21 03:01:47',NULL,NULL,0),(1531,1940284000182472704,1,5796897599225338949,'2026-05-21 00:00:00',0.010000,0.000000,0.000000,0.000000,2057295871922409473,2057295903492935682,2057295903554146306,3,NULL,NULL,'2026-05-21 03:02:20',NULL,NULL,0),(1532,1940284000182472704,1,5796897609968022661,'2026-05-21 00:00:00',0.010000,0.000000,0.000000,0.000000,2057339895842480129,2057339905531322370,NULL,1,NULL,NULL,'2026-05-21 05:57:15',NULL,NULL,0),(1533,1940284000182472704,1,5796897610264748165,'2026-05-21 00:00:00',0.010000,0.000000,0.000000,0.000000,2057341082809540609,2057341120910598146,NULL,1,NULL,NULL,'2026-05-21 06:02:04',NULL,NULL,1),(1534,1940284000182472704,1,5796897610267578501,'2026-05-21 00:00:00',0.010000,0.000000,0.000000,0.000000,2057341082809540609,2057341132507848706,NULL,1,NULL,NULL,'2026-05-21 06:02:04',NULL,NULL,1),(1535,1940284000182472704,1,5796897612140061893,'2026-05-21 00:00:00',0.010000,0.000000,0.000000,0.000000,2057348772183158786,2057348802197598209,NULL,1,NULL,NULL,'2026-05-21 14:32:36',NULL,NULL,1),(1536,1940284000182472704,1,5796897612140061894,'2026-05-21 00:00:00',100.000000,0.000000,0.000000,0.000000,2057348772183158786,2057348802197598209,NULL,5,NULL,NULL,'2026-05-21 14:32:36',NULL,NULL,1),(1537,1940284000182472704,1,5796897612144019653,'2026-05-21 00:00:00',0.010000,0.000000,0.000000,0.000000,2057348772183158786,2057348818408583170,NULL,1,NULL,NULL,'2026-05-21 14:32:37',NULL,NULL,1),(1538,1940284000182472704,1,5796897612144019654,'2026-05-21 00:00:00',100.000000,0.000000,0.000000,0.000000,2057348772183158786,2057348818408583170,NULL,5,NULL,NULL,'2026-05-21 14:32:37',NULL,NULL,1);
/*!40000 ALTER TABLE `mall_pay_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_sku`
--

DROP TABLE IF EXISTS `mall_sku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_sku` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `spu_id` bigint DEFAULT NULL COMMENT 'SPU ID',
  `attrs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '销售属性值;{attr_value_id}-{attr_value_id} 多个销售属性值逗号分隔',
  `banner_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT 'banner图片;多个图片逗号分隔',
  `main_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '商品介绍主图;多个图片逗号分隔',
  `price_fee` int DEFAULT NULL COMMENT '售价，整数方式保存',
  `price_scale` int DEFAULT NULL COMMENT '售价，金额对应的小数位数',
  `market_price_fee` int DEFAULT NULL COMMENT '市场价，整数方式保存',
  `market_price_scale` int DEFAULT NULL COMMENT '市场价，金额对应的小数位数',
  `points_fee` int DEFAULT NULL COMMENT '所需积分，整数方式保存',
  `points_scale` int DEFAULT NULL COMMENT '所需积分，金额对应的小数位数',
  `sales_volume` decimal(24,6) DEFAULT NULL COMMENT '销量',
  `cost` decimal(24,6) DEFAULT NULL COMMENT '成本',
  `type_` int DEFAULT NULL COMMENT '类型',
  `type_lid` bigint DEFAULT NULL COMMENT '值',
  `type_num` decimal(24,6) DEFAULT NULL COMMENT '数量',
  `show_order` int DEFAULT NULL COMMENT '显示顺序',
  `obsolete` tinyint(1) DEFAULT '0' COMMENT '已经下架',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  KEY `idx_mid_spu_id` (`mid`,`spu_id`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='标准库存单元';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_sku`
--

LOCK TABLES `mall_sku` WRITE;
/*!40000 ALTER TABLE `mall_sku` DISABLE KEYS */;
INSERT INTO `mall_sku` VALUES (159,1940284000182472704,NULL,2055211654657216513,2055211654627856386,NULL,NULL,'',0,2,300,2,30,0,0.000000,NULL,2,NULL,NULL,NULL,0,NULL,NULL,'2026-05-15 09:00:17',NULL,'2026-05-16 09:27:12',0),(160,1940284000182472704,NULL,2055212974030065665,2055212973975539713,NULL,NULL,'',100000,2,100000,2,NULL,0,1.000000,NULL,2,NULL,NULL,NULL,0,NULL,NULL,'2026-05-15 09:05:31',NULL,'2026-05-16 09:30:25',0),(161,1940284000182472704,NULL,2055230835414929410,2055230835406540802,NULL,NULL,'',1,2,300,2,NULL,0,5.000000,NULL,2,NULL,NULL,NULL,0,NULL,NULL,'2026-05-15 10:16:30',NULL,'2026-05-21 06:02:52',0),(162,1940284000182472704,NULL,2055231086062342146,2055231086058147842,NULL,NULL,'',1,2,300,2,100,0,2.000000,NULL,2,NULL,NULL,NULL,0,NULL,NULL,'2026-05-15 10:17:29',NULL,'2026-05-21 14:32:25',0),(163,1940284000182472704,NULL,2055231901971910658,2055231901967716353,NULL,NULL,'',468505,2,500000,2,NULL,0,0.000000,NULL,2,NULL,NULL,NULL,0,NULL,NULL,'2026-05-15 10:20:44',NULL,'2026-05-16 06:24:07',0);
/*!40000 ALTER TABLE `mall_sku` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_sku_stock`
--

DROP TABLE IF EXISTS `mall_sku_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_sku_stock` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `sku_id` bigint DEFAULT NULL COMMENT 'SKU ID',
  `quantity` int DEFAULT NULL COMMENT '库存',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_sku_id` (`mid`,`sku_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='sku库存表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_sku_stock`
--

LOCK TABLES `mall_sku_stock` WRITE;
/*!40000 ALTER TABLE `mall_sku_stock` DISABLE KEYS */;
INSERT INTO `mall_sku_stock` VALUES (159,1940284000182472704,NULL,2055211654690770945,2055211654657216513,10,NULL,NULL,'2026-05-15 09:00:17',NULL,'2026-05-16 09:27:12',0),(160,1940284000182472704,NULL,2055212974034259969,2055212974030065665,9,NULL,NULL,'2026-05-15 09:05:31',NULL,'2026-05-16 09:30:25',0),(161,1940284000182472704,NULL,2055230835414929411,2055230835414929410,5,NULL,NULL,'2026-05-15 10:16:30',NULL,'2026-05-21 06:02:52',0),(162,1940284000182472704,NULL,2055231086066536450,2055231086062342146,8,NULL,NULL,'2026-05-15 10:17:29',NULL,'2026-05-21 14:32:25',0),(163,1940284000182472704,NULL,2055231901971910659,2055231901971910658,11,NULL,NULL,'2026-05-15 10:20:44',NULL,'2026-05-16 06:24:07',0);
/*!40000 ALTER TABLE `mall_sku_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_spu`
--

DROP TABLE IF EXISTS `mall_spu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_spu` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `brand_id` bigint DEFAULT NULL COMMENT '品牌ID',
  `category_id` bigint DEFAULT NULL COMMENT '分类ID',
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '名称',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '描述',
  `selling_point` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '卖点',
  `unit` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '单位',
  `banner_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT 'banner图片;多个图片逗号分隔',
  `main_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '商品介绍主图;多个图片逗号分隔',
  `show_order` int DEFAULT NULL COMMENT '显示顺序',
  `show_in_home` tinyint(1) DEFAULT NULL COMMENT '显示在首页',
  `obsolete` tinyint(1) DEFAULT '0' COMMENT '已经下架',
  `purchase_limit_per_person` int DEFAULT NULL COMMENT '每人总限购数',
  `purchase_limit_per_person_per_day` int DEFAULT NULL COMMENT '每人每天限购数',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_brand_id` (`mid`,`brand_id`) USING BTREE,
  KEY `idx_mid_category_id` (`mid`,`category_id`) USING BTREE,
  KEY `idx_mid_lid` (`mid`,`lid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=164 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='标准产品单元';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_spu`
--

LOCK TABLES `mall_spu` WRITE;
/*!40000 ALTER TABLE `mall_spu` DISABLE KEYS */;
INSERT INTO `mall_spu` VALUES (159,1940284000182472704,NULL,2055211654627856386,NULL,2055211425887293442,'雪碧',NULL,NULL,'瓶','','',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-05-15 09:00:17','admin','2026-05-15 09:01:02',0),(160,1940284000182472704,NULL,2055212973975539713,NULL,2055211425887293442,'可乐',NULL,NULL,'瓶',NULL,'',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-05-15 09:05:31',NULL,NULL,0),(161,1940284000182472704,NULL,2055230835406540802,NULL,2055211425887293442,'一分钱雪碧',NULL,NULL,'瓶',NULL,'',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-05-15 10:16:30',NULL,NULL,0),(162,1940284000182472704,NULL,2055231086058147842,NULL,2055211425887293442,'一分钱雪碧（加100积分）',NULL,NULL,'瓶','','',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-05-15 10:17:29','admin','2026-05-15 10:17:54',0),(163,1940284000182472704,NULL,2055231901967716353,NULL,2055211425887293442,'天价雪碧',NULL,NULL,'瓶','','',NULL,NULL,0,NULL,NULL,NULL,NULL,'2026-05-15 10:20:44','admin','2026-05-16 05:53:44',0);
/*!40000 ALTER TABLE `mall_spu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_spu_sku_attr_map`
--

DROP TABLE IF EXISTS `mall_spu_sku_attr_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_spu_sku_attr_map` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `spu_id` bigint DEFAULT NULL COMMENT 'SPU ID',
  `sku_id` bigint DEFAULT NULL COMMENT 'SKU ID',
  `attr_id` bigint DEFAULT NULL COMMENT '销售属性ID',
  `attr_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '销售属性名称',
  `attr_value_id` bigint DEFAULT NULL COMMENT '销售属性值ID',
  `attr_value_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '销售属性值',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`) USING BTREE,
  KEY `idx_mid_spu_id` (`mid`,`spu_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='关联关系冗余表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_spu_sku_attr_map`
--

LOCK TABLES `mall_spu_sku_attr_map` WRITE;
/*!40000 ALTER TABLE `mall_spu_sku_attr_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `mall_spu_sku_attr_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mall_user_count`
--

DROP TABLE IF EXISTS `mall_user_count`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mall_user_count` (
  `pid` bigint NOT NULL AUTO_INCREMENT COMMENT '物理编号',
  `mid` bigint DEFAULT NULL COMMENT '租户号',
  `sid` bigint DEFAULT NULL COMMENT '门店号',
  `lid` bigint NOT NULL COMMENT '逻辑编号',
  `user_id` bigint DEFAULT NULL COMMENT '用户编号',
  `new_count` int DEFAULT NULL COMMENT '待付款',
  `paid_count` int DEFAULT NULL COMMENT '待发货',
  `shipped_count` int DEFAULT NULL COMMENT '待收货',
  `delivered_count` int DEFAULT NULL COMMENT '已完成',
  `cancel_count` int DEFAULT NULL COMMENT '已取消',
  `refunded_count` int DEFAULT NULL COMMENT '已退款',
  `evaluated_count` int DEFAULT NULL COMMENT '待评价',
  `revision` int DEFAULT NULL COMMENT '乐观锁',
  `created_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '创建人',
  `created_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updated_by` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  `deleted` bigint DEFAULT NULL COMMENT '是否删除',
  PRIMARY KEY (`pid`,`lid`) USING BTREE,
  UNIQUE KEY `uk_lid` (`lid`) USING BTREE,
  KEY `idx_mid_user_id` (`mid`,`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='用户订单数';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mall_user_count`
--

LOCK TABLES `mall_user_count` WRITE;
/*!40000 ALTER TABLE `mall_user_count` DISABLE KEYS */;
INSERT INTO `mall_user_count` VALUES (206,1940284000182472704,1,2055212011017867265,2047944929193627650,9,0,4,0,36,0,0,NULL,NULL,'2026-05-15 09:01:42',NULL,'2026-05-21 14:33:19',0),(207,1940284000182472704,1,2055232399693189121,2047945239853142017,5,0,4,0,10,0,0,NULL,NULL,'2026-05-15 10:22:43',NULL,'2026-05-21 03:04:00',0);
/*!40000 ALTER TABLE `mall_user_count` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'a_mall'
--

--
-- Dumping routines for database 'a_mall'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-13 10:47:58
